<br>

# **Direction of education**
- Gain practical experience by performing practical tasks based on basic course education.
- Prioritize directly solving various problems that arise during practice and promote teamwork by sharing resolved errors.
- Textbooks are provided as a guide for overall practice, and are different in nature from the textbooks for the basic course.

<br>

<br/>


# ** Lab environment configuration **

- [**Direction of education**](#Direction of education)
- [\*\* Practice environment configuration\*\*](#-Practice environment-configuration)
- [**Final Goal**](#Final Goal)
- [**One. Configuration of practice environment**](#1-Practice environment-configuration)
   - [**1-1. Install WSL2 and Ubuntu**](#1-1-wsl2-and-ubuntu-install)
     - [**1-1-1. Install WSL and Download Ubuntu**](#1-1-1-wsl-install-and-ubuntu-download)
     - [**1-1-2. system-restart-and-install-ubuntu-distribution**](#1-1-2-system-restart-and-ubuntu-distribution-install)
     - [**1-1-3. Check Ubuntu version and enable systemd**](#1-1-3-ubuntu-version-check-and-systemd-enable)
       - [🐳 **(Reference) What to do in case of WSL installation error**](#-Reference--WSL-installation-error-what-to-do-method)
       - [🐳 **(Note) WSL manual installation**](#-Note-wsl-manual-installation)
       - [🐳 **(Note) Manually create MobaXTerm WSL Ubuntu session**](#-Note-mobaxterm-wsl-ubuntu-session-manually-create)
     - [**1-1-4. Used without entering a password when performing a sudo command**](#1-1-4-sudo-command-used without entering a password)
   - [**1-2. Configure existing AS-IS sources and install required programs**](#1-2-Configure existing-as-is-sources and install required programs)
     - [**1-2-1. OpenJDK, Node.js, NPM installation**](#1-2-1-openjdk-nodejsnpm installation)
     - [**1-2-2. Saving git settings and eshop-legacy-mentee source to private Github**](#1-2-2-git-setting-and-saving-eshop-legacy-mentee-source to private-github)
     - [**1-2-3. Visual Studio Code remote development environment settings**](#1-2-3-visual-studio-code-remote-development environment-settings)
     - [**1-2-4. Docker \& Docker-compose installation**](#1-2-4-docker--docker-compose installation)
     - [**1-2-5. install minikube, kubectl**](#1-2-5-minikube-kubectl-install)
   - [**1-3. AWS domain utilization**](#1-3-aws-domain-utilization)
   - [**1-4. Create AWS Certificate**](#1-4-aws-certificate-create)
   - [**💡Troubleshooting💡**](#troubleshooting)

---
<br/>



# **Final Goal**
- Configuring eshop Legacy local development environment

<br><br>

---

# **One. Practice environment configuration**
<br/><br/>

> ![](images/1-0/image1.png)
>
> Let’s configure Legacy’s development environment and configure the development environment on the local PC.
>
> Configure a remote development environment in the Linux (Ubuntu) environment using WSL2 (Linux subsystem for Windows)

<br/>

---
<br>

## **1-1. Install WSL2 and Ubuntu**

---
<br>

> **Prerequisite**

- Windows 10 version 2004 or later (Build 19041 or later) or Windows 11 version
- Home PC or higher specifications recommended
<br>

> ℹ️ Note
> To check the Windows version and build number, enter `Windows logo key + R(r)`, then enter `winver` and select OK.
You can update to the latest Windows version by selecting > `Start` (🪟) > `Settings` (⚙️) > `Windows Update` > `Check for updates`.
>
> ![](images/1-0/w1-d1-windows version.png)

> If you have Windows 10 version 2004 or lower (build 19041 or lower), update to the latest Windows and then proceed with installation.
If Windows update is not possible, refer to [WSL manual installation] (#-reference-wsl-manual-installation).

<br>

### **1-1-1. Install WSL and download Ubuntu**

&emsp;(1) On the Control Panel - Turn Windows features on/off screen, ① Windows subsystem for Linux, ② Activate virtual machine platform.
&emsp;&emsp; After setting and confirming, boot if a boot request message appears for application.
  > **📌 If 'Virtual Machine Platform' does not appear in the feature list, you need to enable SVM in your PC's BIOS. For setup instructions, search on Google and refer to it.**
> > ![](images/1-0/w1-wsl-vm-setting.png)

<br>

&emsp;(2) Search for linux in the Microsoft Store and install the two items below.
> > ① Search for ‘linux’ and select Windows Subsystem for Linux and ubuntu 20.04 LTS, then download and install.
> > ![](images/1-0/wsl-ms-linux.png)
<br>
 
> > ② Select Windows Subsystem for Linux and download and install or update.
> **📌If the update button appears in the above process, be sure to update. (In some cases, it may take more than 5 minutes)**
> > ![](images/1-0/wsl-ms-install-2.png)
<br>

> > ③ Select ubuntu 20.04 LTS, download and run (install)
> > ![](images/1-0/wsl-ms-ubuntu-1.png)

<br>
<details>
<summary>Refer to [Expand👇]. How to install with command in PowerShell</summary>
If you run PowerShell as 'administrator' and run the command below, the features required for WSL will be installed and the Ubuntu distribution will be downloaded.<br>

``` wsl --install -d Ubuntu-20.04 ```

> ℹ️ Note - How to run PowerShell as ‘Administrator’ <br>
> `Start` (🪟) > Enter `powershell` > Select `Run as administrator` in the searched PowerShell.

(Example of results)
```
PS C:\WINDOWS\system32> wsl --install -d Ubuntu-20.04
Installing: Virtual Machine Platform
The virtual machine platform is installed.
Installing: Windows Subsystem for Linux
Windows Subsystem for Linux is installed.
Downloading: WSL kernel
Installing: WSL kernel
The WSL kernel is installed.
Downloading: GUI app support
Installing: GUI app support
GUI app support is installed.
Downloading: Ubuntu 20.04 LTS
The requested operation was executed successfully. Restart your system for the changes to take effect.
PS C:\WINDOWS\system32>
```

If an error occurs while downloading Ubuntu, restart the system and the download will automatically resume.
</details>

<br>

### **1-1-2. Restart your system and install your Ubuntu distribution**
> Restart the system according to the guide. Once the restart is complete, the Ubuntu distribution is automatically installed. <br/>
> Or select Ubuntu 20.04 LTS from the Windows Start menu. <br/>
> Create a user account and set a password in the Ubuntu terminal that is first launched. <br/>
> For convenience of practice, set the username to `ubuntu` and record the password so as not to lose it.
> > username: ubuntu
> > password: Enter personal password (ex: ubuntu) <br/> <br/>
> > ![](images/1-0/wsl-install-2.png) <br/><br/>
> > Screen after completion <br/>
> > ![](images/1-0/wsl-install-3.png)
>
> **📌 If an installation error occurs, refer to Troubleshooting at the end of the textbook**

> **📌 [Check points after installing WSL]**
> > Run PowerShell (or cmd) as administrator and check whether the wsl version is **2** with the command ``` wsl -l -v ```.
> > If it is not 2, you need to run ``` wsl --set-version Ubuntu-20.04 2 ``` to change to version 2.
> >
> > ![](images/1-0/wsl-version2-1.png)
>
<br>

> **📌 [Notes during practice on day 1]**
>
> ➕ *id* : **ubuntu**
> ➕ *pw* : << PW to be used by the individual >> After designating it, record it so as not to lose it.
> ➕ *<< YOUR_DOMAIN >>* :

<br>

&nbsp; Afterwards, you can access Ubuntu using Windows Terminal or **MobaXterm** (recommended!! Easy to paste script with cut & paste).
<br/>

&nbsp; &nbsp; ※ ssh input method tip: In the CLI interface, copy uses the Ctrl + Insert keys, and paste uses the Shift + Insert keys.
<br><br>

### **1-1-3. Check Ubuntu version and enable systemd**
<br>
&nbsp; (1) Check Ubuntu version
> Execute the command below in Terminal to confirm that the Ubuntu version is `20.04 LTS`.
> ```bash
> lsb_release -a
> ```
> (Example result)
> ```bash
> ubuntu@DESKTOP-R9KK4PJ:~$ lsb_release -a
> No LSB modules are available.
> Distributor ID: Ubuntu
> Description: Ubuntu 20.04 LTS
> Release: 20.04
> Codename: focal
> ```
<br/>

&nbsp;(2) Latest updates to Windows Subsystem for Linux
> Update to the latest version of Windows Subsystem for Linux from the Microsoft Store as shown in 1-2 above.
> **📌If the update button appears in the above process, be sure to update. (In some cases, it takes more than 5 minutes)**

> > ![](images/1-0/wsl-ms-update.png)
<br/>

> > Or, run PowerShell (or cmd) as administrator as shown below and then run 'wsl --update'.
> > ![](images/1-0/wsl-update.png)
> <br/>

&nbsp;(3) Activate systemd
> **📌 If '[boot] systemd=true' is included in the /etc/wsl.conf file, skip it.**
>
> ① Run ‘sudo vi /etc/wsl.conf’ in WSL (Ubuntu) and save the contents below.
> << WSL >>
> ```bash
> sudo vi /etc/wsl.conf
> ```

> ```bash
> [boot]
>systemd=true
> ```
<br/>

> ② In PowerShell (or cmd) administrator mode, run ‘wsl --shutdown’ and then rerun wsl.
> << Powershell or cmd >>
>``` powershell
>wsl --shutdown
>```
> ![](images/1-0/wsl-shutdown.png)



#### 🐳 **(Reference) What to do in case of WSL installation error**
> If an error occurs while installing WSL or Ubuntu, refer to the ‘Linux distribution and how to delete WSL’ guide below, delete the related apps and functions, and then try again.
<details>
<summary>[Expand👇] How to distribute Linux and delete WSL</summary>

**One. Delete your Ubuntu distribution**
- Select ‘Start’ (🪟) > ‘Settings’ (⚙️) > ‘Apps’ > ‘Apps and features’.
- Enter ‘ubuntu’ in ‘App Search’ in ‘App List’.
- When Ubuntu is searched, select Uninstall from the Ubuntu menu (`⋮`) to delete the Ubuntu distribution.
- If ubuntu is not searched, proceed to the next step.

![](images/1-0/w1-d1-app-function.png) ![](images/1-0/w1-d1-ubuntudelete.png)

**2. Delete WSL-related apps**
- Enter `linux` in `App Search` of `App List`.
- Select Uninstall from the menu ( `⋮` ) of `Windows Subsystem for Linux Update` to delete WSL update. (In Windows 10, when you click an item, you will see a Remove button, and click it to delete it.)
- (Windows 11 only) Select Uninstall from the menu (`⋮`) of `Windows Subsystem for Linux WSLg Preview` to delete the WSL preview.
- If a pop-up appears requesting a system restart, select `No` and click `3. Restart in the process of deleting wsl-related functions.
- If no Linux-related items are found, proceed to the next step.

![](images/1-0/w1-d1-wsldelete.png)

**3. Delete wsl related functions**

- Go to ‘Start’ (🪟) > Enter ‘Windows Features’ > Run the searched ‘Turn Windows Features On/Off’.
- In the Turn Windows features on/off window, uncheck ‘Windows Subsystem for Linux’ and ‘Virtual Machine Platform’ and then click Select.
- Restart the system according to the guide.

![](images/1-0/w1-d1-wsldelete-wsl.png) ![](images/1-0/w1-d1-wsldelete-virtual machine.png)

This completes the deletion of Linux distribution and WSL, and you can proceed with the installation again.

If the problem persists even after deletion and installation, refer to [Troubleshooting Windows Subsystem for Linux](https://learn.microsoft.com/ko-kr/windows/wsl/troubleshooting).
</details>

<br>

#### 🐳 **(Note) Manual installation of WSL**
> If you have Windows 10 version 2004 or lower (build 19041 or lower) or want to install manually, you can install WSL and Ubuntu distributions by following the steps below.

<details>
<summary>[Expand👇] How to install WSL manually</summary>

> **Prerequisite**
- For Windows 10 x64 systems: Version 1903 or higher, Build 18362 or higher, or
- For Windows 10 ARM64 systems: Version 2004 or higher, Build 19041 or higher, or
-Windows 11

> If your Windows version and build do not meet the prerequisites, first update to the latest Windows version.

<br>

> **1. Activate WSL and virtual machine features**

> Run PowerShell with `administrator privileges` and then run the commands below to activate WSL and virtual machine functions.
```
dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart
```

```
dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart
```

> **2. Install Linux kernel update package**

> Download [the latest WSL2 Linux kernel update package for x64 machines](https://wslstorestorage.blob.core.windows.net/wslblob/wsl_update_x64.msi), run it, and install it according to the guide.

> ![](images/1-0/image2.tmp)

> ℹ️Note
> If you are using an ARM64 machine, install [WSL2 Linux kernel package for ARM64 machines](https://wslstorestorage.blob.core.windows.net/wslblob/wsl_update_arm64.msi).
> To determine the type of machine you are using, check the information in ‘System Type’ among the contents displayed after executing the ‘systeminfo’ command in PowerShell.

> **3. Set WSL 2 as default version**

> Run the command below in PowerShell to set WSL 2 as the default version when installing a new Linux distribution.
```
wsl --set-default-version 2
```

> **4. Install Ubuntu 20.04 distribution**

After running ‘Start’ (🪟) > Microsoft Store, enter ‘ubuntu 20’ in the search box to install the searched ‘Ubuntu 20.04.5 LTS’.

> ![](images/1-0/w1-d1-ubuntu installation.png)

> Set up a user account in the Ubuntu terminal. (For convenience of practice, set the username to `ubuntu`.)
</details>

<br>

#### 🐳 **(Reference) Manually creating a MobaXTerm WSL Ubuntu session**
> When the WSL Ubuntu distribution is installed, a WSL-Ubuntu session is automatically created in MobaXTerm.
If the WSL-Ubuntu session is not created automatically, you can create it manually by following the guide below.

<details>
<summary>[Expand👇] How to manually create a MobaXTerm WSL Ubuntu session</summary>

![](images/1-0/w1-d1-xterm-wsl.png)

</details>

<br>

### **1-1-4. Use without entering password when using sudo command**
<< WSL environment >>
```bash
sudo visudo
```
When the file opens, add the following content to the bottom and save.
```bash
ubuntu ALL=NOPASSWD: ALL
```
> If the username set in Ubuntu is not ubuntu, enter the username set in place of ubuntu.

<br/><br/>

---
## **1-2. Configure existing AS-IS sources and install required programs**

---

<br/>

&nbsp; Connect to WSL's Ubuntu and proceed with various settings and installation to configure the source.
<br/><br/>

### **1-2-1. Install OpenJDK, Node.js, NPM**

> Execute the commands below in order. Please note that depending on the command, inputting 'y' may be required.
```bash
sudo apt update
sudo apt upgrade
sudo apt install openjdk-11-jdk
sudo apt install build-essential

curl -k -sL https://deb.nodesource.com/setup_16.x | sudo -E bash -
sudo apt install nodejs
# After installing node.js and npm, check the version information with the command below.
node -v
npm -v
# If the version cannot be confirmed because npm is not installed, proceed with installation using the command below. An apt dependency error may occur after installation, but if the npm -v version output is normal, it can be ignored.
sudo apt install npm
npm -v

```
<br/>

<details>
<summary>[Expand👇] Check Java, NodeJS, and NPM versions </summary>
You can check the Java, NodeJS, and NPM versions through the commands below. (The versions may be different, but only the major version needs to match.)

```bash
java --version
node -v
npm -v
```

> ![](images/1-0/result/java_node_npm_v_result.png)

</details>

<br />

> Create a .npmrc file in the user $HOME directory with the following contents.
```bash
vi ~/.npmrc
```

```bash
strict-ssl=false
rejectUnauthorized=false
registry=https://registry.npmjs.org/
```
<br/>


### **1-2-2. Save git settings and eshop-legacy-mentee source to your personal Github**

> 🚩 Create a private repository (name: eshop-legacy-mentee) directly in your personal git on the github site, download the source provided through s3 to your own wsl, unzip it, and link it to your private git.
<br/>

&nbsp; **1) Create eshop-legacy-mentee repository on personal Github and generate token**
<br>

&nbsp;&nbsp;&nbsp; Create the eshop-legacy-mentee repository on your personal github and check the status as follows.
&nbsp;&nbsp;&nbsp; ![](images/1-0/repo-legacy.png)
  <br><br>

&nbsp;&nbsp; 🚩 **If you do not have a personal git token, create a new token on Github and store it carefully. If lost or leaked, a new one must be created.**
&nbsp;&nbsp;&nbsp; ![](images/1-0/git-token.png)
  <br><br>

&nbsp; **2) git settings**

   ```bash
   git config --global user.name “username”
   git config --global user.email “User email”
   git config --global credential.helper store
   ```
<br>

<details>
<summary>[Expand👇] Check git settings </summary>
You can check the git settings using the command below. (Check in the root folder using the cd command.)

   ```bash
    CD
    git config list
   ```

> ![](images/1-0/result/git_config_result.png)

</details>
<br/><br>


&nbsp; **3) How to download the source from S3 and link it to your personal Git**

   ```bash
   cd ~
   sudo apt-get install awscli -y

   # The access key ID and secret access key are keys issued from the AWS console (📂Operating area practice textbook: 1-2-Settings.md)
   # You can skip inputting the default region and default output format items by pressing enter.
   # Check the previously used value and enter it, or obtain it again and enter it.
   configure aws

   git clone https://github.com/<<github_username>>/eshop-legacy-mentee.git

   aws s3 cp s3://t2hubintern/eshop-legacy-mentee.tar.gz .
   tar -zxvf eshop-legacy-mentee.tar.gz
   cd ~/eshop-legacy-mentee
   git status
   git add .
   git commit -m "init legacy mentee"
   git branch -m master main
   git push origin main
   ```

<details>
<summary>[Expand👇] Check AWS Cli installation </summary>
You can check the AWS Cli version through the command below.

```bash
aws --version
```

> ![](images/1-0/result/aws_version_result.png)

</details>

<br/>

### **1-2-3. Setting up a Visual Studio Code remote development environment**
<br>

▶ **Install Visual Studio Code**
<br>

> Select the Windows version from [Download page](https://code.visualstudio.com/download) and download Visual Studio Code.

> ![](images/1-0/image5.tmp)
<br/>

> Run the downloaded installer to install Visual Studio Code.

> ![](images/1-0/image6.tmp)
<br>

▶ **Install WSL extension**

> Click the ‘Extension’ menu on the left, then search for **wsl and install**. Using this plugin, you can access files and folders in the WSL environment from the Windows vscode environment. When installing a plug-in like this, it is a good idea to check whether it is a trustworthy supplier (the WSL plug-in is provided by Microsoft) or whether many people have used it (check the number of downloads).

> ![](images/1-0/image7.png)

> After installation, press F1 > Search for "WSL" or "connect" and select **"Connect to WSL using Distro..."**. After a while, **"Ubuntu 20.04"** appears, make the final selection.

> ![](images/1-0/image8.tmp)

> In the WSL2 Ubuntu distribution environment, a new remote development window will be launched, and if you click "Open Folder..." in the center of the screen and select "/home/ubuntu/", you can access WSL.

> ![](images/1-0/image9.png)
<br>

▶ **For the convenience of java (springboot) development, we recommend installing the Extension pack for java.** You can install the java extension by searching for java in the 'Extension' menu on the left. You must install it while connected to WSL to check **'Extension is enabled on WSL:Ubuntu-20.04'**.

> ![](images/1-0/java-extension.png)
<br><br>

<details>
<summary>[Expand👇] Reference - Using ssh in VSCode</summary>

> To set up ssh connection in wsl, select vscode plugin and enter ssh to install remote ssh.

   ![](images/1-0/image10.png)

> After installing the ssh plugin, press F1 and select “open ssh configuration” as follows.
   ![](images/1-0/image11.png)

   After selection, select "C:/Users/Personal PC name/.ssh/config" from the list and access the remote server by referring to the instructions below.
   In the case of the admin server, this is the setting for accessing using bastion as a jump host.
 
``` bash
Host bastion
     HostName bastion_public_ip
     Port 22
     User ubuntu
     IdentityFile C:\Users\SDS\Downloads\MyKeyPair.pem

Host admin
     HostName admin_private_ip
     Port 22
     User ubuntu
     IdentityFile C:\Users\SDS\Downloads\MyKeyPair.pem
     ProxyJump bastion
```
</details>

<br/>

### **1-2-4. Install Docker & Docker-compose**

> Install docker and docker compose using commands directly from the WSL console.
>
> (You can search for ‘install docker engine on ubuntu’ on Google, find the official site script, copy it, and install it.)

🧲 (COPY)
```bash
for pkg in docker.io docker-doc docker-compose podman-docker containerd runc; do sudo apt-get remove $pkg; done

sudo apt-get update
sudo apt-get install ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo \
   "deb [arch="$(dpkg --print-architecture)" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
   "$(. /etc/os-release && echo "$VERSION_CODENAME")" stable" | \
   sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

#Grant permission to perform Docker commands
sudo usermod -aG docker $USER && newgrp docker

#Check Docker engine version
docker --version

#Check Docker compose version
docker compose version
```

<details>
<summary>[Expand👇] Check docker, docker compose version </summary>
You can check the docker and docker compose versions and installation status using the command below.

```bash
docker --version
docker compose version
```

> ![](images/1-0/result/docker_docker_compose_result.png)

</details>

<br/>


```shell
# Check if the Docker daemon is running
sudo systemctl status docker
```
If the message `Active: inactive(dead)` or `* Docker is not running` appears in the output, start the Docker daemon with the command below.

```shell
sudo systemctl start docker
# ok if active (running)
```

<details>
<summary>[Expand👇] docker ps example </summary>

```bash
docker ps
```
> ![](images/1-0/result/docker_ps_result.png)
</details>
<br>

<details>
<summary>[Expand👇] How to stop docker </summary>

```shell
sudo systemctl stop docker.socket
```

</details>
<br/><br/>


### **1-2-5. Install minikube, kubectl**


Install minikube using a direct command in the WSL console. ([minikube start |
minikube (k8s.io)](https://minikube.sigs.k8s.io/docs/start/) and [kubeadm
Install |
Kubernetes](https://kubernetes.io/ko/docs/setup/production-environment/tools/kubeadm/install-kubeadm/)
reference)

🧲 (COPY)
```bash
# install minikube
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
sudo install minikube-linux-amd64 /usr/local/bin/minikube

# install kubectl
sudo apt-get update
sudo apt-get install -y apt-transport-https ca-certificates curl

sudo curl -fsSL https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-archive-keyring.gpg

echo "deb [signed-by=/etc/apt/keyrings/kubernetes-archive-keyring.gpg] https://apt.kubernetes.io/kubernetes-xenial main" | sudo tee /etc/apt/sources.list.d/kubernetes.list

sudo apt-get update
sudo apt-get install -y kubelet kubeadm kubectl
sudo apt-mark hold kubelet kubeadm kubectl

# Run minikube and check its status
minikube start
minikube status
```
 
<br/>

<details>
<summary>[Expand👇] Check kubectl and minikube versions </summary>

You can check the kubectl and minikube versions and whether they are installed using the command below.

```bash
kubectl version
minikube version
```

> ![](images/1-0/result/minikube_version_result.png)

</details>

<br/>

<details>
<summary>[Expand👇] Check minikube status </summary>

You can check the minikube status using the command below.

```bash
minikube status
```

minikube is stopped
> ![](images/1-0/result/minikube_status_stop_result.png)


You can run minikube with the command below.
```bash
minikube start
```

minikube start log example
> ![](images/1-0/result/minikube_start_result.png)

minikube is running
> ![](images/1-0/result/minikube_status_start_result.png)

</details>

<br/>

## **1-3. Take advantage of AWS domains**
> The domain created in the T3 basic course will be used in subsequent exercises, so refer to Route53 in the AWS Management Console that you have already created.

 
<br/>

## **1-4. Create AWS Certificate**
  >**N. Certificate creation is required in Virginia** region (**us-east-1**) and **Oregon** region (**us-west-2**). If it is not created, create it.
 
  </br>
 
  > ### Creating a certificate

> In this process, the CM (Certificate Manager) service provided by AWS is used to securely connect (TLS communication) to the eshop service.
>
> (📂Operation area practice textbook: 1-3-Route53.md)
>
> A certificate has already been created in the N. Virginia (us-east-1) region, and an additional certificate is created in the Oregon (us-west-2) region.
>
1. Go to the AWS Certificate Manager service.
- Confirm that Region is Oregon (us-west-2)

![](images/1-0/image18.png)

2. Select the Request certificate menu and click the Next button.

- If the left menu is collapsed, click the **≡** icon at the top left.

![](images/1-0/image19.tmp)

![](images/1-0/image20.png)

3. Enter the __wild card certificate (\*\)__ request including your domain created in Route53. Finally, click the Request button.

(ex) *.msp-pjt.click

> |Item|Content|
> |---|---|
> |➕ Fully qualified domain name | *.<< YOUR_DOMAIN >>.click|

<br/>

4. Go to the List certificates menu on the left and check the list of created certificates. Then click on the created Certificate ID value.

    - The Certificate ID value created for each person is different.

<br/>

<details>
<summary>[Expand👇] If there is no certificate in us-east-1, proceed below</summary>

1) Check the ARN value of the generated certificate and click the Create records in Route53 button at the bottom.

    - This is the process of adding the created certificate information to Route53’s CNAME record.

    - The ARN value of the certificate will be used when distributing applications in the future.

<br/>

2) Check if your domain created in Route53 is correct and click the Create records button.

    - This is the process of connecting the created certificate to your domain in Route53.

</details>

<br/>

5. Confirm that the certificate information has been successfully added to your domain through the green label/text at the top (Successfully created DNS records).

    - 🐳 (Note) If you check your domain in the Route53 menu, you may see that one CNAME type record has been added.

    ![](images/1-0/successfully-created-dns-records.png)

<br/>

6. Go to the List certificates menu on the left and check whether the status value of the created certificate is Issued.

    - It may take **approximately 5 minutes** to change from Pending validation to Issued status.
   


<br/>


## **💡Troubleshooting💡** ##

<br/>
[ 🐳 Note 👉 <a href="./1w-troubleshooting.md">1w-troubleshooting.md</a>]
<br/>
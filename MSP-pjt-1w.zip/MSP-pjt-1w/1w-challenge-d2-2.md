## 도전과제 2
    Legacy 소스(eshop-backend)의 Product와 Category의 N:N관계를 JPA 구현 해보자.
- Class Diagram  
![](images/1-ch/product-category-class.png)

<br>

- Database  
![](images/1-ch/product-category-erd.png)
<br>


### eshop-legacy-mentee/eshop-backend 수정을 위해 branch 생성
```shell
cd ~/eshop-legacy-mentee/

git branch feature-c1

git checkout feature-c1

git status
```

### 관련 Class 생성
    Category
    CategoryController
    CategoryService
    CategoryRepository 
    ProductCategory
    ProductCateoryRepositoy
<br>

### Category Class 생성
    @OneToMany를 이용하여 category:product_category = 1: N 관계가 되도록 작성한다.

**eshop-backend/src/main/java/com/samsungsds/eshop/product/Category.java** 

```java
package com.samsungsds.eshop.product;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Category {
    @Id
    private String category;
    @Column(nullable = false)
    private String name;

    @OneToMany(mappedBy = "category")
    @JsonBackReference
    private Set<ProductCategory> productCategories;

    public String getCategory() {
        return this.category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<ProductCategory> getProductCategories() {
        return productCategories;
    }

    public void setProductCategories(Set<ProductCategory> productCategories) {
        this.productCategories = productCategories;
    }

    @Override
    public String toString() {
        return "{" +
                " id='" + getCategory() + "'" +
                ", name='" + getName() + "'" +
                ", products='" + getProductCategories() + "'" +
                "}";
    }

}

```
<br>

### ProductCategory Class 생성
    @ManyToOne을 이용하여 product_category:product = N:1, product_category:category = N:1 관계가 되도록 작성한다.

**eshop-backend/src/main/java/com/samsungsds/eshop/product/ProductCategory.java** 

```java
package com.samsungsds.eshop.product;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class ProductCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;


    @ManyToOne
    @JoinColumn(name = "product_id", insertable=false, updatable=false)
    Product product;

    @ManyToOne
    @JoinColumn(name = "category", insertable=false, updatable=false)
    Category category;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "ProductCategory [id=" + id + ", product=" + product + ", category=" + category + "]";
    }

}

```
<br>

### CategoryRepository를 Class 생성
    CrudRepository를 상속하여 Repository를 작성한다.

**eshop-backend/src/main/java/com/samsungsds/eshop/product/CategoryRepository.java** 

```java
package com.samsungsds.eshop.product;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoryRepository extends CrudRepository<Category, String> {

}
```
<br>

### CategoryService를 Class 생성
    전체 category별 product 조회, category별 product 조회할 수 있도록 CategoryService를 작성한다.

**eshop-backend/src/main/java/com/samsungsds/eshop/product/CategoryService.java** 

```java
package com.samsungsds.eshop.product;

import java.util.Set;

import org.springframework.stereotype.Service;

@Service
public class CategoryService {
	private final CategoryRepository categoryRepository;

	public CategoryService(CategoryRepository categoryRepository) {
		this.categoryRepository = categoryRepository;
	}

	public Iterable<Category> fetchAll() {
		return categoryRepository.findAll();
	}

	public Set<ProductCategory> fetchProductsById(final String id) {
		return categoryRepository.findById(id).get().getProductCategories();
	}

}
```
<br>

### CategoryController를 Class 생성
    전체 category별 product 조회, category별 product  조회할 수 있도록 CategoryController를를 작성한다.

**eshop-backend/src/main/java/com/samsungsds/eshop/product/CategoryController.java** 

```java
package com.samsungsds.eshop.product;

import java.util.Set;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/categories")
public class CategoryController {

	private final CategoryService categoryService;

	public CategoryController(CategoryService categoryService) {
		this.categoryService = categoryService;
	}

	@GetMapping(value = "")
	public ResponseEntity<Iterable<Category>> fetchAllCategories() {
		return ResponseEntity.ok(categoryService.fetchAll());
	}

	@GetMapping(value = "/{id}")
	public ResponseEntity<Set<ProductCategory>> fetchProductsById(@PathVariable("id") String id) {
		return ResponseEntity.ok(categoryService.fetchProductsById(id));
	}
}
```
<br>

### Product Class 수정
    @OneToMany를 이용하여 product:product_category = 1: N 관계가 되도록 작성한다.

**eshop-backend/src/main/java/com/samsungsds/eshop/product/Product.java** 

```java
package com.samsungsds.eshop.product;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.samsungsds.eshop.payment.Money;

@Entity
public class Product {
    @Id
    @Column(nullable = false)
    private String id;
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private String description;
    @Column(nullable = false)
    private String picture;
    @Column(nullable = false)
    private Money priceUsd;
    @OneToMany(mappedBy = "product")
    @JsonBackReference
    private Set<ProductCategory> categories;

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPicture() {
        return this.picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public Money getPriceUsd() {
        return this.priceUsd;
    }

    public void setPriceUsd(Money priceUsd) {
        this.priceUsd = priceUsd;
    }

    public Set<ProductCategory> getCategories() {
        return this.categories;
    }

    public void setCategories(Set<ProductCategory> categories) {
        this.categories = categories;
    }

    @Override
    public String toString() {
        return "{" +
                " id='" + getId() + "'" +
                ", name='" + getName() + "'" +
                ", description='" + getDescription() + "'" +
                ", picture='" + getPicture() + "'" +
                ", priceUsd='" + getPriceUsd() + "'" +
                ", categories='" + getCategories() + "'" +
                "}";
    }

}

```
<br>


### category 정보 추가
    category Table에 카테고리 정보 Insert 

**eshop-backend/src/main/resources/import.sql**

```sql
INSERT INTO category(category, name) VALUES ('vintage','vintage');
INSERT INTO category(category, name) VALUES ('photography','photography');
INSERT INTO category(category, name) VALUES ('cookware','cookware');
INSERT INTO category(category, name) VALUES ('gardening','gardening');
INSERT INTO category(category, name) VALUES ('music','music');
INSERT INTO category(category, name) VALUES ('cycling','cycling');
```
> 아래 그림처럼 위 Insert문을 import.sql(파일경로:eshop-backend/src/main/resources/import.sql) 에 추가
 
>![](images/1-ch/insert-sql.png)
<br>

### eshop-legacy-mentee/eshop-backend를 실행한다.
> postgresql과 redis가 실행 되었는지 확인한다. 안되어 있으면 먼저 실행한다.<br>
```shell
cd ~/eshop-legacy-mentee/
docker compose up -d 
```


> eshop-backend 실행<br>
```shell
cd ~/eshop-legacy-mentee/eshop-backend<br>
./gradlew bootRun<br>
```
### 브라우저로 확인한다.
1. localhost:8090/api/products
>   ![](images/1-ch/req-products.png)
   
<br>

2. localhost:8090/api/categories
>   ![](images/1-ch/req-category-all.png)

   <br>

3. localhost:8090/api/categories/vintage
>   ![](images/1-ch/req-category-vintage.png)

   <br>

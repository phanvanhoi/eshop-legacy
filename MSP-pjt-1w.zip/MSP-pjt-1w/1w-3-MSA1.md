# **3. Micro Service Separation (1)**

- [**3. Micro Service Separation (1)**](#3-micro-service-separation-1)
   - [**Final Goal**](#Final Goal)
- [**3-1. Shopping Cart Service Separation**](#3-1-Shopping Cart-Service-Separation)
   - [Intro](#intro)
     - [Looking at the existing shopping cart implementation](#Existing-Shopping Cart-Implementation-Looking at)
     - [Technology structure selection](#technology-structure-selection)
   - [Build](#build)
     - [Create shopping cart service] (#Create shopping cart-service)
     - [Setting up shopping cart service k8s distribution](#Shopping cart-service-k8s-distribution-setting)
     - [Remove Shopping Cart Service Code from Backend](#Remove Shopping Cart-Service-Code-From Backend)
   - [Measure](#measure)
   - [Try deploying to AWS EC2](#Try deploying to aws-ec2)
       - [Basic structure for docker compose](#docker-compose-for-basic-structure)
     - [Verify functionality after creating a container on AWS EC2] (#Verify functionality after creating a container on AWS EC2)
- [**3-2. Product-Service Separation**](#3-2-Product-Service-Separation)
   - [Intro](#intro-1)
     - [Looking at existing product implementation](#Existing-product-implementation-Looking at)
     - [Technology structure selection](#technology-structure-selection-1)
   - [Build](#build-1)
     - [Configuring mongoDB](#mongodb-config)
     - [Create product service](#Product-Service-Create)
     - [Product Service k8s Distribution Settings](#Product-Service-k8s-Distribution-Settings)
     - [Modify to use product-service in eshop-backend](#Edit to use product-service in eshop-backend)
   - [Measure](#measure-1)
   - [Try deploying to AWS EC2](#Try deploying to AWS EC2-1)
     - [Functionality verification after container creation in AWS EC2](#aws-ec2-after-container-creation-function-verification-1)
- [**3-3. Recommendation Service Separation**](#3-3-Recommendation-Service-Separation)
   - [Intro](#intro-2)
     - [Look at the existing recommended implementation](#Existing-Recommended-Implementation-Look)
     - [Technology structure selection](#technology-structure-selection-2)
   - [Build](#build-2)
     - [Preparing Python development (in case of WSL environment)] (#python-development-preparation-in case of wsl environment)
     - [Create a recommended service](#Recommended-Service-Create)
     - [Setting up recommended service k8s distribution](#Recommended-service-k8s-distribution-setting)
       - [Installing gunicorn](#gunicorn-installing)
       - [Create Dockerfile](#dockerfile-create)
       - [Set skaffold](#skaffold-Setting)
     - [Remove existing recommendation-related code from eshop-backend](#Remove existing-recommendation-related-code from eshop-backend)
   - [Measure](#measure-2)
   - [Try deploying to AWS EC2](#Try deploying to AWS EC2-2)
     - [Functionality verification after creating a container on AWS EC2](#aws-ec2-after-container-creation-function-verification-2)
   - [**💡Troubleshooting💡**](#troubleshooting)


<br/><br/>

---

## **Final Goal**

- Perform MicroService separation in the local environment - Shopping cart service, product service, recommendation service
---
<br/><br/>


# **3-1. Separate shopping cart service**

![](images/1-3/image101.png)
![](images/1-3/EC2-2-1.png)

<br/>

## Intro

### Take a look at existing shopping cart implementations

> The existing shopping cart implementation is located in the cart package of eshop-backend.

![](images/1-3/image15.tmp)

> CartController is a typical RestController that processes REST API and does not process logic directly but delegates it to CartService.

> CartService processes shopping cart business logic and uses CartItemRepository to retrieve/save data.

> CartItemRepository is a JPA CrudRepository implementation and is declared to handle basic CRUD of CartItem.

> CartItem is a Value Object with a Key/Value structure to interact with Redis. You can see that the shopping cart function does not use PostgreSQL.

> The RedisConfig class in the config package is a configuration class for Backend to communicate with Redis. Aside from the shopping cart function, other parts of the backend do not use Redis.

> You can see that OrderController uses CartService and CartItem classes. This part must be converted to an API call when dividing the service.

<br/>

### Technical structure selection
| **Design Decisions** | **Rationale** | **Retired alternative**         |
|-----------|------------------------------|---------------------------|
| Select Redis as data storage | • The existing shopping cart service implementation uses Redis and is not related to other tasks, so it can be separated as is | N/A |
| Java was selected as the development language and Spring Boot was selected as the development framework | • Since the shopping cart task does not have an implementation related to other task packages, using Spring Boot allows the existing implementation to be separated and reused. | • Development language Node.js / Development framework Express <br/> o Faster service startup/shutdown <br/> o Smaller image size compared to Spring Boot<br/>o Less memory usage compared to Spring Boot <br/>  Easy to use framework<br/>o JPA used in existing implementation cannot be used and interaction with Redis must be implemented directly, so it is discarded|



<br/>

## Build

### Creating a shopping cart service

Create an eshop-cartservice directory in the project root directory.

![](images/1-3/image16.png)

Copy the following files from eshop-backend to the eshop-cartservice directory.

- gradle directory (including sub-wrapper)

- .gitignore

-build.gradle

- gradlew

- gradlew.bat

- settings.gradle

![](images/1-3/image17.tmp) ![](images/1-3/image18.tmp)

<br/>

> Modify the settings.gradle file of eshop-cartservice with the following content.

**eshop-cartservice/settings.gradle**

```bash
   rootProject.name = 'eshop-cartservice'
```
<br/>

> Modify the build.gradle file of eshop-cartservice with the following content. Some dependencies (ex: PostgreSQL, JPA) have been removed from build.gradle of the existing eshop-backend.

**eshop-cartservice/build.gradle**
```bash
plugins {
    id 'org.springframework.boot' version '2.2.6.RELEASE'
    id 'io.spring.dependency-management' version '1.0.9.RELEASE'
    id 'java'
    id 'com.google.cloud.tools.jib' version '2.7.0'
}

jib{
    container {
        creationTime = 'USE_CURRENT_TIMESTAMP'      
    }
}
group = 'com.samsungsds'
version = '0.0.1-SNAPSHOT'
sourceCompatibility = '11'

configurations {
    developmentOnly
    runtimeClasspath {
        extendsFrom developmentOnly
    }
}

repositories {
    mavenCentral()
}

dependencies {
    implementation 'org.springframework.boot:spring-boot-starter-web'   
    implementation 'org.springframework.boot:spring-boot-starter-data-redis'
    developmentOnly 'org.springframework.boot:spring-boot-devtools'   
    implementation 'com.google.guava:guava:28.2-jre'
 
    testImplementation('org.springframework.boot:spring-boot-starter-test') {
        exclude group: 'org.junit.vintage', module: 'junit-vintage-engine'
    }
}
 
test {
    useJUnitPlatform()
}
```
<br/>

> Create the src folder structure in eshop-cartservice as follows.

-   src/main/java/com/samsungsds/eshop
-   src/main/resources
-   src/test/java/com/samsungsds/eshop

```bash
  cd ~/eshop-legacy-mentee/eshop-cartservice/
  mkdir -p src/main/java/com/samsungsds/eshop src/main/resources src/test/java/com/samsungsds/eshop
```

![](images/1-3/image19.tmp)

<br/>

> src/main/java/com/samsungsds/eshop Below, create the EshopCartserviceApplication.java file with the following content.

**eshop-cartservice/src/main/java/com/samsungsds/eshop/EshopCartserviceApplication.java** 
```java
package com.samsungsds.eshop;
 
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
 
@SpringBootApplication
public class EshopCartserviceApplication {
 
    public static void main(String[] args) {
        SpringApplication.run(EshopCartserviceApplication.class, args);
    }
 
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
 
}
```
<br/>

> src/resources Create an application.properties file with the following content below.

> **eshop-cartservice/src/main/resources/application.properties** 

```bash
server.port=8091
spring.redis.host=localhost
spring.redis.port=6379
```

<br/>
> Copy the following files from eshop-backend to the src/main/java/com/samsungsds/eshop path of eshop-cartservice.

- All files in the cart package
- RedisConfig.java file in the config package

![](images/1-3/image20.tmp)

> Enter the following in the eshop-cartservice directory to check if it builds properly.

```bash
./gradlew build
```

![](images/1-3/image21.png)

### Setting up a shopping cart service k8s deployment

Create the k8s/cartservice.yaml file with the following content.

**k8s/cartservice.yaml**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-cartservice
spec:
  selector:
    matchLabels:
      app: eshop-cartservice
  template:
    metadata:
      labels:
        app: eshop-cartservice
    spec:
      containers:
        - name: eshop-cartservice
          image: eshop-cartservice
          ports:
          - containerPort: 8091
          env:
            - name: SPRING_REDIS_HOST
              value: redis
---
apiVersion: v1
kind: Service
metadata:
  name: eshop-cartservice
spec:
  type: ClusterIP
  selector:
    app: eshop-cartservice
  ports:
  - port: 8091
```
<br/>

Modify the skaffold.yaml file as follows.

**skaffold.yaml** 

```yaml
apiVersion: skaffold/v2beta10
kind: Config
build:
  artifacts:
    - image: eshop-cartservice
      context: eshop-cartservice
      jib:
        type: gradle
    - image: eshop-backend
      context: eshop-backend
      jib:
        type: gradle
    - image: eshop-frontend
      context: eshop-frontend
deploy:
  kubectl:
    manifests:
      - k8s/**.yaml
```

<br/>

k8s/ingress.yaml Modify the contents of the file as follows.

**k8s/ingress.yaml**

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: eshop-ingress
  annotations:
    kubernetes.io/ingress.class: "nginx"
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
spec:
  rules:
  - http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: eshop-frontend
            port:
              number: 8080
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /static
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /api/carts
        pathType: Prefix
        backend:
          service:
            name: eshop-cartservice
            port:
              number: 8091
```

<br/>
<br/>
### Remove Shopping Cart Service Code from Backend

> If the operation of eshop-cartservice is confirmed, the shopping cart-related code must be removed from the existing backend. The work flow is as follows:
1. Since OrderController uses CartItem and CartService, do not delete CartItem and CartService, but modify the implementation to call eshop-cartservice.

2. Delete CartController, CartItemRepository and RedisConfig classes and related settings that are no longer needed.

<br/>

> Modify the implementation of the CartService class of eshop-backend to use RestTemplate.

> **eshop-backend/src/main/java/com/samsungsds/eshop/cart/CartService.java** 

```java
package com.samsungsds.eshop.cart;
 
import java.util.List;
 
import com.google.common.collect.Lists;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.stereotype.Service;
 
@Service
public class CartService {
    private final Logger logger = LoggerFactory.getLogger(CartService.class);
    private final RestTemplate restTemplate;
 
    @Value("${url.cartservice}")
    private String cartServiceUrl;
 
    public CartService(final RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
 
    public void emptyCart() {
        logger.info("emptyCart()");
        String emptyCartUrl = cartServiceUrl + "/api/carts/empty";
        restTemplate.postForEntity(emptyCartUrl, null,  Void.class);
    }
 
    public void addToCart(final CartItem cartItem) {
        logger.info("addToCart() : {}", cartItem);
        String addToCartUrl = cartServiceUrl + "/api/carts";
        restTemplate.postForEntity(addToCartUrl, cartItem,  CartItem.class);
    }
 
    public List<CartItem> getCartItems() {
        logger.info("getCartItems()");
        String getCartItemsUrl = cartServiceUrl + "/api/carts";
        ResponseEntity<CartItem[]> cartItemsResponse = restTemplate.getForEntity(getCartItemsUrl, CartItem[].class);
        return Lists.newArrayList(cartItemsResponse.getBody());
    }
 
    public Long getCartItemsCount() {
        logger.info("getCartItemsCount()");
        String cartItemsCountUrl = cartServiceUrl + "/api/carts/count";
        ResponseEntity<Long> cartItemsCountResponse = restTemplate.getForEntity(cartItemsCountUrl, Long.class);
        return cartItemsCountResponse.getBody();
    }
}

```
<br/>

> eshop-backend Modify the CartItem so that it no longer uses redis.

> **eshop-backend/src/main/java/com/samsungsds/eshop/cart/CartItem.java** 

```java
package com.samsungsds.eshop.cart;
 
import org.springframework.data.annotation.Id;
 
public class CartItem {
    private String id;
    private int quantity;
 
    public String getId() {
        return id;
    }
 
    public void setId(String id) {
        this.id = id;
    }
 
    public int getQuantity() {
        return quantity;
    }
 
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
 
    @Override
    public String toString() {
        return "CartItem{" +
                "id='" + id + '\'' +
                ", quantity=" + quantity +
                '}';
    }
}
```

<br/>

> **CartController.java(eshop-backend/src/main/java/com/samsungsds/eshop/cart/CartController.java), CartItemRepository.java(eshop-backend/src/main/java/com/samsungsds/eshop/cart/CartItemRepository.java)와 RedisConfig.java(eshop-backend/src/main/java/com/samsungsds/eshop/config/RedisConfig.java)Delete**.
> Finally, in the application.properties file of eshop-backend **redis 관련 설정(spring.redis.host, spring.redis.port)Remove**.
<br/>

> **eshop-backend/src/main/resources/application.properties**
```bash
server.port=8090
spring.jpa.show-sql=true
spring.jpa.generate-ddl=true
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQL10Dialect
spring.jpa.hibernate.ddl-auto=create-drop
spring.datasource.initialization-mode=always
spring.datasource.url=jdbc:postgresql://localhost:5432/eshop_db
spring.datasource.username=eshop_user
spring.datasource.password=password
spring.mvc.static-path-pattern=/static/**
spring.resources.cache.cachecontrol.max-age=3600
```
<br/>

 Add the URL_CARTSERVICE environment variable to the k8s/backend.yaml file as follows, and delete the existing redis-related environment variable SPRING_REDIS_HOST.
**k8s/backend.yaml**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-backend
spec:
  selector:
    matchLabels:
      app: eshop-backend
  template:
    metadata:
      labels:
        app: eshop-backend
    spec:
      containers:
        - name: eshop-backend
          image: eshop-backend
          ports:
          - containerPort: 8090
          env:
            - name: URL_CARTSERVICE
              value: http://eshop-cartservice:8091
            - name: SPRING_DATASOURCE_URL
              value: "jdbc:postgresql://postgres:5432/eshop_db"
          resources:
            requests:
              cpu: 200m
              memory: 384Mi
            limits:
              cpu: 1000m
              memory: 1024Mi
---
apiVersion: v1
kind: Service
metadata:
  name: eshop-backend
spec:
  type: ClusterIP
  selector:
    app: eshop-backend
  ports:
  - port: 8090
```

<br/>

> eshop-backend Exclude redis-related code from the build.gradle file.

> **eshop-backend/build.gradle** 

```bash
plugins {
    id 'org.springframework.boot' version '2.2.6.RELEASE'
    id 'io.spring.dependency-management' version '1.0.9.RELEASE'
    id 'java'
    id 'com.google.cloud.tools.jib' version '2.7.0'
}

jib{
    container {
        creationTime = 'USE_CURRENT_TIMESTAMP'      
    }
}
 
group = 'com.samsungsds'
version = '0.0.1-SNAPSHOT'
sourceCompatibility = '11'
 
configurations {
    developmentOnly
    runtimeClasspath {
        extendsFrom developmentOnly
    }
}
 
repositories {
    mavenCentral()
}
 
dependencies {
    implementation 'org.springframework.boot:spring-boot-starter-web'
    implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
    implementation 'org.postgresql:postgresql'
    developmentOnly 'org.springframework.boot:spring-boot-devtools'   
    implementation 'com.google.guava:guava:28.2-jre'
 
    testImplementation('org.springframework.boot:spring-boot-starter-test') {
        exclude group: 'org.junit.vintage', module: 'junit-vintage-engine'
    }
}
 
test {
    useJUnitPlatform()
} 
```

<br/>
<br/>

## Measure
> Start the service using skaffold.

```bash
skaffold dev
```
> To connect to ingress, perform port-forward in a separate Cloud Shell window.

```bash
kubectl port-forward deployment.apps/ingress-nginx-controller 8080:80 -n ingress-nginx
```

> When calling the localhost:8080/api/carts path in a web browser
Check if the eshop-cartservice log similar to the following is visible.

```bash
[eshop-cartservice] 2020-10-23 04:29:07.423 INFO 1 --- [nio-8091-exec-6] com.samsungsds.eshop.cart.CartService : getCartItems()
```

![](images/1-3/image22.tmp)

It was confirmed that shopping cart-related requests were properly routed to eshop-cartservice.

When you access the service from a web browser and add/delete a shopping cart, you can see what is being processed by eshop-cartservice.

![](images/1-3/image23.tmp)

When you place an order in a web browser, you can see that the shopping cart inquiry function and the shopping cart emptying function operate in eshop-cartservice.

<br/>
<br/>

## Deploy to AWS EC2

🚩Upload a total of 3 Docker images (frontend, backend, eshop-cartservice), including the separated shopping cart service, to AWS ECR, configure each VPC environment appropriately, and then launch a container using the 3 Docker images on EC2. < br/>
(Implementing the ingress role through nginx reverse proxy and launching containers through docker compose)
 
#### Basic structure for docker compose

```sh
mkdir eshop
cd eshop

mkdir proxy

touch compose.yaml
touch proxy/nginx.conf
```


<br/>

![](images/1-3/EC2_2_1.png)

<br/>
<br/>
### Verify functionality after creating a container in AWS EC2

> Function operation check (common)

**Let’s look at the screens below and check if each function is working properly**

- Upon first access

![](images/1-3/image24.png)

- When clicking on a product (product details)

![](images/1-3/image25.png)

- Shopping cart screen (before ordering)

![](images/1-3/image26.png)

- After ordering

![](images/1-3/image27.png)

<br/><br/><br/>

---

<br>

# **3-2. Separation of products and services**
<br>

![](images/1-3/image103.png)
![](images/1-3/EC2-2-2.png)

<br/>

## Intro

### Explore existing product implementations

> The existing product implementation is located in the product package of eshop-backend.

![](images/1-3/image28.tmp)

> ProductController is a typical RestController that processes REST API and does not process logic directly but delegates it to ProductService.
> ProductService processes product business logic and uses ProductRepository for data retrieval (no storage function).
> ProductRepository is a JPA CrudRepository implementation and is declared to handle basic CRUD of CartItem. The **findAllByIdIn(String[] ids)** interface is additionally defined to group multiple ID items and search them in list form.
> Product is a JPA Entity and has a list of product categories in CollectionTable format.
> Products is a general Value Object class that has an array of Products as a member. Use this type when returning products in json list format.
> If you look at the Product-related part of the import.sql file, you can see that it consists of two entities: product and product_category. product_category is confirmed to be an entity dependent on the product.

<br/>
### Technical structure selection

| **Design Decisions** | **Rationale** | **Retired alternative**          |
|-----------|------------------------------|---------------------------|
| Mongo DB selected as data storage | - Availability/scalability is important because product services must receive intensive requests when users flock <br/> - There is no need to insist on the RDB format as there are only transactions that list/detail search using only the ID value of the product<br/> - HA (High Availability) configuration and scaling can be easily configured in a Kubernetes environment compared to existing RDBs<br> | PostgreSQL <br/> - Existing implementation exists<br/> - HA configuration and scaling configuration in kubernetes environment is not smooth compared to mongoDB |
| Node.js was selected as the development language and Express was selected as the development framework | - Service startup/stop speed is fast, so it is more advantageous when configuring Auto Scaling <br/> - It runs with less memory compared to Spring Boot, so more service instances can be launched and it is advantageous in terms of availability<br/> - Framework Simple and easy to use makes migration of existing logic easier | Spring Boot <br/>- Easy to transfer business logic because an existing implementation exists<br/>- Slow startup/shutdown speed during Auto Scaling compared to Express (scalability -)<br/>- Due to the size of the JVM Since basic memory usage is higher than Express, the number of service instances that can be started is less than Express (scalability -)


<br/>

## Build
### Configuring mongoDB

Create the k8s/mongodb.yaml file with the following content.

mongodb.yaml

**k8s/mongodb.yaml** 

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: mongodb
spec:
  serviceName: mongodb
  replicas: 1
  selector:
    matchLabels:
      app: mongodb
  template:
    metadata:
      labels:
        app: mongodb
        selector: mongodb
    spec:
      containers:
      - name: mongodb
        image: mongo:4.0.20
        env:
          - name: MONGO_INITDB_ROOT_USERNAME
            value: admin
          - name: MONGO_INITDB_ROOT_PASSWORD
            value: password
---
apiVersion: v1
kind: Service
metadata:
  name: mongodb
  labels:
    app: mongodb
spec:
  clusterIP: None
  selector:
    app: mongodb
```
<br/>
### Creating a product service

> Create an eshop-productservice directory in the project root directory.

> eshop-productservice

![](images/1-3/image29.png)

> In the eshop-productservice directory, create a package.json file using the npm init command as follows.

**npm init**

```bash
npm init --yes
```

![](images/1-3/image30.png)

<br/>

> Enter the following to install the necessary packages.

```bash
npm install express dotenv mongoose --save

//result below
78 packages added, and 79 packages audited in 15s

6 packages are looking for funding
   run `npm fund` for details

found 0 vulnerabilities
```

<br/>

> Create an .env file in the eshop-productservice directory with the following content.

**eshop-productservice/.env**

```bash
PORT=8092
MONGO_URI=mongodb://127.0.0.1:27017
```
<br/>

> Create a .gitignore file in the eshop-productservice directory with the following content.

> .gitignore

**eshop-productservice/.gitignore**

```bash
#Logs
logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
lerna-debug.log*

# Diagnostic reports (https://nodejs.org/api/report.html)
report.[0-9]*.[0-9]*.[0-9]*.[0-9]*.json

# Compiled binary addons (https://nodejs.org/api/addons.html)
build/release

# Dependency directories
node_modules/

# Optional npm cache directory
.npm

# dotenv environment variables file
.env
.env.test

# Stores VSCode versions used for testing VSCode extensions
.vscode-test
```
<br/>

> Create an index.js file in the eshop-productservice directory with the following content.
> index.js

> **eshop-productservice/index.js** 

```js
const express = require("express");
const app = express();
const dotenv = require("dotenv");
const mongoose = require("mongoose");
const Product = require("./product-model")

dotenv.config();

const port = process.env.PORT;

let db = mongoose.connection;
db.on("error", console.error);
db.once("open", function () {
  console.log("Connected to mongod server");
  if(process.env.INIT_DATA) {
    console.log("initializing product data...");
    Product.initProduct(Product);
  }
});
mongoose.connect(process.env.MONGO_URI, {
  useUnifiedTopology: true,
  useNewUrlParser: true,
});

app.get("/api/products", async (req, res) => {
  if (req.query.ids) {
    const ids = req.query.ids.split(",");
    console.log("Filtered Product List : ", ids);
    const findResults = await Product.find({ id: { $in: ids } });
    const result = {
      products: findResults,
    };
    console.log("Filtered Products : " + JSON.stringify(result));
    res.send(result);
  } else {
    console.log("All Product List");
    const allProducts = await Product.find();
    const result = {
      products: allProducts,
    };
    res.send(result);
  }
});

app.get("/api/products/:id", async (req, res) => {
  const requestedId = req.params.id;
  console.log("Requested Product : " + requestedId);
  const result = await Product.findOne({ id: requestedId });
  console.log("Found Product : " + JSON.stringify(result));
  res.send(result);
});

app.listen(port, function () {
  console.log("Product Catalog service has started on port " + port);
});
```

> MongoDB Mongoose is used for connection, and it is implemented to generate product initial data only when an environment variable called INIT_DATA exists.
<br/> 

> eshop-productservice Create a product-model.js file in the directory with the following content. The product-model.js file performs mongoose schema creation.

product-model.js

**eshop-productservice/product-model.js** 

```js
const mongoose = require("mongoose");
const data = require("./data/products.json");

// Nodejs의 native Promise 사용
mongoose.Promise = global.Promise;

let Product;

const MoneySchema = new mongoose.Schema({
  currencyCode: String,
  units: Number,
  nanos: Number,
});
const ProductSchema = new mongoose.Schema({
  id: String,
  name: String,
  description: String,
  picture: String,
  categories: [{ type: String, }],
  priceUsd: MoneySchema,
});
ProductSchema.statics.initProduct = async (Product) => {
  const count = await Product.countDocuments({});
  if (count == 0) {
    data.products.forEach((product) => {
      Product.create(product);
    });
  }
};

Product = mongoose.model("Product", ProductSchema);
module.exports = Product;
```

<br/>

eshop-productservice/data Create a products.json file in the directory with the following content.

products.json

**eshop-productservice/data/products.json** 

```js
{
    "products": [
      {
        "id": "OLJCESPC7Z",
        "name": "Vintage Typewriter",
        "description": "This typewriter looks good in your living room.",
        "picture": "/static/img/products/typewriter.jpg",
        "priceUsd": {
          "currencyCode": "USD",
          "units": 67,
          "nanos": 990000000
        },
        "categories": ["vintage"]
      },
      {
        "id": "66VCHSJNUP",
        "name": "Vintage Camera Lens",
        "description": "You won't have a camera to use it and it probably doesn't work anyway.",
        "picture": "/static/img/products/camera-lens.jpg",
        "priceUsd": {
          "currencyCode": "USD",
          "units": 12,
          "nanos": 490000000
        },
        "categories": ["photography", "vintage"]
      },
      {
        "id": "1YMWWN1N4O",
        "name": "Home Barista Kit",
        "description": "Always wanted to brew coffee with Chemex and Aeropress at home?",
        "picture": "/static/img/products/barista-kit.jpg",
        "priceUsd": {
          "currencyCode": "USD",
          "units": 124
        },
        "categories": ["cookware"]
      },
      {
        "id": "L9ECAV7KIM",
        "name": "Terrarium",
        "description": "This terrarium will looks great in your white painted living room.",
        "picture": "/static/img/products/terrarium.jpg",
        "priceUsd": {
          "currencyCode": "USD",
          "units": 36,
          "nanos": 450000000
        },
        "categories": ["gardening"]
      },
      {
        "id": "2ZYFJ3GM2N",
        "name": "Film Camera",
        "description": "This camera looks like it's a film camera, but it's actually digital.",
        "picture": "/static/img/products/film-camera.jpg",
        "priceUsd": {
          "currencyCode": "USD",
          "units": 2245
        },
        "categories": ["photography", "vintage"]
      },
      {
        "id": "0PUK6V6EV0",
        "name": "Vintage Record Player",
        "description": "It still works.",
        "picture": "/static/img/products/record-player.jpg",
        "priceUsd": {
          "currencyCode": "USD",
          "units": 65,
          "nanos": 500000000
        },
        "categories": ["music", "vintage"]
      },
      {
        "id": "LS4PSXUNUM",
        "name": "Metal Camping Mug",
        "description": "You probably don't go camping that often but this is better than plastic cups.",
        "picture": "/static/img/products/camp-mug.jpg",
        "priceUsd": {
          "currencyCode": "USD",
          "units": 24,
          "nanos": 330000000
        },
        "categories": ["cookware"]
      },
      {
        "id": "9SIQT8TOJO",
        "name": "City Bike",
        "description": "This single gear bike probably cannot climb the hills of San Francisco.",
        "picture": "/static/img/products/city-bike.jpg",
        "priceUsd": {
          "currencyCode": "USD",
          "units": 789,
          "nanos": 500000000
        },
        "categories": ["cycling"]
      },
      {
        "id": "6E92ZMYYFZ",
        "name": "Air Plant",
        "description": "Have you ever wondered whether air plants need water? Buy one and figure out.",
        "picture": "/static/img/products/air-plant.jpg",
        "priceUsd": {
          "currencyCode": "USD",
          "units": 12,
          "nanos": 300000000
        },
        "categories": ["gardening"]
      }
    ]
  }
```
<br/>

### Setting up product service k8s deployment

> eshop-productservice Create a Dockerfile with the following content in the directory.

> **eshop-productservice/Dockerfile** 

```bash
FROM node:16.18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --only=production
COPY . .

EXPOSE 8092
CMD ["node", "index.js"]
```

<br/>

k8s Create a k8s/productservice.yaml file for skaffold deployment in the directory.

**k8s/productservice.yaml** 

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-productservice
spec:
  selector:
    matchLabels:
      app: eshop-productservice
  template:
    metadata:
      labels:
        app: eshop-productservice
    spec:
      terminationGracePeriodSeconds: 5
      containers:
      - name: eshop-productservice
        image: eshop-productservice
        ports:
        - containerPort: 8092
        env:
        - name: PORT
          value: "8092"
        - name: MONGO_URI
          value: "mongodb://admin:password@mongodb"
        - name: INIT_DATA
          value: "true"
        resources:
          requests:
            cpu: 100m
            memory: 64Mi
          limits:
            cpu: 200m
            memory: 128Mi
---
apiVersion: v1
kind: Service
metadata:
  name: eshop-productservice
spec:
  type: ClusterIP
  selector:
    app: eshop-productservice
  ports:
  - name: api
    port: 8092
    targetPort: 8092
```

<br/>

Modify the k8s/ingress.yaml file as follows so that eshop-productservice handles product-related APIs.

**k8s/ingress.yaml** 

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: eshop-ingress
  annotations:
    kubernetes.io/ingress.class: "nginx"
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
spec:
  rules:
  - http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: eshop-frontend
            port:
              number: 8080
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /static
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /api/carts
        pathType: Prefix
        backend:
          service:
            name: eshop-cartservice
            port:
              number: 8091
      - path: /api/products
        pathType: Prefix
        backend:
          service:
            name: eshop-productservice
            port:
              number: 8092
```

<br/>

To deploy the product service, modify the skaffold.yaml file as follows.

**skaffold.yaml** 

```yaml
apiVersion: skaffold/v2beta10
kind: Config
build:
  artifacts:
    - image: eshop-productservice
      context: eshop-productservice
    - image: eshop-cartservice
      context: eshop-cartservice
      jib:
        type: gradle
    - image: eshop-backend
      context: eshop-backend
      jib:
        type: gradle
    - image: eshop-frontend
      context: eshop-frontend
deploy:
  kubectl:
    manifests:
      - k8s/**.yaml
```

<br/>

Start the service and check whether eshop-productservice processes the product inquiry API.

```bash
skaffold dev
```
-   port-forward

![](images/1-3/image31.tmp)

<br/>
<br/>


### eshop-backendModify to use the product service in

> eshop-backend Let's take a look at where product services are still being used.

1. OrderController If you look at , you can see that ProductService and PostgreSQL data are still used when processing orders.

**OrderController** 

```java
@RestController
@RequestMapping(value = "/api/checkouts")
public class OrderController {
    ...
    private final ProductService productService;

    public OrderController(final OrderService orderService, 
    final ShippingService shippingService,
    final  PaymentService paymentService,
    final CartService cartService,
    final ProductService productService) {
        this.orderService = orderService;
        this.shippingService = shippingService;
        this.paymentService = paymentService;
        this.cartService = cartService;
        this.productService = productService;
    }

    @PostMapping(value = "/orders")
    public ResponseEntity<OrderResult> placeOrder(@RequestBody OrderRequest orderRequest) {
        ...

        // cart 상품 조회
        Product[] products = getProducts(cartItems);

        ...
    }

    private Product[] getProducts(CartItem[] cartItems) {
        String[] cartItemIds = Stream.of(cartItems).map(CartItem::getId).toArray(String[]::new);
        return productService.fetchProductsByIds(cartItemIds).getProducts();
    }
}
```

2. RecommendService You can see that ProductService is used for product recommendation.

```java
@Service
public class RecommendService {
  private final ProductService productService;
  
  public RecommendService(ProductService productService) {
    this.productService = productService;
  }

  public Recommendations recommendProducts() {
    Recommendations recommendations = new Recommendations();
    Product[] recommendedProducts = recommend(productService.fetchProducts().getProducts());
    recommendations.setRecommendations(recommendedProducts);
    return recommendations;
  }

  private Product[] recommend(Product[] products) {
    List<Product> productList = Lists.newArrayList(products);
    Collections.shuffle(productList);
    Product[] recommendedProducts = new Product[4];
    productList.subList(0, 4).toArray(recommendedProducts);
    return recommendedProducts;
  }

}
```

> 1, 2 In case number 1, all products are using ProductService, so the work flow is as follows.
1. Modify ProductService to use eshop-productservice.

2. Delete ProductController and ProductRepository that are no longer needed.

<br/>
First, modify ProductService to use REST API as follows.

**eshop-backend/src/main/java/com/samsungsds/eshop/product/ProductService.java** 
```java
package com.samsungsds.eshop.product;

import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ProductService {
  private final RestTemplate restTemplate;

  @Value("${url.productservice}")
  private String productServiceUrl;

  public ProductService(final RestTemplate restTemplate) {
    this.restTemplate = restTemplate;
  }
  
  public Products fetchProducts() {
    String fetchProductsUrl = productServiceUrl + "/api/products";
    ResponseEntity<Products> productsResponse = restTemplate.getForEntity(fetchProductsUrl, Products.class);
    return productsResponse.getBody();
  }

  public Product fetchProductById(final String id) {
    String fetchProductsByIdUrl = productServiceUrl + "/api/products/" + id;
    ResponseEntity<Product> productResponse = restTemplate.getForEntity(fetchProductsByIdUrl, Product.class);
    return productResponse.getBody();
  }

  public Products fetchProductsByIds(final String[] ids) {
    String idsString = Stream.of(ids).collect(Collectors.joining(","));
    String fetchProductsByIdsUrl = productServiceUrl + "/api/products" + "?ids=" + idsString;
    ResponseEntity<Products> productsResponse = restTemplate.getForEntity(fetchProductsByIdsUrl, Products.class);
    return productsResponse.getBody();
  }
}
```

<br/>

Products: A JSON parsing error occurs because the class does not have a Default Constructor, so modify it as follows.

**eshop-backend/src/main/java/com/samsungsds/eshop/product/Products.java** 
```java
package com.samsungsds.eshop.product;

import java.util.Arrays;

public class Products {
    private Product[] products;

    public Product[] getProducts() {
        return products;
    }

    public Products() {}

    public Products(Product[] products) {
        this.products = products;
    }
    public void setProducts(Product[] products) {
        this.products = products;
    }

    @Override
    public String toString() {
        return "CartProductResponse{" +
                "products=" + Arrays.toString(products) +
                '}';
    }
}
```

<br/>

k8s/backend.yaml Add the URL_PRODUCTSERVICE environment variable as follows.

**k8s/backend.yaml**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-backend
spec:
  selector:
    matchLabels:
      app: eshop-backend
  template:
    metadata:
      labels:
        app: eshop-backend
    spec:
      containers:
        - name: eshop-backend
          image: eshop-backend
          ports:
          - containerPort: 8090
          env:
            - name: URL_CARTSERVICE
              value: http://eshop-cartservice:8091
            - name: URL_PRODUCTSERVICE
              value: http://eshop-productservice:8092
            - name: SPRING_DATASOURCE_URL
              value: "jdbc:postgresql://postgres:5432/eshop_db"
          resources:
            requests:
              cpu: 500m
              memory: 384Mi
            limits:
              cpu: 1000m
              memory: 1024Mi
---
apiVersion: v1
kind: Service
metadata:
  name: eshop-backend
spec:
  type: ClusterIP
  selector:
    app: eshop-backend
  ports:
  - port: 8090
```

<br/>

eshop-backend Delete the ProductController and ProductRepository classes from the service.

Since the Product class no longer needs to use JPA, modify it as follows.
**eshop-backend/src/main/java/com/samsungsds/eshop/product/Product.java** 

```java
package com.samsungsds.eshop.product;

import java.util.Set;

import com.samsungsds.eshop.payment.Money;

public class Product {
    private String id;
    private String name;
    private String description;
    private String picture;
    private Money priceUsd;
    private Set<String> categories;

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPicture() {
        return this.picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public Money getPriceUsd() {
        return this.priceUsd;
    }

    public void setPriceUsd(Money priceUsd) {
        this.priceUsd = priceUsd;
    }

    public Set<String> getCategories() {
        return this.categories;
    }

    public void setCategories(Set<String> categories) {
        this.categories = categories;
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", name='" + getName() + "'" +
            ", description='" + getDescription() + "'" +
            ", picture='" + getPicture() + "'" +
            ", priceUsd='" + getPriceUsd() + "'" +
            ", categories='" + getCategories() + "'" +
            "}";
    }

}
```

<br/>

eshop-backend Remove all INSERT statements for product and product_category from the service's import.sql file.

**import.sql** 
```sql
INSERT INTO currency (currency_code, currency_value) VALUES (  'EUR', 1.0);
INSERT INTO currency (currency_code, currency_value) VALUES (  'USD', 1.1305);
INSERT INTO currency (currency_code, currency_value) VALUES (  'JPY', 126.40);
INSERT INTO currency (currency_code, currency_value) VALUES (  'BGN', 1.9558);
INSERT INTO currency (currency_code, currency_value) VALUES (  'CZK', 25.592);
INSERT INTO currency (currency_code, currency_value) VALUES (  'DKK', 7.4609);
INSERT INTO currency (currency_code, currency_value) VALUES (  'GBP', 0.85970);
INSERT INTO currency (currency_code, currency_value) VALUES (  'HUF', 315.51);
INSERT INTO currency (currency_code, currency_value) VALUES (  'PLN', 4.2996);
INSERT INTO currency (currency_code, currency_value) VALUES (  'RON', 4.7463);
INSERT INTO currency (currency_code, currency_value) VALUES (  'SEK', 10.5375);
INSERT INTO currency (currency_code, currency_value) VALUES (  'CHF', 1.1360);
INSERT INTO currency (currency_code, currency_value) VALUES (  'ISK', 136.80);
INSERT INTO currency (currency_code, currency_value) VALUES (  'NOK', 9.8040);
INSERT INTO currency (currency_code, currency_value) VALUES (  'HRK', 7.4210);
INSERT INTO currency (currency_code, currency_value) VALUES (  'RUB', 74.4208);
INSERT INTO currency (currency_code, currency_value) VALUES (  'TRY', 6.1247);
INSERT INTO currency (currency_code, currency_value) VALUES (  'AUD', 1.6072);
INSERT INTO currency (currency_code, currency_value) VALUES (  'BRL', 4.2682);
INSERT INTO currency (currency_code, currency_value) VALUES (  'CAD', 1.5128);
INSERT INTO currency (currency_code, currency_value) VALUES (  'CNY', 7.5857);
INSERT INTO currency (currency_code, currency_value) VALUES (  'HKD', 8.8743);
INSERT INTO currency (currency_code, currency_value) VALUES (  'IDR', 15999.40);
INSERT INTO currency (currency_code, currency_value) VALUES (  'ILS', 4.0875);
INSERT INTO currency (currency_code, currency_value) VALUES (  'INR', 79.4320);
INSERT INTO currency (currency_code, currency_value) VALUES (  'KRW', 1275.05);
INSERT INTO currency (currency_code, currency_value) VALUES (  'MXN', 21.7999);
INSERT INTO currency (currency_code, currency_value) VALUES (  'MYR', 4.6289);
INSERT INTO currency (currency_code, currency_value) VALUES (  'NZD', 1.6679);
INSERT INTO currency (currency_code, currency_value) VALUES (  'PHP', 59.083);
INSERT INTO currency (currency_code, currency_value) VALUES (  'SGD', 1.5349);
INSERT INTO currency (currency_code, currency_value) VALUES (  'THB', 36.012);
INSERT INTO currency (currency_code, currency_value) VALUES (  'ZAR', 16.0583);

INSERT INTO ad (category, redirect_url, text) VALUES ('photography','/products/2ZYFJ3GM2N','Film camera for sale. 50% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('vintage','/products/2ZYFJ3GM2N','Film camera for sale. 50% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('photography','/products/66VCHSJNUP','Vintage camera lens for sale. 20% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('vintage','/products/66VCHSJNUP','Vintage camera lens for sale. 20% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('vintage','/products/0PUK6V6EV0','Vintage record player for sale. 30% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('cycling','/products/9SIQT8TOJO', 'City Bike for sale. 10% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('cookware','/products/1YMWWN1N4O', 'Home Barista kitchen kit for sale. Buy one, get second kit for free');
INSERT INTO ad (category, redirect_url, text) VALUES ('gardening','/products/6E92ZMYYFZ', 'Air plants for sale. Buy two, get third one for free');
INSERT INTO ad (category, redirect_url, text) VALUES ('gardening','/products/L9ECAV7KIM', 'Terrarium for sale. Buy one, get second one for free');
```

<br/>
<br/>


## Measure
> Start the service using skaffold.

```bash
skaffold dev
```

> When calling the localhost:8080/api/products path in a web browser, check whether the eshop-productservice log similar to the following is visible.

```bash
[eshop-productservice] All Product List
```

![](images/1-3/image32.tmp)

> It was confirmed that product-related requests were routed normally to eshop-productservice.

> You can see that eshop-productservice is called when you access the service from a web browser and perform product inquiry/recommendation/order functions.

<br/>

## Deploy to AWS EC2

> Let’s upload a total of 4 Docker images, including the separated shopping cart service, to AWS ECR and launch a container using the above images on the previously configured EC2.
-frontend
-backend
- eshop-cartservice
- eshop-productservice
<br>

(Implementing the ingress role through nginx reverse proxy and launching containers through docker compose)

<br/>

![](images/1-3/EC2_2_2.png)

<br/>

### Verify functionality after creating a container in AWS EC2

Function operation check (common)

**Let’s look at the screens below and check if each function is working properly**

- Upon first access

![](images/1-3/image24.png)

- When clicking on a product (product details)

![](images/1-3/image25.png)

- Shopping cart screen (before ordering)

![](images/1-3/image26.png)

- After ordering

![](images/1-3/image27.png)



<br/>
<br/>

---

<br>

# **3-3. Recommended service separation**

![](images/1-3/image105.png)
![](images/1-3/EC2-2-3.png)

<br/>

## Intro

### Explore existing recommended implementations

> The existing recommendation implementation is located in the recommend package of eshop-backend.

![](images/1-3/image33.tmp)

> RecommendController is a RestController that handles only the /recommends API. Logic is processed using RecommendService.

> RecommendService uses ProductService to search and recommend products. Currently, it is implemented to recommend 4 random products.

> The Recommendations class is a Value Object that contains a list of recommended products.
<br/>

### Technical structure selection

| **Design Decisions** | **Rationale** | **Abandoned alternative** |
|-----------|------------------------------|---------------------------|
|Select Python as the development language| When adding AI-based product recommendation functions in the future, it is expected that the time to port related code will be reduced by using Python, a language widely used in AI implementation. | • Java <br/> - There is an existing implementation, but there is no meaningful business logic, so there is no problem with migration. <br/> - There is no benefit when adding AI-based product recommendation functionality in the future, so it is discarded.<br/><br /> • Node.js <br/> - Discarded as there is no advantage in adding AI-based product recommendation function in the future |
|Select Flask as the development framework | - Micro framework commonly used in Python development <br/> - Operates lighter than other frameworks by providing only very basic functions in advance and adding necessary functions in combination <br/> - Developers can provide the necessary functions If you need a lot of features, the amount of manual coding you have to do increases because you have to put them together yourself. | •	Django <br/> - Python It is one of the frameworks widely used in web application development, and many functions necessary for developing web applications, including ORM, are provided by default, allowing users to focus solely on business development.<br/> - Many functions are included in advance, so they can be started/ It is inferior to Flask in terms of shutdown speed and memory usage<br/> - Discarded as no other functions other than API calls are needed for recommendation service development.


<br/>

## Build

### Python Preparing for development (in WSL environment)

> Refer to the following document for Python development in a WSL environment.

<https://docs.microsoft.com/ko-kr/windows/python/web-frameworks>

> Check whether Python3 is already installed by entering the following in the WSL terminal.

```bash
$ python3 --version
Python 3.8.5
```

If the python3 version is too low, upgrade by entering the following:

```bash
sudo apt upgrade python3
```

Enter the following to install pip and venv.

```bash
sudo apt install python3-pip python3-venv
```
<br/>

### Creating a recommended service

> Create an eshop-recommendservice directory in the project root directory.

![](images/1-3/image34.tmp)

> In the eshop-recommendservice directory, create a venv by entering the following.

```bash
python3 -m venv .venv
```

> Activate the virtual environment by entering the following:

```bash
source .venv/bin/activate
```

![](images/1-3/image35.tmp)

<br/>

.venv Install Flask in venv by entering the following in the terminal.

```bash
$ python3 -m pip install flask

Collecting flask

Downloading https://files.pythonhosted.org/packages/8f/b6/b4fdcb6d01ee20f9cfe81dcf9d3cd6c2f874b996f186f1c0b898c4a59c04/Flask-2.0.2-py3-none-any.whl (95kB)
    100% |████████████████████████████████| 102kB 3.6MB/s 
Collecting Werkzeug>=2.0 (from flask)
  Downloading https://files.pythonhosted.org/packages/1e/73/51137805d1b8d97367a8a77cae4a792af14bb7ce58fbd071af294c740cf0/Werkzeug-2.0.2-py3-none-any.whl (288kB)
    100% |████████████████████████████████| 296kB 2.3MB/s 
Collecting Jinja2>=3.0 (from flask)
  Downloading https://files.pythonhosted.org/packages/20/9a/e5d9ec41927401e41aea8af6d16e78b5e612bca4699d417f646a9610a076/Jinja2-3.0.3-py3-none-any.whl (133kB)
    100% |████████████████████████████████| 143kB 6.9MB/s 
Collecting click>=7.1.2 (from flask)
  Downloading https://files.pythonhosted.org/packages/48/58/c8aa6a8e62cc75f39fee1092c45d6b6ba684122697d7ce7d53f64f98a129/click-8.0.3-py3-none-any.whl (97kB)
    100% |████████████████████████████████| 102kB 8.9MB/s 
Collecting itsdangerous>=2.0 (from flask)
  Downloading https://files.pythonhosted.org/packages/9c/96/26f935afba9cd6140216da5add223a0c465b99d0f112b68a4ca426441019/itsdangerous-2.0.1-py3-none-any.whl
Collecting MarkupSafe>=2.0 (from Jinja2>=3.0->flask)
  Downloading https://files.pythonhosted.org/packages/d7/56/9d9c0dc2b0f5dc342ff9c7df31c523cc122947970b5ea943b2311be0c391/MarkupSafe-2.0.1-cp37-cp37m-manylinux1_x86_64.whl
Collecting importlib-metadata; python_version < "3.8" (from click>=7.1.2->flask)
  Downloading https://files.pythonhosted.org/packages/f9/6c/a14560ec00a14f50fdb3e91665563500b55f3c672e621c3ef159d351e9f7/importlib_metadata-4.10.0-py3-none-any.whl
Collecting typing-extensions>=3.6.4; python_version < "3.8" (from importlib-metadata; python_version < "3.8"->click>=7.1.2->flask)
  Downloading https://files.pythonhosted.org/packages/05/e4/baf0031e39cf545f0c9edd5b1a2ea12609b7fcba2d58e118b11753d68cf0/typing_extensions-4.0.1-py3-none-any.whl
Collecting zipp>=0.5 (from importlib-metadata; python_version < "3.8"->click>=7.1.2->flask)
  Downloading https://files.pythonhosted.org/packages/bd/df/d4a4974a3e3957fd1c1fa3082366d7fff6e428ddb55f074bf64876f8e8ad/zipp-3.6.0-py3-none-any.whl
Installing collected packages: Werkzeug, MarkupSafe, Jinja2, typing-extensions, zipp, importlib-metadata, click, itsdangerous, flask
Successfully installed Jinja2-3.0.3 MarkupSafe-2.0.1 Werkzeug-2.0.2 click-8.0.3 flask-2.0.2 importlib-metadata-4.10.0 itsdangerous-2.0.1 typing-extensions-4.0.1 zipp-3.6.0
```
<br/>

.venv Install requests on venv by entering the following in the terminal.

```bash
python3 -m pip install requests

Collecting requests
  Downloading https://files.pythonhosted.org/packages/92/96/144f70b972a9c0eabbd4391ef93ccd49d0f2747f4f6a2a2738e99e5adc65/requests-2.26.0-py2.py3-none-any.whl (62kB)
    100% |████████████████████████████████| 71kB 1.2MB/s 
Collecting certifi>=2017.4.17 (from requests)
  Downloading https://files.pythonhosted.org/packages/37/45/946c02767aabb873146011e665728b680884cd8fe70dde973c640e45b775/certifi-2021.10.8-py2.py3-none-any.whl (149kB)
    100% |████████████████████████████████| 153kB 1.5MB/s 
Collecting urllib3<1.27,>=1.21.1 (from requests)
  Downloading https://files.pythonhosted.org/packages/af/f4/524415c0744552cce7d8bf3669af78e8a069514405ea4fcbd0cc44733744/urllib3-1.26.7-py2.py3-none-any.whl (138kB)
    100% |████████████████████████████████| 143kB 3.1MB/s 
Collecting idna<4,>=2.5; python_version >= "3" (from requests)
  Downloading https://files.pythonhosted.org/packages/04/a2/d918dcd22354d8958fe113e1a3630137e0fc8b44859ade3063982eacd2a4/idna-3.3-py3-none-any.whl (61kB)
    100% |████████████████████████████████| 61kB 3.8MB/s 
Collecting charset-normalizer~=2.0.0; python_version >= "3" (from requests)
  Downloading https://files.pythonhosted.org/packages/47/84/b06f6729fac8108c5fa3e13cde19b0b3de66ba5538c325496dbe39f5ff8e/charset_normalizer-2.0.9-py3-none-any.whl
Installing collected packages: certifi, urllib3, idna, charset-normalizer, requests
Successfully installed certifi-2021.10.8 charset-normalizer-2.0.9 idna-3.3 requests-2.26.0 urllib3-1.26.7
```
<br/>

eshop-recommendservice/ Create an app.py file with the following content.

**eshop-recommendservice/app.py** 
```py
from flask import Flask
import requests, random, os

_url_productservice = os.environ.get("URL_PRODUCTSERVICE", default='http://localhost:8080')

app = Flask(__name__)

@app.route("/api/recommends", methods=['GET'])
def recommend():
  # 상품 목록을 조회한다.
  response = requests.get(_url_productservice + "/api/products")
  products = response.json()
  # 랜덤한 4개의 상품을 추천한다.
  recommendations = { 'recommendations': random.sample(products['products'], 4)}
  print("recommendations : {}".format(recommendations))
  return recommendations
```

<br/>

.venv Run the flask app by entering the following in the terminal. Because it accesses the product API

❗** Start the existing service using skaffold and test it with port-forward enabled as well**❗

```bash
$ python3 -m flask run

 * Environment: production
   WARNING: This is a development server. Do not use it in a production deployment.
   Use a production WSGI server instead.
 * Debug mode: off
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
```
If you check the URL with the following command, you can see that four random products are recommended as follows.

```bash
curl localhost:5000/api/recommends
```
![](images/1-3/image14.tmp)

<br/>

### Setting up recommended service k8s deployment

#### Installing gunicorn

If you run flask as is, an error message will appear telling you not to use it for production deployment as it is a development server, so install gunicorn, a WSGI server, to remove the error message.

```bash
*Environment: production
WARNING: This is a development server. Do not use it in a production deployment.
Use a production WSGI server instead.
```

Install gunicorn in venv by entering the following in the .venv terminal.
```bash
$ python3 -m pip install gunicorn
Collecting gunicorn
  Downloading gunicorn-20.0.4-py2.py3-none-any.whl (77 kB)
     |████████████████████████████████| 77 kB 666 kB/s
Requirement already satisfied: setuptools>=3.0 in ./.venv/lib/python3.8/site-packages (from gunicorn) (44.0.0)
Installing collected packages: gunicorn
Successfully installed gunicorn-20.0.4
```

.venv Run the app by entering the following in the terminal.

```bash
$ gunicorn -b 0.0.0.0:8093 app:app
[2020-10-26 16:56:33 +0900] [26484] [INFO] Starting gunicorn 20.0.4
[2020-10-26 16:56:33 +0900] [26484] [INFO] Listening at: http://0.0.0.0:8093 (26484)
[2020-10-26 16:56:33 +0900] [26484] [INFO] Using worker: sync
[2020-10-26 16:56:33 +0900] [26486] [INFO] Booting worker with pid: 26486
```

'[http://localhost:8093](http://localhost:8093/)/api/recommends' If you check , you can see that the service is running on port 8093.

```bash
curl localhost:8093/api/recommends
```

![](images/1-3/image36.tmp)

<br/>

#### Create Dockerfile 

eshop-recommendservice .venv Create a requirements.txt file by entering the following in the terminal.

```bash
python3 -m pip freeze > requirements.txt
```

The following requirements.txt file is created.

**eshop-recommendservice/requirements.txt** 

```txt
certifi==2021.10.8
charset-normalizer==2.0.9
click==8.0.3
Flask==2.0.2
gunicorn==20.1.0
idna==3.3
importlib-metadata==4.10.0
itsdangerous==2.0.1
Jinja2==3.0.3
MarkupSafe==2.0.1
requests==2.26.0
typing-extensions==4.0.1
urllib3==1.26.7
Werkzeug==2.0.2
zipp==3.6.0
```

If the 'pkg-resources==0.0.0' item exists, delete the line.

<br/>

Create a Dockerfile with the following content in the eshop-recommendservice directory.
**eshop-recommendservice/Dockerfile** 

```bash
FROM python:3.8-slim-buster
ADD ./requirements.txt .
RUN pip install -r requirements.txt
COPY . .

EXPOSE 8093
CMD ["sh", "-c", "gunicorn -b 0.0.0.0:8093 app:app --access-logfile - --error-logfile -"]
```

<br/>

Enter the following command to check if the build is successful.

 
```bash
$ docker build -t eshop-recommendservice .
Sending build context to Docker daemon  14.11MB
Step 1/5 : FROM python:3.8-alpine
 ---> 8744555ae7bb
Step 2/5 : COPY . /app
 ---> ed154bb25525
Step 3/5 : RUN pip install -r /app/requirements.txt
 ---> Running in 82b3d0625b51
Collecting certifi==2020.6.20
  Downloading certifi-2020.6.20-py2.py3-none-any.whl (156 kB)
Collecting chardet==3.0.4
  Downloading chardet-3.0.4-py2.py3-none-any.whl (133 kB)
Collecting click==7.1.2
  Downloading click-7.1.2-py2.py3-none-any.whl (82 kB)
Collecting Flask==1.1.2
  Downloading Flask-1.1.2-py2.py3-none-any.whl (94 kB)
Collecting gunicorn==20.0.4
  Downloading gunicorn-20.0.4-py2.py3-none-any.whl (77 kB)
Collecting idna==2.10
  Downloading idna-2.10-py2.py3-none-any.whl (58 kB)
Collecting itsdangerous==1.1.0
  Downloading itsdangerous-1.1.0-py2.py3-none-any.whl (16 kB)
Collecting Jinja2==2.11.2
  Downloading Jinja2-2.11.2-py2.py3-none-any.whl (125 kB)
Collecting MarkupSafe==1.1.1
  Downloading MarkupSafe-1.1.1.tar.gz (19 kB)
Collecting requests==2.24.0
  Downloading requests-2.24.0-py2.py3-none-any.whl (61 kB)
Collecting urllib3==1.25.11
  Downloading urllib3-1.25.11-py2.py3-none-any.whl (127 kB)
Collecting Werkzeug==1.0.1
  Downloading Werkzeug-1.0.1-py2.py3-none-any.whl (298 kB)
Requirement already satisfied: setuptools>=3.0 in /usr/local/lib/python3.8/site-packages (from gunicorn==20.0.4->-r /app/requirements.txt (line 5)) (50.3.2)
Building wheels for collected packages: MarkupSafe
  Building wheel for MarkupSafe (setup.py): started
  Building wheel for MarkupSafe (setup.py): finished with status 'done'
  Created wheel for MarkupSafe: filename=MarkupSafe-1.1.1-py3-none-any.whl size=12627 sha256=048b3f591cac4a2c80d4a80c8eb98c62a6f59e334a92f0564187543a811baf25
  Stored in directory: /root/.cache/pip/wheels/0c/61/d6/4db4f4c28254856e82305fdb1f752ed7f8482e54c384d8cb0e
Successfully built MarkupSafe
Installing collected packages: certifi, chardet, click, Werkzeug, itsdangerous, MarkupSafe, Jinja2, Flask, gunicorn, idna, urllib3, requests
Successfully installed Flask-1.1.2 Jinja2-2.11.2 MarkupSafe-1.1.1 Werkzeug-1.0.1 certifi-2020.6.20 chardet-3.0.4 click-7.1.2 gunicorn-20.0.4 idna-2.10 itsdangerous-1.1.0 requests-2.24.0 urllib3-1.25.11
Removing intermediate container 82b3d0625b51
 ---> 5676bc24f9c5
Step 4/5 : EXPOSE 8093
 ---> Running in 605d11945348
Removing intermediate container 605d11945348
 ---> f1cfcf70364f
Step 5/5 : CMD ["sh", "-c", "gunicorn -b 0.0.0.0:8093 app:app"]
 ---> Running in 3eec73fcd796
Removing intermediate container 3eec73fcd796
 ---> 49b37c6a3133
Successfully built 49b37c6a3133
Successfully tagged eshop-recommendservice:latest
```
<br/>

Once the Docker image build is complete, the .venv environment is no longer needed, so exit the .venv environment using the deactivate command on the WSL console.

```bash
deactivate
```

#### Setting up skaffold

Create a recommendservice.yaml file for skaffold deployment in the k8s directory.

**k8s/recommendservice.yaml** 

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-recommendservice
spec:
  selector:
    matchLabels:
      app: eshop-recommendservice
  template:
    metadata:
      labels:
        app: eshop-recommendservice
    spec:
      terminationGracePeriodSeconds: 5
      containers:
      - name: eshop-recommendservice
        image: eshop-recommendservice
        ports:
        - containerPort: 8093
        env:
          - name: URL_PRODUCTSERVICE
            value: http://eshop-productservice:8092
---
apiVersion: v1
kind: Service
metadata:
  name: eshop-recommendservice
spec:
  type: ClusterIP
  selector:
    app: eshop-recommendservice
  ports:
  - name: api
    port: 8093
    targetPort: 8093
```
<br/>

k8s/ingress.yaml Modify the file as follows:

**k8s/ingress.yaml** 

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: eshop-ingress
  annotations:
    kubernetes.io/ingress.class: "nginx"
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
spec:
  rules:
  - http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: eshop-frontend
            port:
              number: 8080
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /static
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /api/carts
        pathType: Prefix
        backend:
          service:
            name: eshop-cartservice
            port:
              number: 8091
      - path: /api/products
        pathType: Prefix
        backend:
          service:
            name: eshop-productservice
            port:
              number: 8092
      - path: /api/recommends
        pathType: Prefix
        backend:
          service:
            name: eshop-recommendservice
            port:
              number: 8093
```
<br/>

skaffold.yaml Modify the file as follows:

**skaffold.yaml**

```yaml
apiVersion: skaffold/v2beta10
kind: Config
build:
  artifacts:
    - image: eshop-recommendservice
      context: eshop-recommendservice
    - image: eshop-productservice
      context: eshop-productservice
    - image: eshop-cartservice
      context: eshop-cartservice
      jib:
        type: gradle
    - image: eshop-backend
      context: eshop-backend
      jib:
        type: gradle
    - image: eshop-frontend
      context: eshop-frontend
deploy:
  kubectl:
    manifests:
      - k8s/**.yaml
```
<br/>

### Removing existing referral related code from eshop-backend

Since there are no other parts in eshop-backend that use the recommend package, delete the recommend package itself.

<br/><br/>

## Measure

Try starting the service using skaffold.

```bash
skaffold dev
```

When accessing the localhost:8080/api/recommends path in a web browser, check whether an eshop-recommendservice log similar to the following is displayed.
```shell
[eshop-recommendservice] recommendations : {'recommendations': [{'_id': '61c3f7f8b4c65fbf26bba4a9', 'id': 'LS4PSXUNUM', 'name': 'Metal Camping Mug', 'description': "You probably don't go camping that often but this is better than plastic cups.", 'picture': '/static/img/products/camp-mug.jpg', 'categories': ['cookware'], 'priceUsd': {'currencyCode': 'USD', 'units': 24, 'nanos': 330000000, '_id': '61c3f7f8b4c65fbf26bba4aa'}, '__v': 0}, {'_id': '61c3f7f8b4c65fbf26bba4a1', 'id': '1YMWWN1N4O', 'name': 'Home Barista Kit', 'description': 'Always wanted to brew coffee with Chemex and Aeropress at home?', 'picture': '/static/img/products/barista-kit.jpg', 'categories': ['cookware'], 'priceUsd': {'currencyCode': 'USD', 'units': 124, '_id': '61c3f7f8b4c65fbf26bba4a2'}, '__v': 0}, {'_id': '61c3f7f8b4c65fbf26bba49d', 'id': 'OLJCESPC7Z', 'name': 'Vintage Typewriter', 'description': 'This typewriter looks good in your living room.', 'picture': '/static/img/products/typewriter.jpg', 'categories': ['vintage'], 'priceUsd': {'currencyCode': 'USD', 'units': 67, 'nanos': 990000000, '_id': '61c3f7f8b4c65fbf26bba49e'}, '__v': 0}, {'_id': '61c3f7f8b4c65fbf26bba49f', 'id': '66VCHSJNUP', 'name': 'Vintage Camera Lens', 'description': "You won't have a camera to use it and it probably doesn't work anyway.", 'picture': '/static/img/products/camera-lens.jpg', 'categories': ['photography', 'vintage'], 'priceUsd': {'currencyCode': 'USD', 'units': 12, 'nanos': 490000000, '_id': '61c3f7f8b4c65fbf26bba4a0'}, '__v': 0}]}
```
It was confirmed that recommendation-related requests were properly routed to eshop-recommendservice.

When you access the service through a web browser and select a specific product, you can check the processing by eshop-recommendservice.

![](images/1-3/image37.tmp)

![](images/1-3/image38.tmp)

<br/>

## Deploy to AWS EC2

A total of 5 Docker images, including a separate shopping cart service.
-frontend
-backend
- eshop-cartservice
- eshop-productservice
- eshop-recommendservice

Let's upload to AWS ECR and launch a container using the images above on EC2 previously configured.
<br>
(Implementing the ingress role through nginx reverse proxy and launching containers through docker compose)

<br/>

![](images/1-3/EC2_2_3.png)

<br/>

### Verify functionality after creating a container in AWS EC2

Function operation check (common)

**Let’s look at the screens below and check if each function is working properly**

- Upon first access

![](images/1-3/image24.png)

- When clicking on a product (product details)

![](images/1-3/image25.png)

- Shopping cart screen (before ordering)

![](images/1-3/image26.png)

- After ordering

![](images/1-3/image27.png)

<br/>

## **💡Troubleshooting💡** ##

<br/>
[ 🐳 참고  👉 <a href="./1w-troubleshooting.md">1w-troubleshooting.md</a>]
<br/>

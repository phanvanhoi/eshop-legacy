## 도전과제 3-1
Application Load Balancer(이하 ALB)를 생성하여 EC2의 Backend 서비스를 구축 해보자.

ALB - Target Group - EC2(legacyProd)

![](images/1-ch/1w-d3-challenge-arch.png)

<br>

### 수행 전에 EC2상 8080 포트가 열려있는 상태여야 한다. 
즉, `docker compose up` 또는 `docker compose up -d` 명령어로서 eshop 전체가 실행되어 있어야 한다. 왜냐하면 AWS의 load balancer 가 target group의 목적지에 대한 health check를 연결하기 전에 사전 수행하기 때문이다. 

<br>

### AWS Target Group 생성
- EC2 > Instances > Target Groups 클릭하여 생성한다.
> |항목| 내용                                          |
> |---|---------------------------------------------|
> |➕ Basic configuration | `Instances`                                 |
> |➕ Target group name | `legacy-tg`                                 |
> |➕ Protocol | `HTTP`                                      |
> |➕ Port | `8080`                                      |
> |➕ VPC | `N.Virginia(us-east-1) Region의 default VPC` |
> |➕ Protocol version | `HTTP1`                                     |
> |➕ Health check protocol | `HTTP`                                      |
> |➕ Health check path | `/`                                         |

Register targets

> legacyProd 인스턴스 선택 후 `Include as pending below`

생성 후 매핑된 ELB가 없으므로, `pending`으로 표기되는 것이 확인된다.

<br>

### AWS ALB 생성
- EC2 > Load Balancers 클릭하여 생성한다.

> |항목|내용|
> |---|---|
> |➕ Load balancer name | `legacy-lb` |
> |➕ Scheme | `Internet-facing` |
> |➕ IP address type |`IPv4`|
> |➕ Mappings |`legacyProd` EC2가 생성된 subnet을 포함한 다른 서브넷 중 택1 (ex) a, d zone |
> |➕ Security groups | `legacy-lb-sg` 생성 및 Inbound My IP 80 // My IP 443 포트 허용 추가 후 `legacy-lb-sg`로 지정|
> |➕ Listeners and routing | Listener HTTP:80 default action에 legacy-tg 추가|

Create load balancer 클릭 후 생성

<br>

### EC2의 Security Group에 ALB Security Group을 허용
- EC2 > legacyProd 인스턴스의 SG의 Inbound에 룰 추가
- `legacy-lb-sg`의 8080 포트 엑세스를 허용한다. 
- Security Group 허용 후 TG의 EC2가 바로 Healthy가 안되면, Deregister했다가 다시 Register 해준다.

### ALB DNS Name을 호출하여 eshop 서비스 엑세스해본다.
(ex) http://legacy-lb-1205034915.us-east-1.elb.amazonaws.com

<br>
<br>

## 도전과제 3-2
ALB에 SubDomain을 입혀서 호출해보자. (Route 53 레코드 추가)
(ex) http://eshop-legacy.seant2hub.click

### AWS Route53 서비스에 접근하여 도메인 레코드를 생성한다.

- 개인 도메인 Hosted Zone에 들어간다.
- Create Record

방법1.  
> |항목|내용|
> |---|---|
> |➕ Record name | `eshop-legacy` |
> |➕ Record type | `CNAME` |
> |➕ Value |`ALB의 DNS Name`|


방법2.  
> |항목| 내용                                               |
> |---|--------------------------------------------------|
> |➕ Record name | `eshop-legacy`                                   |
> |➕ Record type | `A Record`                                       |
> |➕ Alias | `활성화`                                            |
> |➕ Route traffic to | `Alias to Application and Classic Load Balancer` |
> |➕ Region | `us-east-1`                                      |
> |➕ Choose load balancer | `dualstack.ALB DNS Name`                         |
> |➕ Routing policy | `Simple routing`                                 |
> |➕ Evaluate target health | `Yes`                                            |

<br>

### http://도메인을 호출하여 eshop 서비스 엑세스해본다.
(ex) http://eshop-legacy.seant2hub.click

<br>
<br>

## 도전과제 3-3 (ALB Listener 설정)
ALB에 1일차에 생성한 ACM 인증서를 입혀서 호출해보자.

HTTP (80)

HTTPS (443)

(ex) https://eshop-legacy.seant2hub.click

<br>

### EC2 > Load balancers > legacy-lb : Add listener HTTPS protocol 추가
- default actions > Forward to > `legacy-tg` Weight은 `1`로 한다.
- Secure listener settings 중 From ACM에서 개인이 생성한 ACM 인증서를 셀렉트 `*.개인도메인.click`

<br>

### http://도메인을 호출하여 eshop 서비스 엑세스해본다. 
(ex) https://eshop-legacy.seant2hub.click

<br>

### 최종적으로 TLS 호출만 허용할 것이기 때문에 HTTP*(80) 리스너는 삭제해준다. (TLS Only)

- 이후 https 호출만 서비스에 inbound됨을 확인할 수 있다.

<br>

# **4. Micro Service Separation (2)**

- [**4. Micro Service Separation (2)**](#4-micro-service-separation-2)
   - [**Final Goal**](#Final Goal)
- [**4-1. Exchange rate service separation**](#4-1-Exchange rate-service-separation)
   - [Intro](#intro)
     - [Looking at the implementation of the existing exchange rate](#Existing-exchange-rate-implementation-Looking at)
     - [Technology structure selection](#technology-structure-selection)
   - [Build](#build)
     - [Create exchange rate service](#Exchange rate-Service-Create)
     - [Prepare initial data](#Initial-data-Prepare)
     - [Implementing a service](#Service-Implementing)
     - [Exchange rate service k8s distribution settings](#Exchange rate-service-k8s-distribution-settings)
     - [Remove exchange rate service-related codes from eshop-backend](#Remove exchange rate-service-related-codes from eshop-backend)
   - [Measure](#measure)
   - [Try deploying to AWS EC2](#Try deploying to aws-ec2)
     - [Verify functionality after creating a container on AWS EC2] (#Verify functionality after creating a container on AWS EC2)
- [**4-2. Asynchronous communication structure**](#4-2-Asynchronous-communication-structure)
- [Architecture](#architecture)
   - [Related Concept](#Related-Concept)
     - [Asynchronous Messaging](#Asynchronous-Messaging)
     - [Event notification pattern](#event-notification-pattern)
   - [Build](#build-1)
     - [Rabbitmq configuration](#rabbitmq-config)
     - [Implementing event publication](#event-issuance-implementation)
     - [Implementing event reception](#event-receiving-implementation)
   - [Measure](#measure-1)
   - [Deploy images to AWS EC2 (docker compose method)] (#Distribute images to AWS EC2-docker-compose-method)
     - [One. docker image push to ECR](#1-docker-image-push-to-ecr)
     - [2. EC2 basic utility installation (can be omitted if done on day 2)](#2-ec2-basic-utility-installation-can be omitted if done on day 2)
       - [awscli install aws configure](#awscli-install-aws-configure)
       - [Add docker sudo permission group, ecr login](#docker-sudo-permission-group-add-ecr-login)
       - [Structure for docker compose](#docker-compose-for-structure)
     - [3. Add Nginx Config file](#3-nginx-config-file-add)
     - [4. compose.yaml file and docker compose up](#4-composeyaml-file-and-docker-compose-up)
- [**4-3. Advertising service separation**](#4-3-Advertising service-separation)
   - [Intro](#intro-1)
     - [Looking at existing advertising implementation](#Existing-Advertising-Implementation-Looking at)
     - [Technology structure selection](#technology-structure-selection-1)
   - [Build](#build-2)
     - [Create advertising service](#Advertising-service-Creating)
     - [Advertising service k8s distribution settings](#Advertising-service-k8s-distribution-settings)
     - [remove-ad-related-code-and-postgresql-repository-settings-from-eshop-backend](#remove-ad-related-code-and-postgresql-repository-settings-from-eshop-backend)
   - [Measure](#measure-2)
   - [Try deploying to AWS EC2](#Try deploying to AWS EC2-1)
     - [Functionality verification after container creation in AWS EC2](#aws-ec2-after-container-creation-function-verification-1)
   - [AWS resource cleanup](#aws-resource-cleanup)
   - [**💡Troubleshooting💡**](#troubleshooting)


<br/><br/>

---
## **Final Goal**

- Establishment of MSA asynchronous communication structure
- Perform MSA separation - Exchange rate, advertising service separation
---
<br/><br/>


# **4-1. Separate exchange rate service**

![](images/1-4/image107.png)
![](images/1-4/EC2-2-3-2.png)

<br/>

## Intro

### Explore existing exchange rate implementations

> The existing exchange rate implementation is located in the currency package of eshop-backend.

> ![](images/1-4/image39.tmp)

> CurrencyController는 '/currencies', '/currencies/convert' Processing two requests RestController am. The actual processing logic is CurrencyService delegate to

> CurrencyService Processes business logic related to exchange rates and uses CurrencyRepository for data inquiry (no storage function).

> CurrencyRepository is a JPA CrudRepository implementation and is declared to handle basic CRUD of Currency. There is no separately added interface.

> Currency is a JPA Entity. Excluding the id used as a key in the existing DB, it has a Key-Value type structure.

> CurrencyConvertRequest is a Value Object that is received as an input value in the exchange rate conversion function.

<br/>

### Technical structure selection

| **Design Decisions** | **Rationale** | **Retired alternative**         |
|-----------|------------------------------|---------------------------|
Instead of using a separate data storage, data in the form of a file is loaded into in-memory when starting a service instance. | •	Exchange rate data has a very small data size and does not require separate add/delete operations. <br/> •  | •	PostgreSQL <br/> - Existing implementations exist <br/> - there is an overhead as various query functions are not needed for a list of exchange rates.|
Node.js was selected as the development language and Express was selected as the development framework|• Service startup/stop speed is fast, so it is more advantageous when configuring Auto Scaling<br/>• It runs with less memory compared to Spring Boot, so more service instances can be installed. It can be floated and is advantageous in terms of usability<br/>• The framework is simple and easy to use, making it easier to transfer existing logic| •	Spring Boot <br/>-	Easy to transfer business logic because an existing implementation exists<br/>- Slow startup/shutdown speed during auto scaling compared to Express (scalability -)<br/>- Due to the size of the JVM, basic memory usage is lower than that of Express. Because it is high, the number of service instances that can be launched is less than that of Express (scalability -)|


<br/>

## Build

### 환율 서비스 생성하기

> 프로젝트 루트 디렉토리에 eshop-currencyservice 디렉토리를 생성한다.

![](images/1-4/image40.tmp)

<br/>

> Create a package.json file in the eshop-currencyservice directory using the npm init command as follows.

> **npm init**

```bash
npm init --yes
```

> Enter the following to install the necessary packages.

> **npm install**

```bash
npm install express dotenv body-parser --save
```

> Create a .gitignore file in the eshop-currencyservice directory with the following content.

> **.gitignore** 
```bash
# Logs
logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
lerna-debug.log*

# Diagnostic reports (https://nodejs.org/api/report.html)
report.[0-9]*.[0-9]*.[0-9]*.[0-9]*.json

# Compiled binary addons (https://nodejs.org/api/addons.html)
build/Release

# Dependency directories
node_modules/

# Optional npm cache directory
.npm


# dotenv environment variables file
.env
.env.test


# Stores VSCode versions used for testing VSCode extensions
.vscode-test
```
<br/>

### 초기 데이터 준비하기

> eshop-currencyservice Create a data directory under the directory and create the initial-data.json file as follows.

**data/initial-data.json** 
```json
{
  "EUR": "1.0",
  "USD": "1.1305",
  "JPY": "126.40",
  "BGN": "1.9558",
  "CZK": "25.592",
  "DKK": "7.4609",
  "GBP": "0.85970",
  "HUF": "315.51",
  "PLN": "4.2996",
  "RON": "4.7463",
  "SEK": "10.5375",
  "CHF": "1.1360",
  "ISK": "136.80",
  "NOK": "9.8040",
  "HRK": "7.4210",
  "RUB": "74.4208",
  "TRY": "6.1247",
  "AUD": "1.6072",
  "BRL": "4.2682",
  "CAD": "1.5128",
  "CNY": "7.5857",
  "HKD": "8.8743",
  "IDR": "15999.40",
  "ILS": "4.0875",
  "INR": "79.4320",
  "KRW": "1275.05",
  "MXN": "21.7999",
  "MYR": "4.6289",
  "NZD": "1.6679",
  "PHP": "59.083",
  "SGD": "1.5349",
  "THB": "36.012",
  "ZAR": "16.0583"
}
```

<br/>

### Implementing the service

> eshop-currencyservice Create an index.js file in the directory with the following content.

> **eshop-currencyservice/index.js** 
```js
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const data = require('./data/initial-data.json');
const dotenv = require('dotenv');
dotenv.config();

const port = process.env.PORT || 8094;

app.use(bodyParser.json());

app.get('/api/currencies', (req, res) => {
  console.log("All Currencies")
  res.send(data)
})

app.post('/api/currencies/convert', (req, res) => {
	const from = req.body.from;
	const to_code = req.body.to_code;

  console.log("convert from : " + from.currencyCode + ", to : " + to_code + ", units : " + from.units + ", nanos :" + from.nanos);

  const euros = {
    units: from.units / data[from.currencyCode],
    nanos: Math.round(from.nanos / data[from.currencyCode])
  };

  const result = {
		currencyCode: to_code,
    units: Math.floor(euros.units * data[to_code]),
    nanos: Math.floor(euros.nanos * data[to_code])
  };
  
  res.send(JSON.stringify(result))
})

app.listen(port, function(){
    console.log("Currency service has started on port " + port)
})
```
<br/>

### Setting up exchange rate service k8s deployment

> eshop-currencyservice Create a Dockerfile with the following content in the directory.

> **eshop-currencyservice/Dockerfile** 
```bash
# build stage
FROM node:16.18-alpine as build-stage
WORKDIR /app
COPY package*.json ./
RUN npm set strict-ssl false --global
RUN npm ci --only=production
COPY . .
 
EXPOSE 8094
CMD ["node", "index.js"]
```
<br/>

> Create a currencyservice.yaml file for skaffold deployment in the k8s directory.

**k8s/currencyservice.yaml** 
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-currencyservice
spec:
  selector:
    matchLabels:
      app: eshop-currencyservice
  template:
    metadata:
      labels:
        app: eshop-currencyservice
    spec:
      terminationGracePeriodSeconds: 5
      containers:
      - name: eshop-currencyservice
        image: eshop-currencyservice
        ports:
        - containerPort: 8094
        env:
        - name: PORT
          value: "8094"
        resources:
          requests:
            cpu: 100m
            memory: 64Mi
          limits:
            cpu: 200m
            memory: 128Mi
---
apiVersion: v1
kind: Service
metadata:
  name: eshop-currencyservice
spec:
  type: ClusterIP
  selector:
    app: eshop-currencyservice
  ports:
  - name: api
    port: 8094
    targetPort: 8094
```

<br/>

> Modify the k8s/ingress.yaml file as follows so that eshop-currencyservice handles the exchange rate-related API.

> **k8s/ingress.yaml** 
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: eshop-ingress
  annotations:
    kubernetes.io/ingress.class: "nginx"
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
spec:
  rules:
  - http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: eshop-frontend
            port:
              number: 8080
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /static
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /api/carts
        pathType: Prefix
        backend:
          service:
            name: eshop-cartservice
            port:
              number: 8091
      - path: /api/products
        pathType: Prefix
        backend:
          service:
            name: eshop-productservice
            port:
              number: 8092
      - path: /api/recommends
        pathType: Prefix
        backend:
          service:
            name: eshop-recommendservice
            port:
              number: 8093
      - path: /api/currencies
        pathType: Prefix
        backend:
          service:
            name: eshop-currencyservice
            port:
              number: 8094

```

> To deploy the exchange rate service, modify the skaffold.yaml file as follows.

> **skaffold.yaml** 
```yaml
apiVersion: skaffold/v2beta10
kind: Config
build:
  artifacts:
    - image: eshop-currencyservice
      context: eshop-currencyservice
    - image: eshop-recommendservice
      context: eshop-recommendservice
    - image: eshop-productservice
      context: eshop-productservice
    - image: eshop-cartservice
      context: eshop-cartservice
      jib:
        type: gradle
    - image: eshop-backend
      context: eshop-backend
      jib:
        type: gradle
    - image: eshop-frontend
      context: eshop-frontend
deploy:
  kubectl:
    manifests:
      - k8s/**.yaml
```
<br/>

### Remove exchange rate service related code from eshop-backend

- Since there is no part in eshop-backend that directly uses the code of the currency package, delete the currency package.
- In import.sql, the section inserted into the currency table is deleted because it is no longer needed. The insert statement remains only in relation to the ad table.

**import.sql**
```sql
INSERT INTO ad (category, redirect_url, text) VALUES ('photography','/products/2ZYFJ3GM2N','Film camera for sale. 50% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('vintage','/products/2ZYFJ3GM2N','Film camera for sale. 50% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('photography','/products/66VCHSJNUP','Vintage camera lens for sale. 20% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('vintage','/products/66VCHSJNUP','Vintage camera lens for sale. 20% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('vintage','/products/0PUK6V6EV0','Vintage record player for sale. 30% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('cycling','/products/9SIQT8TOJO', 'City Bike for sale. 10% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('cookware','/products/1YMWWN1N4O', 'Home Barista kitchen kit for sale. Buy one, get second kit for free');
INSERT INTO ad (category, redirect_url, text) VALUES ('gardening','/products/6E92ZMYYFZ', 'Air plants for sale. Buy two, get third one for free');
INSERT INTO ad (category, redirect_url, text) VALUES ('gardening','/products/L9ECAV7KIM', 'Terrarium for sale. Buy one, get second one for free');
```

<br/>

## Measure

> Start the service and check whether eshop-currencyservice processes the exchange rate inquiry API.

```bash
skaffold dev
```

> If you access the service through a web browser and refresh the initial screen, you can check the following log.

```bash
[eshop-currencyservice] All Currencies
```

<br/>

> If you access localhost:8080/api/currencies in a web browser, you can see that the exchange rate API is being called normally.

![](images/1-4/image41.tmp)

<br/>

## Deploy to AWS EC2

> Let’s upload a total of 6 Docker images, including the separated shopping cart service, to AWS ECR and launch a container using the above images on EC2 previously configured.

- frontend
- backend
- eshop-cartservice
- eshop-productservice
- eshop-recommendservice
- eshop-currencyservice  
  
(Implementing the ingress role through nginx reverse proxy and launching containers through docker compose)

<br/>

![](images/1-4/EC2_2_3_2.png)

<br/>

### Verify functionality after creating a container in AWS EC2

> Function operation check (common)

<br/>

> **Let’s look at the screens below and check if each function is working properly**

- Upon first access

![](images/1-4/image24.png)

- When clicking on a product (product details)

![](images/1-4/image25.png)

- Shopping cart screen (before ordering)

![](images/1-4/image26.png)

- After ordering

![](images/1-4/image27.png)

<br/>



<br/><br/>
<br/>


<br>

#**4-2. Asynchronous communication structure**

![](images/1-4/image109.png)
![](images/1-4/EC2-2-4.png)

<br/>

> All calls between services use the synchronous REST API.

> Shopping cart inquiry and product inquiry are essential business logic for normal ordering, so if they fail, let's assume that the ordering transaction itself will fail.

> Emptying the shopping cart is not an essential function for order creation, but there may be cases where the transaction fails because the result of the empty shopping cart call is not received when order creation is completed. If this situation occurs, there are concerns about a decrease in user experience and sales.

> However, after order creation is complete, the shopping cart must be emptied before the customer places a new order.

> The requirements are as follows.
- I hope that order creation does not fail regardless of the processing result of the shopping cart empty request.
- If the shopping cart service cannot immediately process a request to empty the shopping cart, I hope that the request will not disappear and will be processed at a later date.

<br/>
# Architecture

| **Design Decisions** | **Rationale** |
|-----------|------------------------------|
|Apply the asynchronous event notification pattern to the shopping cart emptying request of the order function.| • The Place Order function is not interested in the response outcome of the empty shopping cart request, so it can only send a notification at the time of order creation and complete the transaction. <br/>• Utilizing an asynchronous messaging infrastructure, even if the shopping cart service cannot process the request right away, the request can be preserved and processed later or processed by another instance with available resources.|
|Select Rabbitmq as the message broker.|• Rabbitmq is a commonly used message broker.<br/>• The current system size is small to use Kafka, and the number of transmitted messages is not large.<br/>• By providing spring-boot-starter-amqp, it can be easily configured with the Spring Boot framework used in eshop-backend and eshop-cartservice.|
<br/>
## Related concepts

### Asynchronous Messaging

![](images/1-4/image42.tmp)

Source: Theory textbook
- Interaction in the form of issuing and receiving ‘messages’
- Designed on the premise that the message sender will not receive a response immediately
- Blocks after issuing message and does not wait for response
- Response is processed by receiving a separate message
- A message broker is needed to deliver messages.

<br/>

### Event notification pattern

![](images/1-4/image43.tmp)

Source: Theory textbook
- Pattern for delivering state change events to interested recipients
- Delivery can be guaranteed by messaging infrastructure

<br/>

## Build

### Rabbitmq configuration

Create the k8s/rabbitmq.yaml file with the following content.
**k8s/rabbitmq.yaml** 
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: rabbitmq
spec:
  selector:
    matchLabels:
      app: rabbitmq
  template:
    metadata:
      labels:
        app: rabbitmq
    spec:
      containers:
      - name: rabbitmq
        image: rabbitmq:3.8.9-alpine
        ports:
        - containerPort: 5672
---
apiVersion: v1
kind: Service
metadata:
  name: rabbitmq
spec:
  type: ClusterIP
  selector:
    app: rabbitmq
  ports:
  - port: 5672

```

<br/>

### Implement event publishing

Add dependencies to the dependencies block of eshop-backend's build.gradle as follows.

**eshop-backend/build.gradle**

```bash
implementation 'org.springframework.boot:spring-boot-starter-amqp'
```
![](images/1-4/image44_1.png)

<br/>
Add the SPRING_RABBITMQ_HOST environment variable to k8s/backend.yaml.

**k8s/backend.yaml**
```yaml
env:
- ...
- name: SPRING_RABBITMQ_HOST
  value: rabbitmq
```

![](images/1-4/image45.tmp)

<br/>

com.samsungsds.eshop.config Create a RabbitConfig.java file in the package with the following content.

**eshop-backend/src/main/java/com/samsungsds/eshop/config/RabbitConfig.java** 
```java
package com.samsungsds.eshop.config;

import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {
  @Bean
  RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory, MessageConverter messageConverter) {
    RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
    rabbitTemplate.setMessageConverter(messageConverter);
    return rabbitTemplate;
  }
  @Bean
  MessageConverter messageConverter() {
    return new Jackson2JsonMessageConverter();
  }
}

```
<br/>

To send an event object in JSON format, create the OrderPlaced class in the com.samsungsds.eshop.order package as follows.

OrderPlaced.java

**eshop-backend/src/main/java/com/samsungsds/eshop/order/OrderPlaced.java** 
```java
package com.samsungsds.eshop.order;

public class OrderPlaced {
    private String orderId;

    protected OrderPlaced() {
    }

    public OrderPlaced(String orderId) {
        this.orderId = orderId;
    }
 
    public String getOrderId() {
        return orderId;
    }
 
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
 
    @Override
    public String toString() {
        return "OrderPlaced{" +
                "orderId='" + orderId + '\'' +
                '}';
    }
}
```

<br/>
Modify the existing OrderController logic as follows to issue an event, excluding the emptyCart() part.

**eshop-backend/src/main/java/com/samsungsds/eshop/order/OrderController.java** 
```java
...
import org.springframework.amqp.rabbit.core.RabbitTemplate; //addition
...

@RestController
@RequestMapping(value = "/api/checkouts")
public class OrderController {
    ...
    private final RabbitTemplate rabbitTemplate; //addition

    public OrderController(final OrderService orderService, 
    final ShippingService shippingService,
    final  PaymentService paymentService,
    final CartService cartService,
    final ProductService productService,
    final RabbitTemplate rabbitTemplate) { //addition
        this.orderService = orderService;
        this.shippingService = shippingService;
        this.paymentService = paymentService;
        this.cartService = cartService;
        this.productService = productService;
        this.rabbitTemplate = rabbitTemplate; //addition
    }
    
    @PostMapping(value = "/orders")
    public ResponseEntity<OrderResult> placeOrder(@RequestBody OrderRequest orderRequest) {
        ...

        // empty cart
        // cartService.emptyCart(); //comment processing
        
        //Publish event (add)
        rabbitTemplate.convertAndSend("eshop-exchange","order.placed", new OrderPlaced(orderId));

        return ResponseEntity.ok(new OrderResult(orderId, shippingResult.getShippingTrackingId(),
                shippingResult.getShippingCost(), totalCost));
    }
    ...
}
```
Add the contents of lines #2, #9, #16, #22, and #32~#36, and comment out or delete lines #29~#30.


<br/>

### Implementing event reception

Add dependencies to the dependencies block in build.gradle of eshop-cartservice as follows.

**eshop-cartservice/build.gradle**
```bash
implementation 'org.springframework.boot:spring-boot-starter-amqp'
```
![](images/1-4/image46.tmp)

<br/>
Add the SPRING_RABBITMQ_HOST environment variable to k8s/cartservice.yaml.
**k8s/cartservice.yaml**
```yaml
env:
- ...
- name: SPRING_RABBITMQ_HOST
  value: rabbitmq
```

![](images/1-4/image47.tmp)

<br/>
To receive an event object in JSON format, create the OrderPlaced class in the com.samdungsds.eshop.cart package as follows. For Json conversion, you must add a default constructor as protected.

**eshop-cartservice/src/main/java/com/samsungsds/eshop/cart/OrderPlaced.java** 
```java
package com.samsungsds.eshop.cart;
 
public class OrderPlaced {
    private String orderId;
  
    protected OrderPlaced() {

    }
    
    public OrderPlaced(String orderId) {
        this.orderId = orderId;
    }
  
    public String getOrderId() {
        return orderId;
    }
  
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
  
    @Override
    public String toString() {
        return "OrderPlaced{" +
                "orderId='" + orderId + '\'' +
                '}';
    }
}
```
<br/>
com.samsungsds.eshop.config Create a RabbitConfig.java file in the package with the following content.

**eshop-cartservice/src/main/java/com/samsungsds/eshop/config/RabbitConfig.java** 
```java
package com.samsungsds.eshop.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {
  static final String exchangeName = "eshop-exchange";
  static final String queueName = "eshop-queue";

  @Bean
  Queue queue() {
    return new Queue(queueName, false);
  }

  @Bean
  TopicExchange exchange() {
    return new TopicExchange(exchangeName);
  }

  @Bean
  Binding binding(Queue queue, TopicExchange exchange) {
    return BindingBuilder.bind(queue).to(exchange).with("order.placed");
  }

  @Bean
  MessageConverter messageConverter() {
    return new Jackson2JsonMessageConverter();
  }

  @Bean
  RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory, MessageConverter messageConverter) {
    RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
    rabbitTemplate.setMessageConverter(messageConverter);
    return rabbitTemplate;
  }  
}
```
<br/>
com.samsungsds.eshop.cart.CartEventListener.java Create the file as follows.

**eshop-cartservice/src/main/java/com/samsungsds/eshop/cart/CartEventListener.java** 
```java
package com.samsungsds.eshop.cart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class CartEventListener {
  private final Logger logger = LoggerFactory.getLogger(CartEventListener.class);
  private final CartService cartService;

  public CartEventListener(CartService cartService) {
    this.cartService = cartService;
  }

  @RabbitListener(queues = "eshop-queue")
  public void receiveMessage(final OrderPlaced orderPlaced) {
    // empty cart
    logger.info("empty Cart : {}", orderPlaced.getOrderId());
    cartService.emptyCart();
  }
}

```
<br/>

## Measure

> Start the service using skaffold.

```bash
skaffold dev
```

> After running the service using skaffold, you can check that a rabbitmq instance has been created by entering the following.
```bash
$ kubectl get pod
NAME                                      READY   STATUS    RESTARTS   AGE
eshop-adservice-66c9f5fb8f-8vvp5          1/1     Running   0          25s
eshop-backend-5b575c64f5-nd446            1/1     Running   0          24s
eshop-cartservice-6cdd667fc9-qnw2t        1/1     Running   0          24s
eshop-currencyservice-66775bb559-ft8l8    1/1     Running   0          24s
eshop-frontend-69cd866946-9c68t           1/1     Running   0          24s
eshop-productservice-55d5b94db-69qdj      1/1     Running   0          23s
eshop-recommendservice-5488fff9b5-88srw   1/1     Running   0          23s
mongodb-0                                 1/1     Running   0          24s
postgres-755bd87f85-kjfr8                 1/1     Running   0          24s
rabbitmq-5d858fff4b-mp7nm                 1/1     Running   0          23s
redis-56bc58d996-zjr2s                    1/1     Running   0          23s
```

<br/>

> Access your web browser, add products to your shopping cart, and place an order.

> ![](images/1-4/image48.tmp)

> You can check the log of messages sent/received through Rabbitmq as follows.
> Because it is processed asynchronously, the log output order may not be consistent.
```shell
[eshop-backend] 2021-12-27 01:37:31.212  INFO 1 --- [nio-8090-exec-7] o.s.a.r.c.CachingConnectionFactory       : Attempting to connect to: [rabbitmq:5672]
[eshop-backend] 2021-12-27 01:37:31.310  INFO 1 --- [nio-8090-exec-7] o.s.a.r.c.CachingConnectionFactory       : Created new connection: rabbitConnectionFactory#5edc67dd:0/SimpleConnection@7a83257b [delegate=amqp://guest@10.109.118.90:5672/, localPort= 52456]
[eshop-cartservice] 2021-12-27 01:37:31.413  INFO 1 --- [ntContainer#0-7] c.s.eshop.cart.CartEventListener         : empty Cart : ORDER-440ca3b3-4ebd-4aaa-8f17-0fb7605ccece
[eshop-cartservice] 2021-12-27 01:37:31.414  INFO 1 --- [ntContainer#0-7] com.samsungsds.eshop.cart.CartService    : emptyCart()
```

<br/>
## Deploy images to AWS EC2 (docker compose method)

> **This is a device that allows mentees to think about how to launch a container on their own, without actively requiring the process to launch a service container on EC2.**

> There may be several ways.
- Execute individual containers using environment variables and connect to docker network
- Include the ingress implementation and run it all at once with docker compose
- Create a container using the manifest by configuring the K8S Cluster environment
- etc\...

> Here, only the docker compose execution that uses nginx as a reverse proxy to perform the ingress function is included.

<br/>

> **The steps to upload to EC2** are as follows. To explain first,

1. Renew the docker image build locally and upload it to ECR**

2. Upload proxy/ and compose.yaml using nginx on EC2, modify only the image name of docker compose to match, and then **docker compose up**

3. Connect using EC2 IP and Port (80).

<br/>

❗If you cannot connect when `docker compose up` in local or the API call does not work properly when using frontend, check the two things below.
- Is it connected to port 80?
- If localhost does not work, try changing it to 127.0.0.1.

<br/>



<br/>

### 1. docker image push to ECR

**docker push**
```sh
# It is assumed that Docker, awscli, aws configure, and docker commands are sudoed in the local environment.
# Check existing Docker image
docker images

# docker build using jib
./gradlew jibDockerBuild

# docker build using Dockerfile
docker build -t <<service name>>:<<tag name>> .
```
```sh
# ECR login (see "View push commands" in AWS ECR)
aws ecr get-login-password --region <<ECR region>> | docker login --username AWS --password-stdin <<ECR URI>>/<<SERVICE NAME>>
```
```sh
# Change tag name
docker tag <<IMAGE>>:<<TAG>> <<ECR_URI>>/<<SERVICE NAME>>:<<TAG>>
```
```sh
# docker push (image based on ECR URI created earlier)
docker push <<ECR_URI>>/<<SERVICE NAME>>:<<TAG>>
```
<br/>

### 2. EC2 basic utility installation (can be omitted if done on day 2)

- After configuring the VPC basic environment and running the EC2 instance

- Install required utility docker (always refer to the official website)
**ec2 base set-up**
```sh
sudo apt-get update

sudo apt-get install \
    ca-certificates \
    curl \
    gnupg \
    lsb-release

sudo mkdir -p /etc/apt/keyrings

curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update

sudo apt-get install docker-ce docker-ce-cli containerd.io docker-compose-plugin 

docker --version
```

<br/>

#### awscli installation aws configure

**aws**
```sh
sudo apt-get install awscli

aws --version

aws configure
# AWS Access Key ID [None]: <<AWS Access Key>>
# AWS Secret Access Key [None]: <<AWS Secret Access Key>>
# Default region name [None]: <<ECR Region>>
# Default output format [None]: json
```

❗** Since branches are divided according to the cases where services are divided one by one, a new Docker image must be created and pushed to reflect the changed image. (requires re-creation after reflecting backend, cartservice-rabbitmq)**

<br/>

#### Add docker sudo permission group, ecr login

**let docker be on sudogroup**
```sh
sudo groupadd docker
# groupadd: group 'docker' already exists

sudo usermod -aG docker $USER

newgrp docker

# ECR login
aws ecr get-login-password --region <<region>> | docker login --username AWS --password-stdin <<AWS Account>>.dkr.ecr.<<ECR_Region>>.amazonaws.com
```

<br/>

#### Structure for docker compose

**basic structure for docker compose**

```sh
mkdir eshop
cd eshop

mkdir proxy

touch compose.yaml
touch proxy/nginx.conf
```

<br/>

### 3.Add Nginx Config File

> Copy and paste the contents of nginx.conf into the ~/eshop/proxy/nginx.conf file (path may vary depending on the name of the directory you created)

> Based on nginx.conf including rabbitmq, it is as follows.

<details>
<summary><span style="font-weight:bold">nginx.conf</span>  [Expand👇]  </summary>
<div ref="1">

```js
user nginx;
worker_processes auto;
error_log  /var/log/nginx/error.log warn;
pid        /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include   /etc/nginx/mime.types;
    default_type application/octet-stream;

    upstream eshopfrontend {
        server frontend:8080;
    }

    upstream eshopbackend {
        server backend:8090;
    }

    upstream eshopcartservice {
        server cartservice:8091;
    }

    upstream eshopproductservice {
        server productservice:8092;
    }

    upstream eshoprecommendservice {
        server recommendservice:8093;
    }

    upstream eshopcurrencyservice {
        server currencyservice:8094;
    }

    server {
        listen 80;
        server_name localhost;
        
        location / {
            proxy_pass       http://eshopfrontend;
            proxy_redirect   off;

        }

        location /api {
            proxy_pass      http://eshopbackend;
            proxy_redirect   off;
            proxy_set_header  Host $host;
            proxy_set_header  X-Real-IP $remote_addr;
            proxy_set_header  X-Forwarded-For $proxy_add_x_forwarded_for;
        }

        location /static {
            proxy_pass      http://eshopbackend;
            proxy_redirect   off;
            proxy_set_header  Host $host;
            proxy_set_header  X-Real-IP $remote_addr;
            proxy_set_header  X-Forwarded-For $proxy_add_x_forwarded_for;
        }

        location /api/carts {
            proxy_pass       http://eshopcartservice;
            proxy_redirect   off;

        }

        location /api/products {
            proxy_pass       http://eshopproductservice;
            proxy_redirect   off;

        }

        location /api/recommends {
            proxy_pass       http://eshoprecommendservice;
            proxy_redirect   off;

        }

        location /api/currencies {
            proxy_pass       http://eshopcurrencyservice;
            proxy_redirect   off;

        }

    }

    sendfile on;
    keepalive_timeout 65;
    include /etc/nginx/conf.d/*.conf;

}
```

</div>
</details>

<br/>

### 4. Compose.yaml file and docker compose up

> Copy and paste the contents of compose.yaml into the ~/eshop/compose.yaml file (path may vary depending on the name of the directory you created)

> Only the images in compose.yaml are changed to images and tags pushed to ECR. The standards for compose.yaml, including rabbitmq, are as follows.

<details>
<summary><span style="font-weight:bold">compose.yaml</span> [Expand👇] </summary>
<div ref="1">

```js
version: "3"
services:
  redis:
    image: redis:5.0-alpine
    restart: always
    ports:
      - "6379:6379"
  postgres:
    image: postgres:13
    restart: always
    ports:
      - "5432:5432"
    volumes:
      - ./data/postgres/data:/var/lib/postgresql/data
    environment:
      - POSTGRES_DB=eshop_db
      - POSTGRES_USER=eshop_user
      - POSTGRES_PASSWORD=password
    container_name: eshop_postgres
  mongodb:
    image: mongo:4.0.20
    restart: always
    ports:
      - "27017:27017"
    volumes:
      - ./data/mongodb/data:/var/lib/mongodb/data
    environment:
      - MONGO_INITDB_ROOT_USERNAME=admin
      - MONGO_INITDB_ROOT_PASSWORD=password
    container_name: eshop_mongodb
  rabbitmq:
    image: rabbitmq:3.8.9-alpine
    restart: always
    ports:
      - "5672:5672"
    volumes:
      - ./data/rabbitmq/data:/var/lib/rabbitmq/data
    container_name: eshop_rabbitmq
  backend:
    depends_on:
      - postgres
      - cartservice
      - rabbitmq
    image: <<개인 ECR URI>>/<<SERVICE NAME(backend)>>:<<TAG>>
    ports:
      - "8090:8090"
    environment:
      - SPRING_DATASOURCE_URL=jdbc:postgresql://eshop_postgres:5432/eshop_db
      - URL_PRODUCTSERVICE=http://eshopproductservice:8092
      - URL_CARTSERVICE=http://eshopcartservice:8091
      - SPRING_RABBITMQ_HOST=rabbitmq
    container_name: eshopbackend
  frontend:
    depends_on:
      - backend
    image: <<개인 ECR URI>>/<<SERVICE NAME(frontend)>>:<<TAG>>
    ports:
      - "8080:8080"
    container_name: eshopfrontend
    #command: http-server dist --proxy http://backend:8090
  cartservice:
    depends_on:
      - redis
      - rabbitmq
    image: <<개인 ECR URI>>/<<SERVICE NAME(cartservice)>>:<<TAG>>
    environment:
      - SPRING_REDIS_HOST=redis
      - SPRING_RABBITMQ_HOST=rabbitmq
    ports:
      - "8091:8091"
    container_name: eshopcartservice
  productservice:
    depends_on:
      - mongodb
    image: <<개인 ECR URI>>/<<SERVICE NAME(productservice)>>:<<TAG>>
    environment:
      - PORT=8092
      - MONGO_URI=mongodb://admin:password@mongodb
      - INIT_DATA=true
    ports:
      - "8092:8092"
    container_name: eshopproductservice
  recommendservice:
    depends_on:
      - productservice
    image: <<개인 ECR URI>>/<<SERVICE NAME(recommendservice)>>:<<TAG>>
    environment:
      - URL_PRODUCTSERVICE=http://eshopproductservice:8092
    ports:
      - "8093:8093"
    container_name: eshoprecommendservice
  currencyservice:
    image: <<개인 ECR URI>>/<<SERVICE NAME(currencyservice)>>:<<TAG>>
    ports:
      - "8094:8094"
    container_name: eshopcurrencyservice
  nginx:
    image: nginx:1.21.5-alpine
    ports:
      - "80:80"
    volumes:
      - ./proxy/nginx.conf:/etc/nginx/nginx.conf
    container_name: eshop_nginx_ingress
    depends_on:
      - frontend
      - backend
      - cartservice
      - productservice
      - recommendservice
      - currencyservice
```

</div>
</details>

<br/>

❗ docker compose up from the directory where compose.yaml is located
```sh
docker compose up
```
\# Omit -d to view the log together.


![](images/1-4/EC2_2_4.png)

<br/>

**Let’s look at the screens below and check if each function is working properly**

- Upon first access

![](images/1-4/image24.png)

- When clicking on a product (product details)

![](images/1-4/image25.png)

- Shopping cart screen (before ordering)

![](images/1-4/image26.png)

- After ordering

![](images/1-4/image27.png)

<br/>



<br/>
<br/>

<br/>

# **4-3. Separation of advertising services**

![](images/1-4/image111.png)

![](images/1-4/EC2-2-5.png)

## Intro

### Explore existing ad implementations

> The existing advertising implementation is located in the ad package of eshop-backend.

> ![](images/1-4/image49.tmp)

> AdController searches for advertisements in AdRepository and implements the function of returning random advertisements or advertisements by product category.

**AdController** 
```java
@RestController
@RequestMapping(value="/api/ads")
public class AdController {
    private Logger logger = LoggerFactory.getLogger(AdController.class);
    // private static final ImmutableListMultimap<String, Ad> adsMap = createAdsMap();
    private final AdRepository adRepository;
    private static final Random random = new Random();
    private static final int MAX_ADS_TO_SERVE = 2;

    public AdController(AdRepository adRepository) {
        this.adRepository = adRepository;
    }

    @GetMapping
    @ResponseBody
    public ResponseEntity<List<Ad>> getRandomAds() {
        logger.info("getRandomAds");
        List<Ad> ads = new ArrayList<>(MAX_ADS_TO_SERVE);
        List<Ad> allAds = Lists.newArrayList(adRepository.findAll());
        for(int i = 0; i < MAX_ADS_TO_SERVE; i++) {
            ads.add(Iterables.get(allAds, random.nextInt(allAds.size())));
        }
        logger.info(ads.toString());
        return ResponseEntity.ok(ads);
    }

    @GetMapping(value="/{categories}")
    @ResponseBody
    public ResponseEntity<List<Ad>> getAdsByCategory(@PathVariable String[] categories) {
        logger.info("getAdsByCategory {}", Arrays.toString(categories));
        List<Ad> ads = Lists.newArrayList(adRepository.findByCategoryIn(categories));
        logger.info(ads.toString());
        return ResponseEntity.ok(ads);
    }
}
```

<br/>

AdRepository is a JPA CrudRepository implementation, and the **findByCategoryIn(String[] categories)** interface is additionally declared to retrieve advertisements by receiving basic CRUD and category list.

**AdRepository** 
```java
@Repository
public interface AdRepository extends CrudRepository<Ad, Integer> {
  Iterable<Ad> findByCategoryIn(String[] categories);
}
```
<br/>

Ad is a JPA Entity and consists of the category and content of the ad, and the URL that is redirected when the ad is clicked.
**Ad** 
```java
@Entity
public class Ad {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    
    @Column(nullable = false)
    private String category;

    @Column(nullable = false)
    private String redirectUrl;

    @Column(nullable = false)
    private String text;

    // Getter, Setter, toString()
    ...
}
```

<br/>

### Technical structure selection

| **Design Decisions** | **Rationale** | **Retired alternative**          |
|-----------|------------------------------|---------------------------|
|Select PostgreSQL as data storage|• After separating the advertising service, the existing backend no longer requires storage, so the existing PostgreSQL can be used in the advertising service as is.<br/>• Search data based on a specific column (product category) RDB is suitable for | •	MongoDB <br/> - MongoDB also provides a query function similar to RDB's query<br/> - Discarded because it requires writing code and rewriting queries for DB integration.|
|Java was selected as the development language and Spring Boot as the development framework.|•	Existing logic and PostgreSQL integration implementation can be reused |• Development language Node.js / Development framework Express <br/>- JPA used in the existing implementation cannot be used and the DB integration part must be rewritten, so it is discarded|


<br/>

## Build
### Creating an ad service

> Create an eshop-adservice directory in the project root directory.

> ![](images/1-4/image50.png)

> Copy the following files from eshop-backend to the eshop-adservice directory.
- gradle directory (including sub-wrapper)
- src directory
- .gitignore
-build.gradle
- settings.gradle
- gradlew
- gradlew.bat

> ![](images/1-4/image51.tmp)

> Modify the settings.gradle file of eshop-adservice with the following contents.
```bash
rootProject.name = 'eshop-adservice'
```
<br/>
> Delete irrelevant files from eshop-adservice.

- src/main/test/java/com/samsungsds/eshop subtest implementations
- Remaining packages in addition to ad and config under src/main/java/com/samsungsds/eshop
- src/main/java/com/samsungsds/eshop/EshopApplication.java
- src/main/resources/static directory

<br/>

> src/main/java/com/samsungsds/eshop/EshopAdApplication.java file as follows:
Write with the same content.
**eshop-adservice/src/main/java/com/samsungsds/eshop/EshopAdApplication.java** 
```java
package com.samsungsds.eshop;
 
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
 
@SpringBootApplication
public class EshopAdApplication {
    public static void main(String[] args) {
        SpringApplication.run(EshopAdApplication.class, args);
    }
}
```
<br/>

> src/main/resources/application.properties Modify the contents as follows.

**application.properties** 
```bash
server.port=8095
spring.jpa.show-sql=true
spring.jpa.generate-ddl=true
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQL10Dialect
spring.jpa.hibernate.ddl-auto=create-drop
spring.datasource.initialization-mode=always
spring.datasource.url=jdbc:postgresql://localhost:5432/eshop_db
spring.datasource.username=eshop_user
spring.datasource.password=password
```

<br/>

eshop-adservice The directory and file structure is as follows.

![](images/1-4/image52.tmp)

<br/>

eshop-adservice Build normally by entering the following in the directory:
Check if it works.

```bash
./gradlew build

BUILD SUCCESSFUL in 4s
3 actionable tasks: 3 executed
```

<br/>

### Setting up ad service k8s deployment

Create the k8s/adservice.yaml file with the following content.

**k8s/adservice.yaml** 

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-adservice
spec:
  selector:
    matchLabels:
      app: eshop-adservice
  template:
    metadata:
      labels:
        app: eshop-adservice
    spec:
      containers:
        - name: eshop-adservice
          image: eshop-adservice
          ports:
          - containerPort: 8095
          env:
            - name: SPRING_DATASOURCE_URL
              value: "jdbc:postgresql://postgres:5432/eshop_db"
---
apiVersion: v1
kind: Service
metadata:
  name: eshop-adservice
spec:
  type: ClusterIP
  selector:
    app: eshop-adservice
  ports:
  - port: 8095
```
<br/>

k8s/ingress.yaml Edit the file with the following contents.

**ingress.yaml** 
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: eshop-ingress
  annotations:
    kubernetes.io/ingress.class: "nginx"
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
spec:
  rules:
  - http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: eshop-frontend
            port:
              number: 8080
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /static
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /api/carts
        pathType: Prefix
        backend:
          service:
            name: eshop-cartservice
            port:
              number: 8091
      - path: /api/products
        pathType: Prefix
        backend:
          service:
            name: eshop-productservice
            port:
              number: 8092
      - path: /api/recommends
        pathType: Prefix
        backend:
          service:
            name: eshop-recommendservice
            port:
              number: 8093
      - path: /api/currencies
        pathType: Prefix
        backend:
          service:
            name: eshop-currencyservice
            port:
              number: 8094
      - path: /api/ads
        pathType: Prefix
        backend:
          service:
            name: eshop-adservice
            port:
              number: 8095

```
<br/>

skaffold.yaml Modify the contents of the file as follows.

**skaffold.yaml** 
```yaml
apiVersion: skaffold/v2beta10
kind: Config
build:
  artifacts:
    - image: eshop-currencyservice
      context: eshop-currencyservice
    - image: eshop-recommendservice
      context: eshop-recommendservice
    - image: eshop-productservice
      context: eshop-productservice
    - image: eshop-cartservice
      context: eshop-cartservice
      jib:
        type: gradle
    - image: eshop-backend
      context: eshop-backend
      jib:
        type: gradle
    - image: eshop-adservice
      context: eshop-adservice
      jib:
        type: gradle        
    - image: eshop-frontend
      context: eshop-frontend
deploy:
  kubectl:
    manifests:
      - k8s/**.yaml
```
<br/>

### eshop-backend Remove ad-related code and PostgreSQL storage settings from

> eshop-backend Delete the package src/main/java/com/samsungsds/eshop/ad 

> eshop-backend In src/main/java/com/samsungsds/eshop/cart/CartItem.java file import org.springframework.data.annotation.Id; If there is a line, delete it.

> eshop-backend In src/main/resources/import.sql file, 

> eshop-backend Remove the src/main/java/com/samsungsds/eshop/payment/MoneyConverter.java class.

<br/>

> src/resources/application.properties Modify the contents as follows.

> **eshop-backend/src/main/resources/application.properties** 
```bash
server.port=8090
spring.mvc.static-path-pattern=/static/**
spring.resources.cache.cachecontrol.max-age=3600
#url.cartservice="http://eshop-cartservice:8091"
#url.productservice="http://eshop-productservice:8092"
```
<br/>

> eshop-backend Modify the build.gradle file as follows.

> **build.gradle** 
```bash
plugins {
    id 'org.springframework.boot' version '2.2.6.RELEASE'
    id 'io.spring.dependency-management' version '1.0.9.RELEASE'
    id 'java'
    id 'com.google.cloud.tools.jib' version '2.7.0'
}

group = 'com.samsungsds'
version = '0.0.1-SNAPSHOT'
sourceCompatibility = '11'

configurations {
    developmentOnly
    runtimeClasspath {
        extendsFrom developmentOnly
    }
}

repositories {
    mavenCentral()
}

dependencies {
    implementation 'org.springframework.boot:spring-boot-starter-web'   
    developmentOnly 'org.springframework.boot:spring-boot-devtools'   
    implementation 'com.google.guava:guava:28.2-jre'

    implementation 'org.springframework.boot:spring-boot-starter-amqp'
 
    testImplementation('org.springframework.boot:spring-boot-starter-test') {
        exclude group: 'org.junit.vintage', module: 'junit-vintage-engine'
    }
}

test {
    useJUnitPlatform()
}
```
<br/>

## Measure

> Start the service using skaffold.
```bash
skaffold dev
```
> When accessing the localhost:8080/api/ads path in a web browser, check whether eshop-adservice is processing it.

![](images/1-4/image53.tmp)

> As the following log is displayed, it can be confirmed that advertising-related requests are being routed normally to eshop-adservice.
```shell
[eshop-adservice] Hibernate: select ad0_.id as id1_0_, ad0_.category as category2_0_, ad0_.redirect_url as redirect3_0_, ad0_.text as text4_0_ from ad ad0_
[eshop-adservice] 2020-10-27 03:40:11.475  INFO 1 --- [nio-8095-exec-1] com.samsungsds.eshop.ad.AdController     : [{ id='6', category='cycling', redirectUrl='/products/9SIQT8TOJO', text='City Bike for sale. 10% off.'}, { id='4', category='vintage', redirectUrl='/products/66VCHSJNUP', text='Vintage camera lens for sale. 20% off.'}]
```

>Access the service in a web browser, view the product list, and check whether eshop-adservice returns advertising content normally when a specific product is selected.

![](images/1-4/image54.tmp)

> Even when accessed from the screen, you can see that eshop-adservice is processing related requests.

![](images/1-4/image55.tmp)
<br/>
<br/>

## Deploy to AWS EC2

> Let’s launch a container on the EC2 configured previously.
<br>

> (Implementing the ingress role through nginx reverse proxy and launching containers through docker compose)

<br/>

![](images/1-4/EC2_2_5.png)

<br/>

### Verify functionality after creating a container in AWS EC2

> Function operation check (common)

<br/>
<br/>

## Clean up AWS resources
> **Delete AWS resources (EC2, ALB, etc.) used during the 1st week process.**

<br/><br/>

## **💡Troubleshooting💡** ##

<br/>
[ 🐳 Note 👉 <a href="./1w-troubleshooting.md">1w-troubleshooting.md</a>]
<br/>
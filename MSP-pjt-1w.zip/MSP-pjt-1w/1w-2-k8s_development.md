# **2. Legacy service operation and K8S environment configuration**

- [**2. Legacy service operation and K8S environment configuration**](#2-legacy-service-operation-and-k8s-environment-configuration)
- [**Final Goal**](#Final Goal)
- [**2-1. Establishment of eshop Legacy service operation infrastructure on EC2**](#2-1-eshop-legacy-service-operation-infrastructure-construction on ec2)
   - [2-1-1. Establishment of eshop Legacy service operation infrastructure on EC2](#2-1-1-ec2-eshop-legacy-service-operation-infrastructure-construction)
     - [Start service from EC2 to Docker container] (#Start service from ec2 to docker-container)
     - [Create a repository to upload eshop-frontend and eshop-backend images to ECR] (#Create a repository to upload eshop-frontend-eshop-backend images to ECR)
     - [Create AWS EC2 instance](#aws-ec2-instance-create)
     - [EC2 ssh connection settings using MobaXterm program] (#mobaxterm-program-ec2-ssh-connection-settings)
       - [EC2 basic structure for docker compose](#docker-compose-for-ec2-basic-structure)
     - [Create a docker image in the local environment and push it to ECR] (#Create a docker image in the local environment and then push it to ECR)
     - [One. Change tag so that backend image can be uploaded to ECR](#1-backend-image can be uploaded to ECR)
     - [2. Build the frontend into an image executable on EC2](#2-Build the frontend into an image executable on EC2)
     - [Install Docker and Docker Compose so that the docker image is executable on EC2](#Install-docker-and-docker-compose-so that the docker-image is executable on EC2)
   - [**2-1-2. Starting eshop Legacy service with Docker image in EC2 environment**](#2-1-2-eshop-legacy-service-starting-with-docker-image-in-ec2-environment)
     - [One. awscli install and aws configure](#1-awscli-install-and-aws-configure)
     - [2. ECR login (see ECR's View push commands in AWS console)](#2-ecr-login-aws-console-see ECR's view-push-commands)
     - [3. change my backend / frontend image to reference ECR](#3-composeyaml-change my-backend--frontend-image to reference ECR)
     - [4. Run docker compose up](#4-docker-compose-up-run)
- [**2-2. Build a local K8S environment and API Gateway**](#2-2-local-k8s-environment-and-api-gateway-build)
   - [**2-2-1. Manually run Kubernetes Manifest**](#2-2-1-kubernetes-manifest-manually-run)
       - [As an example, let’s start the nginx service in WSL] (#As an example, let’s start the nginx service in WSL)
       - [0. Check the status of minikube in the WSL environment.](#0-check the status of minikube in the wsl-environment)
       - [One. `nginx.yaml` - Deployment definition](#1-nginxyaml---deployment-definition)
       - [2. `nginx-service.yaml` - Service definition](#2-nginx-serviceyaml---service-definition)
       - [3. `kubectl apply`](#3-kubectl-apply)
       - [4. Check `nginx` operation](#4-nginx-operation-check)
       - [5. `kubectl delete` - **Delete nginx resources deployed as an example**](#5-kubectl-delete---Delete nginx-resources deployed as an example)
     - [🔦 Kubernetes 🔦](#-kubernetes-)
   - [**2-2-2. Running the AS-IS source as a service in the K8S environment**](#2-2-2-As-is-source in the K8S environment)
     - [One. Create Kubernetes Template](#1-kubernetes-template-create)
       - [If you have made it this far, 4 files should be added under the k8s folder as shown below.](#If you have made it this far, 4 files should be added under the k8s folder as shown below. must be)
     - [2. Skaffold settings](#2-skaffold-settings)
     - [3. Measure](#3-measure)
   - [**2-2-3. Application of API Gateway using Ingress**](#2-2-3-Application of API Gateway using Ingress)
       - [Configuration](#Configuration)
     - [One. Architecture](#1-architecture)
     - [**Ingress**](#ingress)
     - [2. Build](#2-build)
     - [3. Measure](#3-measure-1)
   - [2-2-4. Evaluation](#2-2-4-evaluation)
   - [**💡Troubleshooting💡**](#troubleshooting)


---
<br/>

# **Final Goal**
- Configuring eshop Legacy container service and configuring service operating environment in cloud environment
- Establishment of MSA development environment in local environment, API Gateway establishment

<br/><br/>

---
<br>

# **2-1. Establishment of eshop Legacy service operation infrastructure on EC2**
## 2-1-1. Establishment of eshop Legacy service operation infrastructure on EC2
### Starting a service as a Docker container in EC2

> **🚩Goal: Deploy and start a service on AWS EC2 using an application image created in an existing local environment.**

> **Overview**
>
   > If you determine that the development was successful in the local environment, upload it to the Docker repository and deploy it in the operating Linux VM environment.
   > Currently, this is done manually, but in the future, CI/CD will be implemented using automation tools.
   > Upload two self-developed docker images, eshop-backend and eshop-frontend, to ECR.
   > Upload the docker image created by referring to the basic course learning material (part 2.2 of the construction textbook md file) to the eshop-backend and eshop-frontend repositories of ECR created in the AWS management console.

![](images/1-2/image33.png)

### Create a repository to upload eshop-frontend and eshop-backend images to ECR
- After logging in to the AWS Management Console, search for the Elastic Container Resistry service and click it.

![](images/1-2/result/aws_ecr_link.png)

- Click Repositories on the left menu and then click Create repository on the right.

![](images/1-2/result/aws_ecr_repository.png)

- Enter the repository name and click Create Repository (leave the remaining input values as default and create)
👉 Two Repository names to be created: `eshop-frontend`, `eshop-backend`

![](images/1-2/result/aws_ecr_create.png)

- Save the URI of each image repository in notepad.

![](images/1-2/result/aws_ecr_finish.png)

ex) <br/>
`482713377086.dkr.ecr.us-east-1.amazonaws.com/eshop-frontend` <br/>
`482713377086.dkr.ecr.us-east-1.amazonaws.com/eshop-backend`

<br/>

### Create AWS EC2 instance
- Click EC2 > Instances > Launch instances to create an instance.
> | item                    | detail                                                                   |
> |-------------------------|--------------------------------------------------------------------------|
> | ➕ OS                    | `Ubuntu Server 20.04 LTS(HVM), SSD Volume Type`                          |
> | ➕ intance type          | `t3.medium`                                                              |
> | ➕ Tag (name)            | `legacyProd`                                                             |
> | ➕ Subnet                | `Public Subnet` Choose 1                                                  |
> | ➕ VPC                   | `N.Virginia(us-east-1) Region of default VPC`                              |
> | ➕ Auto-assign public IP | `Enable`                                                                 |
> | ➕ Key pair              | `eshopProd`                                                              |
> | ➕ Network setting       | security group After creating a new one, add port 22 for SSH connection and port 8080 of MY_IP as inbound rule. |
> | ➕ Configure storage     | 8 GiB 👉 30 GiB                                                    |
         
<br/>
### Setting up EC2 ssh connection with MobaXterm program

- Set up SSH connection using the Public IP of EC2 created above (📂Operating Area Practice Material: 1-1-VPC-Configuration.md)

- Install AWS CLI

<< EC2 environment >>

```bash
sudo apt-get update
sudo apt-get -y install awscli
aws --version
aws configure #(Enter Access key ID, Secret access key)
```

<< EC2 environment >>
#### EC2 basic structure for docker compose

```sh
mkdir eshop
cd eshop

mkdir proxy

touch compose.yaml
touch proxy/nginx.conf
```
<br/>

### Create docker image in local environment and push to ECR

<br/>

### 1. Change tag to upload backend image to ECR
>
> 🔸 The reason for changing the tag is that the name must be the same to be uploaded to ECR.
>
> Change the image tag by entering the following in the WSL environment.

<< WSL environment >>

```bash
docker tag <<existing image>> <<new image>>

# ex) docker tag eshop-backend:0.0.1-SNAPSHOT 123456789012.dkr.ecr.us-east-1.amazonaws.com/eshop-backend:0.0.1
```
<br/>

### 2. Build the frontend into a runnable image on EC2
>
> *Create frontend image for release to AWS Linux VM environment (operating system)*
>
> Create a frontend image for the operating system so that it can be executed at a specific URL rather than the address of the local development environment (localhost)
>
> You can set the Base URL of the execution environment with an environment variable such as `VUE_APP_BASE_URL`.
>
> If you create an image by directly entering the URL value to be executed, you must modify it and create the image again every time the environment changes.
>
> In other words, if testing across various environments such as local environment and staging environment increases during development, the image must be re-created every time the environment changes, making it inconvenient and inefficient to manage.
>
> We decide to create the frontend image in a way that does not require regenerating the image even when testing across multiple environments.
>

<br/>
<!--
<mark style="font-weight: bold"> 👉 Create image without specifying BASE_URL value in frontend Dockerfile </mark>
-->
<< WSL environment >>

1) Edit eshop-legacy-mentee/eshop-frontend/.env
```dockerfile
VUE_APP_BASE_URL=''
```

2) Edit eshop-legacy-mentee/eshop-frontend/Dockerfile

```dockerfile
#buildstage
FROM node:16.18-alpine as build-stage
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
 
# production stage
FROM node:16.18-alpine as production-stage
WORKDIR /app
RUN npm install -g http-server
COPY --from=build-stage /app/dist /app/dist
EXPOSE 8080
CMD ["http-server", "dist", "--proxy", "http://backend:8090"]
```

3) Edit eshop-legacy-mentee/eshop-frontend/vue.config.js

```dockerfile
module.exports = {}
```

Go to the frontend source folder and run the command below to build the image

<< WSL environment >>

```bash
docker image build -t eshop-frontend:0.0.1 .
```
<br/>

**3. Push the created eshop-frontend and eshop-backend images to ECR**

The method of pushing to ECR is as follows.

After injecting the ECR Login Credential in the WSL local environment, push it using the `docker push` command.
The image version can be changed to suit each situation.

Since the ECR repository is created by region, be sure to set the region appropriately.

*Even if you have ECR credentials, docker pull/push must be run with sudo privileges to avoid the no basic auth credentials error.*

<br/>
<< WSL environment >>

```shell
# Assuming that the docker image has been created locally as version 0.0.1, and that the backend and frontend repositories have been created in AWS ECR, respectively.
sudo apt install amazon-ecr-credential-helper

# The commands below can be checked by selecting AWS Management Console > ECR > Repository and clicking ‘View Commands’.
aws ecr get-login-password --region <<region where ECR is located >> | docker login --username AWS --password-stdin <<ECR URI>>/<<SERVICE NAME>>
```
```shell
# Change backend tag (if already changed, proceed with docker push) // ex) 123456.dkr.ecr.us-east-1.amazonaws.com/eshop-backend:0.0.1
docker tag eshop-backend:0.0.1-SNAPSHOT <<ECR URI>>/eshop-backend:0.0.1
docker push <<ECR URI>>/eshop-backend:0.0.1
```
```shell
# Change frontend tag (if already changed, proceed with docker push) // ex) 123456.dkr.ecr.us-east-1.amazonaws.com/eshop-frontend:0.0.1
docker tag eshop-frontend:0.0.1 <<ECR URI>>/eshop-frontend:0.0.1
docker push <<ECR URI>>/eshop-frontend:0.0.1
```




<br/>


<details>
<summary> <span style="font-weight: bold"> 📃Reference📃</span> How to create an image by explicitly specifying the frontend execution environment URL </summary>

> Below we introduce two ways to create an image by explicitly entering a URL.
>
> Let’s compare the two methods and understand why they differ from the one we adopted.

<br/>

**Method (1) - Create image by directly modifying the URL of the frontend source code**

Since the operating environment is deployed using the public IP of the Linux VM and is not in localhost status, the .env of the frontend and the springboot URL of the backend must be modified to match the public IP of EC2.

Modifying .env in frontend

After editing, create an image again using the Dockerfile and push it to AWS ECR.

<< WSL environment >>
```bash
cd ~/eshop-legacy-mentee/eshop-frontend
vi .env
```

<< WSL environment >>
```bash
#Before change
VUE_APP_BASE_URL=http://localhost:8080

#after
VUE_APP_BASE_URL=http://<<Public IP of your Linux VM>>:8080
```
<br/>

**Method (2) - Pass the public IP value as an environment variable to the Dockerfile for creating the frontend image**

Enter public IP as an environment variable in the Dockerfile for creating the existing frontend image.

After creating the image, push it to AWS ECR. ECR repositories are created by region, so be careful to set the region appropriately.

<br>

<< WSL environment >>

Docker build after modifying frontend Dockerfile

```dockerfile
#buildstage
FROM node:16.18-alpine as build-stage
WORKDIR /app

#👇<Add content below>
ENV VUE_APP_BASE_URL=http://<<Public IP of your Linux VM>>:8080

COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
 
# production stage
FROM node:16.18-alpine as production-stage
WORKDIR /app
RUN npm install -g http-server
COPY --from=build-stage /app/dist /app/dist
EXPOSE 8080
CMD ["http-server", "dist", "--proxy", "http://backend:8090"]
```

Go to the root of the frontend and run the command below to build the image.

<< WSL environment >>
```bash
docker image build -t eshop-frontend:0.0.1 .
```
<br>
</details>

<br/>

### Install Docker and Docker Compose to make the docker image runnable on EC2

<< EC2 environment >>

```sh
# Install Docker and docker compose
sudo apt-get update
sudo apt-get install ca-certificates curl gnupg -y

sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo \
   "deb [arch="$(dpkg --print-architecture)" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
   "$(. /etc/os-release && echo "$VERSION_CODENAME")" stable" | \
   sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin -y


# Grant permission to perform Docker commands
sudo usermod -aG docker $USER && newgrp docker

# Check Docker engine version
docker --version

# Check Docker compose version
docker compose version
````

```shell
# Check if the Docker daemon is running
sudo service docker status
```
If the message `Active: inactive(dead)` or `* Docker is not running` appears in the output, start the Docker daemon with the command below.

```shell
sudo service docker start
# ok if active (running)
```

```bash
# Lastly, check whether the Docker command is executed normally.
docker ps
```

<br/>

## **2-1-2. Running eshop Legacy service with Docker image in EC2 environment**

After creating a Linux VM in EC2 and installing the Docker environment, prepare to run the image by git clone, copying the compose.yaml file, or creating the compose.yml file directly.
*(.yml and .yaml can both be used)*

Lastly, modify the compose.yaml file so that you can pull the docker container image.

### 1. Install awscli and configure aws

When performing the AWS configure task below, enter the Access key ID / Secret access key / region of the personal IAM account (default region can be skipped by pressing the Enter key)
Basic Textbook Day 1 2-4 Enter the IAM Access key by referring to the generated value.

```bash
aws configure list

// If it is not displayed in the aws configure list, register it with the command below.
configure aws
```

<br>

### 2. ECR login (see ECR’s View push commands in AWS console)

<< EC2 environment >>

```sh
sudo apt update
sudo apt install amazon-ecr-credential-helper
aws ecr get-login-password --region <<region name>> | docker login --username AWS --password-stdin <<ECR URI>>/eshop-backend
aws ecr get-login-password --region <<region name>> | docker login --username AWS --password-stdin <<ECR URI>>/eshop-frontend
```

<br/>

### 3. Change my backend/frontend image in compose.yaml to reference ECR
🧲 (COPY) Add the following content to the existing redis and postgres content

<< EC2 environment >>

```yaml
   backend:
     depends_on:
       -postgres
     image: <<Private ECR URI>>/<<SERVICE NAME>>:<<TAG>> # ex) 123456.dkr.ecr.us-east-1.amazonaws.com/eshop-backend:0.0.1
     restart : always
     ports:
       - "8090:8090"
     container_name: eshop-backend
     environment:
       - SPRING_DATASOURCE_URL=jdbc:postgresql://postgres:5432/eshop_db
       - SPRING_REDIS_HOST=redis
   frontend:
     depends_on:
       -backend
     image: <<Personal ECR URI>>/<<SERVICE NAME>>:<<TAG>> # ex) 123456.dkr.ecr.us-east-1.amazonaws.com/eshop-frontend:0.0.1
     restart : always
     ports:
       - "8080:8080"
     container_name: eshop-frontend
```
<br/>

### 4. Run docker compose up

<< EC2 environment >>

```sh
docker compose up
```

<br/>

<details>
<summary>Refer to [Expand👇]. How to pull Docker Image with the same Tag in EC2 or WSL environment</summary>

When using the frontend image by continuously pushing it to ECR with the same tag name, start it with the following command combination <br/>
Even if it is the same tag, if a source change is detected, a new image is received and started.

This means there is no need to delete EC2 or local WSL Docker images for renewal.

```sh
docker compose pull && docker compose up
```

**Reason** ✍

This is because once a Docker image has been pulled with a specific tag name in WSL or EC2, images with the same tag are not pulled again.

*Reference: https://stackoverflow.com/questions/37685581/how-to-get-docker-compose-to-use-the-latest-image-from-repository*
</details>

<br>

> Open your Linux VM Public_IP:8080 in your browser and check whether the homepage screen appears properly.
> If a timeout occurs, check again whether the Custom TCP 8080 port is properly registered as an inbound rule in the security group of the VM.

![](images/1-2/image29.png)

<br/>

---


# **2-2. Establishment of local K8S environment and API Gateway**

<br>

> **🚩Goal**
> - **Try starting the service locally in a Kubernetes environment in an existing Docker-only environment.**
> - **Use Skaffold to automatically reflect code changes in the local environment.**
> - **Use Ingress to create one API contact point for services.**
---

**💡Note. Run pod after defining manifest in Kubernetes environment**

![](images/1-2/image34.png)

---
## **2-2-1. Manually running Kubernetes Manifest**
> How to define and run Pod, Deployment, and Service resources in a basic Kubernetes (hereinafter referred to as k8s) environment is as follows.
>
> Define Deployment and Service resources as shown below and create resources through the `kubectl apply -f <<file name>>.yaml` command.
>


#### Let’s start the nginx service in WSL as an example.

#### 0. Check the status of minikube in the WSL environment.
```sh
minikube status

// If it is not in the Running state, run minikube using the start command.
minikube start
```


#### 1. `nginx.yaml` - Deployment definition
<< WSL environment >>
*nginx.yaml*
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
   labels:
     app: nginx
   name: nginx
spec:
   replicas: 1
   selector:
     matchLabels:
       app: nginx
   template:
     metadata:
       labels:
         app: nginx
     spec:
       containers:
       - image: nginx
         name: nginx
```

#### 2. `nginx-service.yaml` - Service definition

<< WSL environment >>

*nginx-service.yaml*
```yaml
apiVersion: v1
kind: Service
metadata:
   labels:
     app: nginx
   name: nginx
spec:
   ports:
   - port: 80
     protocol: TCP
     targetPort: 80
   selector:
     app: nginx
   type: ClusterIP
```
<br/>

#### 3. `kubectl apply`

<< WSL environment >>

```sh
kubectl apply -f nginx.yaml
kubectl apply -f nginx-service.yaml
```

#### 4. Check `nginx` operation

<< WSL environment >>

Perform `kubectl port-forwarding` on nginx deployment on localhost.
```sh
kubectl port-forward deployment.apps/nginx 8080:80
```
*Output result*
```sh
Forwarding from 127.0.0.1:8080 -> 80
Forwarding from [::1]:8080 -> 80
```

  Try calling nginx through curl. You can check whether it is actually operating normally.

<< WSL environment >>

```sh
curl localhost:8080
```
*Output result*
```html
<!DOCTYPE html>
<html>
     <head>
         <title>Welcome to nginx!</title>
           <style>
             html { color-scheme: light dark; }
             body { width: 35em; margin: 0 auto; font-family: Tahoma, Verdana, Arial, sans-serif; }
           </style>
     </head>
   <body>
       <h1>Welcome to nginx!</h1>
       <p>If you see this page, the nginx web server is successfully installed and working.
         Further configuration is required.</p>
       <p>For online documentation and support please refer to
       <a href="http://nginx.org/">nginx.org</a>.<br/>
           Commercial support is available at
       <a href="http://nginx.com/">nginx.com</a>.</p>
       <p><em>Thank you for using nginx.</em></p>
   </body>
</html>
```

#### 5. `kubectl delete` - **Delete the nginx resource deployed as an example**

<< WSL environment >>

```sh
kubectl delete -f nginx.yaml
kubectl delete -f nginx-service.yaml
```
<br>

### 🔦 Kubernetes 🔦
>
> In order to define and execute resources in a k8s environment like this, <mark> manifest definition </mark> and <mark> apply</mark> are the basic operating orders.<br/> <br/>
> However, there are too many manifest files to manage to integrate and manage a large number of applications. <br/>
>
> <strong>In the next area, let’s check out the tools that can be integrated and manage manifests in the local environment.</strong>

---
## **2-2-2. Running AS-IS source service in K8S environment**
### 1. Create Kubernetes Template

> Create a k8s directory under the project root directory and create a yaml configuration file to create a Kubernetes pod.

<< WSL environment >>

```sh
# Skip if the folder has already been created
mkdir k8s
```
![](images/1-2/image35.png)

---

>Write the `k8s/postgres.yaml` file.
<details> <summary style="font-style: italic"> postgres.yaml </summary>

<< WSL environment >>

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
   name: postgres
spec:
   selector:
     matchLabels:
       app:postgres
   template:
     metadata:
       labels:
         app:postgres
     spec:
       containers:
       - name: postgres
         image:postgres:13
         env:
           - name: POSTGRES_USER
             value: eshop_user
           - name: POSTGRES_DB
             value: eshop_db
           - name: POSTGRES_PASSWORD
             value: password
         ports:
         - containerPort: 5432
         resources:
           limits:
             memory: 512Mi
             cpu: 500m
           requests:
             CPU: 300m
             memory: 384Mi
---
apiVersion: v1
kind: Service
metadata:
   name: postgres
spec:
   type: ClusterIP
   selector:
     app:postgres
   ports:
   - port: 5432
```
</details>

---

>Create the `k8s/redis.yaml` file.

<details> <summary style="font-style: italic"> redis.yaml</summary>

<< WSL environment >>

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
   name: redis
spec:
   selector:
     matchLabels:
       app: redis
   template:
     metadata:
       labels:
         app: redis
     spec:
       containers:
       - name: redis
         image: redis:5.0-alpine
         ports:
         - containerPort: 6379
         volumeMounts:
         - mountPath: /data
           name: redis-data
         resources:
           limits:
             memory: 512Mi
             cpu: 500m
           requests:
             cpu: 100m
             memory: 384Mi
       volumes:
       - name: redis-data
         emptyDir: {}
---
apiVersion:v1
kind: Service
metadata:
   name: redis
spec:
   type: ClusterIP
   selector:
     app: redis
   ports:
   - port: 6379
```
</details>

>Write the `k8s/backend.yaml` file.

<details> <summary style="font-style: italic"> backend.yaml </summary>

<< WSL environment >>
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-backend
spec:
  selector:
    matchLabels:
      app: eshop-backend
  template:
    metadata:
      labels:
        app: eshop-backend
    spec:
      containers:
        - name: eshop-backend
          image: eshop-backend
          ports:
          - containerPort: 8090
          env:
            - name: SPRING_REDIS_HOST
              value: redis
            - name: SPRING_DATASOURCE_URL
              value: "jdbc:postgresql://postgres:5432/eshop_db"
          resources:
            requests:
              cpu: 200m
              memory: 384Mi
            limits:
              cpu: 1000m
              memory: 1024Mi
---
apiVersion: v1
kind: Service
metadata:
  name: eshop-backend
spec:
  type: ClusterIP
  selector:
    app: eshop-backend
  ports:
  - port: 8090
```

</details> 

> k8s/frontend.yaml Write a file.


<details> <summary style="font-style: italic"> frontend.yaml</summary> 

<< WSL environment >>

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-frontend
spec:
  selector:
    matchLabels:
      app: eshop-frontend
  template:
    metadata:
      labels:
        app: eshop-frontend
    spec:
      containers:
        - name: eshop-frontend
          image: eshop-frontend
          command: [ "http-server", "dist", "--proxy", "http://eshop-backend:8090"]
          ports:
          - containerPort: 8080
          resources:
            requests:
              cpu: 100m
              memory: 64Mi
            limits:
              cpu: 200m
              memory: 128Mi
---
apiVersion: v1
kind: Service
metadata:
  name: eshop-frontend
spec:
  type: ClusterIP
  selector:
    app: eshop-frontend
  ports:
  - port: 8080
```
>🧩 **Note** 🧩
>
> <br/> in the `k8s/frontend.yaml` file
> `command: [ "http-server", "dist", "--proxy", "[http://eshop-backend:8090](http://eshop-backend:8090/)"]` <br />
The > part is for the `http-server` inside the `eshop-frontend` container to proxy the incoming request to `eshop-backend`. <br/>
> This part will be removed from the frontend settings later by adding <mark style='font-weight:bold'>Ingress pod</mark>, which is responsible for the network.

</details>

#### If you have progressed to this point, four files should be added under the k8s folder as shown below.

![](images/1-2/image36.tmp)

---

### 2. Skaffold settings

> To install Skaffold in the local environment, execute the installation command below.
> Skaffold is a tool that allows you to easily run each pod in a single Kubernetes environment.

<< WSL environment >>

```bash
curl -Lo skaffold https://storage.googleapis.com/skaffold/releases/latest/skaffold-linux-amd64 && \
sudo install skaffold /usr/local/bin/
```
```bash
# Because it is installed with the latest version, it may be different from the version of the textbook.

skaffold version
v2.5.1
```

<br/>

<< WSL environment >>

Check out the features available in skaffold.
```bash
$ skaffold
A tool that facilitates continuous development for Kubernetes applications.

  Find more information at: https://skaffold.dev/docs/getting-started/

End-to-end Pipelines:
  run               Run a pipeline
  dev               Run a pipeline in development mode
  debug             Run a pipeline in debug mode

Pipeline Building Blocks:
  build             Build the artifacts
  test              Run tests against your built application images
  deploy            Deploy pre-built artifacts
  delete            Delete any resources deployed by Skaffold
  render            Generate rendered Kubernetes manifests
  apply             Apply hydrated manifests to a cluster
  verify            Run verification tests against skaffold deployments

Getting Started With a New Project:
  init              Generate configuration for deploying an application

Other Commands:
  completion        Output shell completion for the given shell (bash, fish or zsh)
  config            Interact with the global Skaffold config file (defaults to `$HOME/.skaffold/config`)
  diagnose          Run a diagnostic on Skaffold
  exec              Execute a custom action
  fix               Update old configuration to a newer schema version
  schema            List JSON schemas used to validate skaffold.yaml configuration
  survey            Opens a web browser to fill out the Skaffold survey
  version           Print the version information

Usage:
  skaffold [flags] [options]

Use "skaffold <command> --help" for more information about a given command.
Use "skaffold options" for a list of global command-line options (applies to all commands).
```
![](images/1-2/image37.png)

- skaffold dev: Detects changes in the application's source file, builds the image again, and deploys it.

- skaffold run: You can check the log with the --tail option, but it cannot detect source changes. Once deployed, it will no longer be deployed.

> Create a `skaffold.yaml` file in **project root path** with the following content.

![](images/1-2/image38.png)

---

**skaffold.yaml**

<< WSL environment >>

```yaml
apiVersion:skaffold/v2beta10
kind: Config
build:
   artifacts:
     - image: eshop-backend
       context: eshop-backend
       jib:
         type: gradle
     - image: eshop-frontend
       context: eshop-frontend
deploy:
   kubectl:
     manifests:
       - k8s/**.yaml
```
---

### 3. Measure

Run skaffold with the following command from the project root where the skaffold.yaml file is located. <br/>
Before running skaffold, make sure minikube is running.

<< WSL environment >>

```sh
skaffold dev --port-forward
```

You can see that the `frontend` and `backend` logs are displayed together.

![](images/1-2/image39.png)

> You can check whether the service has started properly by accessing <http://localhost:8080> in a web browser.

> When you modify the frontend's source code, you can see that the skaffold pipeline runs immediately and automatically builds and deploys a new service.

![](images/1-2/image40.png)

![](images/1-2/image41.tmp)

You can access the service and check that source code changes have been deployed within 5 minutes (http://localhost:8080).

![](images/1-2/image42.png)

By entering Ctrl + C in the terminal where skaffold is running, you can check that the contents deployed to local Kubernetes are being cleaned up.

![](images/1-2/image43.png)

<br/>

## **2-2-3. Application of API Gateway using Ingress**
<br>

> 💡In this exercise, we will review **API Gateway pattern application** before separating the backend into microservice.💡

#### Diagram
![](images/1-2/image44.png)

|Classification|Content|
|---|----|
|Restraints|Need to switch to microservice architecture style.|
|Restrictions|Frontend logic is not modified if possible.|

When switching to a microservice architecture style, the number of backend services increases, so the frontend must know the endpoints of each service to access it.

And as the number of endpoints increases, the related frontend code must be modified, thereby violating constraints.

![](images/1-2/image45.tmp)

### 1. Architecture

|Design Decisions|Rationale|
|---------|---|
|Apply the API Gateway pattern.|- Frontend can be accessed through a single endpoint without knowing the location of the detailed service as long as you know the API Gateway access path. <br/> - There is no need to change the frontend source code by simply modifying the existing backend access path environment variable values. |

<br/>

**Selection of API Gateway implementation**
|Classification| Representative implementation |Characteristics|
|----|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---|
|Directly implemented and exposed in the form of a general microservice| - [Spring Cloud Gateway](https://spring.io/projects/spring-cloud-gateway#overview)<br/> - [Zuul](https://github.com/Netflix/zuul) <br/> - [Express Gateway](https://www.express-gateway.io/)                                                                                                                                 |- Customizable to fit business functions<br/>- Not dependent on features of the Kubernetes platform|
|Kubernetes Ingress Controller| - [Ingress Controller](https://kubernetes.io/ko/docs/concepts/services-networking/ingress-controllers/) See documentation<br/><ul> o Ambassador</ul><ul>o AWS ALB Ingress Controller</ul><ul>o GKE Ingress</ul><ul>o Gloo</ul><ul>o HAProxy Ingress</ul><ul>o Istio</ul><ul>o Kong</ul><ul>o Nginx Ingress Controller</ul><ul>o Traefik |- Kubernetes Utilizing platform functions<br/>- Functions and features are different for each implementation, so detailed review is required

---

### **Ingress**

It is an API object that **manages external access** to services within the cluster, and generally manages HTTP.

Ingress can provide load balancing, SSL termination, and name-based virtual hosting.

![](images/1-2/image46.tmp)

Source: <https://kubernetes.io/ko/docs/concepts/services-networking/ingress/>

In this lab, we will select and review several Ingress Controller implementations.

---

### 2. Build
 
**ingress-nginx installation (enabled)**

<< WSL environment >>

```sh
minikube addons enable ingress
```

**Check if ingress-nginx is enabled**

Enter the following to confirm that the Nginx Ingress Controller is properly installed.

<< WSL environment >>

```sh
$ kubectl get all -n ingress-nginx
NAME                                            READY   STATUS      RESTARTS   AGE
pod/ingress-nginx-admission-create--1-bxvh4     0/1     Completed   0          2m29s
pod/ingress-nginx-admission-patch--1-vc5f2      0/1     Completed   1          2m29s
pod/ingress-nginx-controller-69bdbc4d57-99zkx   1/1     Running     0          2m29s
 
NAME                                         TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)                      AGE
service/ingress-nginx-controller             NodePort    10.97.156.178    <none>        80:31262/TCP,443:30326/TCP   2m29s
service/ingress-nginx-controller-admission   ClusterIP   10.105.155.209   <none>        443/TCP                      2m29s
 
NAME                                       READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/ingress-nginx-controller   1/1     1            1           2m29s
 
NAME                                                  DESIRED   CURRENT   READY   AGE
replicaset.apps/ingress-nginx-controller-69bdbc4d57   1         1         1       2m29s
 
NAME                                       COMPLETIONS   DURATION   AGE
job.batch/ingress-nginx-admission-create   1/1           5s         2m29s
job.batch/ingress-nginx-admission-patch    1/1           6s         2m29s
```

**Create Ingress resource**
>
> Create a `k8s/ingress.yaml` file with the following content.


<details> <summary style="font-style: italic"> k8s/ingress.yaml </summary>

<< WSL environment >>
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: eshop-ingress
  annotations:
    kubernetes.io/ingress.class: "nginx"
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
spec:
  rules:
  - http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: eshop-frontend
            port:
              number: 8080
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090
      - path: /static
        pathType: Prefix
        backend:
          service:
            name: eshop-backend
            port:
              number: 8090      
```
</details>
**Remove the proxy part from the `k8s/frontend.yaml` file.**

> This part 👉 `command: [ "http-server", "dist", "--proxy", "http://eshop-backend:8090"]`

<details> <summary style="font-style: italic"> k8s/frontend.yaml </summary>

<< WSL environment >>
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-frontend
spec:
  selector:
    matchLabels:
      app: eshop-frontend
  template:
    metadata:
      labels:
        app: eshop-frontend
    spec:
      containers:
        - name: eshop-frontend
          image: eshop-frontend
          ports:
          - containerPort: 8080
          resources:
            requests:
              cpu: 100m
              memory: 64Mi
            limits:
              cpu: 200m
              memory: 128Mi
---
apiVersion: v1
kind: Service
metadata:
  name: eshop-frontend
spec:
  type: ClusterIP
  selector:
    app: eshop-frontend
  ports:
  - port: 8080
```

</details>

**`eshop-frontend/vue.config.js` 파일에서 더 이상 proxy 설정이 필요하지 않으므로 제거되었는지 다시 확인한다.**
<details> <summary style="font-style: italic"> eshop-frontend/vue.config.js </summary>

<< WSL environment >>
```js
module.exports = {}
```
</details>

**Service startup and Nginx Ingress Controller port-forward**
<br/> <br/>
Start the service by entering the following: This time we do not use the --port-forward flag.

```sh
skaffold dev
```

> When installing the Ingress Controller in a cloud-based K8s cluster, a LoadBalancer type service (ex: AWS ELB, etc.) is installed by default.
>
> However, when installed on WSL, a separate service for external connection is not configured.
>
>
> Therefore, open a new console window and use the `port-forward` flag as shown below to connect to ingress when calling `localhost:8080`.

<< WSL environment >>

```shell
kubectl port-forward deployment.apps/ingress-nginx-controller 8080:80 -n ingress-nginx
```
```shell
# output result
Forwarding from 127.0.0.1:8080 -> 80
Handling connection for 8080
```



> **Troubleshooting**
>
> If an error occurs, it may be that the existing minikube is occupying port 80, so try `minikube stop` / `minikube start` and restart the K8s.

---

### 3. Measure

> When you access the http://localhost:8080 port, you can check that the service is running normally.

![](images/1-2/image47.png)

> If you access <http://localhost:8080/api/currencies> using a web browser, you can check that the exchange rate list inquiry API is operating normally.

```sh
{"EUR":"1.0","USD":"1.1305","JPY":"126.40","BGN":"1.9558","CZK":"25.592","DKK":"7.4609","GBP":"0.85970","HUF":"315.51","PLN":"4.2996","RON":"4.7463","SEK":"10.5375","CHF":"1.1360","ISK":"136.80","NOK":"9.8040","HRK":"7.4210","RUB":"74.4208","TRY":"6.1247","AUD":"1.6072","BRL":"4.2682","CAD":"1.5128","CNY":"7.5857","HKD":"8.8743","IDR":"15999.40","ILS":"4.0875","INR":"79.4320","KRW":"1275.05","MXN":"21.7999","MYR":"4.6289","NZD":"1.6679","PHP":"59.083","SGD":"1.5349","THB":"36.012","ZAR":"16.0583"}
```

Enter Ctrl + C in the terminal where port-forward is run and the terminal where skaffold is running to clean up the contents deployed to local Kubernetes.

<br/>

<details>
<summary> [Reference - Expand👇] Notes on skaffold and minikube </summary>

<br>

> If you encounter a situation where the minikube cluster is in an abnormal state, one solution is to delete existing related images.
The easiest way to completely delete this image is as follows, and you can also try removing minikube from Docker and reinstalling it. (However, docker must be running)


> Ssh shell connection command to minikube container

```sh
minikube ssh
```

skaffold How to delete all my images

```sh
minikube delete
```
```sh
minikube start
```
```sh
minikube addons enable ingress (requires reinstall)
```

<br>

> If you want to delete only some images rather than all images

```sh
minikube ssh
```
```sh
docker rmi [image id]
```
```sh
exit
```

<br>

</details>


<br>

## 2-2-4. Evaluation

- By applying the API Gateway pattern, it is now possible to access a single path regardless of the location of the service when dividing the service.

- Services can be added without changing the frontend code.

- Currently, there is no requirement, but application of istio will be reviewed when service mesh application is necessary.

<br/>
<br/>


## **💡Troubleshooting💡** ##

<br/>
[ 🐳 Note 👉 <a href="./1w-troubleshooting.md">1w-troubleshooting.md</a>]
<br/>
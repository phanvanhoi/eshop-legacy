# **Troubleshooting**

## WSL related
1. 🎓 WSL cannot be installed in VDI environments and virtual environments.
     - Cannot install another virtual environment within a virtual environment <br/>
     If you try to install within a VDI, the VDI may be broken and data may not be recoverable. 👉 You must reinstall the VDI and your data will be lost!
     - AWS Windows Server also does not support Hyper-V except for .baremetal ami (both Hyper-V and WSL2@Hyper-V are not supported) <br/><br/>

2. 🎓 The minikube program installed in WSL uses a lot of memory, so if you leave your PC on for too long, your PC may become unstable!
<br/> 👉 During the practical PJT period, it is recommended to shut down the PC every day and boot it in the morning.<br/><br/>

3. WSL 2 configuration: Things to check when applying WSL Version 2 <br/>
     ① Press Win + S keys (search window), then search for *Developer features* and change it to *Enable* <br/>
     ② Press Win + S keys (search window) and then *Turn on Windows features* (Control Panel) <br/>
     👉 Make sure *Windows Subsystem for Linux* item is checked ( ✔️ ) <br/>
     🎓 Suspect the case when error 0x8007019e occurs<br/><br/>
    

4. If you delete and reinstall WSL and ubuntu due to a system error during ubuntu configuration, a system reboot is recommended <br/>
     💡How to delete <br/>
     ubuntu: *Microsoft Store* → Search for *ubuntu* and remove it <br/>
     WSL: *Add/Remove Programs* → Uninstall *Windows Subsystem For Linux* <br/> <br/>
    
5. If error 0x800701bc occurs when running WSL2 Ubuntu, it can be resolved by installing *WSL2 Linux Kernel Update* <br/>
   👉Refer to [https://tars.tistory.com/m/50](https://tars.tistory.com/m/50) <br/><br/>

6. ERROR when running systemctl: System has not been booted with systemd as init system (PID 1). Can't operate.
   Or, when running Docker, /sys/fs/cgroup/cpuset: wrong fs type, bad option, bad superblock on cgroup issue.
   Or problem with docker not running automatically
   How to solve the above 3 problems
``` powershell
   1. Run PowerShell as administrator and run below
   wsl --update
  
   2. sudo vi /etc/wsl.conf Save the contents below
   [boot]
   systemd=true
  
   1. Re-run wsl after wsl --shutdown in PowerShell
   wsl --shutdown
```
<br/>

1. What to do if WSL 2 is installed and the following case occurs when running Docker<br/>
   🔸 There is no problem in proceeding with the exercise (minikube start), but how to resolve the cgroup-related mount error below
```sh
ubuntu@gildong:~/eshop-legacy-mentee$ sudo service docker start
mount: /sys/fs/cgroup/cpuset: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/cpu: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/cpuacct: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/blkio: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/memory: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/devices: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/freezer: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/net_cls: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/perf_event: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/net_prio: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/hugetlb: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/pids: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/rdma: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
mount: /sys/fs/cgroup/misc: wrong fs type, bad option, bad superblock on cgroup, missing codepage or helper program, or other error.
  * Starting Docker: docker
```
   📗Solution 📗<br/>
     👉Refer to [https://github.com/microsoft/WSL/issues/9868](https://github.com/microsoft/WSL/issues/9868)
    
<br/>

## Scaffold-related
- When skaffold dev --port-forward, if the location of skaffold.yaml is not the proejct main directory (./k8s/*.yaml lookup), an error appears saying "postgres permission problem"<br/>
   👉Check the location of the skaffold.yaml directory<br/>

- Since even a single typo in several yaml files to run skaffold will prevent it from running, it is recommended to try it locally while watching Confluence, and if that does not work, to share the file through a mentor.

   👉 If possible, it is easier to understand the meaning if you type them one by one. Anyway, k8s yaml will continue to be used, deployment → service structure, etc.<br/>

- When installing node.js, an error occurs if you use the [sudo apt install nodejs] command. <br/>
   👉 Complete the normal installation by executing the [sudo apt-get install -y nodejs] command<br/>

- 1.4 When performing “sudo apt install npm” in local practice environment configuration <br/>
   👉"E: Unable to correct problems, you have held broken packages." Even if an error appears, just ignore it<br/>

- Strangely, an error occurred such that there was no @optional annotation in the jib file of eshop-backend, and the Docker file was not created, so I upgraded the plugin version to 2.7.1 in build.gradle instead of 2.7.0 in the textbook and ran ./gradlew jibDockerbuild, but it actually worked. The debug text said to upgrade to the latest version, 3.2.1, so I did that and it still worked. It just throws out errors and warnings saying that there is no credential, but if you wait for a while, you get it from somewhere and the Docker build works.
<br/>
## NPM installation related
If npm run serve does not run after NPM install, run the command below, run npm install and npm i chokidar, and then run npm run serve again.
```sh
npm cache clear --force
```
<br/>

## Docker compose related
If the following error occurs when running the docker compose up -d command after installing Docker compose, run the rm ~/.docker/config.json command.

Error details>
```sh
docker.credentials.errors.InitializationError: docker-credential-desktop.exe not installed or not available in PATH [ 59408 ] Failed to excute script docker-compose
```

<br/>

## Minikube related
- minikube status result apiserver: Stopped - This Container is having trouble accessing https://k8s.gcr.io error message (error related to connection)

- Add nameserver 8.8.8.8 to sudo vi /etc/resolv.conf

<br/>

## ECR related
- If a 'no basic auth credentials' error occurs when pushing an image on the local PC to AWS ECR, remove the sudo command from the command and push.
```sh
sudo docker push 61XXXXX.dkr.ecr..amazon.com/eshop-backend:0.0.1 → Remove sudo and run
```

- When performing docker compose up, if there is no image on the system, the image is downloaded, but once downloaded, the image is not downloaded again.
Therefore, no matter how much you modify the content locally and push it to ECR with the same name and tag, if you have downloaded the image name and tag even once,
The image will not be downloaded again, and as a result, changes will not be reflected. Therefore, to reflect changes to the same tag with the same name,
After deleting the image, run docker compose up again to download the actually changed image.

<br/>

## Basic settings such as Github settings
Basic script to set up personal github

<details>
<summary> [Reference - Expand👇] </summary>
<div ref="1">
[Pre-work]

❗ <<github_username>> 👉 With your personal github username, private on the github.com site!! Create a repository with .

```sh
cd ~
sudo apt install unzip
git clone https://github.com/<<github_username>>/<<github_private_repository>>.git
```
```sh
# You can drop the zip file by downloading the source zip file provided for mentees as a zip from github and dragging and dropping it on the left explorer of mobaXterm.
unzip eshop-legacy-mentee-main.zip
cd ~/eshop-legacy-mentee-main
mv * ~/eshop-legacy-mentee
rm -rf eshop-legacy-mentee-main
rm eshop-legacy-mentee-main.zip
cd ~/eshop-legacy-mentee

# git operations
git status
git add .
git status
git commit -m "initial"
git branch -m main
git push (or git push origin main)
```
</div>
</details>

- If an error occurs during git commit that the data/ folder created in the work folder does not have permission, handle it by specifying the file or folder that should not be uploaded to git in the *.gitignore* file.<br/>
If it is uploaded to git, how to delete it<br/>
① $git rm --cached -r data/ <br/>
② $git commit -m "delete folder" <br/>
It can be deleted from git by processing it as

- Install ingress-nginx in WSL VM<br/>
The method below is used in cases other than minikube <br/>
```sh
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.0.0/deploy/static/provider/cloud/deploy.yaml
```

- Check whether ingress-nginx is installed in the WSL VM.
```sh
kubectl get all -n ingress-nginx
kubectl get pods --all-namespaces -l app.kubernetes.io/name=ingress-nginx
kubectl get services ingress-nginx-controller --namespace=ingress-nginx
```

- Running a fully MSA-enabled application within the WSL VM
```sh
skaffold dev
```

- Ingress port-forward operation within WSL VM
```sh
kubectl port-forward deployment.apps/ingress-nginx-controller 8080:80 -n ingress-nginx
```

- If you perform multiple operations when setting up the local environment (reinstallation, working for several days, etc.), the following error may occur when running the service.
> 2-1 When running eshop-backend, Web server failed to start. Port 8090 was already in use.

> Solution: When you restart the local PC, PostgreSQL and redis executed with docker compose are automatically executed and the web server runs normally. In other words, if a service port error occurs during setup, restart...

- If WSL in the local environment is messed up and you want to start over completely, go to the Windows App Store, delete Ubuntu20.04 LTS and WSL, and proceed from the beginning according to the guide. (PC reboot required after deletion)


## Related to using VSCode
- When converting each service into an MSA, to make it easier to type in JAVA or other languages, install java extension pack or vue language features (volar) as an extension of VSCode, and auto-completion and highlighting are good, making the work easier. (When installing, install in WSL:Ubuntu-20.04)

- Among VSCode's extensions, we also recommend installing 'ESLint' (JSON, YAML, Javascript, etc.) and 'IntelliCode' (autocomplete).

<br/>

## Execution error related
(1) When changing Java, when using VSCode Extention, changing to Java Version > 17, Gradle > 7.2.1 or higher and configuring a mixed environment, **backend build error (2 types)**
<br/>
   
    - **Task: test FAILED contextLoads() FAILED** <br/>
      👉 Add application.properties url.cartservice=http://localhost:8091 to eshop-backend
      <br/>
    
    - **major version 62 error** <br/>
      👉 Check the Java Version and compile it to 11. java -version check
        <br/>

(2) **Optional error when building cartservice Jib Docker image**
      <br/>
    👉 Check whether the distributionUrl version of gradle/wrapper/gradle-wrapper.properties is appropriate.
      <br/><br/>

(3) **Internal Error occurs when running the flask app at the end of step 2.4.3 Creating a recommended service**
<br/> <br/> **Phenomena**: When calling the recommend service through the curl command, an internal error (500) occurs. If execution is not possible with flask, the same error occurs even when running with gunicorn.
<br/>
    👉 If the product service itself is operating normally, you can skip this step and check after deploying with k8s to check that the recommended service is operating normally.
<br/>
<br/>
< Error details on the Flask execution console screen when an Internal 500 error occurs 👇>
```sh
$ curl localhost:5000/api/recommends
[2022-07-19 11:51:48,210] ERROR in app: Exception on /api/recommends [GET]
Traceback (most recent call last):
File "/home/ubuntu/handson-cloud-msa/eshop-recommendservice/.venv/lib/python3.8/site-packages/requests/models.py", line 971, in json
    return complexjson.loads(self.text, **kwargs)
File "/usr/lib/python3.8/json/__init__.py", line 357, in loads
    return _default_decoder.decode(s)
File "/usr/lib/python3.8/json/decoder.py", line 337, in decode
    obj, end = self.raw_decode(s, idx=_w(s, 0).end())
File "/usr/lib/python3.8/json/decoder.py", line 355, in raw_decode
    raise JSONDecodeError("Expecting value", s, err.value) from None
json.decoder.JSONDecodeError: Expecting value: line 1 column 1 (char 0)

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
File "/home/ubuntu/handson-cloud-msa/eshop-recommendservice/.venv/lib/python3.8/site-packages/flask/app.py", line 2073, in wsgi_app
    response = self.full_dispatch_request()
File "/home/ubuntu/handson-cloud-msa/eshop-recommendservice/.venv/lib/python3.8/site-packages/flask/app.py", line 1519, in full_dispatch_request
    rv = self.handle_user_exception(e)
File "/home/ubuntu/handson-cloud-msa/eshop-recommendservice/.venv/lib/python3.8/site-packages/flask/app.py", line 1517, in full_dispatch_request
    rv = self.dispatch_request()
File "/home/ubuntu/handson-cloud-msa/eshop-recommendservice/.venv/lib/python3.8/site-packages/flask/app.py", line 1503, in dispatch_request
    return self.ensure_sync(self.view_functions[rule.endpoint])(**req.view_args)
File "/home/ubuntu/handson-cloud-msa/eshop-recommendservice/app.py", line 12, in recommend
    products = response.json()
File "/home/ubuntu/handson-cloud-msa/eshop-recommendservice/.venv/lib/python3.8/site-packages/requests/models.py", line 975, in json
    raise RequestsJSONDecodeError(e.msg, e.doc, e.pos)
requests.exceptions.JSONDecodeError: Expecting value: line 1 column 1 (char 0)
127.0.0.1 - - [19/Jul/2022 11:51:48] "GET /api/recommends HTTP/1.1" 500 -
```
<br/>
After taking action, if you check the URL with the following command, you can see that four random products are recommended as follows.

```sh
curl localhost:5000/api/recommends
```

    
<br/>
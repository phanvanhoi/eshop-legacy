# Create E-SHOP API Document page <!-- omit in toc -->
- [One. Creating an API Document Page Using Swagger] (#1-Creating an API Document Page Using Swagger)
   - [1.1 Swagger?](#11-swagger)
   - [1.2 Let’s apply Swagger] (#12 Let’s apply swagger)
- [2. Creating an API Document page using REST Docs](#2-Creating an api-document page using rest-docs)
   - [2.1 REST Docs?](#21-rest-docs)
   - [2.2 Let’s write test code for REST Docs] (#22 Let’s write test code for rest-docs)

## 1. Creating an API Document page using Swagger

### 1.1 Swagger?
> - Note
> - https://swagger.io/

```text
Swagger provides several tools for designing and documenting REST APIs.
```

![](images/1-ch/swagger-features.png)

Let’s take a look at the tools provided by Swagger.

| tools | Description | Note |
|-------------------|----------------------------- --------------|--------------------------------------- -------------------------------------|
| `Swagger Editor` | API specifications can be designed through UI. | - Online Swagger Editor: https://editor.swagger.io/ <br>- Also available in download form |
| `Swagger UI` | Provides UI for API Spec | - Live Demo: https://petstore.swagger.io/ |
| `Swagger Codegen` | You can create server or client code from the API Spec. | |

### 1.2 Let’s apply Swagger
The challenge will use `Swagger UI`. Provides UI for API Spec through `Swagger UI` for already built projects.

To implement Swagger UI, we plan to use `Springfox` learned in the T2 course.<br>
Add dependency on `Springfox`.

<details>
<summary>Add dependencies</summary>

📄 `build.gradle` 
```gradle
plugins {
    id 'org.springframework.boot' version '2.2.6.RELEASE'
    id 'io.spring.dependency-management' version '1.0.9.RELEASE'
    id 'java'
}

group = 'com.samsungsds'
version = '0.0.1-SNAPSHOT'
sourceCompatibility = '11'

configurations {
    developmentOnly
    runtimeClasspath {
        extendsFrom developmentOnly
    }
}

repositories {
    mavenCentral()
}

dependencies {
    implementation 'org.springframework.boot:spring-boot-starter-web'
    implementation 'org.springframework.boot:spring-boot-starter-thymeleaf'    
    implementation 'org.springframework.boot:spring-boot-starter-data-redis'
    implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
    implementation 'org.postgresql:postgresql'
    developmentOnly 'org.springframework.boot:spring-boot-devtools'    
    implementation 'com.google.guava:guava:28.2-jre'

    implementation 'io.springfox:springfox-boot-starter:3.0.0' //👈👈  add line
    implementation "io.springfox:springfox-swagger-ui:3.0.0" //👈👈  add line

    testImplementation('org.springframework.boot:spring-boot-starter-test') {
        exclude group: 'org.junit.vintage', module: 'junit-vintage-engine'
    }
}

test {
    useJUnitPlatform()
}
```

</details>
<br>
Start the local development environment.
<details>
<summary>Starting a local development environment</summary>
Caution] Please proceed in the initial state where the backend and frontend parts are not reflected in the compose.yaml file.

Running postgreSQL and redis using docker compose

```
docker compose up -d
```

Running the backend development server

```
cd eshop-backend
./gradlew bootRun
```

Run frontend development server

```
cd eshop-frontend
npm run serve
```

</details>
<br>

Access http://localhost:8080/swagger-ui/ and check the Swagger page.<br>
Since the configuration for each Controller and Swagger is not set, a page with default values is displayed.

![](images/1-ch/swagger-local-pure.png)

<br>

Create a configuration file for Swagger UI.<br>
For descriptions of configuration files, refer to the official documentation (https://springfox.github.io/springfox/docs/current/#quick-start-guides).
<details>
<summary>SwaggerConfig</summary>

```java
package com.samsungsds.eshop.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@Configuration
public class SwaggerConfig {
    private ApiInfo swaggerInfo() {
        return new ApiInfoBuilder().title("E-SHOP API Document")
                .description("E-SHOP API에 대한 설명 페이지")
                .license("")
                .licenseUrl("http://unlicense.org")
                .termsOfServiceUrl("")
                .version("v1")
                .contact(new Contact("","", ""))
                .build();
    }

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.OAS_30)
            .useDefaultResponseMessages(false)    
            .apiInfo(swaggerInfo())
            .select()
            .apis(RequestHandlerSelectors.basePackage("com.samsungsds.eshop")) // 해당 경로 내에 있는 API들을 대상으로 한다.
            .paths(PathSelectors.ant("/api/**"))
            .build();
    }
}

```

</details>

<br>
Access http://localhost:8080/swagger-ui/#/ and check the Swagger page.

![](images/1-ch/swagger-local-2.png)

<br>

The description of each API is not easy to read.
<br>
Add information about each API as annotation.
<br>

<details>
<summary>Cart</summary>

```java

package com.samsungsds.eshop.cart;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api; //👈👈  add line
import io.swagger.annotations.ApiOperation; //👈👈  add line

 

@RestController
@RequestMapping(value = "/api/carts")
@Api(tags = "shopping basket", description = "Shopping Cart API") //👈👈  add line
public class CartController {
    private final CartService cartService;

    public CartController(final CartService cartService) {
        this.cartService = cartService;
    }

    @PostMapping(value = "/empty")
    @ApiOperation(value = "Reset shopping cart") //👈👈  add line
    public ResponseEntity<Void> emptyCart() {
        cartService.emptyCart();
        return ResponseEntity.ok().build();
    }

    @PostMapping
    @ApiOperation(value = "Add to Cart") //👈👈  add line
    public ResponseEntity<Void> addToCart(@RequestBody CartItem cartItem) {
        cartService.addToCart(cartItem);
        return ResponseEntity.ok().build();
    }

    @GetMapping
    @ApiOperation(value = "Shopping Cart View") //👈👈  add line
    public ResponseEntity<List<CartItem>> getCartItems() {
        List<CartItem> cartItems = cartService.getCartItems();
        return ResponseEntity.ok(cartItems);
    }

    @GetMapping(value = "/count")
    @ApiOperation(value = "Check the number of shopping carts") //👈👈  add line
    public ResponseEntity<Long> getCartItemsCount() {
        Long cartItemCount = cartService.getCartItemsCount();
        return ResponseEntity.ok(cartItemCount);
    }
}


```

</details>

<details>
<summary>Ad</summary>

```java

package com.samsungsds.eshop.ad;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

import io.swagger.annotations.Api; //👈👈  add line
import io.swagger.annotations.ApiOperation; //👈👈  add line

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value="/api/ads")
@Api(tags = "광고", description = "광고 관련 API") //👈👈  add line
public class AdController {
    private Logger logger = LoggerFactory.getLogger(AdController.class);
    // private static final ImmutableListMultimap<String, Ad> adsMap = createAdsMap();
    private final AdRepository adRepository;
    private static final Random random = new Random();
    private static final int MAX_ADS_TO_SERVE = 2;

    public AdController(AdRepository adRepository) {
        this.adRepository = adRepository;
    }

    @GetMapping
    @ResponseBody
    @ApiOperation(value = "랜덤 광고 조회하기") //👈👈  add line
    public ResponseEntity<List<Ad>> getRandomAds() {
        logger.info("getRandomAds");
        List<Ad> ads = new ArrayList<>(MAX_ADS_TO_SERVE);
        List<Ad> allAds = Lists.newArrayList(adRepository.findAll());
        for(int i = 0; i < MAX_ADS_TO_SERVE; i++) {
            ads.add(Iterables.get(allAds, random.nextInt(allAds.size())));
        }
        logger.info(ads.toString());
        return ResponseEntity.ok(ads);
    }

    @GetMapping(value="/{categories}")
    @ResponseBody
    @ApiOperation(value = "카테고리에 따른 광고 조회하기") //👈👈  add line
    public ResponseEntity<List<Ad>> getAdsByCategory(@PathVariable String[] categories) {
        logger.info("getAdsByCategory {}", Arrays.toString(categories));
        List<Ad> ads = Lists.newArrayList(adRepository.findByCategoryIn(categories));
        logger.info(ads.toString());
        return ResponseEntity.ok(ads);
    }
}



```

</details>

<details>
<summary>Shipping</summary>

```java

package com.samsungsds.eshop.shipping;

import java.util.List;

import com.samsungsds.eshop.payment.Money; 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api; //👈👈  add line
import io.swagger.annotations.ApiOperation; //👈👈  add line

@RestController
@RequestMapping(value="/api/checkouts/shippings")
@Api(tags = "배송비", description = "배송비 관련 API") //👈👈  add line
public class ShippingController {
    private final Logger logger = LoggerFactory.getLogger(ShippingController.class);
    private final ShippingService shippingService;

    public ShippingController(ShippingService shippingService) {
        this.shippingService = shippingService;
    }

    @PostMapping(value = "/cost")
    @ApiOperation(value = "배송비 조회") //👈👈  add line
    public ResponseEntity<Money> calculateShippingCost(@RequestBody List<ShippingItem> shippingList) {
        logger.info("calculateShippingCost");
        int itemCount = shippingList.stream()
                .map(ShippingItem::getQuantity)
                .reduce(0, Integer::sum);
        Money shippingCost = shippingService.calculateShippingCostFromCount(itemCount);
        logger.info("shippingCost : " + shippingCost);
        return ResponseEntity.ok(shippingCost);
    }
}


```

</details>

<details>
<summary>Product</summary>

```java

package com.samsungsds.eshop.product;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api; //👈👈  add line
import io.swagger.annotations.ApiOperation; //👈👈  add line

@RestController
@RequestMapping(value = "/api/products")
@Api(tags = "상품", description = "상품 관련 API") //👈👈  add line
public class ProductController {
  private final ProductService productService;

  public ProductController(ProductService productService) {
    this.productService = productService;
  }

  @GetMapping
  @ApiOperation(value = "상품 조회") //👈👈  add line
  public ResponseEntity<Products> fetchProducts(@RequestParam(value = "ids", required = false) String ids) {
    Products products = null;
    if (ids == null || ids.isEmpty()) {
      try {
        products = productService.fetchProducts();
      } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(products);
      }
      return ResponseEntity.ok(products);
    } else {
      String[] itemIds = ids.split(",");
      products = productService.fetchProductsByIds(itemIds);
      return ResponseEntity.ok(products);
    }
  }

  @GetMapping(value = "/{id}")
  @ApiOperation(value = "id로 상품 조회") //👈👈  add line
  public ResponseEntity<Product> fetchProductsByIds(@PathVariable("id") String id) {
    Product product = productService.fetchProductById(id);
    return ResponseEntity.ok(product);
  }
}



```

</details>

<details>
<summary>Order</summary>

```java

package com.samsungsds.eshop.order;

import java.util.stream.Stream;

import com.google.common.collect.Iterables;
import com.samsungsds.eshop.cart.CartItem;
import com.samsungsds.eshop.cart.CartService;
import com.samsungsds.eshop.payment.Money;
import com.samsungsds.eshop.payment.PaymentRequest;
import com.samsungsds.eshop.payment.PaymentService;
import com.samsungsds.eshop.product.Product;
import com.samsungsds.eshop.product.ProductService;
import com.samsungsds.eshop.shipping.ShippingRequest;
import com.samsungsds.eshop.shipping.ShippingResult;
import com.samsungsds.eshop.shipping.ShippingService;

import io.swagger.annotations.Api; //👈👈  add line
import io.swagger.annotations.ApiOperation; //👈👈  add line

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/checkouts")
@Api(tags = "주문", description = "주문 관련 API") //👈👈  add line
public class OrderController {
    private final Logger logger = LoggerFactory.getLogger(OrderController.class);
    private final OrderService orderService;
    private final ShippingService shippingService;
    private final CartService cartService;
    private final PaymentService paymentService;
    private final ProductService productService;

    public OrderController(final OrderService orderService, 
    final ShippingService shippingService,
    final  PaymentService paymentService,
    final CartService cartService,
    final ProductService productService) {
        this.orderService = orderService;
        this.shippingService = shippingService;
        this.paymentService = paymentService;
        this.cartService = cartService;
        this.productService = productService;
    }

    @PostMapping(value = "/orders")
    @ApiOperation(value = "주문 생성") //👈👈  add line
    public ResponseEntity<OrderResult> placeOrder(@RequestBody OrderRequest orderRequest) {
        logger.info("placeOrder : " + orderRequest);

        // cart 조회
        CartItem[] cartItems = Iterables.toArray(cartService.getCartItems(), CartItem.class);


        // cart 상품 조회
        Product[] products = getProducts(cartItems);

        // 상품 가격 합계 계산
        Money itemPrice = orderService.calculateItemPrice(cartItems, products);
        logger.info("total item price : " + itemPrice);

        // 예상 배송비 계산
        Money shippingCost = shippingService.calculateShippingCostFromCartItems(cartItems);

        // 결제 요청
        PaymentRequest request = new PaymentRequest(orderRequest.getCreditCardInfo(), itemPrice.plus(shippingCost));
        paymentService.requestPayment(request);

        // 배송 요청
        ShippingResult shippingResult = shippingService
                .shipOrder(new ShippingRequest(cartItems, orderRequest.getAddress()));
        logger.info("shippingCost : " + shippingResult.getShippingCost());

        // 총액 계산
        Money totalCost = itemPrice.plus(shippingResult.getShippingCost());

        // 주문ID 생성
        String orderId = orderService.createOrderId(orderRequest);

        // 카트 비우기
        cartService.emptyCart();
        return ResponseEntity.ok(new OrderResult(orderId, shippingResult.getShippingTrackingId(),
                shippingResult.getShippingCost(), totalCost));
    }

    private Product[] getProducts(CartItem[] cartItems) {
        String[] cartItemIds = Stream.of(cartItems).map(CartItem::getId).toArray(String[]::new);
        return productService.fetchProductsByIds(cartItemIds).getProducts();
    }
}



```

</details>

<details>
<summary>Recommend</summary>

```java

package com.samsungsds.eshop.recommend;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api; //👈👈  add line
import io.swagger.annotations.ApiOperation; //👈👈  add line

@RestController
@RequestMapping(value="/api/recommends")
@Api(tags = "추천", description = "추천 관련 API") //👈👈  add line
public class RecommendController {
  private final RecommendService recommendService;

  public RecommendController(final RecommendService recommendService) {
    this.recommendService = recommendService;
  }

  @GetMapping
  @ApiOperation(value = "추천 상품 조회") //👈👈  add line
  public ResponseEntity<Recommendations> recommendProducts() {
    return ResponseEntity.ok(recommendService.recommendProducts());
  }
}


```

</details>

<details>
<summary>Currency</summary>

```java

package com.samsungsds.eshop.currency;

import java.util.Map;

import com.samsungsds.eshop.payment.Money;

import io.swagger.annotations.Api; //👈👈  add line
import io.swagger.annotations.ApiOperation; //👈👈  add line

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/currencies")
@Api(tags = "통화", description = "통화 관련 API") //👈👈  add line
public class CurrencyController {
  private final CurrencyService currencyService;

  public CurrencyController(final CurrencyService currencyService) {
    this.currencyService = currencyService;
  }

  @GetMapping
  @ApiOperation(value = "통화 조회") //👈👈  add line
  public ResponseEntity<Map<String, Double>> fetchCurrencyMap() {
    Map<String, Double> currencies = null;
    try {
      currencies = currencyService.fetchCurrency();
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(currencies);
    }
    return ResponseEntity.ok(currencies);
  }

  @PostMapping(value = "/convert")
  @ApiOperation(value = "통화 변환") //👈👈  add line
  public ResponseEntity<Money> convertMoneyCurrency(@RequestBody CurrencyConvertRequest request) {
    return ResponseEntity.ok(currencyService.convertMoneyCurrency(request));
  }

}


```

</details>

<br>
API Name 및 Description이 적용된 화면
<br>

![](images/1-ch/swagger-local-3.png)


## 2. REST Docs을 활용한 API Document 페이지 생성

### 2.1 REST Docs?
> - 참고
>   - https://spring.io/projects/spring-restdocs

```text
Spring REST Docs는 Spring Framework에서 제공하는 API 문서 자동화 도구이다.
```

|                 | Swagger                                        | Spring REST Docs                                                                    |
|-------------------|-------------------------------------------|-----------------------------------------------------------------------|
| 장점  | API를 테스트할 수 있는 화면을 제공한다. <br> 간결한 UI| 테스트 기반 문서 생성<br> 프로덕션 코드에 영향을 주지 않는다. |
| 단점      | 프로덕션 코드에 어노테이션 등을 추가하여 가독성이 떨어질 수 있음                     | UI가 Swagger에 비해 간결하지 않음. <br> 테스트 코드 실패 시, 문서도 생성되지 않음.                            |


<br>

```text
도전 과제의 경우, Swagger와 REST Docs를 각각 사용하지만, 같이 사용하여 각각의 장점들을 취할 수 있다.
(Spring REST Docs를 통해 OpenAPI Spec을 생성하고 Swagger를 통해 UI를 그려주는 방식)
```

### 2.2 REST Docs를 위한 테스트 코드를 작성해보자
com.samsungsds.eshop.common.MoneyTest.java의 테스트를 수행해보자

<details>
<summary>예상 결과</summary>

```java
java.lang.NoClassDefFoundError: org/junit/platform/engine/EngineDiscoveryListener
	at java.base/java.lang.ClassLoader.defineClass1(Native Method)
	at java.base/java.lang.ClassLoader.defineClass(ClassLoader.java:1017)
	at java.base/java.security.SecureClassLoader.defineClass(SecureClassLoader.java:174)
	at java.base/jdk.internal.loader.BuiltinClassLoader.defineClass(BuiltinClassLoader.java:800)
	at java.base/jdk.internal.loader.BuiltinClassLoader.findClassOnClassPathOrNull(BuiltinClassLoader.java:698)
	at java.base/jdk.internal.loader.BuiltinClassLoader.loadClassOrNull(BuiltinClassLoader.java:621)
	at java.base/jdk.internal.loader.BuiltinClassLoader.loadClass(BuiltinClassLoader.java:579)
	at java.base/jdk.internal.loader.ClassLoaders$AppClassLoader.loadClass(ClassLoaders.java:178)
	at java.base/java.lang.ClassLoader.loadClass(ClassLoader.java:522)
	at org.junit.platform.launcher.core.ListenerRegistry.forLauncherDiscoveryListeners(ListenerRegistry.java:37)
	at org.junit.platform.launcher.core.DefaultLauncher.<init>(DefaultLauncher.java:40)
	at org.junit.platform.launcher.core.LauncherFactory.createDefaultLauncher(LauncherFactory.java:134)
	at org.junit.platform.launcher.core.LauncherFactory.create(LauncherFactory.java:125)
	at org.junit.platform.launcher.core.LauncherFactory.create(LauncherFactory.java:109)
	at org.eclipse.jdt.internal.junit5.runner.JUnit5TestLoader.<init>(JUnit5TestLoader.java:37)
	at java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)
	at java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)
	at java.base/java.lang.reflect.Constructor.newInstance(Constructor.java:490)
	at java.base/java.lang.Class.newInstance(Class.java:584)
	at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.createRawTestLoader(RemoteTestRunner.java:371)
	at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.createLoader(RemoteTestRunner.java:366)
	at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.defaultInit(RemoteTestRunner.java:310)
	at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.init(RemoteTestRunner.java:225)
	at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.main(RemoteTestRunner.java:209)
Caused by: java.lang.ClassNotFoundException: org.junit.platform.engine.EngineDiscoveryListener
	at java.base/jdk.internal.loader.BuiltinClassLoader.loadClass(BuiltinClassLoader.java:581)
	at java.base/jdk.internal.loader.ClassLoaders$AppClassLoader.loadClass(ClassLoaders.java:178)
	at java.base/java.lang.ClassLoader.loadClass(ClassLoader.java:522)
	... 25 more
```

</details>

<br>
eshop의 경우, Spring Boot 2.2.6 버전을 사용하고 있다. <br>작성된 테스트 코드가 참조하는 Library 중 에러가 나는 라이브러리는 하단 이미지와 같다.
<br>

![](images/1-ch/junit-error.png)

에러 참조하는 클래스인 EngineDiscoveryListener 등은 1.6 버전 이상부터 추가된 클래스이므로, 테스트 도중 사용하는 라이브러리의 버전을 높은 버전으로 변경한다.

build.gradle 파일을 하단과 같이 수정한다.

<details>
<summary>build.gradle</summary>

```gradle
plugins {
    id 'org.springframework.boot' version '2.2.6.RELEASE'
    id 'io.spring.dependency-management' version '1.0.9.RELEASE'
    id 'java'
}

group = 'com.samsungsds'
version = '0.0.1-SNAPSHOT'
sourceCompatibility = '11'

configurations {
    developmentOnly
    runtimeClasspath {
        extendsFrom developmentOnly
    }
}

repositories {
    mavenCentral()
}

dependencies {
    implementation 'org.springframework.boot:spring-boot-starter-web'
    implementation 'org.springframework.boot:spring-boot-starter-thymeleaf'    
    implementation 'org.springframework.boot:spring-boot-starter-data-redis'
    implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
    implementation 'org.postgresql:postgresql'
    developmentOnly 'org.springframework.boot:spring-boot-devtools'    
    implementation 'com.google.guava:guava:28.2-jre'

    testImplementation('org.springframework.boot:spring-boot-starter-test') {
        exclude group: 'org.junit.vintage', module: 'junit-vintage-engine'
    }

    testImplementation 'org.junit.platform:junit-platform-engine:1.8.2' //👈👈  add line
    testImplementation 'org.junit.platform:junit-platform-commons:1.8.2' //👈👈  add line
}

test {
    useJUnitPlatform()
}

```

</details>


<br>
추가된 라이브러리는 다음과 같다.
<br>

![](images/1-ch/junit-error-resolve.png)

<br>

다시 com.samsungsds.eshop.common.MoneyTest.java의 테스트를 수행해보자

<br>
에러 없이 수행된 테스트 결과
<br>

![](images/1-ch/restdoc-1.png)

<br>
이제 Test 코드 작성에 대한 환경 설정을 끝낸 상태이다. <br>
Spring REST Docs를 사용하기 위한 의존성 관리를 추가한다.

<details>
<summary>build.gradle</summary>

```gradle
plugins {
    id 'org.springframework.boot' version '2.2.6.RELEASE'
    id 'io.spring.dependency-management' version '1.0.9.RELEASE'
    id 'java'
    // Asciidoctor 적용
    id 'org.asciidoctor.jvm.convert' version '3.3.2' //👈👈  add line
}

group = 'com.samsungsds'
version = '0.0.1-SNAPSHOT'
sourceCompatibility = '11'

repositories {
    mavenCentral()
}

configurations { //👈👈  add line
    asciidoctorExtensions // dependencies 에서 적용한 것 추가
    developmentOnly
    runtimeClasspath {
        extendsFrom developmentOnly
    }
}

dependencies {
    implementation 'org.springframework.boot:spring-boot-starter-web'
    implementation 'org.springframework.boot:spring-boot-starter-thymeleaf'    
    implementation 'org.springframework.boot:spring-boot-starter-data-redis'
    implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
    implementation 'org.postgresql:postgresql'
    developmentOnly 'org.springframework.boot:spring-boot-devtools'
    implementation 'com.google.guava:guava:28.2-jre'

    testImplementation 'org.springframework.boot:spring-boot-starter-test'
    testImplementation 'org.junit.platform:junit-platform-engine:1.8.2'
    testImplementation 'org.junit.platform:junit-platform-commons:1.8.2'
    
    // mockMvc를 사용해서 snippets를 추출
    testImplementation 'org.springframework.restdocs:spring-restdocs-mockmvc' //👈👈  add line

    // 병합된 .adoc파일을 HTML로 export
    asciidoctorExtensions 'org.springframework.restdocs:spring-restdocs-asciidoctor' //👈👈  add line

    // Json 관련 작업을 위한 라이브러리 추가.
    implementation 'com.google.code.gson:gson' //👈👈  add line
}

ext { //👈👈  add line
    snippetsDir = file('build/generated-snippets')
}

asciidoctor { //👈👈  add line asciidoctor 작업 명시
    inputs.dir snippetsDir
    configurations 'asciidoctorExtensions' // configuration 적용
    dependsOn test
    sources{
        include("**/index.adoc","**/common/*.adoc")
    }
    baseDirFollowsSourceFile()
}

// static/docs 폴더 비우기 -> 초기화 작업
asciidoctor.doFirst { //👈👈  add line
    delete file('src/main/resources/static/docs')
}

// 작업 이후 생성된 HTML 파일을 static/docs 로 복사
task copyDocument(type: Copy) { //👈👈 add line - copyDocument 작업 명시
    dependsOn asciidoctor
    from file("build/docs/asciidoc")
    into file("src/main/resources/static/docs")
}

bootRun { //👈👈 add line - bootRun 의 의존작업 명시
    dependsOn copyDocument
}

//👈👈 add line - build 의 의존작업 명시
build {
    dependsOn copyDocument
}

test {
    outputs.dir snippetsDir //👈👈 add line - snippets 생성 경로 정의
    useJUnitPlatform()
}

```
</details>

Spring REST Docs를 사용하기 위한 의존성 설정이 완료되었다. 이에 따라, Spring REST Docs를 사용하는 Test 코드를 작성한다.
<br>
Ad(광고)의 Controller에 대한 Test 코드를 작성한다.(AdController.java - AdControllerTest.java)

<details>
<summary>AdControllerTest.java</summary>

```java
package com.samsungsds.eshop.ad;

import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.mockito.BDDMockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;

@ExtendWith({RestDocumentationExtension.class})
@WebMvcTest(AdController.class)
public class AdControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdRepository adRepository;

    @MockBean
    private Random random;

    @BeforeEach
    void setUp(WebApplicationContext webApplicationContext, RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
                .apply(documentationConfiguration(restDocumentation)) 
                .build();
    }

    @Test
    public void getRandomAds() throws Exception {
        Ad ad1 = new Ad();
        ad1.setId(1);
        ad1.setRedirectUrl("testUrl-1");
        ad1.setCategory("testCategory-1");
        ad1.setText("testText-1");

        Ad ad2 = new Ad();
        ad2.setId(2);
        ad2.setRedirectUrl("testUrl-2");
        ad2.setCategory("testCategory-2");
        ad2.setText("testText-2");

        List<Ad> allAds = List.of(ad1, ad2);
        given(adRepository.findAll()).willReturn(allAds);
        given(random.nextInt(2)).willReturn(0).willReturn(1);

        this.mockMvc.perform(
            MockMvcRequestBuilders.get("/api/ads")
        )
        .andExpect(status().isOk())
        .andDo(document("get-ad-random", responseFields(
                    fieldWithPath("[].id").description("광고 id"),
                    fieldWithPath("[].category").description("광고 카테고리"),
                    fieldWithPath("[].redirectUrl").description("광고 리다이렉트 주소"),
                    fieldWithPath("[].text").description("광고 설명")
                )
            )
        );
    }

    @Test
    public void getAdsByCategory() throws Exception {
        Object[] inputs = new Object[]{"category"};

        Ad ad1 = new Ad();
        ad1.setId(1);
        ad1.setRedirectUrl("testUrl-1");
        ad1.setCategory("category");
        ad1.setText("testText-1");
        
        List<Ad> allAds = List.of(ad1);

        given(adRepository.findByCategoryIn(any())).willReturn(allAds);
        
        this.mockMvc.perform(
            RestDocumentationRequestBuilders.get("/api/ads/{categories}", inputs)
        )
        .andExpect(status().isOk())
        .andDo(
            document("get-ad-by-category", 
                pathParameters(
                    parameterWithName("categories").description("광고 카테고리")
                ),
                responseFields(
                    fieldWithPath("[].id").description("광고 id"),
                    fieldWithPath("[].category").description("광고 카테고리"),
                    fieldWithPath("[].redirectUrl").description("광고 리다이렉트 주소"),
                    fieldWithPath("[].text").description("광고 설명")
                )
            )
        );
    }
}

```

</details>

<br>
💡비지니스 로직에 대한 테스트 수행 뒤, Document를 생성하는 부분에 대해 확인한다.
<br>
테스트 코드를 작성하였으니, build를 수행한다.

```
./gradlew build
```
<br>
build 디렉토리 내 AD에 해당하는 adoc파일이 생성되었는지 확인한다.
<br>

![](images/1-ch/restdoc-3.png)
<br>
생성된 adoc를 조합하는 파일에 대해 정의한다.
<br>
src 디렉토리 내에 docs/asciidoc 폴더를 생성한다.
<br>
해당 폴더 내에 index.adoc파일을 생성한다.
<br>
index.adoc 파일은 Document 설정 파일에 해당하며 제목, 목차, API 대상 등을 정의한다. 현재 AD에 대해 작업한 상태이므로, AD에 대한 정의를 index.adoc파일에 추가한다.

<details>
<summary>index.adoc</summary>
= E-SHOP API Documentation<br>
E-SHOP API Documentation<br>
:source-highlighter: highlightjs<br>
:toc: left<br>
:toc-title: 목차<br>
:toclevels: 2<br>
:sectnums:<br>
:sectlinks:<br>
<br>
[[AD-API]]<br>
== AD API<br>
<br>
[[AD-랜덤-조회]]<br>
=== AD 랜덤 조회<br>
operation::get-ad-random[snippets='http-request,http-response,response-fields']<br>
<br>
[[AD-카테고리-ID-조회]]<br>
=== AD 카테고리 ID 조회<br>
operation::get-ad-by-category[snippets='http-request,path-parameters,http-response,response-fields']<br>
</details>

<br>
로컬 환경 실행 방법을 참고하여, 로컬을 실행한다.
build 폴더 내, generated-snippets 생성 여부를 확인한다.

localhost:8080/static/docs/index.html 로 접속한다.

<details>
<summary>화면 참조</summary>

![](images/1-ch/restdoc-2.png)

</details>

<br>
나머지 모듈인 Cart, Currency, Order, Product, Recommend, Shipping에 대해 동일하게 Test 코드를 작성하고 REST Docs이 제대로 생성되었는지 확인한다.
<br>
<details>
<summary>CartControllerTest.java</summary>

```java
package com.samsungsds.eshop.cart;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.restdocs.payload.JsonFieldType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;

import static org.mockito.BDDMockito.*;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;

@ExtendWith({RestDocumentationExtension.class})
@WebMvcTest(CartController.class)
public class CartControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CartService cartService;

    @BeforeEach
    void setUp(WebApplicationContext webApplicationContext, RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
                .apply(documentationConfiguration(restDocumentation)) 
                .build();
    }

    @Test
    void testAddToCart() throws Exception {
        CartItem param = new CartItem();
        param.setId("1");
        param.setQuantity(1);

        doNothing().when(cartService).addToCart(param);
        
        Gson gson = new Gson();
        String inputJson = gson.toJson(param);
        this.mockMvc.perform(
            RestDocumentationRequestBuilders
                .post("/api/carts")
                .content(inputJson)
                .contentType(MediaType.APPLICATION_JSON)
        )
        .andExpect(status().isOk())
        .andDo(
            document("post-add-carts",
                requestFields( 
                    fieldWithPath("id").type(JsonFieldType.STRING).description("상품 ID"), 
                    fieldWithPath("quantity").type(JsonFieldType.NUMBER).description("상품 갯수") 
                )
            )
        );
    }

    @Test
    void testEmptyCart() throws Exception {
        doNothing().when(cartService).emptyCart();
        this.mockMvc.perform(
            MockMvcRequestBuilders.post("/api/carts/empty")
        )
        .andExpect(status().isOk())
        .andDo(document("post-empty-carts"));
    }

    @Test
    void testGetCartItems() throws Exception {
        CartItem cartItem1 = new CartItem();
        cartItem1.setId("1");
        cartItem1.setQuantity(1);
        CartItem cartItem2 = new CartItem();
        cartItem2.setId("2");
        cartItem2.setQuantity(2);

        given(cartService.getCartItems()).willReturn(List.of(cartItem1, cartItem2));
        
        this.mockMvc.perform(
            MockMvcRequestBuilders.get("/api/carts")
        )
        .andExpect(status().isOk())
        .andDo(document("get-carts", 
                responseFields(
                    fieldWithPath("[].id").description("상품 id"),
                    fieldWithPath("[].quantity").description("상품 갯수")
                )
            )
        );
    }

    @Test
    void testGetCartItemsCount() throws Exception {
        Long responseMock = 1L;
        given(cartService.getCartItemsCount()).willReturn(responseMock);
        
        this.mockMvc.perform(
            MockMvcRequestBuilders.get("/api/carts/count")
        )
        .andExpect(status().isOk())
        .andDo(document("get-count-carts"));
    }
}

```
</details>

<details>
<summary>CurrencyControllerTest.java</summary>

```java
package com.samsungsds.eshop.currency;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.mockito.BDDMockito.*;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;

import java.util.HashMap;
import java.util.Map;

@ExtendWith({RestDocumentationExtension.class})
@WebMvcTest(CurrencyController.class)
public class CurrencyControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CurrencyService currencyService;
    
    @BeforeEach
    void setUp(WebApplicationContext webApplicationContext, RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
                .apply(documentationConfiguration(restDocumentation)) 
                .build();
    }

    @Test
    void testConvertMoneyCurrency() throws Exception {
        Map<String, Double> mockResponse = new HashMap<String, Double>();
        mockResponse.put("CHF", 1.136);
        mockResponse.put("HRK", 7.421);
        mockResponse.put("MXN", 21.7999);
        mockResponse.put("ZAR", 16.0583);
        mockResponse.put("INR", 79.432);
        mockResponse.put("CNY", 7.5857);
        mockResponse.put("THB", 36.012);
        mockResponse.put("AUD", 1.6072);
        mockResponse.put("ILS", 4.0875);
        mockResponse.put("KRW", 1275.05);
        mockResponse.put("JPY", 126.4);
        mockResponse.put("PLN", 4.2996);
        mockResponse.put("GBP", 0.8597);
        mockResponse.put("IDR", 15999.4);
        mockResponse.put("HUF", 315.51);
        mockResponse.put("PHP", 59.083);
        mockResponse.put("TRY", 6.1247);
        mockResponse.put("RUB", 74.4208);
        mockResponse.put("ISK", 136.8);
        mockResponse.put("HKD", 8.8743);
        mockResponse.put("EUR", 1.0);
        mockResponse.put("DKK", 7.4609);
        mockResponse.put("USD", 1.1305);
        mockResponse.put("CAD", 1.5128);
        mockResponse.put("MYR", 4.6289);
        mockResponse.put("BGN", 1.9558);
        mockResponse.put("NOK", 9.804);
        mockResponse.put("RON", 4.7463);
        mockResponse.put("SGD", 1.5349);
        mockResponse.put("CZK", 25.592);
        mockResponse.put("SEK", 10.5375);
        mockResponse.put("NZD", 1.6679);
        mockResponse.put("BRL", 4.2682);
        given(currencyService.fetchCurrency()).willReturn(mockResponse);

        this.mockMvc.perform(
            MockMvcRequestBuilders.get("/api/currencies")
        )
        .andExpect(status().isOk())
        .andDo(document("get-currencies", 
            responseFields(
                    fieldWithPath("CHF").description("통화코드 CHF 변환 값"),
                    fieldWithPath("HRK").description("통화코드 HRK 변환 값"),
                    fieldWithPath("MXN").description("통화코드 MXN 변환 값"),
                    fieldWithPath("ZAR").description("통화코드 ZAR 변환 값"),
                    fieldWithPath("INR").description("통화코드 INR 변환 값"),
                    fieldWithPath("CNY").description("통화코드 CNY 변환 값"),
                    fieldWithPath("THB").description("통화코드 THB 변환 값"),
                    fieldWithPath("AUD").description("통화코드 AUD 변환 값"),
                    fieldWithPath("ILS").description("통화코드 ILS 변환 값"),
                    fieldWithPath("KRW").description("통화코드 KRW 변환 값"),
                    fieldWithPath("JPY").description("통화코드 JPY 변환 값"),
                    fieldWithPath("PLN").description("통화코드 PLN 변환 값"),
                    fieldWithPath("GBP").description("통화코드 GBP 변환 값"),
                    fieldWithPath("IDR").description("통화코드 IDR 변환 값"),
                    fieldWithPath("HUF").description("통화코드 HUF 변환 값"),
                    fieldWithPath("PHP").description("통화코드 PHP 변환 값"),
                    fieldWithPath("TRY").description("통화코드 TRY 변환 값"),
                    fieldWithPath("RUB").description("통화코드 RUB 변환 값"),
                    fieldWithPath("ISK").description("통화코드 ISK 변환 값"),
                    fieldWithPath("HKD").description("통화코드 HKD 변환 값"),
                    fieldWithPath("EUR").description("통화코드 EUR 변환 값"),
                    fieldWithPath("DKK").description("통화코드 DKK 변환 값"),
                    fieldWithPath("USD").description("통화코드 USD 변환 값"),
                    fieldWithPath("CAD").description("통화코드 CAD 변환 값"),
                    fieldWithPath("MYR").description("통화코드 MYR 변환 값"),
                    fieldWithPath("BGN").description("통화코드 BGN 변환 값"),
                    fieldWithPath("NOK").description("통화코드 NOK 변환 값"),
                    fieldWithPath("RON").description("통화코드 RON 변환 값"),
                    fieldWithPath("SGD").description("통화코드 SGD 변환 값"),
                    fieldWithPath("CZK").description("통화코드 CZK 변환 값"),
                    fieldWithPath("SEK").description("통화코드 SEK 변환 값"),
                    fieldWithPath("NZD").description("통화코드 NZD 변환 값"),
                    fieldWithPath("BRL").description("통화코드 BRL 변환 값")
                )
            )
        );
    }
}

```
</details>

<details>
<summary>OrderControllerTest.java</summary>

```java
package com.samsungsds.eshop.order;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.restdocs.payload.JsonFieldType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.common.collect.Iterables;
import com.google.gson.Gson;
import com.samsungsds.eshop.cart.CartItem;
import com.samsungsds.eshop.cart.CartService;
import com.samsungsds.eshop.payment.CreditCardInfo;
import com.samsungsds.eshop.payment.Money;
import com.samsungsds.eshop.payment.PaymentRequest;
import com.samsungsds.eshop.payment.PaymentService;
import com.samsungsds.eshop.product.Product;
import com.samsungsds.eshop.product.ProductService;
import com.samsungsds.eshop.product.Products;
import com.samsungsds.eshop.shipping.Address;
import com.samsungsds.eshop.shipping.ShippingResult;
import com.samsungsds.eshop.shipping.ShippingService;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.*;
import static org.mockito.Mockito.doNothing;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;

import java.util.List;
import java.util.Set;

@ExtendWith({RestDocumentationExtension.class})
@WebMvcTest(OrderController.class)
public class OrderControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrderService orderService;

    @MockBean
    private ShippingService shippingService;

    @MockBean
    private CartService cartService;

    @MockBean
    private PaymentService paymentService;

    @MockBean
    private ProductService productService;

    @BeforeEach
    void setUp(WebApplicationContext webApplicationContext, RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
                .apply(documentationConfiguration(restDocumentation)) 
                .build();
    }

    @Test
    void testPlaceOrder() throws Exception {
        CreditCardInfo creditCardInfo = new CreditCardInfo();
        creditCardInfo.setCvv(0);
        creditCardInfo.setCreditCardExpirationYear(2023);
        creditCardInfo.setCreditCardExpirationMonth(3);
        creditCardInfo.setCreditCardNumber("1234567890");
        Address address = new Address();
        address.setCity("test-city");
        address.setCountry("test-country");
        address.setState("test-state");
        address.setStreetAddress("test-street");
        address.setZipCode("test-zipcode");
        OrderRequest orderRequest = new OrderRequest();
        orderRequest.setCreditCardInfo(creditCardInfo);
        orderRequest.setAddress(address);
        orderRequest.setEmailAddress("test-email");

        Gson gson = new Gson();
        String inputJson = gson.toJson(orderRequest);

        CartItem cartItem = new CartItem();
        cartItem.setId("1");
        cartItem.setQuantity(1);
        List<CartItem> cartItemList = List.of(cartItem);

        given(cartService.getCartItems()).willReturn(cartItemList);

        Product product = new Product();
        product.setId("1");
        product.setDescription("test_desc");
        product.setName("test_name");
        product.setPicture("test_picture");
        Money money = new Money();
        money.setCurrencyCode("USD");
        money.setUnits(10L);
        money.setNanos(11L);
        product.setPriceUsd(money);
        product.setCategories(Set.of("test_category"));

        Product[] productList = new Product[]{product};
        given(productService.fetchProductsByIds(new String[]{"1"})).willReturn(new Products(productList));

        Money itemPrice = new Money();
        itemPrice.setCurrencyCode("USD");
        itemPrice.setUnits(10L);
        itemPrice.setNanos(11L);
        given(orderService.calculateItemPrice(Iterables.toArray(cartItemList, CartItem.class), productList)).willReturn(itemPrice);

        Money calculatedCost = new Money();
        calculatedCost.setCurrencyCode("USD");
        calculatedCost.setUnits(4L);
        calculatedCost.setNanos(737192818L);
        given(shippingService.calculateShippingCostFromCartItems(Iterables.toArray(cartItemList, CartItem.class))).willReturn(itemPrice);

        PaymentRequest paymentRequest = new PaymentRequest(orderRequest.getCreditCardInfo(), itemPrice.plus(calculatedCost));
        given(paymentService.requestPayment(paymentRequest)).willReturn(null);

        Money shipMoney = new Money();
        shipMoney.setCurrencyCode("USD");
        shipMoney.setUnits(4L);
        shipMoney.setNanos(737192818L);
        
        given(shippingService.shipOrder(any())).willReturn(new ShippingResult("test-trackingId", shipMoney));
        
        given(orderService.createOrderId(orderRequest)).willReturn("test-orderId");
        
        doNothing().when(cartService).emptyCart();

        this.mockMvc.perform(
            MockMvcRequestBuilders
                .post("/api/checkouts/orders")
                .content(inputJson)
                .contentType(MediaType.APPLICATION_JSON)
        )
        .andExpect(status().isOk())
        .andDo(
            document("post-orders",
                requestFields( 
                    fieldWithPath("emailAddress").type(JsonFieldType.STRING).description("이메일 주소"), 
                    fieldWithPath("address.streetAddress").type(JsonFieldType.STRING).description("상세 주소"), 
                    fieldWithPath("address.city").type(JsonFieldType.STRING).description("도시"), 
                    fieldWithPath("address.state").type(JsonFieldType.STRING).description("주"), 
                    fieldWithPath("address.country").type(JsonFieldType.STRING).description("국가"), 
                    fieldWithPath("address.zipCode").type(JsonFieldType.STRING).description("우편번호"),
                    fieldWithPath("creditCardInfo.creditCardNumber").type(JsonFieldType.STRING).description("카드번호"), 
                    fieldWithPath("creditCardInfo.cvv").type(JsonFieldType.NUMBER).description("cvv"), 
                    fieldWithPath("creditCardInfo.creditCardExpirationYear").type(JsonFieldType.NUMBER).description("유효기간 년"), 
                    fieldWithPath("creditCardInfo.creditCardExpirationMonth").type(JsonFieldType.NUMBER).description("유효기간 월") 
                ),
                responseFields(
                    fieldWithPath("orderId").description("주문 id"),
                    fieldWithPath("shippingTrackingId").description("배송 트래킹 id"),
                    fieldWithPath("shippingCost.currencyCode").description("배송비 통화코드"),
                    fieldWithPath("shippingCost.units").description("배송비 Unit"),
                    fieldWithPath("shippingCost.nanos").description("배송비 Nano"),
                    fieldWithPath("totalPaid.currencyCode").description("총비용 통화코드"),
                    fieldWithPath("totalPaid.units").description("총비용 Unit"),
                    fieldWithPath("totalPaid.nanos").description("총비용 Nano")
                )
            )
        );
    }
}

```
</details>

<details>
<summary>ProductControllerTest.java</summary>

```java
package com.samsungsds.eshop.product;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.samsungsds.eshop.payment.Money;

import static org.mockito.BDDMockito.*;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import java.util.Set;

import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;
import static org.springframework.restdocs.request.RequestDocumentation.requestParameters;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;

@ExtendWith({RestDocumentationExtension.class})
@WebMvcTest(ProductController.class)
public class ProductControllerTest {
    @BeforeEach
    void setUp(WebApplicationContext webApplicationContext, RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
                .apply(documentationConfiguration(restDocumentation)) 
                .build();
    }

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService productService;

    @Test
    void testFetchProducts() throws Exception {
        String ids = "id1,id2";

        Product p1 = new Product();
        p1.setId("id1");
        p1.setDescription("test_desc_id1");
        p1.setName("test_name_id1");
        p1.setPicture("test_picture_id1");
        p1.setPriceUsd(new Money());
        p1.setCategories(Set.of("test_category_id1"));

        Product p2 = new Product();
        p2.setId("id2");
        p2.setDescription("test_desc_id2");
        p2.setName("test_name_id2");
        p2.setPicture("test_picture_id2");
        p2.setPriceUsd(new Money());
        p2.setCategories(Set.of("test_category_id2"));

        Product[] product = new Product[]{p1, p2};
        Products products = new Products(product);

        given(productService.fetchProductsByIds(ids.split(","))).willReturn(products);

        this.mockMvc.perform(
            MockMvcRequestBuilders.get("/api/products").queryParam("ids", ids)
        )
        .andExpect(status().isOk())
        .andDo(
            document("get-products", 
                requestParameters(
                    parameterWithName("ids").description("상품 id")
                ),
                responseFields(
                    fieldWithPath("products.[].id").description("상품 id"),
                    fieldWithPath("products.[].name").description("상품 이름"),
                    fieldWithPath("products.[].description").description("상품 설명"),
                    fieldWithPath("products.[].picture").description("상품 이미지"),
                    fieldWithPath("products.[].priceUsd.currencyCode").description("상품 가격 통화 코드"),
                    fieldWithPath("products.[].priceUsd.units").description("상품 가격 Unit"),
                    fieldWithPath("products.[].priceUsd.nanos").description("상품 가격 Nano"),
                    fieldWithPath("products.[].categories").description("상품 카테고리")
                )
            )
        );
    }

    @Test
    void testFetchProductsByIds() throws Exception {
        String id = "id1";

        Product p1 = new Product();
        p1.setId("id1");
        p1.setDescription("test_desc_id1");
        p1.setName("test_name_id1");
        p1.setPicture("test_picture_id1");
        p1.setPriceUsd(new Money());
        p1.setCategories(Set.of("test_category_id1"));

        given(productService.fetchProductById(id)).willReturn(p1);

        this.mockMvc.perform(
            RestDocumentationRequestBuilders.get("/api/products/{id}", id)
        )
        .andExpect(status().isOk())
        .andDo(
            document("get-products-by-id",
                pathParameters(
                    parameterWithName("id").description("상품 id")
                ),
                responseFields(
                    fieldWithPath("id").description("상품 id"),
                    fieldWithPath("name").description("상품 이름"),
                    fieldWithPath("description").description("상품 설명"),
                    fieldWithPath("picture").description("상품 이미지"),
                    fieldWithPath("priceUsd.currencyCode").description("상품 가격 통화 코드"),
                    fieldWithPath("priceUsd.units").description("상품 가격 Unit"),
                    fieldWithPath("priceUsd.nanos").description("상품 가격 Nano"),
                    fieldWithPath("categories").description("상품 카테고리")
                )
            )
        );

    }
}

```
</details>

<details>
<summary>RecommendControllerTest.java</summary>

```java
package com.samsungsds.eshop.recommend;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.samsungsds.eshop.payment.Money;
import com.samsungsds.eshop.product.Product;

import static org.mockito.BDDMockito.*;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;

import java.util.Set;

@ExtendWith({RestDocumentationExtension.class})
@WebMvcTest(RecommendController.class)
public class RecommendControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    RecommendService recommendService;
    
    @BeforeEach
    void setUp(WebApplicationContext webApplicationContext, RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
                .apply(documentationConfiguration(restDocumentation)) 
                .build();
    }
    
    @Test
    void testRecommendProducts() throws Exception {
        
        Recommendations recommendations = new Recommendations();

        Product p1 = new Product();
        p1.setId("id1");
        p1.setDescription("test_desc_id1");
        p1.setName("test_name_id1");
        p1.setPicture("test_picture_id1");
        p1.setPriceUsd(new Money());
        p1.setCategories(Set.of("test_category_id1"));

        Product p2 = new Product();
        p2.setId("id2");
        p2.setDescription("test_desc_id2");
        p2.setName("test_name_id2");
        p2.setPicture("test_picture_id2");
        p2.setPriceUsd(new Money());
        p2.setCategories(Set.of("test_category_id2"));
        
        Product[] products = new Product[]{p1, p2};

        recommendations.setRecommendations(products);
        given(recommendService.recommendProducts()).willReturn(recommendations);

        this.mockMvc.perform(
            MockMvcRequestBuilders.get("/api/recommends")
        )
        .andExpect(status().isOk())
        .andDo(
            document("get-recommends",
                responseFields(
                    fieldWithPath("recommendations.[].id").description("추천 상품 id"),
                    fieldWithPath("recommendations.[].name").description("추천 상품 이름"),
                    fieldWithPath("recommendations.[].description").description("추천 상품 설명"),
                    fieldWithPath("recommendations.[].picture").description("추천 상품 이미지"),
                    fieldWithPath("recommendations.[].priceUsd.currencyCode").description("추천 상품 가격 통화 코드"),
                    fieldWithPath("recommendations.[].priceUsd.units").description("추천 상품 가격 Unit"),
                    fieldWithPath("recommendations.[].priceUsd.nanos").description("추천 상품 가격 Nano"),
                    fieldWithPath("recommendations.[].categories").description("추천 상품 카테고리")
                )
            )
        );
    }
}

```
</details>

<details>
<summary>ShippingControllerTest.java</summary>

```java
package com.samsungsds.eshop.shipping;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.restdocs.payload.JsonFieldType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.samsungsds.eshop.payment.Money;

import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.mockito.BDDMockito.*;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;

import java.util.List;

@ExtendWith({RestDocumentationExtension.class})
@WebMvcTest(ShippingController.class)
public class ShippingControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ShippingService shippingService;    

    @BeforeEach
    void setUp(WebApplicationContext webApplicationContext, RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
                .apply(documentationConfiguration(restDocumentation)) 
                .build();
    }

    @Test
    void testCalculateShippingCost() throws Exception {
        ShippingItem shippingItem1 = new ShippingItem();
        shippingItem1.setProductId("id1");
        shippingItem1.setQuantity(2);

        ShippingItem shippingItem2 = new ShippingItem();
        shippingItem2.setProductId("id2");
        shippingItem2.setQuantity(1);
        List<ShippingItem> shippingList = List.of(shippingItem1, shippingItem2);

        Money shippingCost = new Money();
        shippingCost.setCurrencyCode("USD");
        shippingCost.setUnits(10);
        shippingCost.setNanos(2);
        given(shippingService.calculateShippingCostFromCount(3)).willReturn(shippingCost);

        Gson gson = new Gson();
        String inputString = gson.toJson(shippingList);

        this.mockMvc.perform(
            MockMvcRequestBuilders
                .post("/api/checkouts/shippings/cost")
                .content(inputString)
                .contentType(MediaType.APPLICATION_JSON)
        )
        .andExpect(status().isOk())
        .andDo(
            document("post-shipping-cost",
                requestFields( 
                    fieldWithPath("[].productId").type(JsonFieldType.STRING).description("배송 요청 상품 id"), 
                    fieldWithPath("[].quantity").type(JsonFieldType.NUMBER).description("배송 요청 상품 갯수")
                ),
                responseFields(
                    fieldWithPath("currencyCode").description("배송비 통화 코드"),
                    fieldWithPath("units").description("배송비 Unit"),
                    fieldWithPath("nanos").description("배송비 Nano")
                )
            )
        );
    }
}

```
</details>

<details>
    <summary>index.adoc</summary>
= E-SHOP API Documentation<br>
E-SHOP API Documentation<br>
:source-highlighter: highlightjs<br>
:toc: left<br>
:toc-title: 목차<br>
:toclevels: 2<br>
:sectnums:<br>
:sectlinks:<br>
<br>
[[AD-API]]<br>
== AD API<br>
<br>
[[AD-랜덤-조회]]<br>
=== AD 랜덤 조회<br>
operation::get-ad-random[snippets='http-request,http-response,response-fields']<br>
<br>
[[AD-카테고리-ID-조회]]<br>
=== AD 카테고리 ID 조회<br>
operation::get-ad-by-category[snippets='http-request,path-parameters,http-response,response-fields']<br>
<br>
[[CARTS-API]]<br>
== CARTS API<br>
<br>
[[CART-추가]]<br>
=== CART-추가<br>
operation::post-add-carts[snippets='http-request,request-fields,http-response']<br>
<br>
[[CART-조회]]<br>
=== CART-조회<br>
operation::get-carts[snippets='http-request,http-response,response-fields']<br>
<br>
[[CART-비우기]]<br>
=== CART-비우기<br>
operation::post-empty-carts[snippets='http-request,http-response']<br>
<br>
[[CART-갯수-조회]]<br>
=== CART-갯수-조회<br>
operation::get-count-carts[snippets='http-request,http-response']<br>
<br>
[[CURRENCIES-API]]<br>
== CURRENCIES API<br>
<br>
[[CURRENCIES-조회]]<br>
=== CURRENCIES-조회<br>
operation::get-currencies[snippets='http-request,http-response,response-fields']<br>
<br>
[[ORDERS-API]]<br>
== ORDERS API<br>
<br>
[[ORDERS-생성]]<br>
=== ORDERS-생성<br>
operation::post-orders[snippets='http-request,request-fields,http-response,response-fields']<br>
<br>
[[PRODUCTS-API]]<br>
== PRODUCTS API<br>
<br>
[[PRODUCTS-다건-조회]]<br>
=== PRODUCTS-다건-조회<br>
operation::get-products[snippets='http-request,request-parameters,http-response,response-fields']<br>
<br>
[[PRODUCTS-단건-조회]]<br>
=== PRODUCTS-단건-조회<br>
operation::get-products-by-id[snippets='http-request,path-parameters,http-response,response-fields']<br>
<br>
[[RECOMMENDS-API]]<br>
== RECOMMENDS API<br>
<br>
[[RECOMMENDS-상품-조회]]<br>
=== RECOMMENDS-상품-조회<br>
operation::get-recommends[snippets='http-request,http-response,response-fields']<br>
<br>
[[SHIPPING-API]]<br>
== SHIPPING API<br>
<br>
[[SHIPPING-비용-계산]]<br>
=== SHIPPING-비용-계산<br>
operation::post-shipping-cost[snippets='http-request,request-fields,http-response,response-fields']<br>

</details>

<br>
로컬 환경 실행 방법을 참고하여, 로컬을 실행한다.
build 폴더 내, generated-snippets 생성 여부를 확인한다.

<br>
<details>
<summary>화면 참조</summary>

![](images/1-ch/restdoc-last.png)

</details>
<br>

localhost:8080/static/docs/index.html 로 접속한다.

<details>
<summary>화면 참조</summary>

![](images/1-ch/restdoc-final.png)

</details>
<br>

```text

💡Test 코드 내에 중복되는 코드가 다수 존재하는 것으로 보인다. 이를 효율적으로 리펙토링을 수행해보자.(Hint: TestConfiguration, extends)
💡Test 코드 기반으로 Document 문서가 생성됨을 확인하였다. Swagger와 Rest Docs를 병합하여 사용하는 방법을 도전해보자.(Hint: OAS)
💡REST Docs 실습을 위해 Controller에 해당하는 Test 코드만 작성하였다. Service에 대해 Test 코드를 작성해보자.

```

# **One. Legacy Service**

- [**One. Legacy service**](#1--legacy-service)
- [**Final Goal**](#Final Goal)
   - [**1-1. Take a look at legacy services**](#1-1-legacy-service-look)
     - [Practice Goals](#Practice Goals)
     - [1-1-1. Current situation of eshop Legacy service (a.k.a. Hipster Shop)](#1-1-1-eshop-legacy-service-aka-hipster-shop-current situation)
     - [1-1-2. eshop Legacy system overview](#1-1-2-eshop-legacy-system-overview)
     - [1-1-3. eshop Legacy service architecture](#1-1-3-eshop-legacy-service-architecture)
     - [1-1-4. Function and API list](#1-1-4-function-and-api-list)
   - [1-2. Looking at AS-IS source](#1-2-as-is-source-looking)
     - [1-2-1. Take a look at the backend code](#1-2-1-backend-code-look)
     - [1-2-2. A look at the frontend code](#1-2-2-frontend-code-look)
     - [1-2-3. Take a look at the compose.yaml file](#1-2-3-composeyaml-file-look into it)
   - [1-3. Running eshop Legacy service (local environment)](#1-3-eshop-legacy-service-running-local-environment)
     - [1-3-1. Executing PostgreSQL and redis locally using docker compose](#1-3-1 Executing postgresql and redis locally using docker-compose)
     - [1-3-2. Backend local execution](#1-3-2-backend-local-execution)
     - [1-3-3. Run Frontend locally](#1-3-3-frontend-local-run)
     - [Frontend execution results](#frontend-execution-results)
   - [**💡Troubleshooting**💡](#troubleshooting)
   - [1-4. eshop Legacy service containerization and local environment startup](#1-4-eshop-legacy-service-containerization-and-local-environment-startup)
   - [1-4-1. Backend containerization](#1-4-1-backend-containerization)
     - [Add backend to compose.yaml](#add-backend-tocomposeyaml)
   - [1-4-2. Frontend containerization](#1-4-2-frontend-containerization)
     - [Add frontend to compose.yaml](#add-frontend-tocomposeyaml)
     - [Start containerized service in local environment] (#Start containerized service in local environment)
   - [**💡Troubleshooting💡**](#troubleshooting-1)

<br/>

---

# **Final Goal**

- Run eshop Legacy in local environment
- eshop Legacy containerization and startup
<br/>
<br/>

---

## **1-1. Explore Legacy Services**

### Practice Objectives
- Try running the service on a local PC using the existing AS-IS source.
<br/><br/><br/>

### 1-1-1. Current status of eshop Legacy service (a.k.a. Hipster Shop)

>*Hipster Shop is an online shopping mall where you can purchase a variety of products.*
>*Hipster Shop started as a small service based on on-premise, but is experiencing frequent **service failure** due to the rapid increase in users.*
>*Also, in order to differentiate ourselves, we want to develop new features faster than our competitors.*
>*Hipster Shop's management decided to move the service to **Public Cloud** as a **container-based microservice**.*

<br/>

### 1-1-2. eshop Legacy system overview

![](images/1-1/image21.tmp) <!--Needs modification-->

<br/><br/>
Main screen <br/><br/>
![](images/1-1/image22.tmp)
<br/>
<br/>
<br/>
Shopping cart screen <br/><br/>
![](images/1-1/image23.tmp)

<br/>

### 1-1-3. eshop Legacy service architecture

![](images/1-1/image24.tmp)

|Classification|Development language|Development framework|Repository|
|-------|---------|-------------|------|
|Frontend|javascript|vue.js|-|
|Backend|java|spring boot|PostgreSQL, Redis|

- Hipster Shop consists of a Frontend in the form of a Single Page Application (SPA) developed with Vue.js and a Backend developed with Spring Boot that communicates through HTTP REST API.

- As data storage, PostgreSQL is used to store product data, etc., and Redis is used to hold shopping cart data.

- Product images are a burden on the backend because the backend server directly serves them in the form of static resources.

- The backend and database are not duplicated, so service availability is not high.

- Development requirements related to user authentication/authorization for smooth practice are omitted in this practice domain.

<br/>

### 1-1-4. Features and API List
| function            | detail of fuction                                                |API|
|---------------|-------------------------------------------------------|---|
| Advertisement Views | Select a few random advertisements and view the list.                           |   GET /ads|
| View ads by category | View the list of advertisements in the same category as the product selected by the user. |GET /ads/{categories}|
| View shopping cart list | View a list of the type and number of products in your shopping cart. |GET /carts|
| Add to Cart | Add the product selected by the user to the shopping cart. |POST /carts|
| Empty shopping cart | Remove all products in the shopping cart. |POST /carts/empty|
| Check the number of products in your shopping cart | Check the number of products in the shopping cart. |GET /carts/count|
| Order | Enter payment and shipping information and order the products added to your shopping cart. | POST /checkouts/orders|
| Calculate shipping cost | Calculate the shipping cost for the products in your shopping cart. |GET /shippings/cost|
| View exchange rate list | Check the list of supported exchange rates. |GET /currencies|
| Currency Conversion | Calculate the amount converted to exchange rate. |POST /currencies/convert|
| Product list inquiry | Search the entire product list or receive the product ID list as a parameter and search the list of corresponding products. |GET /products|
| Product details inquiry | Search detailed product information using the product ID. |GET /products/:id|
| View list of recommended products | View the list of products recommended by the recommendation service. |GET /recommends|


<br/><br/><br/>
## 1-2.Explore AS-IS Source
The main branch of the source code repository is checked in the eshop-legacy-mentee directory.
It is out. Look at the list of files in the directory.

```bash
cd ~/eshop-legacy-mentee

ls -al

total 40
drwxr-xr-x 6 ubuntu ubuntu 4096 Nov 16 2022 .
drwxr-xr-x 15 ubuntu ubuntu 4096 Jun 22 17:41 ..
-rw-r--r-- 1 ubuntu ubuntu 5 Nov 16 2022 .gitignore
-rw-r--r-- 1 ubuntu ubuntu 632 Nov 16 2022 README.md
-rw-r--r-- 1 ubuntu ubuntu 914 Nov 16 2022 compose.yaml
drwxr-xr-x 4 ubuntu ubuntu 4096 Nov 16 2022 eshop-backend
drwxr-xr-x 4 ubuntu ubuntu 4096 Nov 16 2022 eshop-frontend
drwxr-xr-x 2 ubuntu ubuntu 4096 Nov 16 2022 images
drwxr-xr-x 2 ubuntu ubuntu 4096 Nov 16 2022 k8s
-rw-r--r-- 1 ubuntu ubuntu 244 Nov 16 2022 skaffold.yaml

```
The backend code is in the eshop-backend directory, and the eshop-frontend directory is
The frontend code exists.

Let’s take a closer look at the source code structure through VS Code.

<br/>

### 1-2-1. Take a look at the backend code

The following is the source code structure of eshop-backend.

![](images/1-1/image25.tmp)

eshop-backend is a Spring Boot application built using the gradle wrapper.

The root package of the source code is com.samsungsds.eshop, and you can see that sub-packages are divided by business domain.

|Package|Work Domain|
|------|-----------|
|com.samsungsds.eshop.ad |Advertisement|
|com.samsungsds.eshop.cart |Shopping Cart|
|com.samsungsds.eshop.config |Spring Bean Configuration|
|com.samsungsds.eshop.currency |Exchange Rate|
|com.samsungsds.eshop.order |Order|
|com.samsungsds.eshop.payment |Payment|
|com.samsungsds.eshop.product |Product|
|com.samsungsds.eshop.recommend |Recommend|
|com.samsungsds.eshop.shipping |Delivery|

<br/>

Under the resources directory, there is a static/img/products directory for servicing static resources, and product image files can be found here.

The resources/application.properties file contains application settings and its contents are as follows.

```bash
server.port=8090
spring.redis.host=localhost
spring.redis.port=6379
spring.jpa.show-sql=true
spring.jpa.generate-ddl=true
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQL10Dialect
spring.jpa.hibernate.ddl-auto=create-drop
spring.datasource.initialization-mode=always
spring.datasource.url=jdbc:postgresql://localhost:5432/eshop_db
spring.datasource.username=eshop_user
spring.datasource.password=password
spring.mvc.static-path-pattern=/static/**
spring.resources.cache.cachecontrol.max-age=3600
```

The port number of the backend server is 8090, and you can see that redis and postgreSQL are used as data storage.

<br/>

The resources/import.sql file is a script that inputs initial application data.
Through this script, you can guess the database schema of the AS-IS application.

```sql
INSERT INTO currency (currency_code, currency_value) VALUES ('EUR', 1.0);
INSERT INTO currency (currency_code, currency_value) VALUES ('USD', 1.1305);
...
 
INSERT INTO ad (category, redirect_url, text) VALUES ('photography','/products/2ZYFJ3GM2N','Film camera for sale. 50% off.');
INSERT INTO ad (category, redirect_url, text) VALUES ('vintage','/products/2ZYFJ3GM2N','Film camera for sale. 50% off.');
...
 
INSERT INTO product(id, name, description, picture, price_usd) VALUES ('OLJCESPC7Z','Vintage Typewriter', 'This typewriter looks good in your living room.', '/static/img/products/typewriter.jpg', 'USD|67|990000000');
INSERT INTO product(id, name, description, picture, price_usd) VALUES ('66VCHSJNUP','Vintage Camera Lens', 'You won''t have a camera to use it and it probably doesn''t work anyway.', '/static/img/products/camera-lens.jpg', 'USD|12|490000000');
...
 
INSERT INTO product_category(product_id, category) VALUES ('OLJCESPC7Z','vintage');
INSERT INTO product_category(product_id, category) VALUES ('66VCHSJNUP','photography');
...
```

<br/>

### 1-2-2. Take a look at the frontend code

The following is the code structure of eshop-frontend. You can see that it has the structure of a typical vue.js application.

![](images/1-1/image26.tmp)

The following is the contents of package.json.
```json
{
  "name": "frontend",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "serve": "vue-cli-service serve",
    "build": "vue-cli-service build",
    "lint": "vue-cli-service lint"
  },
  "dependencies": {
    "axios": ">=0.21.1",
    "bootstrap-vue": "^2.8.0",
    "core-js": "^3.6.4",
    "dotenv": "^8.2.0",
    "lodash": "^4.17.15",
    "vue": "^2.6.11",
    "vue-router": "^3.1.5",
    "vuex": "^3.1.3"
  },
  "devDependencies": {
    "@vue/cli-plugin-babel": "~4.2.0",
    "@vue/cli-plugin-eslint": "~4.2.0",
    "@vue/cli-plugin-router": "^4.2.3",
    "@vue/cli-plugin-vuex": "^4.2.3",
    "@vue/cli-service": "~4.2.0",
    "babel-eslint": "^10.0.3",
    "eslint": "^6.7.2",
    "eslint-plugin-vue": "^6.1.2",
    "vue-cli-plugin-axios": "0.0.4",
    "vue-template-compiler": "^2.6.11"
  },
  "eslintConfig": {
    "root": true,
    "env": {
      "node": true
    },
    "extends": [
      "plugin:vue/essential",
      "eslint:recommended"
    ],
    "parserOptions": {
      "parser": "babel-eslint"
    },
    "rules": {}
  },
  "browserslist": [
    "> 1%",
    "last 2 versions"
  ]
}
```
If you check the dependencies section, you can see that the frontend application uses bootstrap-vue as the UI framework and vuex for state management. Communication with the backend uses axios.

When you check the scripts section, you can see that the development server of the frontend application can be started with the **npm run serve** command and built with the **npm run build** command.

The following is the contents of the router/index.js file. Vue-router is used to change the screen of the frontend application, and you can see that it has a home screen, shopping cart screen, product detail screen, and order screen.

```js
import Vue from 'vue'
import VueRouter from 'vue-router'
 
 
Vue.use(VueRouter)
 
const routes = [
   {
     path: '/',
     name: 'Home',
     component: () => import('@/components/Home.vue'),
   },
   {
     path: '/cart',
     name: 'Cart',
     component: () => import('@/components/Cart.vue'),
   },
   {
     path: '/products/:id',
     name: 'ProductDetail',
     // route level code-splitting
     // this generates a separate chunk (about.[hash].js) for this route
     // which is lazy-loaded when the route is visited.
     component: () => import('@/components/ProductDetail.vue'),
     props: true
   },
   {
     path: '/order',
     name: 'Order',
     // route level code-splitting
     // this generates a separate chunk (about.[hash].js) for this route
     // which is lazy-loaded when the route is visited.
     component: () => import('@/components/Order.vue'),
     props: true
   },
]
 
const router = new VueRouter({
   routes
})
 
export default router
```

If you look at the vue.config.js file, you can see that proxy settings are set to avoid CORS issues.

```js
module.exports = {
   devServer: {
     proxy: {
         "^/": {
           target: "http://localhost:8090"
         }
     },
     disableHostCheck: true
   }
}
```

If the proxy setting is set, the vue development server does not call the eshop-backend server directly from the web browser, but calls it in proxy form.

<br/>

### 1-2-3. Take a look at the compose.yaml file

The AS-IS application starts redis and postgreSQL, which are used as data storage in the backend service, using docker.

The following is the contents of the compose.yaml file.

As defined in the services below, PostgreSQL can be accessed through port 5432, and Redis can be connected through port 6379.

```yaml
version: "3"
 
services:
   redis:
     image: redis:5.0-alpine
     restart : always
     ports:
       - "6379:6379"
 
   postgres:
     image:postgres:13
     restart : always
     ports:
       - "5432:5432"
     volumes:
       - ./data/postgres/data:/var/lib/postgresql/data
     environment:
       - POSTGRES_DB=eshop_db
       - POSTGRES_USER=eshop_user
       - POSTGRES_PASSWORD=password
     container_name: eshop_postgres
```

<br/><br/><br/>

## 1-3. Running eshop Legacy service (local environment)

### 1-3-1. Running PostgreSQL and redis locally using docker compose

Start PostgreSQL and redis by entering the following in the project root directory.

```bash
docker compose up -d
```

If it started normally, you can see that two containers are running as follows.

```bash
docker ps
```
```bash
CONTAINER ID IMAGE COMMAND CREATED STATUS
   PORTS NAMES
245f29aefe66 postgres:13 "docker-entrypoint.s…" 11 minutes ago Up 10 minutes 0.0.0.0:5432->5432/tcp handson-cloud-msa_postgres
75960e80ab0d redis:5.0-alpine "docker-entrypoint.s…" 11 minutes ago Up 11 minutes 0.0.0.0:6379->6379/tcp handson-cloud-msa_redis_1
...
```
<br/>

### 1-3-2. Backend local execution

Go to the eshop-backend directory and run it as follows.
```bash
cd eshop-backend
./gradlew bootRun
```

![](images/1-1/image27.tmp)

<br/>

### 1-3-3. Run Frontend locally

Since the backend is running in the existing console, open a new console in MobaXterm.

Go to the eshop-frontend directory, install the dependencies with npm install, and then run npm run serve.
npm i chokidar is not required, but if not installed, a chokidar error may occur, so install it first.
```bash
cd eshop-frontend
npm install
npm i chokidar

// frontend run
npm run serve
```

![](images/1-1/image28.tmp)

### Frontend execution result
If you run [http://localhost:8080](http://localhost:8080/) in your browser and see the following screen, the Frontend and Backend applications have started properly.

![](images/1-1/image29.png)

<br/>

## **💡Troubleshooting**💡 ##

>T-1. If the following error occurs when npm run serve:
>```bash
>/home/ubuntu/handson-cloud-msa/eshop-frontend/node_modules/watchpack/lib/chokidar.js:17
>throw new Error(
>^
>
>Error: No version of chokidar is available. Tried chokidar@2 and chokidar@3.
>You could try to manually install any chokidar version.
>chokidar@3: Error: Cannot find module 'chokidar'
>
>.....
>```
>
>👉 Install chokidar directly and run npm run serve again.
>```bash
>npm i chokidar
>```
>
>👉 Before moving on to the next exercise, let’s unload the container launched with docker compose up.
>
>```bash
>docker compose down
>```
<br/><br/><br/>
## 1-4. eshop Legacy service containerization and local environment startup

![](images/1-1/image30.tmp)

**🚩Goal: Let's use the docker compose tool to change the frontend and backend, which were previously executed directly with commands, into images in Docker and run them locally**

<br/>

## 1-4-1. Backend containerization

When containerizing spring boot source code (Docker image), use the **jib plugin**.
※ Using Google's jib plugin, you can build a Docker image without a Dockerfile.

To use jib, add the jib plugin definition to the build.gradle file of eshop-backend. <br/>
If `creationTime` is not specified, the image creation time is set to 1970.01.01 by default, so the exact image creation time cannot be known, so enter it in the `jib` block.
Set it so that it can be created based on the current TIMESTAMP.
```bash
plugins {
     id 'org.springframework.boot' version '2.2.6.RELEASE'
     id 'io.spring.dependency-management' version '1.0.9.RELEASE'
     id 'java'
     id 'com.google.cloud.tools.jib' version '2.7.0'
}

jib{
     container {
         creationTime = 'USE_CURRENT_TIMESTAMP'
     }
}
```

Enter the following in the eshop-backend directory to check whether the docker image was created properly.
The Docker `tag` version can be modified in `version` of `build.gradle`.
```bash
./gradlew jibDockerBuild
docker images
```

![](images/1-1/image31.png)

<br/>

### Add backend to compose.yaml

Add backend content to yaml so that the backend runs automatically when you run docker compose. **Pay attention to indentation.**

The reason the environment: property was added is that if you look at the application.properties of the backend, the ports of postgres and redis refer to localhost.

In fact, inside the Docker container, localhost refers to the default IP of the Docker network rather than 127.0.0.1, so connection refused appears for the postgres and redis connections in the backend.

Therefore, the setting was overwritten and a setting was added to the Dockerfile to access postgres_db inside Docker using container_name:5432/eshop_db instead of localhost:5432.

Add redis in the same way.
```yaml
   backend:
     depends_on:
       -postgres
     image: eshop-backend:0.0.1-SNAPSHOT
     restart : always
     ports:
       - "8090:8090"
     environment:
       - SPRING_DATASOURCE_URL=jdbc:postgresql://eshop_postgres:5432/eshop_db
       - SPRING_REDIS_HOST=redis
```

🐳 (Note) service name and container_name can be used as the domain name.

<br/>

Run the service using the 'docker compose up -d' command in the eshop-legacy-mentee directory, then move to the eshop-frontend directory and run the frontend with the npm run serve command.

Check that the homepage screen appears without any problems. If there is a problem with the backend and the product picture screen does not appear, you can check the error with the docker logs backend command.

Alternatively, you can run 'docker compose up' without the '-d' option to check the log directly, and run the frontend in another console (terminal) to identify and fix the problem.

For reference, if you specify container_name in the yaml file, it is convenient to distinguish containers and run, stop, and analyze logs.

![](images/1-1/image48.png)

<br/>

Go to the eshop-frontend folder again and start the frontend service through npm run serve.

After starting the frontend service, run http://localhost:8080 and if the product photo appears normally as shown below, the backend service is working properly.

![](images/1-1/image29.png)

<br/>
<br/>

## 1-4-2. Frontend containerization

In fact, in a simple project like this, there is no need to change the frontend to Docker because the frontend is frequently modified, but Dockerization is also possible, and in the future Kubernetes environment, the frontend also operates as a container.
Let's understand this and containerize the frontend as well.

Since we will use the http-server's proxy settings, delete or comment out the proxy settings in the vue.config.js file.
```js
module.exports = {
/*
   devServer: {
     proxy: {
         "^/": {
           target: "http://localhost:8090"
         }
     },
     disableHostCheck: true
   }
*/
}
```
<br/>
Create a Dockerfile with the following content in the eshop-frontend directory.

```dockerfile
#buildstage
FROM node:16.18-alpine as build-stage
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
 
# production stage
FROM node:16.18-alpine as production-stage
WORKDIR /app
RUN npm install -g http-server
COPY --from=build-stage /app/dist /app/dist
EXPOSE 8080
CMD [ "http-server", "dist", "--proxy", "http://backend:8090" ]
```

_# production stage_ The additional commands (CMD) below are as described above,
Since docker compose uses an internal network, proxy work is required to connect the frontend to the backend, so this is the part that installs and runs the http-server that will be used in the frontend later.

<br/>

Since node_modules is no longer needed in the local environment, remove it.
This is because from now on, the frontend will not be run locally, but will be run using a Docker image.
Likewise, it is better not to upload the folder to the git repository, so it is already set in .gitignore.

```bash
rm -rf ~/eshop-legacy-mentee/eshop-frontend/node_modules
```

Enter the following in the eshop-frontend directory to check whether the docker image is created properly.

```bash
docker image build -t eshop-frontend:0.0.1 .
docker images
```

![](images/1-1/image32.png)

<br>

### Add frontend to compose.yaml

Modify the compose.yaml file to enable the frontend to also run.

```yaml
   frontend:
     depends_on:
       -backend
     image: eshop-frontend:0.0.1
     restart : always
     ports:
       - "8080:8080"
     container_name: eshop-frontend
```

<br>

### Starting a containerized service in the local environment

After running Docker with the docker compose up command, check whether the homepage appears properly by going to <http://localhost:8080>.
If you do not give the -d option, you can check the log immediately.

&nbsp;&nbsp; depends_on: Gives priority to the Docker image to be executed after the specified Docker image is executed.

&nbsp;&nbsp; container_name: This means that it can be output with that name in logs, etc. or used with docker logs eshop-frontend, etc.
</br>


🐳 (Reference) docker compose start and stop commands
```
    docker compose up # start service
    docker compose ps # check service
    docker compose down # stop service
```


<br/>

## **💡Troubleshooting💡** ##

<br/>
[ 🐳 Note 👉 <a href="./1w-troubleshooting.md">1w-troubleshooting.md</a>]
<br/>
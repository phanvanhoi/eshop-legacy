## 도전과제 3
recommendservice 를 수정하여 직접 같은 카테고리의 상품을 추천하도록 개선해보자

- REST API 구조 이해하기
- vue.js 이해하기
- vue 의 컴포넌트 계층 구조 이해하기
- vue 컴포넌트 간 정보를 어떻게 넘겨주는지 이해하기

우선 eShop 서비스의 frontend 를 이해할 필요가 있다. 
<br>

### eshop legacy frontend 구조

![frontend 구조](images/1-ch/wiki-FDD.png)

위의 구조를 보면 현재 recommendation service는 product service MSA에서 products 정보를 가져와서 특정 상품을 보여주는 코딩으로 되어 있다. 

python 으로 MSA 화를 끝낸 recommend service 내의 소스 코드를 살펴보자

```python {attr.source='.numberLines'}
@app.route("/api/recommends", methods=['GET'])
def recommend():
    response = requests.get(_url_productservice + "/api/products")
    products = response.json()

    recommendations = {'recommendations': random.sample(products['products'], 4)}
    print(f"recommendations: f{recommendations}")
    return recommendations
```    

2,3번째 줄은 위의 구조에서 productcatalog를 가져오는 부분이고, 6번째 줄 recommendations 라는 리턴 컨테이너에 random으로 4개의 product를 가져와서 'recommendations' 의 list 로 세팅하는 부분이다. 

이제 이 부분을 화면에 표출된 상품의 id 를 기반으로 같은 category 의 제품을 추출해서 list 를 채워주게 바꾸면 추천서비스를 정말 카테고리로 추천하도록 수정할 수 있다. 

우선 특정 상품의 recommends로 바꾸도록 REST API구조를 이용해 ID를 받아오도록 바꿔보자.

```python .numberLines
@app.route("/api/recommends/<string:id>", methods=['GET'])  ### modified
def get_recommends_byid(id):                                ### modified
    print("return recommends by id:%s" %id)                 ### log added 
    response = requests.get(_url_productservice + "/api/products")
    products = response.json()

    recommendations = {'recommendations': random.sample(products['products'], 4)}
    print(f"recommendations: f{recommendations}")
    return recommendations
```

이제 갖고 온 상품 id 를 이용하여 category 를 추출해내고 (category가 1개가 아닐 수도 있음에 주의하자) 이를 이용해서 추천할 product list 를 만들어보자. 

우선 특정 id 의 product 정보를 추출해보자 (skaffold dev 실행 기준)

```url
http://localhost:8080/api/products/OLJCESPC7Z
```

이에대한 응답은 아래와 같다.
```json
{
    "categories": [
        "vintage"
    ],
    "description": "This typewriter looks good in your living room.",
    "id": "OLJCESPC7Z",
    "name": "Vintage Typewriter",
    "picture": "/static/img/products/typewriter.jpg",
    "priceUsd": {
        "currencyCode": "USD",
        "nanos": 990000000,
        "units": 67
    }
}
```

이를 이용해 특정 id의 카테고리 정보를 추출하고 다시 전체 product list 에서 해당 카테고리와 매칭되는 product 만 list 에 추가하면 향상된 추천 서비스가 완성된다.

모든 product 의 정보는 아래와 같은 url 로 추출된다.

```url
http://localhost:8080/api/products
```

주의할 것은 모든 정보는 products 라는 key의 하위 value 이다. 

```json
{
"products": [
    {
        "categories": [
            "vintage"
        ],
        "description": "This typewriter looks good in your living room.",
        "id": "OLJCESPC7Z",
        "name": "Vintage Typewriter",
        "picture": "/static/img/products/typewriter.jpg",
        "priceUsd": {
            "currencyCode": "USD",
            "nanos": 990000000,
            "units": 67
        }
    },
    {
        "categories": [
            "photography",
            "vintage"
        ],
        "description": "You won't have a camera to use it and it probably doesn't work anyway.",
        "id": "66VCHSJNUP",
        "name": "Vintage Camera Lens",
        "picture": "/static/img/products/camera-lens.jpg",
        "priceUsd": {
            "currencyCode": "USD",
            "nanos": 490000000,
            "units": 12
        }
    },
    ...
    ]
}
```

이제 이 정보를 이용하여 실제 추천리스트를 리턴하도록 python 코드를 수정해보자

```python .numberLines
@app.route("/api/recommends/<string:id>", methods=['GET'])
def get_recommends_byid(id):

    print("return recommends by id:%s" %id)
    response = requests.get(_url_productservice + "/api/products/" + id)
    recommend = response.json()

    response = requests.get(_url_productservice + "/api/products")
    products = response.json()

    prds = []

    for item in products['products']:
        if item['id'] != id:
            for category in recommend['categories']:
                insertItem = False
                if category in item['categories']:
                    insertItem = True
            if (insertItem == True): prds.append(item)

    recommendations = {'recommendations' : prds}
    return recommendations
```

우선 자기 자신은 추천하지 말아야 하기 때문에 해당 부분을 제외하라는 부분이 14번 줄이다. 
카테고리가 복수여서 카테고리가 같으면 리스트를 추천하라고 코딩하는 경우, 같은 상품id가 중복되어 추천되는 경우가 있다. 따라서 insertItem 이라는 Boolean 키워드를 두어 해당 케이스인 경우만 추천 리스트에 한번 넣도록 한다. 

url 에 입력하여 추천이 잘 이루어지는지 확인해보자 

```url
http://localhost:8080/api/recommends/66VCHSJNUP
```

해당 결과는 아래와 같고, vintage 나 photography 를 카테고리로 갖고 있는 상품이 잘 추천됨을 알 수 있다. 

```json
{
"recommendations": [
    {
        "categories": [
            "vintage"
        ],
        "description": "This typewriter looks good in your living room.",
        "id": "OLJCESPC7Z",
        "name": "Vintage Typewriter",
        "picture": "/static/img/products/typewriter.jpg",
        "priceUsd": {
            "currencyCode": "USD",
            "nanos": 990000000,
            "units": 67
        }
    },
    {
        "categories": [
            "photography",
            "vintage"
        ],
        "description": "This camera looks like it's a film camera, but it's actually digital.",
        "id": "2ZYFJ3GM2N",
        "name": "Film Camera",
        "picture": "/static/img/products/film-camera.jpg",
        "priceUsd": {
            "currencyCode": "USD",
            "units": 2245
        }
    },
    {
        "categories": [
            "music",
            "vintage"
        ],
        "description": "It still works.",
        "id": "0PUK6V6EV0",
        "name": "Vintage Record Player",
        "picture": "/static/img/products/record-player.jpg",
        "priceUsd": {
            "currencyCode": "USD",
            "nanos": 500000000,
            "units": 65
        }
    }
]
}
```

이제 frontend 에서 추천 서비스에 id 를 전달해주도록 수정해보자
Frontend 의 구조는 아래와 같다. 

![frontend vue구조](images/1-ch/w1-d3-vue-route.png)

recommendations.vue 에서 추천서비스를 화면에 표출해주며, 해당 정보는 
eshop-frontend/src/store/modules/recommendations.js 에서 가지고 온다. 해당 부분을 수정해주자 (12, 13번째 줄)

recommendations.js
```javascript .numberLines
import axios from 'axios'

export default {
    namespaced: true,
    state: {
      recommendations: []
    },
    getters: {
      recommendations: state => state.recommendations
    },
    actions: {
      async fetchRecommendations(context, id) {
        const res = await axios.get(process.env.VUE_APP_BASE_URL + "/api/recommends/" + id)  // modified
        context.commit("setRecommendations", res.data.recommendations)
      }
    },
    mutations: {
      setRecommendations(state, recommendations) {
        // 이미지 주소에 서버 url을 더하자.
        recommendations.map(recommendations => recommendations.picture = process.env.VUE_APP_BASE_URL + recommendations.picture) 
        state.recommendations = recommendations 
      }
    },
}
```
해당 fetch 함수에서 productId를 갖고 오도록 ProductDetail.vue에서 Recommendations.vue 로 id를 넘겨줄 필요가 있다. ProductDetail.vue 소스에서 25번째 줄을 아래와 같이 고쳐준다. 

```vue.js
<Recommendations :id="product.id" />
```

마지막으로 Recommendsations.vue 를 수정해주자. props: 를 추가하여 받아오는 id를 설정해주고, fetchRecommendations 에 this.$props.id 를 추가하여 id를 넘겨주자. 주의해야할 점은, watch: 를 사용하여 $props.id 가 할당되는 순간 fetch를 해와야 오동작을 하지 않는다는 점이다. 기존 소스는 created() 에 fetch가 정의되어 있어 여기에 바로 수정을 하면 id 할당 전에 recommend request 가 시작되어 오동작할 수 있다. 

```javascript .numberLines
<template v-if="recommendations">
  <b-container fluid>
    <h5 class="text-muted">Products you might like</h5>
    <b-row class="my-2 py-3">
      <Recommendation v-for="recommendation in recommendations" :key="recommendation.id" :recommendation="recommendation" />
    </b-row>
  </b-container>
</template>

<script>
import Recommendation from '@/components/Recommendation.vue'
import {mapGetters} from 'vuex'

export default {
  name: 'Recommendations',
  components: {
    Recommendation
  },
  props: {
    id: {
      type: String,
      required: true
    }
  },
  computed: {
    ...mapGetters({
      recommendations: 'recommendation/recommendations',
      product: 'product/product'
    }),
  },
  watch: {
    '$props.id'() {
      this.$store.dispatch('recommendation/fetchRecommendations', this.$props.id)
    }
  }
}
</script>
```



이제 잘 동작하는지 확인해보자. skaffold dev 상태면 바로 적용될 것이다. 웹브라우저 화면에서 f5를 몇 번 눌러 수정된 버젼으로 갱신되어 동작하게 만들어주면 추천 서비스가 잘 동작하는 것을 확인할 수 있다. 



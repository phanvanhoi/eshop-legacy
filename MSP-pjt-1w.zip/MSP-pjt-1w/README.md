# T3 MSP Project 1st Week Contents

- [T3 MSP Project 1st Week Contents](#t3-msp-project-1st-week-contents)
   - [Education Goals](#Education-Goals)
   - [Cautions](#Cautions)
   - [Curriculum](#Curriculum)
   - [Challenge](#Challenge)
   - [Reference](#Reference)
----

<br>

## educational goals

- Using the knowledge acquired in the process of developing and building Cloud Native Applications, we perform MSP conversion on monolithic legacy shopping mall applications.
- During the MSA process, experience various related development technologies (SpringBoot, Vue.js, Node.js, Python, RabbitMQ, etc.), Docker, Kubernetes, etc.

<br>

## caution

- The **screen capture** and **execution code/result example** sections in the textbook are samples.
   The screen may change during each person's practice, and different results may be displayed for each individual.
   **If you find it difficult to judge on your own, please actively search and ask your instructor**.

- During the practice process, **save the items you note down by date as one file**, and **parts variable for each content (<< variable >>) must be replaced with personal values** before performing the practice. ,
   Please be careful not to include other content.
----

<br>

## 커리큘럼

<!--<a href="./1w-1.md">MSP PJT 1주차 교재</a>-->

<br>
<br>
<table style="border-collapse:collapse;border:none;">
    <thead>
      <tr>
        <th style="min-width: 40px;">일차</th>
        <th style="min-width: 190px;">주제</th>
        <th>학습 목표</th>
        <th>관련 기술</th>
      </tr>
    </thead>
    <tbody>
        <tr>
            <td><center>0</center></td>  
            <td><a href="./1w-0-Environment_setup.md">Kick off&nbsp;Practice environment configuration</a></td>
            <td>
                <ul style="margin-bottom:0cm;" type="disc">
                    <li style="margin:0cm;font-size:16px;font-family:굴림;">All staff meeting</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;">Local PC WSL2 VM installation</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;">Docker and minikube integration in WSL</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;">VSCode integration with VM</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;">AWS Certificate Manager Generate SSL certificate through service</li>
                </ul>
            </td>
            <td>
                <ul style="margin-bottom:0cm;" type="square">
                    <li style="margin:0cm;font-size:16px;font-family:굴림;text-align:justify;">Skills using WSL (Linux)</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;text-align:justify;">AWS</li>
                </ul>
            </td>
        </tr>
        <tr>
            <td><center>1</center></td>  
            <td><a href="1w-1-Legacy.md">eshop Legacy service startup and containerization</a></td>
            <td>
                 <ul style="margin-bottom:0cm;" type="disc">
                     <li style="margin:0cm;font-size:16px;font-family:Arial;text-align:justify;">Github configuration in WSL2 VM</li>
                     <li style="margin:0cm;font-size:16px;font-family:Arial;text-align:justify;">redis, postgresql startup</li>
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;text-align:justify;">Starting frontend, backend services</li>
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;text-align:justify;">Create frontend,backend images</li>
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;text-align:justify;">Starting the service using an image in a local PC environment</li>
                 </ul>
             </td>
            <td>
                <ul style="margin-bottom:0cm;" type="square">
                    <li style="margin:0cm;font-size:16px;font-family:굴림;text-align:justify;">SpringBoot</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;text-align:justify;">Vue.js, Node.js</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;text-align:justify;"> PostgreSQL, Redis</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;text-align:justify;">Docker</li>
                </ul>
            </td>
        </tr>
        <tr>
            <td><center>2</center></td>  
            <td><a href="./1w-2-k8s_development.md">Establishment of eshop Legacy service operation infrastructure on EC2<br>Establishment of local K8S environment and API Gateway</a></td>
             <td>
                 <ul style="margin-bottom:0cm;" type="disc">
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;text-align:justify;">Create eshop-fronend, eshop-backend repository in ECR</li>
                     <li style="margin:0cm;font-size:16px;font-family:Arial;text-align:justify;">Create AWS EC2 instance</li>
                     <li style="margin:0cm;font-size:16px;font-family:Arial;text-align:justify;">Push Docker image to ECR</li>
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;text-align:justify;">Starting eshop Legacy service using Docker Compose in EC2</li>
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;text-align:justify;">Deployment and development testing of k8s architecture using skaffold in local PC environment</li>
                     <li style="margin:0cm;font-size:16px;font-family:Arial;text-align:justify;">Enable k8s ingress-nginx-controller</li>
                 </ul>
             </td>
            <td>
                <ul style="margin-bottom:0cm;" type="square">
                    <li style="margin:0cm;font-size:16px;font-family:굴림;text-align:justify;">AWS(ECR, EC2), Docker-compose</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;text-align:justify;">Kubernetes, Skaffold, Ingress</li>
                </ul>
            </td>
        </tr>
        <tr>
            <td><center>3</center></td>  
            <td><a href="./1w-3-MSA1.md">eshop Legacy service MSA conversion 1</a></td>
             <td>
                 <ul style="margin-bottom:0cm;" type="disc">
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;">Separation of shopping cart service</li>
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;">Product and service separation</li>
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;">Recommended service separation</li>
                 </ul>
             </td>
            <td>
                <ul style="margin-bottom:0cm;" type="square">
                    <li style="margin:0cm;font-size:16px;font-family:굴림;text-align:justify;">SpringBoot, Node.js, Python</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;text-align:justify;">MongoDB, Redis</li>
                </ul>
            </td>
        </tr>
        <tr>
            <td><center>4</center></td>  
            <td><a href="./1w-4-MSA2_MQ.md">eshop Legacy Service MSA 2<br>Asynchronous Communication Implementation</a></td>
             <td>
                 <ul style="margin-bottom:0cm;" type="disc">
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;">Exchange rate service separation</li>
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;">Implementing asynchronous communication</li>
                     <li style="margin:0cm;font-size:16px;font-family:Gulim;">Separation of advertising services</li>
                 </ul>
             </td>
            <td>
                <ul style="margin-bottom:0cm;" type="square">
                    <li style="margin:0cm;font-size:16px;font-family:굴림;">SpringBoot, Node.js</li>
                    <li style="margin:0cm;font-size:16px;font-family:굴림;">RabbitMQ</li>
                </ul>
            </td>
        </tr>
    </tbody>
</table>


<br>
<br>

## challenge

<table>
<thead>
   <tr>
     <th style="min-width: 150px;">Separation</th>
     <th style="min-width: 190px;">Textbook</th>
     <th>Learning objectives</th>
   </tr>
</thead>
<tbody>
   <tr>
     <td rowspan="1"><center>Day 2 Challenge (1)</td>
     <td>
       <a href="1w-challenge-d2-1.md">1w-challenge-d2-1.md</a>
     </td>
     <td>
       <li>Create E-SHOP API Document page</li>
     </td>
   </tr>
   <tr>
     <td rowspan="1"><center>Day 2 Challenge (2)</td>
     <td>
       <a href="1w-challenge-d2-2.md">1w-challenge-d2-2.md</a>
     </td>
     <td>
       <li>Implementing N:N relationships using JPA</li>
     </td>
   </tr>
   <tr>
     <td rowspan="1"><center>Day 3 Challenge</td>
     <td>
       <a href="1w-challenge-d3.md">1w-challenge-d3.md</a>
     </td>
     <td>
       <li>Build EC2 Backend service by creating ALB</li>
     </td>
   </tr>
   <tr>
     <td rowspan="1"><center>Day 4 Challenge</td>
     <td>
       <a href="1w-challenge-d4.md">1w-challenge-d4.md</a>
     </td>
     <td>
       <li>Modify recommendationservice to directly recommend products in the same category</li>
     </td>
   </tr>
  
  
  
</tbody>
</table>


<br>
<br>

## reference


<br>

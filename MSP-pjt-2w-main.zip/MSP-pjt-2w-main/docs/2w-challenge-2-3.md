## Current status of the program

<br>

## 🤔 Challenge 2-3

### Topic: Helm Chart

<br>

📌 [Notes to be used during this lab]

📌 [ECR URI]<br>
➕ << ECR URI >> : <br>

<br>

## Change the format of eshop PaC from yaml manifest to Helm Chart format (using Helm command).

<br>

To configure Helm, choose one of the two methods below.

(1) Direct Directory structure configuration

(2) Structure configuration through the `helm create` command

<br>

---

**🗎 Note. Preliminary work to use command (2)**

Prior) Check whether the Helm Client in the Admin Server is installed normally.

Day 1 Just check whether the installation was successful using the User Data in the mgmt IaC Terraform code.

< EC2 environment - admin server >
```bash
helm version
```

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-201:~$ helm version
WARNING: Kubernetes configuration file is group-readable. This is insecure. Location: /home/ubuntu/.kube/config
WARNING: Kubernetes configuration file is world-readable. This is insecure. Location: /home/ubuntu/.kube/config
version.BuildInfo{Version:"v3.8.2", GitCommit:"6e3701edea09e5d55a8ca2aae03a68917630e91b", GitTreeState:"clean", GoVersion:"go1.17.5"}
```
> You can ignore the WARNING statement, and if the version information comes out as 3.8.2, it can be considered as a normal installation.

<br>

---

<br>

1. Create a folder structure in the individual **eshop-PaC** repository as follows. (eshop-frontend example)

> ※ eshop-PaC: eshop’s PaC form that will be used in earnest from the 3rd day.

<br>

2. Create eshop root helm chart

<br>

Method (1) Directly configure Directory structure
- Create eshop directory under repo

<< WSL environment created with Command or VSCode >>
> eshop-PaC/eshop

- Create charts directory under eshop, create Chart.yaml, values.yaml, .helmignore

<< WSL environment created with Command or VSCode >>

> eshop-PaC/eshop/charts
> eshop-PaC/eshop/Chart.yaml
> eshop-PaC/eshop/values.yaml
> eshop-PaC/eshop/.helmignore

<br>
<br>

Method (2) Configure structure through `helm create` command

< WSL environment >
```
cd ~/t3-msp-pjt/eshop-PaC
```
< WSL environment >
```
helm create eshop
```
< WSL environment >

Remove unused and unnecessary files and directories
```
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/templates
```

<br>

> When creating a template with the `helm create` command, the structure and files are already created, so there is no need to create them separately.

<br>

---

🗎 Note. directory structure
> ![](../media1/image48.png)

---

<br>

3. Creating eshop-* sub helm chart (eshop-frontend example)

<br>

❗❗ **Below is an example of <span style="color:red">eshop-frontend microservice</span>, and includes the remaining 6 microservices and 4 backing services (postgresql, redis, The same applies to mongodb, rabbitmq).** ❗❗

<br>

Method (1) Directly configure Directory structure

<< WSL environment created with Command or VSCode >>

- Create a template manifest for each service under eshop/charts (ex. eshop-frontend, eshop-backend, istio-vs...)

- Create templates directory, Chart.yaml, values.yaml under eshop/charts/service

- Create deployment.yaml and service.yaml under eshop/charts/service/templates

<br>
<br>

Method (2) Configure structure through `helm create` command

< WSL environment >
```
cd ~/t3-msp-pjt/eshop-PaC/eshop/charts
```
< WSL environment >
```
helm create eshop-frontend
```
< WSL environment >

Remove unused and unnecessary files and directories
```
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/eshop-frontend/templates/tests
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/eshop-frontend/templates/_helpers.tpl
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/eshop-frontend/templates/hpa.yaml
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/eshop-frontend/templates/ingress.yaml
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/eshop-frontend/templates/NOTES.txt
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/eshop-frontend/templates/serviceaccount.yaml
```

When configuring the subchart of eshop-frontend using method (1) or method (2), the directory structure is as follows.

> eshop-PaC/eshop/charts/eshop-frontend/Chart.yaml
> eshop-PaC/eshop/charts/eshop-frontend/values.yaml
> eshop-PaC/eshop/charts/eshop-frontend/templates/deployment.yaml
> eshop-PaC/eshop/charts/eshop-frontend/templates/service.yaml

<br>

<details>
<summary> [Reference - Expand👇] Using shell script </summary>

<br>

Create helm_create.sh (created under /home/ubuntu/t3-msp-pjt)
```bash
vi ~/t3-msp-pjt/helm_create.sh
```

<br>

Write the contents of the shell script as follows:

```bash
#!/bin/bash

mkdir -p /home/ubuntu/t3-msp-pjt/eshop-PaC/eshop/charts
cd /home/ubuntu/t3-msp-pjt/eshop-PaC/eshop/charts
/usr/sbin/helm create $1
rm -rf /home/ubuntu/t3-msp-pjt/eshop-PaC/eshop/charts/$1/templates/tests
rm -rf /home/ubuntu/t3-msp-pjt/eshop-PaC/eshop/charts/$1/templates/_helpers.tpl
rm -rf /home/ubuntu/t3-msp-pjt/eshop-PaC/eshop/charts/$1/templates/hpa.yaml
rm -rf /home/ubuntu/t3-msp-pjt/eshop-PaC/eshop/charts/$1/templates/ingress.yaml
rm -rf /home/ubuntu/t3-msp-pjt/eshop-PaC/eshop/charts/$1/templates/NOTES.txt
rm -rf /home/ubuntu/t3-msp-pjt/eshop-PaC/eshop/charts/$1/templates/serviceaccount.yaml
```

<br>

Grant execution permission
```
chmod 755 helm_create.sh
```

<br>

When executing the command, enter shell script parameter values as shown below. Below is an example script that creates an eshop-adservice Helm chart (execution location is irrelevant)
```bash
./helm_create.sh eshop-adservice
```

If a problem occurs where the helm command cannot be found when executing a command, find the absolute path using the command below, then use the corresponding path by modifying the helm command part of the shell script above.
```bash
which helm
```

Example) Modify as below
```bash
(...skip...)
/usr/local/bin/helm create $1
(...skip...)
```


</details>

---

<br>

---

🗎 Note. directory structure

> ![](../media1/image49.png)

---

<br>

4. Edit eshop root helm chart file

**eshop-PaC/eshop/Chart.yaml**

```yaml
apiVersion: v2
name: eshop
description: A Helm chart for Kubernetes
type: application
version: 2.0.0
appVersion: "2.4.0"
dependencies:

#- name: metrics-server
#  condition: global.lightweight.metrics-server.enabled
#- name: prometheus
#  condition: global.lightweight.prometheus.enabled
#- name: grafana
#  condition: global.lightweight.grafana.enabled
#- name: elasticsearch
#  condition: global.lightweight.elasticsearch.enabled
#- name: jaeger
#  condition: global.tracing.enabled
#- name: kiali-server
#  condition: global.lightweight.kiali-server.enabled
```

**eshop-PaC/eshop/values.yaml**
```yaml
## << 변수 >> 치환 필요

## << ECR URI >>      : ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com
## << SERVICE NAME >> : ex) eshop-backend
## << TAG >>          : ex) latest

global:
   rabbitmq:
    # << Amazon MQ AMQP Endpoint >>Value example) amqps://b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com:5671 value minus protocol and port values The required value => b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com
    #host: << Amazon MQ AMQP Endpoint >> # Uncomment the Amazon MQ challenge and substitute the value in << Amazon MQ Web Console Endpoint >>
    host: rabbitmq # Comment out Amazon MQ challenges
  app:
    name: eshop
    namespace: eshop
  tls:
    enabled: false          # True to enable TLS (set by deploy-all.ps1)
    issuer: ""
  ingress:                                              # ingress related settings
    entries:
      eshop-frontend: eshop-frontend
      eshop-currencyservice: eshop-currencyservice
      eshop-productservice: eshop-productservice
      eshop-recommendservice: eshop-recommendservice
      eshop-adservice: eshop-adservice
      eshop-backend: eshop-backend
      eshop-cartservice: eshop-cartservice
      # spa: ""                                           # ingress entry for web spa
  svc:
    eshop-frontend: eshop-frontend
    eshop-currencyservice: eshop-currencyservice
    eshop-productservice: eshop-productservice
    eshop-recommendservice: eshop-recommendservice
    eshop-adservice: eshop-adservice
    eshop-backend: eshop-backend
    eshop-cartservice: eshop-cartservice
    # spa: webspa                                       # service name for web spa
  images:
    adservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    backend: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>                     # Amazon MQ Comment processing during challenges
    cartservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>                    # Amazon MQ Comment processing during challenges
    # backend: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-backend:amqtest            # Amazon MQ 도전과제 시 주석해제
    # cartservice: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-cartservice:amqtest    # Amazon MQ 도전과제 시 주석해제
    frontend: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    currencyservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    productservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    recommendservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
  appinsights:
    key: ""               # App insights to use
  k8s:                      # inf.k8s defines Kubernetes cluster global config
    dns:  ""                # k8s external  DNS. This value or ip value MUST BE PROVIDED
    local: false            # True when deploying on "local K8s" provided by Docker Desktop.
  hpa:
    minReplicas: 1
    maxReplicas: 18
  misc:                     # inf.misc contains miscellaneous configuration related to infrastructure
    useLoadTest: false      # If running under loading test or not
    useAzureStorage: false  # If catalog api uses azure storage or not
  # lightweight:
    # kiali-server:
    #   enabled: true
    # prometheus:
    #   enabled: true
    # elasticsearch:
    #   enabled: true
    # grafana:
    #   enabled: true
```


**eshop-PaC/eshop/.helmignore**
```
# Patterns to ignore when building packages.
# This supports shell glob matching, relative path matching, and
# negation (prefixed with !). Only one pattern per line.
.DS_Store
# Common VCS dirs
.git/
.gitignore
.bzr/
.bzrignore
.hg/
.hgignore
.svn/
# Common backup files
*.swp
*.bak
*.tmp
*.orig
*~
# Various IDEs
.project
.idea/
*.tmproj
.vscode/
```

5. Create manifest and set sub helm chart variable (convert all yaml in k8s directory using the method below)

<br>

❗❗ **Below is an example of a frontend microservice, and the same applies to the remaining 6 microservices and 4 backing services (postgres, redis, mongodb, rabbitmq) that are not described in the textbook.** ❗❗

<br>

<< Directory list upon completion of execution to date >>
> eshop-PaC/eshop/charts/eshop-adservice
> 
> eshop-PaC/eshop/charts/eshop-backend
> 
> eshop-PaC/eshop/charts/eshop-cartservice
> 
> eshop-PaC/eshop/charts/eshop-currencyservice
> 
> eshop-PaC/eshop/charts/eshop-frontend
> 
> eshop-PaC/eshop/charts/eshop-productservice
> 
> eshop-PaC/eshop/charts/eshop-recommendservice
>
> eshop-PaC/eshop/charts/postgresql
>
> eshop-PaC/eshop/charts/redis
> 
> eshop-PaC/eshop/charts/mongodb
>
> eshop-PaC/eshop/charts/rabbitmq

<br>

Copy the contents of the yaml file in the k8s directory and copy the contents of the yaml file under the eshop-PaC/eshop/charts/service/templates directory.

(The deployment part is stored in deployment.yaml, and the service part is stored in service.yaml)

Select contents to be variable such as image path or db source

※ Save variable values in the eshop-PaC/eshop/values.yaml file and specify to refer to the values.yaml path as {{ .Values.global.images.frontend }} as in the example below.
**eshop-PaC/eshop/charts/eshop-frontend/templates/deployment.yaml**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-frontend
spec:
  selector:
    matchLabels:
      app: eshop-frontend
  template:
    metadata:
      labels:
        app: eshop-frontend
    spec:
      containers:
        - name: eshop-frontend
          image: {{ .Values.global.images.frontend }}
          imagePullPolicy: Always
          ports:
          - containerPort: 8080
          resources:
            requests:
              cpu: 100m
              memory: 64Mi
            limits:
              cpu: 200m
              memory: 128Mi
```

**eshop-PaC/eshop/charts/eshop-frontend/templates/service.yaml**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: eshop-frontend
spec:
  type: ClusterIP
  selector:
    app: eshop-frontend
  ports:
  - port: 8080
```

**eshop-PaC/eshop/charts/eshop-frontend/Chart.yaml** 

When running other microservices, only change the value of the chart name name: in Chart.yaml below to specify it.

```yaml
apiVersion: v2
name: eshop-frontend
description: A Helm chart for Kubernetes
type: application
version: 2.0.0
appVersion: "2.4.0"
```

**eshop-PaC/eshop/charts/eshop-frontend/values.yaml**
```yaml
#Create an empty file or delete all existing contents
```

❗❗ **If you have changed all remaining microservices to Helm Chart Format, add istio-related settings as follows.** ❗❗

<br>

<< Directory list upon completion of execution to date >>
> eshop-PaC/eshop/charts/eshop-adservice
> 
> eshop-PaC/eshop/charts/eshop-backend
> 
> eshop-PaC/eshop/charts/eshop-cartservice
> 
> eshop-PaC/eshop/charts/eshop-currencyservice
> 
> eshop-PaC/eshop/charts/eshop-frontend
> 
> eshop-PaC/eshop/charts/eshop-productservice
> 
> eshop-PaC/eshop/charts/eshop-recommendservice
>
> eshop-PaC/eshop/charts/postgresql
>
> eshop-PaC/eshop/charts/redis
> 
> eshop-PaC/eshop/charts/mongodb
>
> eshop-PaC/eshop/charts/rabbitmq
> 
> eshop-PaC/eshop/charts/istio-vs

<br>

First, create a directory with the path below.

Method (1) Directly configure Directory structure

<< WSL environment created with Command or VSCode >>

**eshop-PaC/eshop/charts/istio-vs**

After creating the directory, create the files below.

<br>

Method (2) Configure structure through `helm create` command

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC/eshop/charts
```

< WSL environment >
```bash
helm create istio-vs
```

< WSL environment >

Remove unused and unnecessary files and directories
```bash
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-vs/templates/tests
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-vs/templates/_helpers.tpl
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-vs/templates/hpa.yaml
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-vs/templates/ingress.yaml
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-vs/templates/NOTES.txt
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-vs/templates/serviceaccount.yaml
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-vs/templates/deployment.yaml
rm -rf ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-vs/templates/service.yaml
```

< WSL environment >

Create the required files
```bash
touch ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-vs/templates/ingress-gateway.yaml
touch ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-vs/templates/eshop-vs.yaml
```

<br>

**eshop-PaC/eshop/charts/istio-vs/templates/ingress-gateway.yaml**

```yaml
apiVersion: networking.istio.io/v1alpha3
kind: Gateway
metadata:
   name: ingress-gateway
spec:
   selector:
     istio: ingressgateway # use istio default controller
   servers:
   -port:
       number: 80
       name: http
       protocol: HTTP
     hosts:
     - "*"
     tls:
       httpsRedirect: false
```

<br>

**eshop-PaC/eshop/charts/istio-vs/Chart.yaml**

In the future, the app version of istio-related Helm Charts will be unified to 1.0.

```yaml
apiVersion: v2
appVersion: "1.0"
description: A Helm chart for Kubernetes
name: istio-vs
version: 1.0.0
```

<br>

**eshop-PaC/eshop/charts/istio-vs/values.yaml**
```yaml
#Create an empty file or delete all existing contents
```

Below are the Virtual Service settings for the eshop service.

**eshop-PaC/eshop/charts/istio-vs/templates/eshop-vs.yaml**
```yaml
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
   name: eshop-vs
spec:
   hosts:
   - "*"
   gateways:
   - ingress-gateway
   http:
   -match:
     - uri:
         prefix: /api/carts
     route:
     -destination:
         host: eshop-cartservice
         port:
           number: 8091
   -match:
     - uri:
         prefix: /api/products
     route:
     -destination:
         host: eshop-productservice
         port:
           number: 8092
   -match:
     - uri:
         prefix: /api/recommends
     route:
     -destination:
         host: eshop-recommendservice
         port:
           number: 8093
   -match:
     - uri:
         prefix: /api/currencies
     route:
     -destination:
         host: eshop-currencyservice
         port:
           number: 8094
   -match:
     - uri:
         prefix: /api/ads
     route:
     -destination:
         host: eshop-adservice
         port:
           number: 8095
   -match:
     - uri:
         prefix: /api
     route:
     -destination:
         host: eshop-backend
         port:
           number: 8090
   -match:
     - uri:
         prefix: /static
     route:
     -destination:
         host: eshop-backend
         port:
           number: 8090
   -match:
     - uri:
         exact: /
     - uri:
         exact: /favicon.ico
     - uri:
         prefix: /css
     - uri:
         prefix: /js
     route:
     -destination:
         host: eshop-frontend
         port:
           number: 8080
```

<br>

😃 **With this, the configuration of eshop's root helm chart and sub helm charts has been completed!!!**

<br>
<br>

6. Deploy eshop Application (eshop-PaC Repository) composed of Helm Chart through Argocd.
 
**Add your personal eshop-PaC repository to argocd's repositories.**

<br>

**Create an eshop application complete with Helm Chart on the argocd web screen.**

### ❗❗ Precautions when creating eshop application❗❗

<br>

When distributing eshop through Helm Chart in this course and future courses, the Application Name must be set to 'eshop'. This is because the Helm Chart to be designed in the future has settings dependent on the application name.

<br>

+New App creation task

Step 1) Enter GENERAL items
|Item|Content|Action|
|------|---|---|
|➕ Application Name |`eshop`|Copy & Paste|
|➕ Project |`default`|Select select box|
|➕ SYNC POLICY | `Manual` |Select select box (default)|
|➕ SYNC OPTIONS |`AUTO-CREATE NAMESPACE`|Select checkbox|

<br>

Step 2) Enter SOURCE items
|Item|Content|Action|
|------|---|---|
|➕Repository URL |`https://github.com/<< GITHUB USER NAME >>/eshop-PaC.git`|Select select box|
|➕Revision| `main` or `HEAD` |Select select box|
|➕Path|`eshop`|Select select box|

<br>

Step 3) Enter DESTINATION items
|Item|Content|Action|
|------|---|---|
|➕ Cluster URL |`<< Service EKS Cluster Endpoint >>`|Select select box|
|➕ Namespace |`eshop`|Copy & Paste|

<br>

Step 4) Helm > VALUES FILES > Select the `values.yaml` select box

<br>

**If deployment has been completed normally, try calling the eshop app through the FQDN domain of the individual eshop specified earlier.**

<br>
<br>

## Install metrics-server with Helm Chart
> If you manually configured eshop's Helm Chart PaC (eshop-PaC) through the challenge, you must install metrics-server separately.

<br>

metrics-server is installed using the metrics-server Helm Chart provided by S3 in the path below.

<s3://t2hubintern/metrics-server.tar.gz>

<br>


1. Install metrics-server Helm Chart.

<br>

Step1) Setting up metrics-server sub helm chart

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC/eshop/charts
```
> Go to eshop-PaC PaC subchart directory

<br>

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/metrics-server.tar.gz .
```
> Download metrics-server helm chart

<br>

< WSL environment >
```bash
tar xvfz metrics-server.tar.gz
```
> Unzip metrics-server helm chart


<br>

< WSL environment >
```bash
rm -rf metrics-server.tar.gz
```
> Delete metrics-server helm chart compressed file

After completing the task, check that the metrics-server directory has been added to the eshop/charts/ subdirectory of the individual eshop-PaC repository.

<br>

Step2) Set up Chart.yaml

Remove the comment from the metrics-server section in the dependencies section of the Chart.yaml file under eshop.
(**Be careful about indentation**)

<br>

**eshop-PaC/eshop/Chart.yaml**
```yaml
apiVersion: v2
name: eshop
description: A Helm chart for Kubernetes
type: application
version: 2.0.0
appVersion: "2.4.0"
dependencies:

- name: metrics-server
   condition: global.lightweight.metrics-server.enabled
#- name: prometheus
# condition: global.lightweight.prometheus.enabled
#- name: grafana
# condition: global.lightweight.grafana.enabled
#- name: elasticsearch
# condition: global.lightweight.elasticsearch.enabled
#- name: jaeger
# condition: global.tracing.enabled
#- name: kiali-server
# condition: global.lightweight.kiali-server.enabled
```

<br>

2. After pushing the changes to git, try syncing argocd's eshop application again.

< WSL environment >
```bash
git add .; git commit -m "install metrics-server helm chart"; git push origin main
```
> git add & git stage commit & git remote push


<br>


3. After installing metrics-server, check for normal installation.

Execute the command below.

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl top
```

If Usage is displayed as shown below, it can be considered a normal installation.

✔ **(Example of execution code/result)**
```bash
Display Resource (CPU/Memory) usage.

  The top command allows you to see the resource consumption for nodes or pods.

  This command requires Metrics Server to be correctly configured and working on the server.

Available Commands:
   node Display resource (CPU/memory) usage of nodes
   pod Display resource (CPU/memory) usage of pods

Usage:
   kubectl top [flags] [options]

Use "kubectl <command> --help" for more information about a given command.
Use "kubectl options" for a list of global command-line options (applies to all commands).
```

<br>

**😃 Challenge Completed!!!**

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
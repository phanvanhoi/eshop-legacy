# **Week 2 (Outer Architecture and GitOps Ops) Day 3**

- [**Week 2 (Outer Architecture and GitOps Ops) Day 3**](#Week 2outer-architecture-and-gitops-ops-Day 3)
- [**Day 3 - Establishing a monitoring environment in the Service EKS Cluster environment**](#Day 3---Constructing a monitoring-environment in the service-eks-cluster-environment)
   - [Practice Goal Structure](#Practice-Goal-Structure)
   - [🚨 List of required tasks 🚨](#-Required tasks-list-)
   - [🤔 Day 3 Full Challenge List 🤔](#-Day 3-Full-Challenge-List-)
   - [🚨Required Assignment 3-1](#Required Assignment-3-1)
   - [**Lab 3-1. Installing the OSS monitoring tool with Helm Chart**](#lab-3-1-oss-monitoring-tool-installing with Helm Chart)
   - [Practice Goal](#Practice-Goal)
   - [**Building an observable service design and monitoring environment**](#Building an observable-service-design-and-monitoring-environment)
     - [3-1-0. Common matters when working](#3-1-0-Common matters when working)
   - [🚨Required Assignment 3-2](#Required Assignment-3-2)
       - [Base eshop-PaC/eshop/values.yaml](#base-eshop-paceshopvaluesyaml)
       - [Base eshop-PaC/eshop/Chart.yaml](#base-eshop-paceshopchartyaml)
     - [3-1-1. install prometheus](#3-1-1-prometheus-install)
     - [3-1-2. grafana installation](#3-1-2-grafana-installation)
     - [3-1-3. jaeger \& elasticsearch installation](#3-1-3-jaeger--elasticsearch-installation)
       - [**🗎 Reference. \[Jaeger\]**](#-note-jaeger)
     - [3-1-4. kiali installation](#3-1-4-kiali-installation)
     - [3-1-5. Other Notes](#3-1-5-Other-Notes)
   - [Challenge 3-1](#Challenge-3-1)
   - [**Lab 3-2. Tour each OSS after completing the installation of the monitoring tool**](#lab-3-2-monitoring-tool-installation-complete-tour each-oss)
     - [3-2-1. **Prometheus**](#3-2-1-prometheus)
       - [**❗❗ Prometheus assignment submission-related instructions❗❗**](#-prometheus-assignment-submission-related-information)
       - [🗎 Reference. Check and note the LoadBalancer ELB DNS Name of prometheus service (📌\<\< Prometheus ELB DNS Name \>\>)](#-Note-loadbalancer-elb-dns-name-prometheus-elb-dns- of prometheus-service name--check-and-note)
       - [🗎 Reference. Prometheus assignment submission check for correct answer](#-reference-prometheus-assignment-submission-correct answer-check)
     - [3-2-2. Grafana](#3-2-2-grafana)
     - [3-2-3. Jaeger](#3-2-3-jaeger)
     - [3-2-4. Kiali-server](#3-2-4-kiali-server)
   - [Challenge 3-2](#Challenge-3-2)
   - [Challenge 3-3](#Challenge-3-3)
   - [Challenge 3-4](#Challenge-3-4)
   - [**Evaluation**](#evaluation)
- [ \[list\] ](#-list-)

---

# **Day 3 - Establishing a monitoring environment in the Service EKS Cluster environment**

<br>

📌 [Notes to be used during this lab]

📌 [GITHUB]<br>
➕ << GITHUB USER NAME >> : <br>
➕ << GITHUB TOKEN >> : <br>

📌 [AWS Access Key]<br>
➕ << Access key >> : <br>
➕ << Secret Access key >> : <br>

📌 [ECR URI]<br>
➕ << ECR URI >> : <br>

📌 [Prometheus Service Endpoint]<br>
➕ << Prometheus ELB DNS Name >> : <span style="color:red"><----- Matters related to assignment submission</span> <br>

<br>

## Practice goal structure

<br>

![](../media2/image7.png)

<br>

![](../media2/4w_arch.png)
> ※ Service(Helm Chart) repo
>
> eshop-PaC: Repository in the form of Helm Chart PaC that will be utilized in earnest when operating eshop services

<br>

## 🚨 List of required tasks 🚨
1. [[Observability] Install OSS Observability Tool (prometheus, grafana, jaeger, elasticsearch, kiali) Helm Chart inside eshop PaC](#🚨Required task-3-1)
2. [[IaC] Check insufficient infrastructure resources when expanding OSS and expand outer architecture through IaC](#🚨Essential task-3-2)

<br>

## 🤔 Day 3 Full Challenge List 🤔
🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥
1. [[Authentication/Authorization] `Authentication and Authorization Strengthening (Istio + Keycloak + Oauth2-proxy)` task on the installed OSS monitoring tool] (#Challenge-3-1) <a href= "./2w-challenge-3-1.md"> (Challenge 3-1) </a>
2. [[K8s HPA] Increasing/decreasing the replicaset HPA to the running eshop app in Service EKS Cluster](#Challenge-3-2) <a href="./2w-challenge-3-2.md" > (Challenge 3-2) </a>
3. [[AWS CloudWatch] Applying AWS CloudWatch Container Insights to Service EKS Cluster](#Challenge-3-3) <a href="./2w-challenge-3-3.md"> (Challenge 3- 3) </a>
4. [[Observability] RabbitMQ version minor upgrade and management UI monitoring environment construction](#Challenge-3-4) <a href="./2w-challenge-3-4.md"> (Challenge 3-4 ) </a>

<br>

## 🚨Required task 3-1
> Lab 3-1 overall work

<br>

## **Lab 3-1. Installing the OSS monitoring tool Helm Chart**

<br>

## Practice Objectives
- Install and configure Observability OSS on eshop PaC.
- When expanding OSS, check for insufficient infrastructure resources and continuously maintain them through IaC.
- Install Prometheus and Grafana to collect Cluster Linux Metrics and view the dashboard.
- Install Kiali and Jaeger (elasticsearch) and prepare to use them in future practice.
- Try using Istio AuthorizationPolicy.

<br>


## **Building an observable service design and monitoring environment**

- Observable services display logs and various indicators that can be monitored.

- Implemented by service developers using adapters provided by the platform

- Monitoring infrastructure collects logs and monitoring indicators and provides them to operators

- In the case of a practical project, set ‘Monitoring (3rd day course)’ and ‘Distributed tracking (4th day course)’ among the areas below and perform service observation-related practice.

![](../media2/image4.png)

<br>
<br>

### 3-1-0. Common things when working

<br>

- OSS to be installed: prometheus, grafana, jaeger (+elasticsearch), kiali-server (5 in total)
- The installation order is irrelevant, but it is recommended to proceed in the order of the guide.
- Each OSS Helm Chart required for installation is provided as a compressed file (tar.gz) in the S3 path.
>The path to each OSS Helm Chart is as follows.<br>
>1) <s3://t2hubintern/prometheus.tar.gz><br>
>2) <s3://t2hubintern/grafana.tar.gz><br>
>3) <s3://t2hubintern/jaeger.tar.gz><br>
>4) <s3://t2hubintern/elasticsearch.tar.gz><br>
>5) <s3://t2hubintern/kiali-server.tar.gz><br>
- Common working directory: ~/t3-msp-pjt/eshop-PaC/eshop/charts
> Download each Helm Chart, unzip it, and place it under eshop-PaC/eshop/charts.
>
> ex) elasticsearch installation location: eshop-PaC/eshop/charts/elasticsearch
- Common work files: <br>
     1) eshop-PaC/eshop/values.yaml<br>
     2) eshop-PaC/eshop/Chart.yaml
> When installing each, uncomment each OSS at the bottom of `lightweight:` in the eshop-PaC/eshop/values.yaml file.
> <br>
> When installing each, uncomment each OSS at the bottom of `dependencies:` in the eshop-PaC/eshop/Chart.yaml file.
- Individual Github Repository related to work: <https://github.com/<< GITHUB USERNAME >>/eshop-PaC.git>
> ※ eshop-PaC: eshop’s Helm Chart PaC form that will be used in earnest from the 3rd day.
- Work-related .helmignore file settings: During the installation process, there is a time to place tar.gz files under eshop-PaC/eshop/charts. In this case, the following information is included at the end of the file in the `eshop-PaC/eshop/.helmignore` path. Add .
>
>***eshop-PaC/eshop/.helmignore***
>```yaml
>(...omitted...)
># Ignore arch
>*.tar.gz
>```
>
> This is to prevent errors that may occur during helm validation of .tar.gz files when attempting to render with a helm template in argocd.

<br>

## 🚨Required task 3-2
> Scale Up operation below

<br>

- (Required task 3-2) The worker nodes of the Service EKS Cluster must be scaled up.
> **When installing elasticsearch as the backend of Jaeger, if you use 3 worker nodes with t3.medium in Service EKS Cluster, an error similar to the following may occur due to insufficient resources when scheduling Pods.**
>
> *0/3 nodes are available: 1 Insufficient cpu, 2 Insufficient memory.*
>
>**To solve this, the Node Group is scaled up (t3.medium => t3.large) through the eshop-service IaC Pipeline.**
>
>**After scaling up the Worker Node (t3.medium => t3.large), pod scheduling problems in the eshop App may occur. In that case, delete the eshop App and then recreate it.**
>
> ***Hint: Modify the Terraform code that was modified when scaling out the Service EKS Cluster worker node on the second day.***

<br>
<br>

---

🗎 Note. Day 3 OSS complete installation copy
> If the practice is difficult or there are any special issues, use the reference that completed the entire 3rd day practice process below. (Requires personalization of Github `eshop-PaC` after downloading)
>
> <s3://t2hubintern/3rd_eshop-PaC.tar.gz>

---

<br>

#### Base eshop-PaC/eshop/values.yaml

Define eshop base values.yaml as follows and install various monitoring tools.

Basically, whenever you install (unzip to an appropriate location) each OSS tool, uncomment the relevant part of the values.yaml file below. Detailed guides for each OSS are provided as course guides 1 to 4 below.

<br>

**eshop-PaC/eshop/values.yaml**
```yaml
global:
  rabbitmq:
    # << Amazon MQ AMQP Endpoint >>값 예시) amqps://b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com:5671 값 중 프로토콜, 포트값을 뺀 값이 필요한 값 => b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com
    #host: << Amazon MQ AMQP Endpoint >>      # Amazon MQ 도전과제 시 주석해제 후 << Amazon MQ Web Console Endpoint >>에 값 치환
    host: rabbitmq                                   # Amazon MQ 도전과제 시 주석처리
  app:
    name: eshop
    namespace: eshop
  tls:
    enabled: false          # True to enable TLS (set by deploy-all.ps1)
    issuer: ""
  ingress:                                              # ingress related settings
    entries:
      eshop-frontend: eshop-frontend
      eshop-currencyservice: eshop-currencyservice
      eshop-productservice: eshop-productservice
      eshop-recommendservice: eshop-recommendservice
      eshop-adservice: eshop-adservice
      eshop-backend: eshop-backend
      eshop-cartservice: eshop-cartservice
      # spa: ""                                           # ingress entry for web spa
  svc:
    eshop-frontend: eshop-frontend
    eshop-currencyservice: eshop-currencyservice
    eshop-productservice: eshop-productservice
    eshop-recommendservice: eshop-recommendservice
    eshop-adservice: eshop-adservice
    eshop-backend: eshop-backend
    eshop-cartservice: eshop-cartservice
    # spa: webspa                                       # service name for web spa
  images:
    adservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    backend: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>                                           # Amazon MQ 도전과제 시 주석처리
    cartservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>                                       # Amazon MQ 도전과제 시 주석처리
    # backend: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-backend:amqtest            # Amazon MQ 도전과제 시 주석해제
    # cartservice: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-cartservice:amqtest    # Amazon MQ 도전과제 시 주석해제
    frontend: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    currencyservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    productservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    recommendservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
  appinsights:
    key: ""               # App insights to use
  k8s:                      # inf.k8s defines Kubernetes cluster global config
    dns:  ""                # k8s external  DNS. This value or ip value MUST BE PROVIDED
    local: false            # True when deploying on "local K8s" provided by Docker Desktop.
  hpa:
    minReplicas: 1
    maxReplicas: 18
  misc:                     # inf.misc contains miscellaneous configuration related to infrastructure
    useLoadTest: false      # If running under loading test or not
    useAzureStorage: false  # If catalog api uses azure storage or not
  # lightweight:
    # kiali-server:
    #   enabled: true
    # prometheus:
    #   enabled: true
    # elasticsearch:
    #   enabled: true
    # grafana:
    #   enabled: true
```

<br>

#### Base eshop-PaC/eshop/Chart.yaml

<br>

```yaml
apiVersion: v2
name: eshop
description: A Helm chart for Kubernetes
type: application
version: 2.0.0
appVersion: "2.4.0"
dependencies:

- name: metrics-server
  condition: global.lightweight.metrics-server.enabled
# - name: prometheus
#   condition: global.lightweight.prometheus.enabled
# - name: grafana
#   condition: global.lightweight.grafana.enabled
# - name: elasticsearch
#   condition: global.lightweight.elasticsearch.enabled
# - name: jaeger
#   condition: global.tracing.enabled
# - name: kiali-server
#   condition: global.lightweight.kiali-server.enabled
```

<br>
<br>

When installing each, change the eshop-PaC/eshop/values.yaml and eshop-PaC/eshop/Chart.yaml files to match each OSS installation guide below.

<br>

### 3-1-1. install prometheus

<br>

❗❗ Prometheus is an OSS that monitors week 2 practice participation, output, and assignment submission. ❗❗

<br>

S3 URL: <s3://t2hubintern/prometheus.tar.gz>

<br>

<br>

Step 1) Download and unzip

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC/eshop/charts
```
> eshop-PaC Go to the PaC working directory.

<br>

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/prometheus.tar.gz .
```
> Execute each OSS-specific s3 file download command.

<br>

< WSL environment >
```bash
tar xvfz prometheus.tar.gz
```
> Perform decompression.

<br>

Step 2) After decompressing, check the creation of the eshop-PaC/eshop/charts/prometheus directory.

<br>

Step 3) Uncomment prometheus > enabled: true in the values.yaml > lightweight section.

**eshop-PaC/eshop/values.yaml**
```yaml
...
  lightweight:
    #kiali-server:
      #enabled: true
    prometheus:
      enabled: true
    #elasticsearch:
      #enabled: true
    #grafana:
      #enabled: true
```

<br>

Step 4) Uncomment the contents of the dependency configuration file below.

**eshop-PaC/eshop/Chart.yaml**
```yaml
apiVersion: v2
name: eshop
description: A Helm chart for Kubernetes
type: application
version: 2.0.0
appVersion: "2.4.0"
dependencies:

- name: metrics-server
  condition: global.lightweight.metrics-server.enabled
- name: prometheus
  condition: global.lightweight.prometheus.enabled
# - name: grafana
#   condition: global.lightweight.grafana.enabled
# - name: elasticsearch
#   condition: global.lightweight.elasticsearch.enabled
# - name: jaeger
#   condition: global.tracing.enabled
# - name: kiali-server
#   condition: global.lightweight.kiali-server.enabled
```

<br>

Step 5) After reflecting the changes in the main branch of Github `eshop-PaC` for each individual, perform deployment using the `Sync` task through Argocd.

<br>

Step 6) Check whether OSS is actually installed using the Pod search command.

< EC2 environment - admin server >
```bash
kubectl config use-context eshop
```
> Switch to eshop context, can be replaced with ec command

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get pod -n eshop | grep prometheus
```
> Pod lookup

<br>
<br>

If the pod is viewed as shown below, it is confirmed normal.

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-1-10-68:~$ kubectl get pod -n eshop | grep prometheus
eshop-prometheus-alertmanager-7fbcccb444-9pk9c   2/2     Running   0            3d
eshop-prometheus-node-exporter-b62wq             1/1     Running   0            3d
eshop-prometheus-node-exporter-jhhr9             1/1     Running   0            3d
eshop-prometheus-node-exporter-p7xlj             1/1     Running   0            3d
eshop-prometheus-pushgateway-f5df9589f-6zt65     1/1     Running   0            3d
```

<br>


### 3-1-2. install grafana

<br>

S3 URL: <s3://t2hubintern/grafana.tar.gz>

<br>

<br>

Step 1) Download and unzip

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC/eshop/charts
```
> eshop-PaC Go to the PaC working directory.

<br>

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/grafana.tar.gz .
```
> Execute each OSS-specific s3 file download command.

<br>

< WSL environment >
```bash
tar xvfz grafana.tar.gz
```
> Perform decompression.

<br>

Step 2) After decompressing, check the creation of the eshop-PaC/eshop/charts/grafana directory.

<br>

Step 3) Uncomment grafana > enabled: true in the values.yaml > lightweight section.

**eshop-PaC/eshop/values.yaml**
```yaml
...
  lightweight:
    #kiali-server:
      #enabled: true
    prometheus:
      enabled: true
    #elasticsearch:
      #enabled: true
    grafana:
      enabled: true
```

<br>

Step 4) Uncomment the contents of the dependency configuration file below.

**eshop-PaC/eshop/Chart.yaml**
```yaml
apiVersion: v2
name: eshop
description: A Helm chart for Kubernetes
type: application
version: 2.0.0
appVersion: "2.4.0"
dependencies:

- name: metrics-server
  condition: global.lightweight.metrics-server.enabled
- name: prometheus
  condition: global.lightweight.prometheus.enabled
- name: grafana
  condition: global.lightweight.grafana.enabled
# - name: elasticsearch
#   condition: global.lightweight.elasticsearch.enabled
# - name: jaeger
#   condition: global.tracing.enabled
# - name: kiali-server
#   condition: global.lightweight.kiali-server.enabled
```

<br>

Step 5) `https://<< DOMAIN >>/grafana` Add Virtual Service definition for URL access.

Adds istio virtual service and destination rule for grafana.

**eshop-PaC/eshop/charts/istio-vs/templates/grafana-vs.yaml**
```yaml
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: grafana-vs
spec:
  hosts:
  - "*"
  gateways:
  - ingress-gateway
  http:
  - match:
    - uri:
        exact: /grafana
    - uri:
        prefix: /grafana
    - uri:
        prefix: /grafana/
    route:
    - destination:
        host: eshop-grafana.eshop.svc.cluster.local
        port:
          number: 80
---
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: grafana-dr
  namespace: eshop
spec:
  host: eshop-grafana.eshop.svc.cluster.local
  trafficPolicy:
    tls:
      mode: DISABLE
```

<br>

Step 6) ❗❗ **Additional work related to authentication** ❗❗

ID when accessing: When logging in as admin, specify to authenticate using the password specified below.

**eshop-PaC/eshop/charts/grafana/values.yaml**
```yaml
...
# Administrator credentials when not using an existing secret (see below)
adminUser: admin
adminPassword: admin1234!
...
```
> 275 Line adminPassword: (Default is admin1234!) can be specified as a personal password, or the default password can be used.

<br>

Step 7) After reflecting the changes in the main branch of each individual Github `eshop-PaC`, perform deployment using the `Sync` task through Argocd.

<br>

Step 8) Check whether OSS is actually installed using the Pod search command.

< EC2 environment - admin server >
```bash
kubectl config use-context eshop
```
> Switch to eshop context, can be replaced with ec command

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get pod -n eshop | grep grafana
```
> Pod lookup

<br>
<br>

If the pod is viewed as shown below, it is confirmed normal.

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-1-10-68:~$ kubectl get pod -n eshop | grep grafana
eshop-grafana-75445c6df7-wtbf4                   2/2     Running   0            3d
```

<br>
### 3-1-3. Install jaeger & elasticsearch

<br>

Installation of jaeger and elasticsearch occurs simultaneously. (For reference, when you install elasticsearch, kibana is also installed internally.)

For reference, the structure of jaeger is as shown in the picture below, and since storage is used as elasticsearch, it needs to be installed together.

---

#### **🗎 Note. [Jaeger]**

> This is an OSS that will be used for monitoring applications in a distributed environment, which will be covered in a later course.
>
> Confirm that the relationship between eshop app, jaeger collector, jaeger query UI, etc. is formed with the structure below.
>
> ![](../media2/image14.png)
>
> Source. <https://twofootdog.tistory.com/67>
>
> Jaeger was initially developed as an open source project by Uber, a ride-sharing service company, in 2015, was adopted as a CNCF (Cloud Native Computing Foundation) Incubation project in 2017, and was approved as a formal project in 2019.
>
> 1. Trace: Data/execution path through the system. It consists of one or more spans. To put it simply, a trace can be understood as the period from when a client requests a specific function until a response is returned.
>
> 2. Span: Jaeger’s logical work unit. Each Span contains information such as task name, start time, and period. Span may be nested or ordered.
>

---

<br>

S3 URL:

<s3://t2hubintern/jaeger.tar.gz>

<s3://t2hubintern/elasticsearch.tar.gz>


<br>

Step 0) Pre-work (creating `istio-authz` sub helm chart)

In the case of `jaeger` and kiali` to be installed in the 3-1-4 process, there is no default `authentication` method, so access control will be set using istio's `AuthorizationPolicy`. Create a helm chart related directory named istio-authz, which is the necessary sub helm chart.

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC/eshop/charts
```
> eshop-PaC Go to the PaC working directory.

<br>

< WSL environment >
```bash
mkdir istio-authz
```
> eshop-PaC Create a directory in the path `eshop-PaC/eshop/charts/istio-authz` in PaC.

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC/eshop/charts/istio-authz
```
> eshop-PaC Go to the PaC working directory.

<br>

< WSL environment >
```bash
mkdir templates
```
> Create a directory in the `eshop-PaC/eshop/charts/istio-authz/templates` path where the manifest definition files of the sub helm chart within eshop-PaC PaC will be located.

<br>

Step 1) Download and unzip

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC/eshop/charts
```
> eshop-PaC Go to the PaC working directory.

<br>

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/jaeger.tar.gz .
aws s3 cp s3://t2hubintern/elasticsearch.tar.gz .
```
> Execute each OSS-specific s3 file download command.

<br>

< WSL environment >
```bash
tar xvfz jaeger.tar.gz
tar xvfz elasticsearch.tar.gz
```
> Perform decompression.

<br>

Step 2) After decompressing, check the creation of the eshop-PaC/eshop/charts/jaeger and eshop-PaC/eshop/charts/elasticsearch directories.

<br>

Step 3) In the values.yaml > lightweight section, elasticsearch > enabled: true `Uncomment` and `Add content`. (Content between comment `# Bottom addition target` and comment `# Top addition target`)
**eshop-PaC/eshop/values.yaml**
```yaml
global:

(...생략...)
  lightweight:
    #kiali-server:
    #  enabled: true
    prometheus:
      enabled: true
    elasticsearch:
     enabled: true
    grafana:
      enabled: true
  # Addition to the lower part
  kibanaEnabled: true 
  high-availability:
    elasticsearch:
      enabled: false
    istio-ingress:
      enabled: false
jaeger:
  provisionDataStore:
    cassandra: false
  storage:
    type: elasticsearch
    elasticsearch:
      host: eshop-coordinating-only
      port: 9200
elasticsearch:
  master:
    replicas: 1
  coordinating:
    replicas: 1
  data:
    replicas: 1 
# Top part to add
```

<br>

Step 4) Uncomment the contents of the dependency configuration file below.

**eshop-PaC/eshop/Chart.yaml**
```yaml
apiVersion: v2
name: eshop
description: A Helm chart for Kubernetes
type: application
version: 2.0.0
appVersion: "2.4.0"
dependencies:

- name: metrics-server
  condition: global.lightweight.metrics-server.enabled
- name: prometheus
  condition: global.lightweight.prometheus.enabled
- name: grafana
  condition: global.lightweight.grafana.enabled
- name: elasticsearch
  condition: global.lightweight.elasticsearch.enabled
- name: jaeger
  condition: global.tracing.enabled
# - name: kiali-server
#   condition: global.lightweight.kiali-server.enabled
```

<br>

Step 5) `https://<< DOMAIN >>/jaeger` Add Virtual Service definition for URL access.

<br>

Add istio virtual service and destination rule for jaeger.
<br>

**eshop-PaC/eshop/charts/istio-vs/templates/jaeger-vs.yaml**

```yaml
#Certification needs to be applied later
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: jaeger-vs
spec:
  hosts:
  - "*"
  gateways:
  - ingress-gateway
  http:
  - match:
    - uri:
        exact: /jaeger
    - uri:
        prefix: /jaeger
    # - uri:
    #     prefix: /js
    route:
    - destination:
        host: eshop-jaeger-query.eshop.svc.cluster.local
        port:
          number: 80
  - match:
    - uri:
        regex: /jaeger
    route:
    - destination:
        host: eshop-jaeger-query.eshop.svc.cluster.local
        port:
          number: 80

  # - match:
  #   - uri:
  #       regex: /js
  #   route:
  #   - destination:
  #       host: eshop-jaeger-query.eshop.svc.cluster.local
  #       port:
  #         number: 80

  # - match:
  #   - uri:
  #       regex: /static
  #   route:
  #   - destination:
  #       host: eshop-jaeger-query.eshop.svc.cluster.local
  #       port:
  #         number: 80

  # - match:
  #   - uri:
  #       regex: /static/css/*
  #   route:
  #   - destination:
  #       host: eshop-jaeger-query.eshop.svc.cluster.local
  #       port:
  #         number: 80
---
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: jaeger
  namespace: eshop
spec:
  host: eshop-jaeger-query.eshop.svc.cluster.local
  trafficPolicy:
    tls:
      mode: DISABLE
```

<br>

Step 6) ❗❗ **Additional work related to authentication** ❗❗

**Added AuthorizationPolicy by Jaeger**

- Since Jaeger-query does not provide authentication such as Token / ID / PW by default, the policy below is applied except at the time of testing.

**eshop-PaC/eshop/charts/istio-authz/templates/jaeger-auth-policy.yaml** Create additional files

```yaml
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: jaeger-ingress-policy
  namespace: istio-system
spec:
  selector:
    matchLabels:
      app: istio-ingressgateway
  action: DENY
  rules:
    # IP Base ACL 미동작
    # - from:
    #   - source:
    #       ipBlocks:
    #       - 121.133.133.0/24
    #       - 221.167.219.0/24
    - to:
      - operation:
          paths: [
            "/jaeger*"
          ]
```

<br>

**eshop-PaC/eshop/charts/istio-authz/Chart.yaml**  Create additional files

```yaml
apiVersion: v2
appVersion: "1.0"
description: A Helm chart for Kubernetes
name: istio-authz
version: 1.0.0
```

<br>

**eshop-PaC/eshop/charts/istio-authz/values.yaml**  Create additional files

```yaml
#빈 파일
```

<br>

Step 7) After reflecting the changes in the main branch of each individual Github `eshop-PaC`, perform deployment using the `Sync` task through Argocd.

<br>

Step 8) Check whether OSS is actually installed using the Pod search command.

< EC2 environment - admin server >
```bash
kubectl config use-context eshop
```
> Switch to eshop context, can be replaced with ec command

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get pod -n eshop | grep jaeger
kubectl get pod -n eshop | grep elasticsearch
```
Step 7) After reflecting the changes in the main branch of each individual Github `eshop-PaC`, perform deployment using the `Sync` task through Argocd.

<br>

Step 8) Check whether OSS is actually installed using the Pod search command.

< EC2 environment - admin server >
```bash
kubectl config use-context eshop
```
> Switch to eshop context, can be replaced with ec command

<br>

< EC2 environment - admin server - eshop con> Pod query

<br>
<br>

If the pod is viewed as shown below, it is confirmed normal.

<br>

✔ **(execution code/result example)**text(ec) >
```bash
ubuntu@ip-10-1-10-68:~$ kubectl get pod -n eshop | grep jaeger
eshop-jaeger-agent-24hzp                         2/2     Running   0            3d
eshop-jaeger-agent-dx8tm                         2/2     Running   0            3d
eshop-jaeger-agent-x4m26                         2/2     Running   0            3d
eshop-jaeger-collector-6d7b65485d-tr7ns          2/2     Running   5 (3d ago)   3d
eshop-jaeger-query-7856b4d54f-vg92s              3/3     Running   4 (3d ago)   3d
```

<br>
<br>

If the pod is viewed as shown below, it is confirmed normal.

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-1-10-68:~$ kubectl get pod -n eshop | grep elasticsearch
eshop-elasticsearch-data-0                       1/1     Running   0            3d
eshop-elasticsearch-master-0                     1/1     Running   0            3d
```

<br>


### 3-1-4. kiali installation


<br>

S3 URL : <s3://t2hubintern/kiali-server.tar.gz>

<br>

<br>
Step 1) Download and unzip

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC/eshop/charts
```
> eshop-PaC Go to the PaC working directory.

<br>

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/kiali-server.tar.gz .
```
> Execute each OSS-specific s3 file download command.

<br>

< WSL environment >
```bash
tar xvfz kiali-server.tar.gz
```
> Perform decompression.

<br>

Step 2) After decompressing, check the creation of the eshop-PaC/eshop/charts/kiali-server directory.

<br>

Step 3) Uncomment kiali-server > enabled: true in the values.yaml > lightweight section.

**eshop-PaC/eshop/values.yaml**
```yaml
...
  lightweight:
    kiali-server:
      enabled: true
    prometheus:
      enabled: true
    elasticsearch:
      enabled: true
    grafana:
      enabled: true
```

<br>

Step 4) Uncomment the contents of the dependency setting file below.

**eshop-PaC/eshop/Chart.yaml**
```yaml
apiVersion: v2
name: eshop
description: A Helm chart for Kubernetes
type: application
version: 2.0.0
appVersion: "2.4.0"
dependencies:

- name: metrics-server
  condition: global.lightweight.metrics-server.enabled
- name: prometheus
  condition: global.lightweight.prometheus.enabled
- name: grafana
  condition: global.lightweight.grafana.enabled
- name: elasticsearch
  condition: global.lightweight.elasticsearch.enabled
- name: jaeger
  condition: global.tracing.enabled
- name: kiali-server
  condition: global.lightweight.kiali-server.enabled
```

<br>

Step 5) `https://<< DOMAIN >>/kiali` Add Virtual Service definition for URL access.

Add istio virtual service and destination rule for kiali.

**eshop-PaC/eshop/charts/istio-vs/templates/kiali-vs.yaml**
```yaml
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: kiali-vs
spec:
  hosts:
  - "*"
  gateways:
  - ingress-gateway
  http:
  - match:
    - uri:
        exact: /kiali
    - uri:
        prefix: /kiali
    route:
    - destination:
        host: kiali.eshop.svc.cluster.local
        port:
          number: 20001
---
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: kiali
  namespace: eshop
spec:
  host: kiali.eshop.svc.cluster.local
  trafficPolicy:
    tls:
      mode: DISABLE
```

<br>

Step 6) ❗❗ **Additional work related to authentication** ❗❗

<br>

**Added AuthorizationPolicy for Kiali**

- Since Kiali is set to use the anonymous policy by default, the policy below is applied except during testing.

**eshop-PaC/eshop/charts/istio-authz/templates/kiali-auth-policy.yaml**
```yaml
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: kiali-ingress-policy
  namespace: istio-system
spec:
  selector:
    matchLabels:
      app: istio-ingressgateway
  action: DENY
  rules:
    # IP Base ACL 미동작
    # - from:
    #   - source:
    #       ipBlocks:
    #       - 121.133.133.0/24
    #       - 221.167.219.0/24
    - to:
      - operation:
          paths: [
            "/kiali*"
          ]
```

<br>

Step 7) ❗❗ **Kiali 추가작업** ❗❗

<br>

Replace the external_service.tracing.url value in the eshop/charts/kiali-server/values.yaml file with << DOMAIN >> FQDN of the individual eshop service.

<br>

(Line 76 of the reference source. external_service > tracing > url part of the bottom source)

<br>

```yaml
(...생략...)
external_services:
  prometheus:
    url: http://eshop-prometheus-server
    custom_metrics_url: http://eshop-prometheus-server
  tracing:
    in_cluster_url: http://eshop-jaeger-query/jaeger
    url: https://<< DOMAIN >>/jaeger
  custom_dashboards:
    enabled: true
(...생략...)
```

<br>

Step 8) After reflecting the changes in the main branch of each individual Github `eshop-PaC`, perform deployment using the `Sync` task through Argocd.

---

🗎 Note. Kiali ConfigMap Changes Settings that cause argocd UI to ignore.
<br>

You can change the Live Manifest by going to the installed eshop App Details > Manifests > Edit in the Argocd UI. Paste ignoreDifferences below to the same Depth as syncPolicy.

```yaml
ignoreDifferences:
  - kind: ConfigMap
    name: kiali
    jsonPointers:
      - /data/config.yaml
```

---

<br>

Step 9) Check whether OSS is actually installed using the Pod search command.

< EC2 environment - admin server >
```bash
kubectl config use-context eshop
```
> Switch to eshop context, can be replaced with ec command

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get pod -n eshop | grep kiali
```
> Pod lookup

<br>
<br>

If the pod is viewed as shown below, it is confirmed normal.

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-1-10-68:~$ kubectl get pod -n eshop | grep kiali
kiali-6b975d7469-ptmbq 1/1 Running 0 3d
```

<br>

### 3-1-5. Other notes

---

**🗎 Note. kibana (ClusterIP to LoadBalancer)**
> Kibana can also be accessed through the URL below after changing the service type to Load Balancer Type, but since logging is not performed in the actual practice process, data is not actually collected.
>
>You can only test if access is possible.
>
><br>
>
>http://<< kibana CLB DNS Name >>:5601/kibana
>
>change Security Group of CLB
>
>-) 0.0.0.0/0 5601
>
>+) MyIP/32 5601

---

<br>
<br>

***

## Challenge 3-1

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

Strengthen authentication and authorization (Istio + Keycloak + Oauth2-proxy) on installed OSS monitoring tools.
<a href="./2w-challenge-3-1.md">(Challenge 3-1)</a>

<br>

❗❗ As a future challenge among OSS monitoring tools, SSO authentication can be applied by applying Istio's oauth proxy and keycloak based authentication to kiali, jaeger, kibana, prometheus, etc.

After application, in the case of jaeger and kiali, it is no longer necessary to apply istio AuthrizationPolicy, which is `access restriction for unauthenticated authorization`.

***

<br>
<br>

## **Lab 3-2. After completing the monitoring tool installation, take a look at each OSS**

<br>

To date, the istio service mesh implementation has been applied as shown in the picture below, and OSS tools related to observability have been installed inside the eshop namespace where the eshop application exists.
- prometheus, grafana, jaeger(+elasticsearch), kiali-server

![](../media2/image8.png)


**Access through the OSS endpoint and examine each characteristic.**

<br>
<br>

### 3-2-1. **Prometheus**

❗❗ Prometheus is an OSS that monitors week 2 practice participation, output, and assignment submission. ❗❗

<br>

🔗 endpoint<br>
http://<< prometheus CLB DNS Name >>

<br>

> Change the service type of prometheus-server service to LoadBalancer and access it by calling the DNS Name. (Check the notes below)
>
> Accessible without authentication

- Basically, OS (Linux) metrics of EC2 Worker Nodes are collected.
- It acts as a collector holding data of original metrics, and provides data to another monitoring tool (Grafana).

<br>

![](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Ft1.daumcdn.net%2Fcfile%2Ftistory%2F9906824D5E15F29D16)

Reference URL: https://bcho.tistory.com/1372

<br>

After connecting to Prometheus, call the example PromQL below.

You can extract various metric data using various PromQLs. (Call various queries and look at the results.)

``` bash
# Container CPU Usage (eshop)
rate(container_cpu_usage_seconds_total{namespace="eshop",container_name=""}[2m])
# Container Memory Usage (eshop)
container_memory_usage_bytes{namespace="eshop",container_name=""}
# Container Network Usage (eshop)
rate(container_network_transmit_bytes_total{namespace="eshop"}[2m])
rate(container_network_receive_bytes_total{namespace="eshop"}[2m])
# Nodes CPU Usage(%)
100 - (avg by (kubernetes_node) (irate(node_cpu_seconds_total{job="kubernetes-service-endpoints",mode="idle"}[2m])) * 100)
# Node Memory Usage(byte) $node 변수에 특정 노드 입력
node_memory_MemTotal_bytes{kubernetes_node=~"$node"} - node_memory_MemAvailable_bytes{kubernetes_node=~"$node"}
# Node Network Usage $node 변수에 특정 노드 입력
rate(node_network_receive_bytes_total{kubernetes_node=~"$node",device=~"eth.*"}[2m])
rate(node_network_transmit_bytes_total{kubernetes_node=~"$node",device=~"eth.*"}[2m])
```

<br>
<br>

#### **<span style="color:red">❗❗ Instructions for submitting Prometheus assignments❗❗</span>**

**Additional instructions for submitting Prometheus assignments**

- <span style="color:red">Because Prometheus does not provide its own authorization by default, in the current practice situation, it is deployed as Load Blancer Type and ACL is controlled by Security Group.</span>
- Restrict the Security Group of Prometheus Service LoadBalancer.

   Delete all existing any open 0.0.0.0/0 entries and add the following to the Security Group entry.

   (Prometheus)
   Source: << MyIP >>/32
   Port: 80
   Protocol: TCP
- Change the Service Type of Prometheus Server from ClusterIP to LoadBalancer Type.
- <span style="color:red">The scoring criteria is checked by the presence or absence of LoadBalancer Ensuring success history through workload distribution in AWS EKS Cluster on AWS CloudTrail.</span>
   History Existence: Pass
   No History: Fail
- <span style="color:red">Record the DNS Name that was actually accessible to Prometheus and submit it. (During future practice courses, even if the LoadBalancer and DNS Name of Prometheus are changed or deleted, it will not be relevant to grading the assignment. )</span>

<br>
<br>

---

🗎 Note. Service type change command for prometheus-server service
>
>```
>kubectl patch service eshop-prometheus-server -n eshop -p '{"spec": {"type": "LoadBalancer"}}'
>```

---

<br>

#### 🗎 Note. Check and note the LoadBalancer ELB DNS Name (📌<< Prometheus ELB DNS Name >>) of the prometheus service

<br>

---

🗎 Note. Check LoadBalancer ELB DNS Name of prometheus-server service
>
>```
>kubectl get svc -n eshop | grep prometheus-server
>```

---

<br>

---

🗎 Note. Permanent change of service type of prometheus-server service
>
>=> Change the Helm Chart settings of prometheus.
>
>prometheus > values.yaml > 939 line
>type: Changed to LoadBalancer
>

---

<br>

#### 🗎 Note. Prometheus assignment submission check for correct answers

<br>

---

🗎 Note. Prometheus assignment submission check for correct answers
>
>=> If the ELB of prometheus has been created at least once on AWS CloudTrail through a CloudTrail-related call in the AWS CLI, you can determine in advance whether the assignment submission is correct (see `[Normal Case]`).
>
>< WSL environment or EC2 environment - admin server >
>```bash
>aws cloudtrail lookup-events --lookup-attributes AttributeKey=EventName,AttributeValue=CreateLoadBalancer --region=us-west-2 | grep << Prometheus ELB DNS Name >>
>```
Replace >`<< Prometheus ELB DNS Name >>` with the ELB DNS Name of the Prometheus Server you submitted and call the above command.
>
><br>
>
>✔ **(Example of execution code/result)**
>
>`[Normal Case]`
>```bash
>ubuntu@ip-10-0-10-114:~$ aws cloudtrail lookup-events --lookup-attributes AttributeKey=EventName,AttributeValue=CreateLoadBalancer --region=us-west-2 | grep a8ddd2d6a21d8492db717be049810246-460711733.us-west-2.elb.amazonaws.com
>            "CloudTrailEvent": "{\"eventVersion\":\"1.08\",\"userIdentity\":{\"type\":\"AssumedRole\",\"principalId\":\"AROATIMLCBK7CYZ7EE3NE:1710123197200692557\",\"arn\":\"arn:aws:sts::224166808254:assumed-role/eshop-mgmt-eks-cluster-role/1710123197200692557\",\"accountId\":\"224166808254\",\"accessKeyId\":\"ASIATIMLCBK7BL5URYHH\",\"sessionContext\":{\"sessionIssuer\":{\"type\":\"Role\",\"principalId\":\"AROATIMLCBK7CYZ7EE3NE\",\"arn\":\"arn:aws:iam::224166808254:role/eshop-mgmt-eks-cluster-role\",\"accountId\":\"224166808254\",\"userName\":\"eshop-mgmt-eks-cluster-role\"},\"webIdFederationData\":{},\"attributes\":{\"creationDate\":\"2024-03-11T02:31:55Z\",\"mfaAuthenticated\":\"false\"}},\"invokedBy\":\"eks.amazonaws.com\"},\"eventTime\":\"2024-03-11T02:31:58Z\",\"eventSource\":\"elasticloadbalancing.amazonaws.com\",\"eventName\":\"CreateLoadBalancer\",\"awsRegion\":\"us-west-2\",\"sourceIPAddress\":\"eks.amazonaws.com\",\"userAgent\":\"eks.amazonaws.com\",\"requestParameters\":{\"subnets\":[\"subnet-0eb32eaf061ae0137\",\"subnet-00db3a638be46584a\"],\"securityGroups\":[\"sg-0b1eb1fb7683fdbc2\"],\"loadBalancerName\":\"a8ddd2d6a21d8492db717be049810246\",\"tags\":[{\"key\":\"kubernetes.io/service-name\",\"value\":\"argocd/argocd-server\"},{\"key\":\"kubernetes.io/cluster/eshop-mgmt-eks-cluster\",\"value\":\"owned\"}],\"listeners\":[{\"protocol\":\"tcp\",\"loadBalancerPort\":80,\"instanceProtocol\":\"tcp\",\"instancePort\":30047},{\"protocol\":\"tcp\",\"loadBalancerPort\":443,\"instanceProtocol\":\"tcp\",\"instancePort\":32637}]},\"responseElements\":{\"dNSName\":\"a8ddd2d6a21d8492db717be049810246-460711733.us-west-2.elb.amazonaws.com\"},\"requestID\":\"9f0f00b6-ce10-4324-958f-906c1ff591e4\",\"eventID\":\"ae5b9d62-cf63-4b2e-9380-a7d30089a8de\",\"readOnly\":false,\"eventType\":\"AwsApiCall\",\"apiVersion\":\"2012-06-01\",\"managementEvent\":true,\"recipientAccountId\":\"224166808254\",\"eventCategory\":\"Management\"}"
>```
> Assuming that the DNS Name value of the submitted Prometheus ELB is `a8ddd2d6a21d8492db717be049810246-460711733.us-west-2.elb.amazonaws.com`, a json response is generated in the same format as the example value above.
>
><br>
>
>`[abnormal case]`
>```bash
>ubuntu@ip-10-0-10-114:~$ aws cloudtrail lookup-events --lookup-attributes AttributeKey=EventName,AttributeValue=CreateLoadBalancer --region=us-west-2 | grep a8ddd2d6a21d8492db717be049810246-460711733.us-west-2.elb.amazonaws.com
>ubuntu@ip-10-0-10-114:~$
>```
> If there is no history, the response to the API call will be a `null` value, as shown in the `[abnormal case]` example.

---

<br>
<br>

### 3-2-2. Grafana

<br>

🔗 endpoint<br>
https://<< DOMAIN >>/grafana

<br>

> ID/PW Login
>
> Enter id/pw based on the authentication information defined in grafana Helm Chart values.yaml.

- It is a tool that scrapes raw data from Prometheus and visualizes it as time series data using a dashboard.

- You can use the basic Dashboard, but users (operators) can configure and import detailed monitoring dashboards to suit their purposes. <a href="../etc/2w-reference-3-grafana_dashboard.md">(Reference. Add Grafana Dashboard)</a>

- Username / Password required for login is set in value.yaml of Grafana helm chart.

![](../media2/image12.png)

---

🗎 Note. You can also view the flow of Grafana with Kiali, which you installed earlier. (Call Grafana → Prometheus)

![](../media2/image13.png)

---

<br>
<br>

### 3-2-3. Jaeger

<br>

🔗 endpoint<br>
https://<< DOMAIN >>/jaeger

<br>

> Accessible without authentication (when AuthorizationPolicy is removed)
>
> HTTP 403 rbac denied occurs (when AuthorizationPolicy is applied)
>
> After applying <a href="./2w-challenge-3-1.md">challenge</a>, authentication is possible (Istio + Keycloak + Oauth2-proxy)

- Trace tracking of specific microservices is possible.
- It is possible to track the time required and bottleneck sections for each span within one trace.

![](../media2/jaeger_initial.png)
![](../media2/jaeger_trace.png)

<br>
<br>

### 3-2-4. Kiali-server

<br>

🔗 endpoint<br>
https://<< DOMAIN >>/kiali

<br>

> https://<< DOMAIN >>/kiali
>
> Accessible without authentication (when AuthorizationPolicy is removed)
>
> HTTP 403 rbac denied occurs (when AuthorizationPolicy is applied)
>
> After applying <a href="./2w-challenge-3-1.md">challenge</a>, authentication is possible (Istio + Keycloak + Oauth2-proxy)

- Envoy metrics, flow within namespace can be monitored, and can be used for application transaction tracing linked to jaeger tracing.

- It is a powerful visualization tool that can monitor intuitive service bottlenecks and stuck states.

![](../media2/image10.png)

![](../media2/image11.png)

<br>
<br>


***
## Challenge 3-2

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

[[K8s HPA] Increasing/decreasing the eshop app running in Service EKS Cluster with replicaset HPA](#Challenge-3-2) <a href="./2w-challenge-3-2.md"> ( Challenge 3-2) </a>
***

<br>

***
## Challenge 3-3

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

[[AWS CloudWatch] Applying AWS CloudWatch Container Insights to Service EKS Cluster](#Challenge-3-3) <a href="./2w-challenge-3-3.md"> (Challenge 3-3) </a>
***

<br>

***
## Challenge 3-4

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

[[Observability] RabbitMQ version minor upgrade and management UI monitoring environment construction](#Challenge-3-4) <a href="./2w-challenge-3-4.md"> (Challenge 3-4) < /a>
***

<br>
<br>

## **Evaluation**
---
- Install and experience various monitoring tools within Service EKS Cluster.

- Experience the operation of HPA, which distributes load internally in K8s.

- In practice, find the optimal monitoring solution suited to each task environment.

- Review trade-offs between OSS and commercial monitoring system costs and features.

<br>

😃 **Day 3 completed!!!**

<br>

⏩ [Move] to the next lab (2w-4-Zerodowntime_Deployment.md).

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
## 🤔 Challenge 4-1

### Topic: Open Tracing

<br>

## Practice Objectives
- Apply application distributed tracing (open tracing) through Kiali and Jaeger.
- Apply modifications to apply Open Tracing to the application.

<br>

## Apply distributed tracking to currencyservice, productservice

<br>

### 4-1-1. currencyservice (Nodejs Express app) Monitoring application transactions by applying jaeger opentracing

<br>

1. Disable Jaeger's AuthorizationPolicy

     - Since Jaeger-query does not provide authentication such as Token / ID / PW by default, the policy below is applied except at the time of testing.

     - For testing, comment out the policy below, push it to the Github main branch, and then `Sync` after `checking` `Prune` when `Sync` of Argocd.
    
     ![](../media1/argocd-prune-sync.png)

<br>

**eshop-PaC/eshop/charts/istio-authz/templates/jaeger-auth-policy.yaml**
```yaml
# apiVersion: security.istio.io/v1beta1
#kind: AuthorizationPolicy
# metadata:
# name: jaeger-ingress-policy
# namespace: istio-system
#spec:
# selector:
#matchLabels:
# app: istio-ingressgateway
# action: DENY
# rules:
# # IP Base ACL not working
# # - from:
# # - source:
# # ipBlocks:
# # - 121.133.133.0/24
# # - 221.167.219.0/24
#-to:
#-operation:
# paths: [
# "/jaeger*"
# ]
```

2. Proceed with setting up opentracing for the Nodejs Express app.

---

🗎 Note. Apply Open Tracing(jaeger) to NodeJS
> <https://github.com/jaegertracing/jaeger-client-node>

> <https://github.com/opentracing/opentracing-javascript>

---

<br>

Add settings to the eshop-currencyservice app through the library provided in the link above.

<br>

3. Creating an image of currencyservice for Open Tracing

<br>

First, add the necessary modules.
<br>
The command execution location is different when performing Challenges 1-3 and when not performing them, as shown below.

< WSL environment >
```bash
// If you have not completed challenges 1-3
cd ~/t3-msp-pjt/eshop-MSA/eshop-currencyservice
npm install jaeger-client
npm install opentracing

// If challenges 1-3 have been completed
cd ~/t3-msp-pjt/eshop-MSA-CI/eshop-currencyservice
npm install jaeger-client
npm install opentracing
```
Add jaeger tracing related dependencies using the above command.
<br>
The completed package.json file is as shown below.

**eshop-currencyservice/package.json**
```json
{
  "name": "eshop-currencyservice",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "keywords": [],
  "author": "",
  "license": "ISC",
  "dependencies": {
    "body-parser": "^1.19.0",
    "dotenv": "^8.2.0",
    "express": "^4.17.1",
    "jaeger-client": "^3.19.0",
    "opentracing": "^0.14.7"
  }
}
```

If the addition of the dependency has been completed successfully, modify the inside of the index.js and main function of eshop-currencyservice.

As shown below, add spans for each section of the trace for each business logic. This allows for section-by-section tracking in the future.
**eshop-currencyservice/index.js**
```javascript
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const data = require('./data/initial-data.json');
const dotenv = require('dotenv');
dotenv.config();

const port = process.env.PORT || 8094;

app.use(bodyParser.json());

const initTracer = require("jaeger-client").initTracer;
const { Tags, FORMAT_HTTP_HEADERS } = require('opentracing');

const tracer = initTracer(
  {
    serviceName: "eshop-currencyservice.eshop",
    sampler: {
      type: "const",
      param: 1,
    },
    reporter: {
      collectorEndpoint: "http://eshop-jaeger-collector:14268/api/traces",
      logSpans: false
    }
  },
  {
    logger: {
      info: (msg) => {
        console.log('INFO  ', msg);
      },
      error: (msg) => {
        console.log('ERROR ', msg);
      },
    },
  }
);

app.get('/api/currencies', (req, res) => {
  const parentSpanContext = tracer.extract(FORMAT_HTTP_HEADERS, req.headers);
  const span = tracer.startSpan(`getAllCurrencies`, {
    childOf: parentSpanContext,
    tags: {
      [Tags.SPAN_KIND]: Tags.SPAN_KIND_RPC_SERVER,
      [Tags.HTTP_URL]: req.url,
      [Tags.HTTP_METHOD]: req.method,
      [Tags.HTTP_STATUS_CODE]: res.statusCode
    }
  });

  console.log("Span ID: ", span.context().toSpanId());

  tracer.inject(span, FORMAT_HTTP_HEADERS, req.headers);

  console.log("All Currencies")
  res.send(data)
  span.finish();
})

app.post('/api/currencies/convert', (req, res) => {
  const from = req.body.from;
  const to_code = req.body.to_code;

  console.log("convert from : " + from.currencyCode + ", to : " + to_code + ", units : " + from.units + ", nanos :" + from.nanos);

  const euros = {
    units: from.units / data[from.currencyCode],
    nanos: Math.round(from.nanos / data[from.currencyCode])
  };

  const result = {
    currencyCode: to_code,
    units: Math.floor(euros.units * data[to_code]),
    nanos: Math.floor(euros.nanos * data[to_code])
  };

  res.send(JSON.stringify(result))
})

app.listen(port, function () {
  console.log("Currency service has started on port " + port)
})
```

<br>
In the same manner as the previous required process, merge the changes into the main branch of the Github Repository where the eshop-currencyservice source is managed and execute the CI Pipeline.

<br>

4. Application of currencyservice for Open Tracing

<br>

If you restart the deployment of eshop-currencyservice through Argocd as shown in the picture below, deployment is completed as a new image.

![](../media2/trace-currencyservice-restart.png)

<br>

After deployment as a new image is completed, a Span Report is captured at every API call, and you can check that it has been applied properly through the Span ID output log as shown below.
![](../media2/trace-currencyservice-log.png)

<br>

5. Monitoring currency service after applying Open Tracing

<br>

After connecting to Kiali, make sure that the GET api/currencies API is continuously called (you can also use the loader call that continuously called adservice in the previous process) and then look at the trace of eshop-currencyservice.

<br>

Kiali Trace

![](../media2/trace-currencyservice-kiali-list.png)

<br>

Jaeger-query Trace

![](../media2/trace-currencyservice-jaeger-detail.png)

<br>

6. After completing the exercise, add Jaeger’s AuthorizationPolicy

     - Since Jaeger-query does not provide authentication such as Token / ID / PW by default, the policy below is applied except at the time of testing.
     - Perform `Sync` in Argocd. (Check ‘Prune’ is not necessary as new policy is created)
     - Now that the tracing test has been completed, add a policy again to block external jaeger entry.

**eshop-PaC/eshop/charts/istio-authz/templates/jaeger-auth-policy.yaml**
```yaml
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: jaeger-ingress-policy
  namespace: istio-system
spec:
  selector:
    matchLabels:
      app: istio-ingressgateway
  action: DENY
  rules:
    # IP Base ACL 미동작
    # - from:
    #   - source:
    #       ipBlocks:
    #       - 121.133.133.0/24
    #       - 221.167.219.0/24
    - to:
      - operation:
          paths: [
            "/jaeger*"
          ]
```

<br>


<br>

### 4-1-2. productservice (Nodejs Express app) Monitor application transaction by applying jaeger opentracing

<br>

1. Disable Jaeger's AuthorizationPolicy

     - Since Jaeger-query does not provide authentication such as Token / ID / PW by default, the policy below is applied except at the time of testing.

     - For testing, comment out the policy below, push it to the Github main branch, and then `Sync` after `checking` `Prune` when `Sync` of Argocd.
    
     ![](../media1/argocd-prune-sync.png)

<br>
**eshop-PaC/eshop/charts/istio-authz/templates/jaeger-auth-policy.yaml**

```yaml
# apiVersion: security.istio.io/v1beta1
# kind: AuthorizationPolicy
# metadata:
#   name: jaeger-ingress-policy
#   namespace: istio-system
# spec:
#   selector:
#     matchLabels:
#       app: istio-ingressgateway
#   action: DENY
#   rules:
#     # IP Base ACL 미동작
#     # - from:
#     #   - source:
#     #       ipBlocks:
#     #       - 121.133.133.0/24
#     #       - 221.167.219.0/24
#     - to:
#       - operation:
#           paths: [
#             "/jaeger*"
#           ]
```

2. Proceed with setting up opentracing for the Nodejs Express app.

---

🗎 Note. Apply Open Tracing(jaeger) to NodeJS
> <https://github.com/jaegertracing/jaeger-client-node>

> <https://github.com/opentracing/opentracing-javascript>

---

<br>

Add settings to the eshop-productservice app through the library provided in the link above.

<br>

3. Creating image of productservice for Open Tracing

<br>

First, add the necessary modules.
<br>
The command execution location is different when performing Challenges 1-3 and when not performing them, as shown below.

< WSL environment >
```bash
// If you have not completed challenges 1-3
cd ~/t3-msp-pjt/eshop-MSA/eshop-productservice
npm install jaeger-client
npm install opentracing

// If challenges 1-3 have been completed
cd ~/t3-msp-pjt/eshop-MSA-CI/eshop-productservice
npm install jaeger-client
npm install opentracing
```
Add jaeger tracing related dependencies using the above command.
<br>
The completed package.json file is as shown below.
**eshop-productservice/package.json**
```json
{
  "name": "eshop-productservice",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "",
  "license": "ISC",
  "dependencies": {
    "dotenv": "^8.2.0",
    "express": "^4.17.1",
    "mongoose": "^5.10.10",
    "jaeger-client": "^3.19.0",
    "opentracing": "^0.14.7"
  }
}
```

If the addition of the dependency has been completed successfully, modify the inside of the index.js and main function of eshop-productservice.

As shown below, add spans for each section of the trace for each business logic. This allows for section-by-section tracking in the future.

**eshop-productservice/index.js**
```javascript
const express = require("express");
const app = express();
const dotenv = require("dotenv");
const mongoose = require("mongoose");
const Product = require("./product-model")

dotenv.config();

const port = process.env.PORT;

const initTracer = require("jaeger-client").initTracer;
const { Tags, FORMAT_HTTP_HEADERS } = require('opentracing');

const tracer = initTracer(
    {
        serviceName: "eshop-productservice.eshop",
        sampler: {
            type: "const",
            param: 1,
        },
        reporter: {
            collectorEndpoint: "http://eshop-jaeger-collector:14268/api/traces",
            logSpans: false
        }
    },
    {
        logger: {
            info: (msg) => {
                console.log('INFO  ', msg);
            },
            error: (msg) => {
                console.log('ERROR ', msg);
            },
        },
    }
);

let db = mongoose.connection;
db.on("error", console.error);
db.on("connected", function () {
    console.log("Connected to mongod server");
    if (process.env.INIT_DATA) {
        console.log("initializing product data...");
        Product.initProduct(Product);
    }
});
db.on('disconnected', function () {
    console.log('MongoDB disconnected!');
    setTimeout(() => connect(), 5000);
});
var connect = function () {
    mongoose.connect(process.env.MONGO_URI, {
        useUnifiedTopology: true,
        useNewUrlParser: true,
    });
}
connect();

app.get("/api/products", async (req, res) => {
    const parentSpanContext = tracer.extract(FORMAT_HTTP_HEADERS, req.headers);
    const span = tracer.startSpan(`getAllProducts`, {
        childOf: parentSpanContext,
        tags: {
            [Tags.SPAN_KIND]: Tags.SPAN_KIND_RPC_SERVER,
            [Tags.HTTP_URL]: req.url,
            [Tags.HTTP_METHOD]: req.method,
            [Tags.HTTP_STATUS_CODE]: res.statusCode
        }
    });
    console.log("Span ID: ", span.context().toSpanId());
    tracer.inject(span, FORMAT_HTTP_HEADERS, req.headers);

    if (req.query.ids) {
        const ids = req.query.ids.split(",");
        console.log("Filtered Product List : ", ids);
        const findResults = await Product.find({ id: { $in: ids } });
        const result = {
            products: findResults,
        };
        console.log("Filtered Products : " + JSON.stringify(result));
        res.send(result);
    } else {
        console.log("All Product List");
        const allProducts = await Product.find();
        const result = {
            products: allProducts,
        };
        res.send(result);
    }
    span.finish();
});

app.get("/api/products/:id", async (req, res) => {
    const parentSpanContext = tracer.extract(FORMAT_HTTP_HEADERS, req.headers);
    const span = tracer.startSpan(`getRequestedProduct`, {
        childOf: parentSpanContext,
        tags: {
            [Tags.SPAN_KIND]: Tags.SPAN_KIND_RPC_SERVER,
            [Tags.HTTP_URL]: req.url,
            [Tags.HTTP_METHOD]: req.method,
            [Tags.HTTP_STATUS_CODE]: res.statusCode
        }
    });
    console.log("Span ID: ", span.context().toSpanId());
    tracer.inject(span, FORMAT_HTTP_HEADERS, req.headers);

    const requestedId = req.params.id;
    console.log("Requested Product : " + requestedId);
    const result = await Product.findOne({ id: requestedId });
    console.log("Found Product : " + JSON.stringify(result));
    res.send(result);

    span.finish();
});

app.listen(port, function () {
    console.log("Product Catalog service has started on port " + port);
});
```

<br>

In the same manner as the previous required process, merge the changes into the main branch of the Github Repository where the eshop-productservice source is managed and execute the CI Pipeline.

<br>

4. Application of product service for Open Tracing

<br>

If you restart the deployment of eshop-productservice through Argocd as shown in the picture below, deployment is completed as a new image.

![](../media2/trace-productservice-restart.png)

<br>

After deployment as a new image is completed, a Span Report is captured at every API call, and you can check that it has been applied properly through the Span ID output log as shown below.
![](../media2/trace-productservice-log.png)

<br>

5. Product service monitoring after applying Open Tracing

<br>

After connecting to Kiali, make sure that the GET api/products API is continuously called (you can also use the loader call that continuously called adservice in the previous process) and then look at the trace of eshop-productservice.

<br>

Kiali Trace

![](../media2/trace-productservice-kiali-list.png)

<br>

Jaeger-query Trace

![](../media2/trace-productservice-jaeger-detail.png)

<br>

6. After completing the exercise, add Jaeger’s AuthorizationPolicy

     - Since Jaeger-query does not provide authentication such as Token / ID / PW by default, the policy below is applied except at the time of testing.
     - Perform `Sync` in Argocd. (Check ‘Prune’ is not necessary as new policy is created)
     - Now that the tracing test has been completed, add a policy again to block external jaeger entry.

**eshop-PaC/eshop/charts/istio-authz/templates/jaeger-auth-policy.yaml**
```yaml
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: jaeger-ingress-policy
  namespace: istio-system
spec:
  selector:
    matchLabels:
      app: istio-ingressgateway
  action: DENY
  rules:
    # IP Base ACL 미동작
    # - from:
    #   - source:
    #       ipBlocks:
    #       - 121.133.133.0/24
    #       - 221.167.219.0/24
    - to:
      - operation:
          paths: [
            "/jaeger*"
          ]
```

<br>

## Apply distributed tracing to recommendservice

<br>

### 4-1-3. recommendservice (python Flask app) Monitor application transactions by applying jaeger opentracing

<br>

1. Disable Jaeger's AuthorizationPolicy

     - Since Jaeger-query does not provide authentication such as Token / ID / PW by default, the policy below is applied except at the time of testing.

     - For testing, comment out the policy below, push it to the Github main branch, and then `Sync` after `checking` `Prune` when `Sync` of Argocd.
    
     ![](../media1/argocd-prune-sync.png)

<br>

**eshop-PaC/eshop/charts/istio-authz/templates/jaeger-auth-policy.yaml**
```yaml
# apiVersion: security.istio.io/v1beta1
# kind: AuthorizationPolicy
# metadata:
#   name: jaeger-ingress-policy
#   namespace: istio-system
# spec:
#   selector:
#     matchLabels:
#       app: istio-ingressgateway
#   action: DENY
#   rules:
#     # IP Base ACL 미동작
#     # - from:
#     #   - source:
#     #       ipBlocks:
#     #       - 121.133.133.0/24
#     #       - 221.167.219.0/24
#     - to:
#       - operation:
#           paths: [
#             "/jaeger*"
#           ]
```

2. This time, we will additionally set up opentracing for the python Flask app.

---

🗎 Note. Applying Open Tracing(jaeger) to Python Flask
> <https://github.com/jaegertracing/jaeger-client-python>

---

<br>

Add settings to the eshop-recommendservice python app (client) through the library provided in the link above.

<br>

<details>
<summary>[Options - Expand👇] Install and set up Pycharm to make Python debugging easier</summary>

<br>

<https://www.jetbrains.com/pycharm/download/download-thanks.html>

<br>

Additionally, when using Pycharm, a .idea directory is created, so you must change that directory to
Let’s add it to the .gitignore file.

**eshop-recommendservice/.gitignore**

![](../media2/image23.png)
</details>

---

<br>

3. Create image of recommendservice for Open Tracing

<br>

First, add the necessary pip module.
**eshop-recommendservice/requirements.txt**
```python
certifi==2020.6.20
chardet==3.0.4
click==7.1.2
Flask==1.1.2
gunicorn==20.0.4
idna==2.10
itsdangerous==1.1.0
Jinja2==2.11.2
MarkupSafe==1.1.1
requests==2.24.0
urllib3==1.25.11
Werkzeug==1.0.1

#Additional items
pyctuator
jaeger_client
flask_opentracing
tornado==4.5.3
opentracing_instrumentation
prometheus_client==0.3.1
```

The modification items for when `Challenge 1-3` is performed and when not performed are different as follows.

1) If performed: `eshop-MSA-CI/eshop-recommendservice/requirements.txt`
2) If not done: `eshop-MSA/eshop-recommendservice/requirements.txt`

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-MSA-CI/eshop-recommendservice
```
> For 1), move the working directory

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-MSA/eshop-recommendservice
```
> For 2), move the working directory

<br>

< WSL environment >
```bash
pip install -r requirements.txt
```
> Install Python library

The above command adds dependencies related to Jaeger tracing in a personal Python development environment (venv, or local).

<br>

If the addition of the dependency has been completed successfully, modify the inside of app.py and the main function of eshop-recommendservice.

<br>

As shown below, add spans for each section of the trace for each business logic. This allows for section-by-section tracking in the future.

<br>

**eshop-recommendservice/app.py**
```python
import time
import os
import random
import requests
from flask import Flask

from jaeger_client import Config

_url_productservice = os.environ.get("URL_PRODUCTSERVICE", default='http://localhost:8080/')
app = Flask(__name__)


def init_conf():
    config = Config(
        config={  # usually read from some yaml config
            'sampler': {
                'type': 'const',
                'param': 1,
            },
            'local_agent': {
                'reporting_host': "eshop-jaeger-agent",
                'reporting_port': 6831,
            },
            'logging': True,
        },
        service_name='eshop-recommendservice.eshop',
        validate=True,
    )
    cfgtracer = config.initialize_tracer()
    return cfgtracer


##
tracer = init_conf()


@app.route("/api/recommends", methods=['GET'])
def recommend():
    ##
    with tracer.start_span('GET-api-recommends') as span:
        ##
        # span.log_kv({'event': 'recommend'})
        span.set_tag('success: get all recommendations information', "ingress recommend")
    # time.sleep(2)  # yield to IOLoop to flush the spans - https://github.com/jaegertracing/jaeger-client-python/issues/50
    # tracer.close()  # flush any buffered spans

    # 상품 목록을 조회한다.
    response = requests.get(_url_productservice + "/api/products")
    products = response.json()
    # 랜덤한 4개의 상품을 추천한다.
    recommendations = {'recommendations': random.sample(products['products'], 4)}
    print("recommendations : {}".format(recommendations))

    ##
    with tracer.start_span('GET-api-recommends-products') as span:
        ##
        # span.log_kv({'event': 'recommend'})
        span.set_tag('success: get all recommendations information', recommendations)
    #time.sleep(2)  # yield to IOLoop to flush the spans - https://github.com/jaegertracing/jaeger-client-python/issues/50
    #tracer.close()  # flush any buffered spans

    return recommendations
```

<br>

As in the previous process, merge the changes into the main branch of the Github Repository where the eshop-recommendservice source is managed and execute the CI Pipeline.

<br>

4. Application of recommendservice for Open Tracing

<br>

If you restart the deployment of eshop-recommendservice through Argocd, deployment will be completed as a new image.

<br>

5. Monitoring recommendservice after applying Open Tracing

<br>

After connecting to Kiali, make sure that the GET api/recommends API is continuously called (you can also use the loader call that continuously called adservice in the previous process) and then look at the trace of eshop-recommendservice.

<br>

Kiali Trace

![](../media2/image24.png)

<br>

Jaeger-query Trace

![](../media2/image25.png)

This is a very basic application of opentracing, and in the future, the span can be expanded to apply detailed tracking for each section.

<br>

6. After completing the exercise, add Jaeger’s AuthorizationPolicy

     - Since Jaeger-query does not provide authentication such as Token / ID / PW by default, the policy below is applied except at the time of testing.
     - Perform `Sync` in Argocd. (Check ‘Prune’ is not necessary as new policy is created)
     - Now that the tracing test has been completed, add a policy again to block external jaeger inflow.

**eshop-PaC/eshop/charts/istio-authz/templates/jaeger-auth-policy.yaml**
```yaml
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: jaeger-ingress-policy
  namespace: istio-system
spec:
  selector:
    matchLabels:
      app: istio-ingressgateway
  action: DENY
  rules:
    # IP Base ACL 미동작
    # - from:
    #   - source:
    #       ipBlocks:
    #       - 121.133.133.0/24
    #       - 221.167.219.0/24
    - to:
      - operation:
          paths: [
            "/jaeger*"
          ]
```

<br>
<br>

**😃 Challenge completed!!!**

<br>

---
# <center> <a href="../README.md">[목록]</a> </center>
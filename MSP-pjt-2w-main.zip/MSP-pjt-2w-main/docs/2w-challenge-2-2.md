## Current status of the program

<br>

## 🤔 Challenge 2-2

### Topic: Test

<br>

📌 [Notes to be used during this lab]

📌 [ECR URI]<br>
➕ << ECR URI >> : <br>

<br>

## Deploy eshop application test via argocd on eshop-service-eks-cluster (eshop-MSA configuration)

<br>

On the argocd screen, specify and create Service EKS Cluster, which is a newly added cluster for New app, and install nginx ingress controller to accept test calls. (Version 1.3.0)

<br>

1. Change the context to eshop using the context switch command.

< EC2 environment - admin server >
```bash
kubectl config use-context eshop
```

<br>

2. Install nginx ingress controller to accept test calls

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.3.0/deploy/static/provider/aws/deploy.yaml
```

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl -n ingress-nginx patch service ingress-nginx-controller -p '{"spec":{"externalTrafficPolicy":"Cluster"}}'
```

<br>

---

🗎 Note. Links related to reasons for executing the above command
> <https://aws.amazon.com/premiumsupport/knowledge-center/eks-unhealthy-worker-node-nginx/?nc1=h_ls>
>
> By setting the spec.externalTrafficPolicy option to Cluster, all worker nodes can be in a healthy state no matter what node they run on. (For reference, there is no problem with operation even if it is an existing local policy.)

---

<br>


< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get all -n ingress-nginx
```

Check installation
> Confirm that the pod related to `ingress-nginx-controller` is Running, as shown in the example below.


✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-1-10-68:~$ kubectl get all -n ingress-nginx
NAME READY STATUS RESTARTS AGE
pod/ingress-nginx-admission-create-qjlcv 0/1 Completed 0 52s
pod/ingress-nginx-admission-patch-fp775 0/1 Completed 1 52s
pod/ingress-nginx-controller-6bf7bc7f94-tqhwb 1/1 Running 0 52s

NAME TYPE CLUSTER-IP EXTERNAL-IP PORT(S) AGE
service/ingress-nginx-controller LoadBalancer 172.20.142.38 af72018dc5cb34383a0bb95377b928e2-db7c7b25517aa10f.elb.us-east-1.amazonaws.com 80:32027/TCP,443:31986/TCP 52s
service/ingress-nginx-controller-admission ClusterIP 172.20.174.83 <none> 443/TCP 52s

NAME READY UP-TO-DATE AVAILABLE AGE
deployment.apps/ingress-nginx-controller 1/1 1 1 52s

NAME DESIRED CURRENT READY AGE
replicaset.apps/ingress-nginx-controller-6bf7bc7f94 1 1 1 52s

NAME COMPLETIONS DURATION AGE
job.batch/ingress-nginx-admission-create 1/1 6s 53s
job.batch/ingress-nginx-admission-patch 1/1 7s 53s
```

<br>

Check service

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get svc -n ingress-nginx
```

<br>

Check the endpoint using the above service inquiry command.
> As shown in the example below, you can check the endpoint that can access ingress in the `EXTERNAL-IP` item.

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-1-10-68:~$ kubectl get svc -n ingress-nginx
NAME TYPE CLUSTER-IP EXTERNAL-IP PORT(S) AGE
ingress-nginx-controller LoadBalancer 172.20.142.38 af72018dc5cb34383a0bb95377b928e2-db7c7b25517aa10f.elb.us-west-2.amazonaws.com 80:32027/TCP,443:31986/TCP 3m8s
ingress-nginx-controller-admission ClusterIP 172.20.174.83 <none> 443/TCP 3m8s
```

<br>

3. Create a new eshop application on the argocd web screen.

Create a new app by designating it to a new cluster as argocd default project and install ingress

<br>

+New App creation task

Step 1) Enter GENERAL items
|Item|Content|Action|
|------|---|---|
|➕ Application Name |`eshop-k8s`|Copy & Paste|
|➕ Project |`default`|Select select box|
|➕ SYNC POLICY | `Manual` |Select select box (default)|
|➕ SYNC OPTIONS |`AUTO-CREATE NAMESPACE`|Select checkbox|

<br>

Step 2) Enter SOURCE items
|Item|Content|Action|
|------|---|---|
|➕Repository URL |`https://github.com/<< GITHUB USER NAME >>/eshop-MSA.git`|Select select box|
|➕Revision|`main` or `HEAD`|Select select box|
|➕Path|`k8s`|Input|

<br>

Step 3) Enter DESTINATION items
|Item|Content|Action|
|------|---|---|
|➕ Cluster URL |`<< Service EKS Cluster Endpoint >>`|Select select box|
|➕ Namespace |`eshop`|Copy & Paste|
> The value of << Service EKS Cluster Endpoint >> can be viewed as a command that appears when querying the API Endpoint of the Kubernetes control plane using the `kubectl cluster-info` command in the `eshop` Context.

<br>
Step 4) Select Directory (It is not Helm Format, so it is not recognized as Helm in Argocd.)

<br>

➡️ Progress to date (red box completed)

![](../media1/image44.png)


1. After confirming the service test, delete the eshop App.
> Delete eshop from Argocd App screen

<br>

5. After confirming the service test, delete ingress-nginx.

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl delete -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.3.0/deploy/static/provider/aws/deploy.yaml
```

<br>

**😃 Challenge Completed!!!**

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
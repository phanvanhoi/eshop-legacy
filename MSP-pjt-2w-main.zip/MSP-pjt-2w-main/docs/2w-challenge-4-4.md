## Current status of the program

<br>

## 🤔 Challenge 4-4

### Topic: Deployment(Canary)

<br>

## Practice Objectives
- Install Argo rollout, the Argo Project's distribution plugin, and perform canary distribution using it.
- (Optional) Try performing SSH Tunneling using Mobaxterm or Putty.

<br>

## Pre-check

This challenge is an extension of Challenge 4-3, so if you have not completed the challenge, follow the `Argo roll-out and plugin installation` process in the `docs/2w-challenge-4-3.md` textbook. Please refer to and proceed with installation.

<br>

## Canary deployment using Argo Roll Out

---

🗎 Note. To perform this process, you must restore and remove the files set for canary deployment using Istio.

---

<br>

Remove Deplyment declaration

**eshop-PaC/eshop/charts/eshop-frontend/templates/deployment.yaml**
```yaml
# apiVersion: apps/v1
# kind: Deployment
# metadata:
#   name: eshop-frontend
# spec:
#   selector:
#     matchLabels:
#       app: eshop-frontend
#   template:
#     metadata:
#       labels:
#         app: eshop-frontend
#     spec:
#       containers:
#         - name: eshop-frontend
#           image: {{ .Values.global.images.frontend }}
#           imagePullPolicy: Always
#           ports:
#           - containerPort: 8080
#           resources:
#             requests:
#               cpu: 100m
#               memory: 64Mi
#             limits:
#               cpu: 200m
#               memory: 128Mi
```

<br>

Virtual Service wonbok

**eshop-PaC/eshop/charts/istio-vs/templates/eshop-vs.yaml**
```yaml
(...skip...)
  - match:
    - uri:
        exact: /
    - uri:
        exact: /favicon.ico
    - uri:
        prefix: /css
    - uri:
        prefix: /js
    route:
    - destination:
        host: eshop-frontend
        port:
          number: 8080
```

eshop-PaC/eshop/charts/istio-vs/templates/drs.yaml Delete.

**eshop-PaC/eshop/charts/istio-vs/templates/drs.yaml**

```yaml
# apiVersion: networking.istio.io/v1alpha3
# kind: DestinationRule
# metadata:
#   name: eshop-frontend
# spec:
#   host: eshop-frontend
#   trafficPolicy:
#     tls:
#       mode: DISABLE
#   subsets:
#   - name: v1
#     labels:
#       version: v1
#   - name: v2
#     labels:
#       version: v2
```

=> After setting the files as above, check `Prune` and `Sync` in Argocd.

<br>

Next, declare and add the Argo Rollout CRD below.
**eshop-PaC/eshop/charts/eshop-frontend/templates/deployment-canary.yaml**

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: eshop-frontend
spec:
  replicas: 1
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: eshop-frontend
  template:
    metadata:
      labels:
        app: eshop-frontend
    spec:
      containers:
      - name: eshop-frontend
        #Edit tag
        #existing
        image: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-frontend:previous
        #new
        #image: {{ .Values.global.images.frontend }}
        imagePullPolicy: Always
        ports:
        - containerPort: 8080
        resources:
          requests:
            cpu: 100m
            memory: 64Mi
          limits:
            cpu: 200m
            memory: 128Mi
  strategy:
    canary:
      #maxSurge: "50%"
      #maxUnavailable: 0
      steps:
      - setWeight: 50
      - pause: {}
```

When performing actual deployment, if you change the image with the `image: {{ .Values.global.images.frontend }}` tag and then merge it into the github main branch, the rollout pause state continues like the blue/green deployment performed previously. (50:50 traffic distribution situation)

<br>

In pause state, you can promote through argo rollout dashboard UI or cli command.

`1) Method of using CLI`

promote: The latest revision is applied in the current state
```bash
kubectl-argo-rollouts promote eshop-frontend -n eshop
```

<br>


`2) Method of using UI`

When promoted, 100% weight is set to the new version, and it is completely replaced with the new version.

<br>
<br>

`Challenge 4-3, Challenge 4-4` After completing the exercise, executing argo rollout is no longer necessary, so delete it using the command below. However, deletion must be performed while changing the kind to the k8s default workload resource type (Rollout -> Deployment).

- Deletion within ESHOP Cluster

< EC2 environment - Admin Server >
```bash
ec
```
> Switch eshop context

<br>

< EC2 environment - Admin Server - eshop context(ec) >
```bash
kubectl delete -n argo-rollouts -f https://github.com/argoproj/argo-rollouts/releases/latest/download/install.yaml
```

<br>

- Deletion within MGMT Cluster

< Admin Server >
```bash
mc
```
>mgmt context switch

<br>

< EC2 environment - Admin Server - mgmt context(mc) >
```bash
kubectl delete -n argo-rollouts -f https://github.com/argoproj/argo-rollouts/releases/latest/download/install.yaml
```

<br>

**😃 Challenge Completed!!!**

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
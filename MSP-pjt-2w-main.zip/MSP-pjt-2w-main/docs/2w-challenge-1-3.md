## Current status of the program

<br>

## 🤔 Challenge 1-3

### Topic: CI Pipeline Automation

<br>

📌 [Additional notes to use during challenges]

📌 [Slack setting information (challenge)]<br>
➕ workspace name ( `<< WORKSPACE >>` ) : <br>
➕ `#ci-notice` channel id ( `<< CHANNEL ID >>` ) : <br>
➕ slack token ( `<< SLACK TOKEN >>`): <br>

<br>

***

📌 Check Slack Workspace name - workspace name ( `<< WORKSPACE >>` )

![](../media1/image37-1.png)

> You can check the Sub Domain of the workspace by clicking the workspace name in the upper left corner of the Slack workspace.

<br>

📌 Check CI result Noti channel id - `#ci-notice` channel id ( `<< CHANNEL ID >>` )

![](../media1/image37-2.png)

> If you right-click the `#ci-notice` channel among the channels in the Slack workspace and click `View Channel Details`, the channel ID will appear at the bottom. Be sure to record the value.

<br>

***

<br>

## Repo separation for each microservice and integration with Blue Ocean CI Pipeline (part that automates CI Pipeline Trigger)

<br>

ⓘ Purpose of using Blue Ocean Pipeline: Different SSOT (Single Source of Truth) for each microservice, configures and automatically sends Github Webhook Noti to the Jenkins controller server when changes occur (merge) in the main branch of each repository. The purpose is to trigger the build.

<br>

## Practice goals
1. Construct CI and Kaniko Pipeline to become a Build Trigger through Github Webhook.
2. Use Jenkins’ Blue Ocean Plugin.
3. Apply the method of linking Jenkins and Slack.
4. Understand the structure of Jenkinsfile and implement functions in various stages.
5. Establish a CI Pipeline and ECR Repository that are managed during actual operation of the eshop service.
6. Separate Source Repository for each microservice.
7. When changes occur in the separated Source Repository (SSOT), Jenkins' Build Pipeline is automatically triggered to automate CI.


<br>

(❗❗ Reference Material) The completed product of this challenge can be downloaded and used from S3 below, and you can also use the actual method of configuring it yourself by following the guide below.

<s3://t2hubintern/eshop-MSA-CI.tar.gz>

<br>

## eshop-MSA-CI completed (Source)
Service Source Repository for Cloud/MSA CI/CD practice

> The difference from the existing eshop-MSA reference is that the Github Repository for each microservice is managed separately.

<br>

## eshop-MSA vs eshop-MSA-CI

![](../media1/Github-MSA-CI.png)

<br>

**Jenkins Inbound Limitation (port 8080)**

**=> As mentioned in the purpose of using Blue Ocean Pipeline above, in order to automate CI Pipeline, github webhook must be received from ELB, so check whether port 8080 of the source IPs below is allowed in ELB's Security Group Inbound.**

<br>

> Therefore, Inbound is set in the Security Group to receive traffic from Github as shown below. Let’s check the entries already registered with Jenkins’ Helm Chart. (❗ Only check history, not work.)

---

>🗎 Note. Github's Hook Source IP information below can be found in the meta API provided by github.com. Check the "hooks" item
>
><https://api.github.com/meta>

|item|
|------|
|192.30.252.0/22|
|185.199.108.0/22|
|140.82.112.0/20|
|143.55.64.0/20|

---

<br>


## 1. Separate repository for eshop-MSA outer architecture CI Pipeline

<br>

---

🗎 Note. eshop-MSA-CI directory
> The eshop-MSA-CI directory serves as the upper directory for repositories (7) separated by microservice within the developer's local development environment, and does not perform Git Initialization on its own. (Check that there is no .git directory)
>
><< Example structure of eshop-MSA-CI >>
>```bash
>drwxr-xr-x 11 ubuntu ubuntu 4096 Apr 11 07:46 .
>drwxr-xr-x  9 ubuntu ubuntu 4096 Apr 13 08:44 ..
>drwxr-xr-x  7 ubuntu ubuntu 4096 Mar 24 11:57 eshop-adservice
>drwxr-xr-x  7 ubuntu ubuntu 4096 Dec 27 19:51 eshop-backend
>drwxr-xr-x  7 ubuntu ubuntu 4096 Dec 27 19:51 eshop-cartservice
>drwxr-xr-x  4 ubuntu ubuntu 4096 Dec 27 19:49 eshop-currencyservice
>drwxr-xr-x  5 ubuntu ubuntu 4096 Apr 13 08:17 eshop-frontend
>drwxr-xr-x  4 ubuntu ubuntu 4096 Jan  5 12:50 eshop-productservice
>drwxr-xr-x  4 ubuntu ubuntu 4096 Mar 13 17:20 eshop-recommendservice
>```

---

<br>

## ❗❗ Precautions when working with eshop-MSA-CI directory❗❗

<br>

<span style="color:red">The tasks guided below must be performed a total of 7 times, depending on the number of microservices.</span>

<br>

Copy the existing eshop-MSA source code to the eshop-MSA-CI directory.

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt
cp -R eshop-MSA eshop-MSA-CI
cd ~/t3-msp-pjt/eshop-MSA-CI
rm -rf .git
rm -rf README.md
rm -rf images
rm -rf k8s
rm -rf skaffold.yaml
```

<br>
Git initialize the directories for each microservice under eshop-MSA-CI.

<br>

**The eshop-adservice Repo must be created in advance as a personal Github Private Repository.**

Below is an example of <span style="color:red">eshop-adservice</span>

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-MSA-CI/eshop-adservice
```

<br>

Run VS Code 

< WSL environment >
```bash
code .
```

<br>

The directory structure is structured as follows.

![](../media1/3-3-4-1.png)

<br>

For reference, create a github repository for each microservice (must be private) and execute the command shown in the red box.

![](../media1/3-3-4-2.png)

<br>

Perform git init for each microservice source.
Go to each of the seven microservice directories. (performed sequentially)

The example below is eshop-adservice
< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-MSA-CI/eshop-adservice
```

< WSL environment >
```bash
echo "# eshop-adservice" >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/<< GITHUB USER NAME >>/eshop-adservice.git
git push -u origin main
git add .
git commit -m "split adservice"
git push origin main
```

<br>

**<span style="color:red">Later, in the operational development stage, service source development and management will be performed in each microservice repository under eshop-MSA-CI.</span>**

<br>

## 2. Local directory eshop-MSA-CI // remote repository eshop-each service name separated

The CI repo of the final operating form of a total of 7 microservices was created as shown below.

![](../media1/3-3-5-1.png)

<br>

---

**🗎 reference. Service Github Repository for each individual work completed microservice**

https://github.com/<< GITHUB USER NAME >>/eshop-adservice    
https://github.com/<< GITHUB USER NAME >>/eshop-backend    
https://github.com/<< GITHUB USER NAME >>/eshop-cartservice    
https://github.com/<< GITHUB USER NAME >>/eshop-currencyservice    
https://github.com/<< GITHUB USER NAME >>/eshop-frontend    
https://github.com/<< GITHUB USER NAME >>/eshop-productservice    
https://github.com/<< GITHUB USER NAME >>/eshop-recommendservice   

---

<br>

## 3. Github webhook ↔ Blue Ocean Build Trigger 연동 (Blue Ocean)


<br>

**As shown below, we will “Move” the Pipelines that are not created with the existing Blue Ocean to a separate folder.**

<br>

***

Create a folder called “Primitive Job” in the New Item > Folder menu.
> 🗎 Note. The meaning of the Pipeline designated as `Primitive Job` can be seen as Jenkins' Classic Pipeline.

<br>

![](../media1/image31-1.png)

***

<br>

As shown below, “Move” the existing Classic Pipelines to a separate folder.


![](../media1/image31-2.png)

***
![](../media1/image31-3.png)

***
![](../media1/image31-4.png)


<br>
<br>
<br>


This is the part that automates the Jenkins pipeline to run when the developer reflects changes to github main.

Additionally, it is a function to notify the slack collaboration space whether the pipeline is operating normally.

<br>

**It can be seen as a CI Pipeline configuration process that produces images to be provided to a full-scale operating environment.**

1. Set up webhooks to personal Jenkins for a total of 7 personal GitHub eshop-* services.

<br>

Within the Admin Server, you can check the endpoint of Jenkins ELB, that is, the << endpoint >> of the individual Jenkins service, using the command below.

``` bash
kubectl get service -n jenkins
```
<br>

<<endpoint>> varies from person to person. You can use `ELB DNS Name`, and if you registered the domain through Route53, you can enter it in the form `jenkins.<< DOMAIN NAME >>`.
> Note. << DOMAIN NAME >>: The name of the domain issued through the Route53 service for each individual (Hosted Zone name) <br>
> ex) mspt3.click

<br>

Enter the value below into the payload url and specify the content type as application/json.
> Jenkins' service port is `8080`, so you must add the service port (`8080`) after the endpoint.

<br>

After performing `Add webhook`, enter the payload url.<br>
`http://<< endpoint >>:8080/github-webhook/`


<br>

In the previous process, enter the normal url value and check if the green check mark (✔️) appears after `Add webhook`.

![](../media1/image34.png)

<br>

2. After connecting to Jenkins Blue Ocean, click “New Pipeline”.

![](../media1/image35.png)

<br>

3. Github > personal github username > personal GitHub eshop-* Create a total of 7 services each.

<br>

***
❗❗❗❗❗ Below is an example of <span style="color:red">eshop-adservice</span>

![](../media1/image36.png)
***

<br>

4. Set Jenkins Management > System Settings > Slack items.

<br>

[Configure System > Slack]

Workspace: <<Slack Workspace name by team>>

Default channel / member id: Enter the name of a specific Slack channel (example: C040PGGUG05) for each team.

<br>

[Jenkins Credentials Provider: Jenkins] Pop-up screen

Kind: Secret Text

Secret: <<Enter Jenkins Secret Token value for each team>>

ID: slack

Description: slack

<br>

✔ Registration and Test Procedure

![](../media1/image37-3.png)

> In `Secret`, enter the Slack Noti authentication token announced in advance in the `#Practice Textbook-Data Sharing` channel in the Slack workspace.
>
> Enter the Slack information obtained in the above process.

<br>

***

5. Add Jenkinsfile (groovy script) as follows.

additional information

- Task Confirm(Approval)

- post build action (post)

***

<br>

### ❗❗ Precautions when modifying Jenkinsfile for eshop-MSA-CI ❗❗

Since eshop-MSA and eshop-MSA-CI have different structures, the Jenkinsfile needs to be modified as follows.

Delete item
``` bash
dir('<<service name>>') {............ #### Need to be deleted
``` 

<br>

```groovy
Gradle


-Before change
       steps {
         container('gradle') {
           dir('eshop-backend') { #### needs to be deleted
             sh......Omitted...... #### Indentation needs to be improved (2 spaces deleted)
           } #### Need to be deleted
         }
-after
       steps {
         container('gradle') {
           sh......omitted.......
         }
---------------------------------------------------------------------
Kaniko

-Before change
       steps {
         container(name: 'kaniko', shell: '/busybox/sh') {
           dir('eshop-currencyservice') { #### needs to be deleted
             sh......Omitted...... #### Indentation needs to be improved (2 spaces deleted)
           } #### Need to be deleted
         }
-after
       steps {
         container(name: 'kaniko', shell: '/busybox/sh') {
           sh......omitted.......
         }
```

***

<br>

### adservice Example (Java Service)

**eshop-adservice/Jenkinsfile**

```groovy
pipeline {
  agent {
    kubernetes {
      yaml """
apiVersion: v1
kind: Pod
metadata:
  labels:
    name: gradle
spec:
  containers:
  - name: gradle
    image: gradle:6.3.0-jdk11
    command:
    - cat
    tty: true
    env:
      # Define the environment variable
      - name: CRED
        valueFrom:
          configMapKeyRef:
            name: jenkinscred
            key: ECR_CREDENTIAL_JSON
  restartPolicy: Never
"""      
    }
  }

  stages {

    stage('Approval') {
      when {
        branch 'main'
      }
      steps {
        script {
          def plan = 'adservice CI'
          input message: "Do you want to build and push?",
              parameters: [text(name: 'Plan', description: 'Please review the work', defaultValue: plan)]
        }
      } 
    }

    stage('build and push docker image') {
      when {
        branch 'main'
      }             
      steps {
        container('gradle') {
          sh 'gradle jib --no-daemon --image << ECR URI >>/<< SERVICE NAME >>:<< TAG >> -Djib.to.auth.username=AWS -Djib.to.auth.password=$CRED'  
        }
      }
      post {
        success { 
          slackSend(channel: '<<CHANNEL ID>>', color: 'good', message: 'adservice CI success')
        }
        failure {
          slackSend(channel: '<<CHANNEL ID>>', color: 'danger', message: 'adservice CI fail')
        }
      }
    }
  }
}
```

<br>

### frontend Example (Java Service)

**eshop-frontend/Jenkinsfile**

```groovy
/*
<< 변수 >> 치환 필요

<< ECR URI >>      => ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com
<< TAG >>          => ex) latest
<< CHANNEL ID >> => Change to the ID value of the ci-notice channel shared in the Slack textbook-information sharing channel.
*/
pipeline {
  agent {
    kubernetes {
      yaml """
kind: Pod
spec:
  containers:
  - name: kaniko
    image: gcr.io/kaniko-project/executor:debug
    imagePullPolicy: Always
    command:
    - /busybox/cat
    tty: true
"""
    }
  }
  environment {
    IMAGE_REGISTRY = "<< ECR URI >>"
  }
  stages {
    
    stage('Approval') {
      when {
        branch 'main'
      }
      steps {
        script {
          def plan = 'frontend CI'
          input message: "Do you want to build and push?",
              parameters: [text(name: 'Plan', description: 'Please review the work', defaultValue: plan)]
        }
      } 
    }
        
    stage('Build with Kaniko') {
      when {
        branch 'main'
      }
      steps {
        container(name: 'kaniko', shell: '/busybox/sh') {
          
          sh '''#!/busybox/sh
          /kaniko/executor \
          --git branch=main \
          --context=. \
          --destination=${IMAGE_REGISTRY}/eshop-frontend:<< TAG >>
          '''

        }
      }
      post {
        success { 
          slackSend(channel: '<< CHANNEL ID >>', color: 'good', message: 'frontend CI success')
        }
        failure {
          slackSend(channel: '<< CHANNEL ID >>', color: 'danger', message: 'frontend CI fail')
        }
      }
    }
  }
}
```

<br>

6. Push the modified Jenkinsfile to the github main branch.

<br>

7. After pushing, check whether the following Approval process appears in the pipeline.

![](../media1/image38.png)

<br>

8. In step 7, click ‘Proceed’ and after CI is performed normally, you can actually log into Slack.
Check whether the notification arrived properly.

![](../media1/image39.png)

<br>

9. As a result, the CI Pipeline for all operational types was configured as follows.

![](../media1/image40.png)

<br>

10. Progress to date (red box completed)

![](../media1/image41.png)

<br>


**😃 Challenge Completed!!!**


<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
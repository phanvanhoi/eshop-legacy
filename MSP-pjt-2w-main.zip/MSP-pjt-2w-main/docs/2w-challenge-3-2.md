## Current status of the program

<br>

## 🤔 Challenge 3-2

### Topic: K8s HPA

<br>

📌 [Additional notes to use during challenges]

📌 [eshop FQDN DOMAIN information (challenge)]<br>
***FQDN value of individual eshop service --- ex) eshop.mspt3.click***<br>
➕ << DOMAIN >> : <br>

<br>

## Expand/decrease the eshop app running in Service EKS Cluster with replicaset HPA

<br>

## Practice Objectives
- After installing metrics-server, build an environment where HPA can be applied.
- Understand the mechanism by which HPA operates by setting the HPA threshold and experiencing Scale Out / Scale In by loading the Pod.

<br>

#### Horizontal Pod Autoscaler

<br>

The Horizontal Pod Autoscaler measures CPU usage (or [custom metrics](https://git.k8s.io/community/contributors/design-proposals/instrumentation/custom-metrics-api.md), or other application-supported metrics). Observe and automatically scale the number of pods in ReplicationController, Deployment, ReplicaSet, or StatefulSet.

<br>

---

🗎 Note. Horizontal Pod Autoscaler does not apply to objects that cannot be resized (e.g. DaemonSets).

<br>

For more information, refer to the [Horizontal Pod Autoscaler](https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale/) document.

![](../media2/image41.png)

source
: <https://d33wubrfki0l68.cloudfront.net/4fe1ef7265a93f5f564bd3fbb0269ebd10b73b4e/1775d/images/docs/horizontal-pod-autoscaler.svg>

---

<br>

### Apply Horizontal pod autoscaler in Kubernetes

- [Link](https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/#%EB%AA%85%EC%8B%9C%EC%A0%81 %EC%9C%BC%EB%A1%9C-%EC%98%A4%ED%86%A0%EC%8A%A4%EC%BC%80%EC%9D%BC%EB%9F%AC- %EB%A7%8C%EB%93%A4%EA%B8%B0) to declare the HorizontalPodAutoscaler resource.

- Configure the autoscaler based on CPU Utilization.

- Configure core service instances to auto-scaling without configuring non-core services.

![](../media2/image42.png)

<br>

Add HorizontalPodAutoscaler.
metadata.name and spec.scaleTargetRef.name are modified and applied to suit each service.

<br>

The HorizontalPodAutoscaler performs scale out and scale in with a goal of 25% CPU usage between a minimum of 2 replicas and a maximum of 10 replicas.

<br>

This exercise will be conducted using the two services below.

- eshop-frontend

- eshop-productservice

※ It is recommended to make a TLS call via https, but due to the nature of the load, TLS calls are not supported, so the call is replaced with http.

<br>

<br>

### TC1: eshop-frontend

The eshop-frontend module can be seen as the first entry point for service users and serves to display the main screen.

Use a load machine to call the FQDN of each individual eshop several times as shown below, and perform load balancing practice by expanding Pod resources as traffic increases.

ex) http://eshop.mspt3.click

<br>

1. Add HPA to the eshop-frontend service. In this lab, it is added to hpa.yaml.

**eshop-PaC/eshop/charts/eshop-frontend/templates/hpa.yaml**
```yaml
apiVersion: autoscaling/v1
kind: HorizontalPodAutoscaler
metadata:
  name: eshop-frontend
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: eshop-frontend
  minReplicas: 2
  maxReplicas: 10
  targetCPUUtilizationPercentage: 25
```

<br>

2. Push the HPA applied code to the Service Repository and merge it into the main branch through PR.

<br>

3. Connect to Argocd, check the Outofsync status, and perform the Sync action.

<br>

4. When Sync is completed, you can see the two Pods specified as minimum floating in the ReplicaSet of HPA and eshop-frontend as shown below.

<br>

![](../media2/image43.png)

<br>

![](../media2/image44.png)

<br>

5. To test the operation of the eshop-frontend HPA, check whether the HPA is currently created properly in the Service EKS Cluster on the Admin Server.

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get hpa -n eshop
```

<br>

The status of Pods in the eshop application configured to date, as examined through the 'kubectl get pods -n eshop' command, will be similar to the following.

<br>

✔ **(Example of execution code/result)**
```bash
eshop-adservice-55bf84db59-xf29l 2/2 Running 0 6h50m
eshop-backend-76fb5c557-vqq2p 2/2 Running 0 6h50m
eshop-cartservice-5978f75bd7-d8k76 2/2 Running 0 6h50m
eshop-coordinating-only-55dcbc8f5c-lmd85 2/2 Running 0 6h50m
eshop-currencyservice-7dfbcbfdd5-w5lzz 2/2 Running 0 6h50m
eshop-elasticsearch-data-0 1/1 Running 0 6h50m
eshop-elasticsearch-master-0 1/1 Running 0 6h50m
eshop-frontend-5fb85f4cf5-pwzm5 2/2 Running 0 6h15m
eshop-frontend-5fb85f4cf5-sbzn5 2/2 Running 0 6h16m
eshop-grafana-f9949cd8c-qpzq8 2/2 Running 0 6h50m
eshop-jaeger-agent-95g68 2/2 Running 0 6h50m
eshop-jaeger-agent-t2frb 2/2 Running 0 6h50m
eshop-jaeger-agent-vhftg 2/2 Running 0 6h50m
eshop-jaeger-collector-548cbfdbd8-kdd7k 2/2 Running 4 (6h49m ago) 6h50m
eshop-jaeger-query-84c44b5bc7-zk2r9 3/3 Running 4 (6h48m ago) 6h50m
eshop-kibana-6cd5f5ff44-jrj7z 2/2 Running 0 6h50m
eshop-kube-state-metrics-57b5c444d4-6t46n 2/2 Running 2 (6h50m ago)
6h50m
eshop-metrics-server-6b955f5cd5-hfwlr 2/2 Running 0 6h50m
eshop-productservice-67c59f7bd5-m66g4 2/2 Running 1 (6h49m ago) 6h50m
eshop-prometheus-alertmanager-8ddd4f69-qxg74 2/2 Running 0 6h50m
eshop-prometheus-node-exporter-2dzpc 1/1 Running 0 6h50m
eshop-prometheus-node-exporter-cg2hl 1/1 Running 0 6h50m
eshop-prometheus-node-exporter-zrvsk 1/1 Running 0 6h50m
eshop-prometheus-pushgateway-6b8f86df97-ktkcx 1/1 Running 0 6h50m
eshop-prometheus-server-75d9b4b5cf-jm9h5 2/2 Running 0 6h50m
eshop-recommendservice-8fd864df9-9knzj 2/2 Running 0 6h50m
kiali-585777667c-fml8g 1/1 Running 0 6h50m
mongodb-0 2/2 Running 0 6h50m
postgres-888fdb474-4bvml 2/2 Running 0 6h50m
rabbitmq-649dcc5d7f-fctff 2/2 Running 0 6h50m
redis-879d7548c-lgz5j 2/2 Running 0 6h50m
```

<br>

6. After confirming that the HPA is created normally and that there are two basic replica sets, create two pods that generate load within the cluster.

   1) load-generator-1

   2) load-generator-2

<br>

**load-generator-1**

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl run -i --tty load-generator-1 --rm --image=busybox --restart=Never -- /bin/sh -c "while sleep 0.01; do wget -q -O- http://< < DOMAIN >>; done"
```
> << DOMAIN >> value must be replaced with the FQDN domain of the personal eshop service.

<br>

After creating the first load generator (load-generator-1), open a new Admin Server session window and create the second load generator (load-generator-2) as shown below.

<br>
<br>

**load-generator-2**

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl run -i --tty load-generator-2 --rm --image=busybox --restart=Never -- /bin/sh -c "while sleep 0.01; do wget -q -O- http://< < DOMAIN >>; done"
```
> << DOMAIN >> value must be replaced with the FQDN domain of the personal eshop service.

<br>

7. Shortly after the load starts, the Pod's CPU utilization threshold of 25% is reached, and you can see that the number of replicas has increased to three as shown below.

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get hpa -n eshop
```

<br>

![](../media2/image45.png)

![](../media2/image46.png)

<br>

Through Argocd, you can also see that the rs of eshop-frontend has increased to 3, so the load is distributed to more replicas.

<br>

![](../media2/image47.png)

<br>

8. Stop loading (CTRL + C) and delete.

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl delete pod load-generator-1
```

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl delete pod load-generator-2
```

<br>

If you wait about 10 minutes after stopping the load, you can see that the minimum replica number has decreased to 2.

![](../media2/image48.png)

<br>

### TC2: eshop-productservice

The eshop-productservice module is a service that responds to the view-level service with overall product data or specific product data.

Therefore, you can load it by calling the URL below.

http://eshop.mspt3.click/api/products

It is the same as the process performed in eshop-frontend above, and you can use the above call when creating a loader.

Let’s perform the same exercise for eshop-productservice.

<br>

9. Organize resources after completing testing

Step 1) After executing TC1 and TC2, comment out the hpa definition of each service and remove the k8s resource.

<br>

[TC1]
eshop-PaC/eshop/charts/eshop-frontend/templates/hpa.yaml

```yaml
#apiVersion: autoscaling/v1
#kind: HorizontalPodAutoscaler
#metadata:
# name: eshop-frontend
#spec:
# scaleTargetRef:
# apiVersion: apps/v1
# kind: Deployment
# name: eshop-frontend
#minReplicas: 2
#maxReplicas: 10
# targetCPUUtilizationPercentage: 25
```

<br>
[TC2]
eshop-PaC/eshop/charts/eshop-productservice/templates/hpa.yaml

```yaml
#apiVersion: autoscaling/v1
#kind: HorizontalPodAutoscaler
#metadata:
#  name: eshop-productservice
#spec:
#  scaleTargetRef:
#    apiVersion: apps/v1
#    kind: Deployment
#    name: eshop-productservice
#  minReplicas: 2
#  maxReplicas: 10
#  targetCPUUtilizationPercentage: 25
```

<br>
Step 2) Each manifest change is reflected in the main branch on Github, and when `Refresh` is performed in Argocd, `Prune` is displayed as a necessary item.

At this time, the Argocd `Sync` task is performed with the `Prune` checkbox checked.

<br>

Step 3) Additionally, restart each deployment to restore the replica set.

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl -n eshop rollout restart deployment eshop-frontend
```
> TC1 original uniform

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl -n eshop rollout restart deployment eshop-productservice
```
> TC2 original uniform

<br>

**😃 Challenge Completed!!!**

<br>

---


<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
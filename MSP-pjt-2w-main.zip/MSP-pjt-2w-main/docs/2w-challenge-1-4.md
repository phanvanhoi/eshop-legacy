## Current status of the program

<br>

## 🤔 Challenge 1-4

### Topic: CI Pipeline

<br>

📌 [Additional notes to use during challenges]

📌 [Slack setting information (challenge)]<br>
➕ workspace name (`<< WORKSPACE >>`) : <br>
➕ `#ci-notice` channel id (`<< CHANNEL ID >>`) : <br>
➕ slack token (`<< SLACK TOKEN >>`): <br>
➕ member ID (`<< MEMBER ID >>`): <br>

<br>

***

📌 Check Slack Workspace name - workspace name ( `<< WORKSPACE >>` )

![](../media1/image37-1.png)

> You can check the Sub Domain of the workspace by clicking the workspace name in the upper left corner of the Slack workspace.

<br>

📌 Check CI result Noti channel id - `#ci-notice` channel id ( `<< CHANNEL ID >>` )

![](../media1/image37-2.png)

> If you right-click the `#ci-notice` channel among the channels in the Slack workspace and click `View Channel Details`, the channel ID will appear at the bottom. Be sure to record the value.
> This value is the actual value of the `<< CHANNEL ID >>` variable that needs to be replaced, so record it separately.

<br>

📌 Check individual member ID within the workspace - Individual ID within the workspace (`<< MEMBER ID >>`)

![](../media1/copy_member_id.png)

> If you click on your personal profile in the Slack workspace, click `⫶`, and then click `Copy member ID`, the individual’s member ID will be copied to the clipboard. Be sure to record that value. (The Slack workspace of the T3 actual project and the Slack workspace of the T3 development process are different, so it is not the same as the member ID used at that time)

<br>

***

<br>

Hipster Shop (eshop) is an online shopping mall where you can purchase a variety of products.

The management of Hipster shop (eshop) has moved the service to **public cloud** and **container-based microservice** and is operating it somewhat stably.

During the CI process of the service, we will apply a method of sending a Noti to the Slack workspace so that relevant development team members can receive notifications of the CI results.

Accordingly, the operation team internally reviewed adding the ‘Slack Noti’ function to the CI Pipeline.

Let’s ‘build’ the function according to the requirements.

<br>
<br>


## solution

<br>

<details>
<summary>[Performance 1 - Expand👇] Proceed with Slack-related settings in Jenkins. </summary>

<br>

### Set Jenkins Management > System Settings > Slack items.


[Configure System > Slack]

Workspace : `<< Workspace >>`

Default channel / member id: `<< CHANNEL ID >>` Enter the name of a specific Slack channel (example: C040PGGUG05) for each team.

<br>

[Jenkins Credentials Provider: Jenkins] Pop-up screen

Kind: Secret Text

Secret: `<< SLACK TOKEN >>`

ID: slack

Description: slack

<br>

✔ Registration and Test Procedure

![](../media1/image37-3.png)

> In `Secret`, enter the Slack Noti authentication token (`<< SLACK TOKEN >>`) announced in advance in the `#PracticeTextbook-Material Sharing` channel in the Slack workspace.
>
> Enter the Slack information obtained in the above process.

<br>

***

<br>

</details>


<br>

<details>
<summary>[Execution 2 - Expand👇] Modify the Jenkinsfile of eshop-MSA child eshop-* microservices </summary>

<br>

reference. Variables composed of the form `<< >>` are replaced with individual values.

Values that need to be replaced
- << ECR URI >>
- << TAG >>
- << CHANNEL ID >>
- << MEMBER ID >>

📌Tips. You can check the variables to be changed by opening the search window with ctrl + f in VSCode and searching for the `<<` symbol.

❗❗ Precautions. You must replace the value up to the `>>` symbol.

<br>

Example) eshop-adservice (Gradle Build)
eshop-MSA/eshop-adservice/Jenkinsfile
```groovy
/*
<< 변수 >> 치환 필요

<< ECR URI >>      => ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com
<< TAG >>          => ex) latest
<< CHANNEL ID >>   => Slack 교재-정보공유 채널에 공유된 ci-notice 채널의 ID 값으로 변경
<< MEMBER ID >>       => Slack 워크스페이스 내 개인별 멤버 ID 값으로 변경
*/
pipeline {
  agent {
    kubernetes {
      yaml """
apiVersion: v1
kind: Pod
metadata:
  labels:
    name: gradle
spec:
  containers:
  - name: gradle
    image: gradle:6.3.0-jdk11
    command:
    - cat
    tty: true
    env:
      # Define the environment variable
      - name: CRED
        valueFrom:
          configMapKeyRef:
            name: jenkinscred
            key: ECR_CREDENTIAL_JSON
  restartPolicy: Never
"""      
    }
  }

  stages {
    stage('build and push docker image') {
                  
      steps {
        container('gradle') {
          dir('eshop-adservice') {
            sh 'gradle jib --no-daemon --image << ECR URI >>/eshop-adservice:<< TAG >> -Djib.to.auth.username=AWS -Djib.to.auth.password=$CRED'
          }
        }
      }

      post {
        success { 
          slackSend(channel: '<< CHANNEL ID >>', color: 'good', message: "(Job : ${env.JOB_NAME} - Build Number : ${env.BUILD_NUMBER}) CI success - from <@<< MEMBER ID >>>")
        }
        failure {
          slackSend(channel: '<< CHANNEL ID >>', color: 'danger', message: "(Job : ${env.JOB_NAME} - Build Number : ${env.BUILD_NUMBER}) CI fail - from <@<< MEMBER ID >>>")
        }
      }
    }
  }
}
```

<br>


예시) eshop-frontend (Kaniko Build)

eshop-MSA/eshop-frontend/Jenkinsfile
```groovy
/*
<< 변수 >> 치환 필요

<< ECR URI >>      => ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com
<< TAG >>          => ex) latest
<< CHANNEL ID >>   => Slack 교재-정보공유 채널에 공유된 ci-notice 채널의 ID 값으로 변경
<< MEMBER ID >>       => Slack 워크스페이스 내 개인별 멤버 ID 값으로 변경
*/
pipeline {
  agent {
    kubernetes {
      yaml """
kind: Pod
spec:
  containers:
  - name: kaniko
    image: gcr.io/kaniko-project/executor:debug
    imagePullPolicy: Always
    command:
    - /busybox/cat
    tty: true
"""
    }
  }
  environment {
    IMAGE_REGISTRY = "<< ECR URI >>"
  }
  stages {
    stage('Build with Kaniko') {
      steps {
        container(name: 'kaniko', shell: '/busybox/sh') {
          dir('eshop-frontend') {
            sh '''#!/busybox/sh
            /kaniko/executor \
            --git branch=main \
            --context=. \
            --destination=${IMAGE_REGISTRY}/eshop-frontend:latest
            '''   
          }
        }
      }
      post {
        success { 
          slackSend(channel: '<< CHANNEL ID >>', color: 'good', message: "(Job : ${env.JOB_NAME} - Build Number : ${env.BUILD_NUMBER}) CI success - from <@<< MEMBER ID >>>")
        }
        failure {
          slackSend(channel: '<< CHANNEL ID >>', color: 'danger', message: "(Job : ${env.JOB_NAME} - Build Number : ${env.BUILD_NUMBER}) CI fail - from <@<< MEMBER ID >>>")
        }
      }
    }
  }
}
```

</details>


<br>



## Check results - After performing Jenkins CI Pipeline, receive CI result Slack Notification

<br>

`${env.JOB_NAME}` and `${env.BUILD_NUMBER}` are environment variables that can be used in Jenkins Job without separate declaration.

<br>
<br>

[Pipeline execution]<br>
After performing all of the solution methods, connect to Jenkins configured by the individual, click the configured pipeline, perform the Build task, and check whether Noti comes properly.

![](../media1/jenkins_pipeline.png)


<br>

[Check pipeline execution result pass or fail]<br>
Check whether the notice is normally delivered to the Slack Channel depending on whether the build task is `Pass` or `Fail`.

![](../media1/jenkins_pipeline_complete.png)

<br>

[Check the result]
![](../media1/jenkins_slack_noti.png)


<br>


[Additional tasks worth doing]<br>
Challenge 1-3 (`Separation of Repo for each microservice and integration with Blue Ocean CI Pipeline (part that automates CI Pipeline Trigger)`) Apply this to the Jenkins file that separates the Source Repo for each microservice.

<br>

**😃 Challenge Completed!!!**

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
## Current status of the program

<br>

## 🤔 Challenge 3-3

### Topic: Observability

<br>

📌 [Additional notes to use during challenges]

📌 [eshop FQDN DOMAIN information (challenge)]<br>
***FQDN value of individual eshop service --- ex) eshop.mspt3.click***<br>
➕ << DOMAIN >> : <br>

<br>

## Applying AWS CloudWatch Container Insights to Service EKS Cluster

<br>
<br>

![](../media2/image40.png)

## Practice Objectives
- Monitor EKS Cluster using AWS CloudWatch and Container Insights.
- Use AWS SNS Topic to set operational alarms and conduct reception tests.

<br>

---

<br>

AWS CloudWatch is a monitoring service that can be used on its own. Since the AWS EKS environment is an operational environment, it is necessary to review a specialized monitoring system.

<br>

It is specialized for AWS EKS and allows you to configure dashboards and set alarms.

In this lab, you will practice dashboard monitoring and alarm settings.

<br>

Introduction to Container Insight
<https://docs.aws.amazon.com/ko_kr/AmazonCloudWatch/latest/monitoring/ContainerInsights.html>

<br>

Container Insight Prerequisites (IAM Role)
<https://docs.aws.amazon.com/ko_kr/AmazonCloudWatch/latest/monitoring/Container-Insights-prerequisites.html>

<br>

Use Container Insight Fluent Bit
<https://docs.aws.amazon.com/ko_kr/AmazonCloudWatch/latest/monitoring/Container-Insights-setup-EKS-quickstart.html>

<br>

**One. Add relevant Permission (Policy) to IAM Role in Service EKS Cluster Node Group**

If you refer to the prerequisite link above, you can see that a specific policy is required.

<br>

Insert the CloudWatchAgentServerPolicy related code into the Service EKS Cluster IaC code and run it.

<br>

**eks-worker-nodes.tf**

< WSL environment >
```bash
(...skip...)
resource "aws_iam_role_policy_attachment" "terra-node-CloudWatchAgentServerPolicy" {
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy"
  role       = aws_iam_role.terra-node.name
}
(...skip...)
depends_on = [
    aws_iam_role_policy_attachment.terra-node-AmazonEKSWorkerNodePolicy,
    aws_iam_role_policy_attachment.terra-node-AmazonEKS_CNI_Policy,
    aws_iam_role_policy_attachment.terra-node-AmazonEC2ContainerRegistryReadOnly,
    aws_iam_role_policy_attachment.terra-node-CloudWatchAgentServerPolicy   ]
}
```

<br>

**2. In this lab, we will install CloudWatch Agent using FluentBit to collect metrics.**

<br>

Install CloudWatch Agent by running it on the Admin Server as shown below.

<br>

**※ Change the ClusterName and RegionName below to suit your environment and run the command.**

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
ClusterName=eshop-service-eks-cluster
RegionName=us-west-2
FluentBitHttpPort='2020'
FluentBitReadFromHead='Off'
[[ ${FluentBitReadFromHead} = 'On' ]] && FluentBitReadFromTail='Off'|| FluentBitReadFromTail='On'
[[ -z ${FluentBitHttpPort} ]] && FluentBitHttpServer='Off' || FluentBitHttpServer='On'
curl https://raw.githubusercontent.com/aws-samples/amazon-cloudwatch-container-insights/latest/k8s-deployment-manifest-templates/deployment-mode/daemonset/container-insights-monitoring/quickstart/cwagent-fluent-bit-quickstart.yaml | sed 's/{{cluster_name}}/'${ClusterName}'/;s/{{region_name}}/'${RegionName}'/;s/{{http_server_toggle}}/"'${FluentBitHttpServer}'"/;s/{{http_server_port}}/"'${FluentBitHttpPort}'"/;s/{{read_from_head}}/"'${FluentBitReadFromHead}'"/;s/{{read_from_tail}}/"'${FluentBitReadFromTail}'"/' | kubectl apply -f -
```

<br>


**3. If the Worker Node is currently composed of t3.large

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get pods --all-namespaces
```

<br>


![](../media2/image27.png)

<br>

Check the status of the pending Pod in detail.

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl describe pod fluent-bit-wch4d -n amazon-cloudwatch
```

<br>


![](../media2/image28.png)

<br>

As experienced earlier when installing the ElasticSearch Helm Chart, installing an additional DaemonSet-type Agent while the application is heavy can result in insufficient resources.

<br>

**First, stop the installation with the delete command.**

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
curl https://raw.githubusercontent.com/aws-samples/amazon-cloudwatch-container-insights/latest/k8s-deployment-manifest-templates/deployment-mode/daemonset/container-insights-monitoring/quickstart/cwagent-fluent -bit-quickstart.yaml | sed 's/{{cluster_name}}/'${ClusterName}'/;s/{{region_name}}/'${LogRegion}'/;s/{{http_server_toggle}}/"'${FluentBitHttpServer}'" /;s/{{http_server_port}}/"'${FluentBitHttpPort}'"/;s/{{read_from_head}}/"'${FluentBitReadFromHead}'"/;s/{{read_from_tail}}/"'${ FluentBitReadFromTail}'"/' | kubectl delete -f -
```

<br>

**4. Scale up worker nodes of Service EKS Cluster through Service IaC Pipeline. (t3.large => t3.xlarge)**

<br>

**5. Proceed with installation again after scale up.**

**※ Change the ClusterName and RegionName below to suit your environment and run the command.**

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
ClusterName=eshop-service-eks-cluster
RegionName=us-west-2
FluentBitHttpPort='2020'
FluentBitReadFromHead='Off'
[[ ${FluentBitReadFromHead} = 'On' ]] && FluentBitReadFromTail='Off'|| FluentBitReadFromTail='On'
[[ -z ${FluentBitHttpPort} ]] && FluentBitHttpServer='Off' || FluentBitHttpServer='On'
curl https://raw.githubusercontent.com/aws-samples/amazon-cloudwatch-container-insights/latest/k8s-deployment-manifest-templates/deployment-mode/daemonset/container-insights-monitoring/quickstart/cwagent-fluent -bit-quickstart.yaml | sed 's/{{cluster_name}}/'${ClusterName}'/;s/{{region_name}}/'${RegionName}'/;s/{{http_server_toggle}}/"'${FluentBitHttpServer}'" /;s/{{http_server_port}}/"'${FluentBitHttpPort}'"/;s/{{read_from_head}}/"'${FluentBitReadFromHead}'"/;s/{{read_from_tail}}/"'${ FluentBitReadFromTail}'"/' | kubectl apply -f -
```

<br>

**6. After installation is complete, check that fluentbit pods are running normally at 1/1.**

<br>

**7. Now, access Container Insights in AWS > CloudWatch.**

Monitoring is possible in various forms such as Performance Monitoring and Container Map as shown below.

![](../media2/image29.png)

![](../media2/image30.png)

<br>

**8. Next is the final step of monitoring: sending an alarm to the operator.**

<br>

First, connect to the AWS SNS service.

Create a topic in the SNS service. Topic name is random

<br>

![](../media2/image31.png)

<br>

After adding an email subscription, proceed with verification using your personal email.

<br>

When verification is completed, the status changes to confirmed.

<br>

![](../media2/image32.png)

<br>

**9. In order to raise an alarm on CPU metrics, increase the CPU utilization by increasing the load on eshop-productservice, and set an alarm with the CPU utilization of the eshop-productservice pod as the threshold.**

<br>

> << DOMAIN >> value must be replaced with the FQDN domain of the personal eshop service. Change to a personal service domain and generate a total of 3 loaders.

Connect to the Admin Server and execute the commands below in order.

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl run -i --tty load-generator-1 --rm --image=busybox --restart=Never -- /bin/sh -c "while sleep 0.01; do wget -q -O- http://< < DOMAIN >>/api/products; done"
```
> << DOMAIN >> value must be replaced with the FQDN domain of the personal eshop service.

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl run -i --tty load-generator-2 --rm --image=busybox --restart=Never -- /bin/sh -c "while sleep 0.01; do wget -q -O- http://< < DOMAIN >>/api/products; done"
```
> << DOMAIN >> value must be replaced with the FQDN domain of the personal eshop service.

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl run -i --tty load-generator-3 --rm --image=busybox --restart=Never -- /bin/sh -c "while sleep 0.01; do wget -q -O- http://< < DOMAIN >>/api/products; done"
```
> << DOMAIN >> value must be replaced with the FQDN domain of the personal eshop service.

<br>

**10. This is the change in the metric indicator of the productservice pod in a situation where load is incoming.**

![](../media2/image33.png)

<br>

**11. For testing, set the alarm threshold of eshop-productservice to 5% CPU usage.**

<br>

Proceed with settings at AWS CloudWatch > Alarms.

<br>

Enter All Alarms and press “create alarm”.

<br>

When you click "ClusterName, Namespace, PodName" in Container Insight, a search window will pop up, and enter "eshop-productservice" in the search box.

<br>

For Metric, select “pod_cpu_utilization” and proceed with detailed settings as follows. (For testing, set the threshold as small as 5%)

<br>

![](../media2/image34.png)

<br>

Next, proceed with alarm settings.

In Alarm mode, select the SNS Topic you set up earlier for notifications (personal email notification).

<br>

![](../media2/image35.png)

Enter the alarm name and description as follows and move on to the next step.

<br>

![](../media2/image36.png)

Finally, click Create Alarm.

<br>

![](../media2/image37.png)

<br>

**12. Since there is already a load on eshop-productservice and the CPU usage rate has exceeded 5%, we confirm that an email notification is sent soon after the alarm is created.**

![](../media2/image38.png)

![](../media2/image39.png)

<br>

**13. When the exercise is completed, delete CloudWatch Agent from the Admin Server as shown below.**


```
curl https://raw.githubusercontent.com/aws-samples/amazon-cloudwatch-container-insights/latest/k8s-deployment-manifest-templates/deployment-mode/daemonset/container-insights-monitoring/quickstart/cwagent-fluent -bit-quickstart.yaml | sed 's/{{cluster_name}}/'${ClusterName}'/;s/{{region_name}}/'${LogRegion}'/;s/{{http_server_toggle}}/"'${FluentBitHttpServer}'" /;s/{{http_server_port}}/"'${FluentBitHttpPort}'"/;s/{{read_from_head}}/"'${FluentBitReadFromHead}'"/;s/{{read_from_tail}}/"'${ FluentBitReadFromTail}'"/' | kubectl delete -f -
```

<br>


❗❗ **If the CPU threshold does not reach 5% during the above process, try setting the threshold to a lower value such as 2% and setting an alarm. (Try reducing the period from 5 minutes to 1 minute. .)** ❗❗

<br>

After that, you can check if there is an email alert.

<br>

**14. After completing the exercise, scale down the Service EKS Cluster Worker Node again through the IaC Pipeline. (t3.xlarge => t3.large)`**


<br>

**😃 Challenge Completed!!!**

<br>

---


<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
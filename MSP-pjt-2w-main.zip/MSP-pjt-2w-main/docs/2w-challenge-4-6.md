## Current status of the program

<br>

## 🤔 Challenge 4-6

### Topic: Deployment

<br>

## Development of new MicroService and deployment of operating system after containerization

<br>

Hipster Shop (eshop) is an online shopping mall where you can purchase a variety of products.

The management of Hipster shop (eshop) has moved the service to **public cloud** and **container-based microservice** and is operating it somewhat stably.

During operation, we received a request from a customer to add a ‘review’ function for the product.

Let’s ‘develop’ and ‘deploy’ the function according to the customer’s needs.

---

🗎 Note. In this process, you are not developing the actual review service, but rather experiencing the operation and development of the service based on the completed development version, so please use the completed product according to the solution below.

You can follow the solution procedure below step by step, or use the completed PaC for this challenge provided through the path below.

<s3://t2hubintern/chal_4-6_eshop-PaC.tar.gz>

---

<br>
<br>


## solution

<br>

<details>
<summary>[Performance 1 - Expand👇] Development and image creation of frontend and reviewservice</summary>

<br>

Please refer to the source where the development of the review service has been completed.

- eshop-reviewservice
> Completed development of review microservice using review API <br>
> Framework: Python Flask <br>
> <s3://t2hubintern/eshop-MSA-review.tar.gz> <br>
>
> Public ECR URI <br>
> 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-reviewservice:latest

- eshop-frontend
> Completed development of frontend microservice with review UI <br>
> Framework: Vue.js <br>
> <s3://t2hubintern/eshop-MSA-frontend-review.tar.gz> <br>
>
> Public ECR URI <br>
> 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-frontend:review

<br>

The above two sources are for simple reference only, and when performing actual challenges, use the completed image provided in the public ECR.

<br>

Option) As a challenge, unlike the guide, you can build and distribute the image by building a CI/CD pipeline using the completed source without using the public ECR.

- Build and push image with eshop-frontend => review tag (Jenkins CI Pipeline)
- Build and push image with eshop-review => latest tag (Jenkins CI Pipeline)

<br>

</details>


<br>


<details>
<summary>[Performance 2 - Expand👇] Set up Istio Virtual Service</summary>

<br>

Add `uri` of review service to the eshop-related Virtual Service definition as shown below. (### Additional parts ###)

**eshop-PaC/eshop/charts/istio-vs/templates/eshop-vs.yaml**

```yaml
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: eshop-vs
spec:
  hosts:
  - "*"
  gateways:
  - ingress-gateway
  http:
  - match:
    - uri:
        prefix: /api/carts
    route:
    - destination:
        host: eshop-cartservice
        port:
          number: 8091
  - match:
    - uri:
        prefix: /api/products
    route:
    - destination:
        host: eshop-productservice
        port:
          number: 8092
  - match:
    - uri:
        prefix: /api/recommends
    route:
    - destination:
        host: eshop-recommendservice
        port:
          number: 8093
  - match:
    - uri:
        prefix: /api/currencies
    route:
    - destination:
        host: eshop-currencyservice
        port:
          number: 8094
  - match:
    - uri:
        prefix: /api/ads
    route:
    - destination:
        host: eshop-adservice
        port:
          number: 8095
  ### 추가 부분 ###
  - match:
    - uri:
        prefix: /api/reviews
    route:
    - destination:
        host: eshop-reviewservice
        port:
          number: 8096
  ### 추가 부분 ###
  - match:
    - uri:
        prefix: /api
    route:
    - destination:
        host: eshop-backend
        port:
          number: 8090
  - match:
    - uri:
        prefix: /static
    route:
    - destination:
        host: eshop-backend
        port:
          number: 8090         
  - match:
    - uri:
        exact: /
    - uri:
        exact: /favicon.ico
    - uri:
        prefix: /css
    - uri:
        prefix: /js
    ### 추가 부분 ###
    - uri:
        prefix: /img
    ### 추가 부분 ###
    route:
    - destination:
        host: eshop-frontend
        port:
          number: 8080
```

</details>

<br>

<details>
<summary>[Performance 3 - Expand👇] Create review service sub helm chart</summary>

<br>

**eshop-PaC/eshop/charts/eshop-reviewservice/templates/deployment.yaml**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-reviewservice
spec:
  selector:
    matchLabels:
      app: eshop-reviewservice
  template:
    metadata:
      labels:
        app: eshop-reviewservice
    spec:
      terminationGracePeriodSeconds: 5
      containers:
      - name: eshop-reviewservice
        image: {{ .Values.global.images.reviewservice }}
        ports:
        - containerPort: 8096
        env:
        - name: PORT
          value: "8096"
        - name: MONGO_URI
          value: "mongodb://admin:password@mongodb"
        - name: INIT_DATA
          value: "true"
        resources:
          requests:
            cpu: 100m
            memory: 64Mi
          limits:
            cpu: 200m
            memory: 128Mi
```
**eshop-PaC/eshop/charts/eshop-reviewservice/templates/service.yaml**

```yaml
apiVersion: v1
kind: Service
metadata:
  name: eshop-reviewservice
spec:
  type: ClusterIP
  selector:
    app: eshop-reviewservice
  ports:
  - name: api
    port: 8096
    targetPort: 8096
```

**eshop-PaC/eshop/charts/eshop-reviewservice/Chart.yaml**

```yaml
apiVersion: v2
name: eshop-reviewservice
description: A Helm chart for Kubernetes
type: application
version: 2.0.0
appVersion: "2.4.0"
```

**eshop-PaC/eshop/charts/eshop-reviewservice/values.yaml**
```yaml
#빈 파일
```

</details>

<br>

<details>
<summary>[Performance 4 - Expand👇] Set the value of the eshop root chart as a review image tag</summary>

<br>

**eshop-PaC/eshop/values.yaml**

```yaml
## << 변수 >> 치환 필요

## << ECR URI >>      : ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com
## << SERVICE NAME >> : ex) eshop-backend
## << TAG >>          : ex) latest

global:
  rabbitmq:
    # << Amazon MQ AMQP Endpoint >>값 예시) amqps://b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com:5671 값 중 프로토콜, 포트값을 뺀 값이 필요한 값 => b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com
    #host: << Amazon MQ AMQP Endpoint >>      # Amazon MQ 도전과제 시 주석해제 후 << Amazon MQ Web Console Endpoint >>에 값 치환
    host: rabbitmq                                   # Amazon MQ 도전과제 시 주석처리
  app:
    name: eshop
    namespace: eshop
  tls:
    enabled: false          # True to enable TLS (set by deploy-all.ps1)
    issuer: ""
  ingress:                                              # ingress related settings
    entries:
      eshop-frontend: eshop-frontend
      eshop-currencyservice: eshop-currencyservice
      eshop-productservice: eshop-productservice
      eshop-recommendservice: eshop-recommendservice
      eshop-adservice: eshop-adservice
      eshop-backend: eshop-backend
      eshop-cartservice: eshop-cartservice
      # spa: ""                                           # ingress entry for web spa
  svc:
    eshop-frontend: eshop-frontend
    eshop-currencyservice: eshop-currencyservice
    eshop-productservice: eshop-productservice
    eshop-recommendservice: eshop-recommendservice
    eshop-adservice: eshop-adservice
    eshop-backend: eshop-backend
    eshop-cartservice: eshop-cartservice
    # spa: webspa                                       # service name for web spa
  images:
    (...생략...)
    ### 추가 부분 ###
    frontend: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-frontend:review
    reviewservice: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-reviewservice:latest
    ### 추가 부분 ###
    (...생략...)
  appinsights:
    key: ""               # App insights to use
  k8s:                      # inf.k8s defines Kubernetes cluster global config
    dns:  ""                # k8s external  DNS. This value or ip value MUST BE PROVIDED
    local: false            # True when deploying on "local K8s" provided by Docker Desktop.
  hpa:
    minReplicas: 1
    maxReplicas: 18
  misc:                     # inf.misc contains miscellaneous configuration related to infrastructure
    useLoadTest: false      # If running under loading test or not
    useAzureStorage: false  # If catalog api uses azure storage or not
  lightweight:
    kiali-server:
      enabled: true
    prometheus:
      enabled: true
    elasticsearch:
      enabled: true
    grafana:
      enabled: true
  # 아랫부분 추가 대상
  kibanaEnabled: true
  tracing:
    enabled: true
    servicename: "eshop-jaeger-agent"
    serviceport: "6831"
    traceinterval: "7500" 
  high-availability:
    elasticsearch:
      enabled: false
    istio-ingress:
      enabled: false
jaeger:
  provisionDataStore:
    cassandra: false
  storage:
    type: elasticsearch
    elasticsearch:
      host: eshop-coordinating-only
      port: 9200
elasticsearch:
  master:
    replicas: 1
  coordinating:
    replicas: 1
  data:
    replicas: 1 
# 윗 부분 추가 대상
```

</details>

<br>

After performing all solution methods, access the final calculated DNS Name (existing personal eshop service access domain)

Check the review list for each product, which was a requirement of the assignment
<br>

![](../media2/Week 4-Challenge_1.png)

<br>

Check review registration for each product and check like and dislike functions for reviews

![](../media2/Week 4-Challenge_2.png)

<br>
<br>

## Access URL after construction

Service URL <br>
https://<< DOMAIN >>

<br>

**😃 Challenge Completed!!!**

<br>

---


<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
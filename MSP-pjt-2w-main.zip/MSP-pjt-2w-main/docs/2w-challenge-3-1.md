## Current status of the program

<br>

## 🤔 Challenge 3-1

### Topic: Authentication / Authorization

<br>

📌 [Additional notes to use during challenges]

📌 [eshop FQDN DOMAIN information (challenge)]<br>
***FQDN value of individual eshop service --- ex) eshop.mspt3.click***<br>
➕ << DOMAIN >> : <br>

📌 [Personal DOMAIN Name (Challenge)]<br>
***Individually created domain name --- ex) .mspt3.click (with “.” in front)***<br>
➕ << DOMAIN NAME >> : <br>

📌 [AWS RDS Mariadb’s Endpoint (Challenge)]<br>
***Endpoint value of AWS RDS Mariadb derived from terraform output of chal_3-1_eshop-service-IaC.tar.gz***<br>
➕ << private AWS RDS maria db endpoint >> : <br>

📌 [AWS RDS Mariadb Password (Challenge)]<br>
***PW value of AWS RDS Mariadb derived from terraform output of chal_3-1_eshop-service-IaC.tar.gz***<br>
➕ <<Personal AWS RDS maria db password >> : <br>

<br>

## Strengthen authentication and authorization (Istio + Keycloak + Oauth2-proxy) on the installed OSS monitoring tool.


<br>

Hipster Shop (eshop) is an online shopping mall where you can purchase a variety of products.

The management of Hipster shop (eshop) has moved the service to **public cloud** and **container-based microservice** and is operating it somewhat stably.

In response to the customer's request to strengthen security aspects, security must be strengthened by applying authentication to OSS monitoring tools using Istio Service Mesh + Keycloak (OIDC solution) + oauth2-proxy.

To summarize the above, what needs to be done is as follows.

- In terms of inner architecture, OSS monitoring tool ‘Authentication and Authorization strengthening (Istio + Keycloak + Oauth2-proxy)’
   => OIDC Realm uses emarket admin, which was covered during the development process.
   => Set Keycloak data in AWS RDS mariadb. (Used in the previous process, emarket)
   => Istio Service Mesh Istio-discovery requires `exntensionProviders` override.
   => ‘Istio authentication and authorization related policies need to be added appropriately’ to istio-vs, istio-authz sub helm chart
   => istio-vs, istio-authz sub charts must `delete` the existing directory and `replace` it with the new PaC directory.

In summary, the goals of the operation team are as follows.
  - Related keywords: Strengthening certification & authorization
  - OSS monitoring tool `Authentication and Authorization Strengthening (Istio + Keycloak + Oauth2-proxy)`


<br>

Please note that upon completing this challenge, the following architecture will be derived.

![](../media2/AWS-2w-3-chal-3-1.drawio.png)

<br>


## solution

<br>

<details>
<summary>[Performance 1 - Expand👇] Redefinition and execution of eshop-service-IaC Terraform code</summary>

<br>

---

🗎 Note. <s3://t2hubintern/chal_3-1_eshop-service-IaC.tar.gz>

Create infrastructure by executing Terraform code, with the Data module for AWS RDS added. AWS RDS service is a fully managed service for relational DBMS systems.

It is applied by creating a separate feature branch on the existing eshop-service-IaC github.

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```
> Go to eshop-service-IaC workspace directory

< WSL environment >
```bash
git checkout -b feature-c3_1
```
> Create a feature branch for the challenge named feature-c3_1. (Once created, the contents of the existing main branch are copied to the branch named feature-c3_1.)

< WSL environment >
```bash
rm -rf *
```
> To apply new sources to the feature-c3_1 branch, delete all existing sources.

< WSL environment >
```bash
cd ~/t3-msp-pjt
```
> Go to the actual project workspace directory

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/chal_3-1_eshop-service-IaC.tar.gz .
```
> Go to the actual project workspace directory and download the IaC source code for the challenge.

< WSL environment >
```bash
tar xvfz chal_3-1_eshop-service-IaC.tar.gz
```
> Unzip the downloaded reference source.

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```
> Go to eshop-service-IaC workspace directory

If the source for newly adding AWS RDS resources, indicated in `Change Logs` below, is ready, proceed sequentially from terraform init to terraform apply.


Change Logs
```
+) Create additional AWS RDS resources
```

---

<br>

If you performed Terraform of the service IaC pipeline through Jenkins during the second day course, you are guided to perform this challenge locally in WSL.

< WSL environment >
```bash
terraform init
```

< WSL environment >
```bash
terraform plan
```
> If you look at the terraform plan, it can be considered normal if a total of 43 resources are scheduled to be created.

< WSL environment >
```bash
terraform apply -auto-approve
```
> Run Terraform code that creates additional resources (RDS, DB Subnet, etc.).

<br>

❗❗ **After executing the Terraform code, carefully record the output values below. This will be used for the value of the Helm Chart of istio and eshop in the future** ❗❗

✔ **(Example of execution code/result)**
> Terraform Output Example
```yaml
eip_allocation_id = <<EOT
eipalloc-************,eipalloc-************ # Write to eshop-istio Helm variable Values.global.eiparn

EOT
mariadb_endpoint = "eshop-service-keycloackdb.************.us-west-2.rds.amazonaws.com" # Enter eshop-PaC Helm variable Values.global.sql.host
mariadb_user_name = "admin"
mariadb_user_password = "************" # Enter eshop-PaC Helm variable Values.global.sql.common.pwd
```

<br>

</details>

<br>


<details>
<summary>[Performance 2 - Expand👇] Add helm chart settings to eshop-PaC PaC and redistribute eshop application</summary>

<br>

---

Please use the references provided below.

🗎 Note. Challenge 3-1 Course Helm Chart completed version
> <s3://t2hubintern/chal_3-1_eshop-PaC.tar.gz>
>
> Personalizes all items that exist in the form of `<< variable >>` in the reference.
>
> Changing values.yaml variable in Root Helm Chart, PaC applied to Keycloak, oauth2-proxy and istio-auth

---

<br>

The Sub Helm Charts that make up the challenge are as follows.
```
- values.yaml
Add helm value variable required for authentication
Comment # Auth notation

- Additional installation of Keycloak
v9.3.0

- Additional installation of oauth2-proxy
v7.1.3

- Add istio Virtual Service and AuthorizationPolicy required for istio-vs & istio-authz authentication
```

<br>

---

🗎 Note. Each Sub Helm Chart in the complete version of PaC can be downloaded from the path below.

***<span style="color:red">Caution. The references below are not essential for practicing, and are for simple reference only. There is no need to download them and then work with them.</span>***

---

🗎 Note 1. <s3://t2hubintern/oauth2-proxy.tar.gz>
> Helm Chart, a medium that connects Istio and oauth2 authentication

🗎 Reference 2. <s3://t2hubintern/istio-vs.tar.gz>
> Istio oauth2 Virtual Service defined Helm Chart

🗎 Reference 3. <s3://t2hubintern/istio-authz.tar.gz>
> Helm Chart with Istio Authorization settings defined

---

<br>

Download the `chal_3-1_eshop-PaC.tar.gz` source with the changes to the Helm Chart indicated in the `Sub Helm Chart composing the challenge` above, and `feature-c3_1` in the individual `eshop-PaC` Github Repository. After creating a branch, reflect the source content in the feature branch. (Push must be performed even after modifying the source code as in step 2.)

<br>

2. Replace the values in the form of `<< variable >>` inside the configured PaC with individual values.

<br>

- eshop/values.yaml
   => Parameterized parts require personalization


***<span style="color:red">eshop-service-IaC Replace the variable type value using the Terraform Output value derived during the redefinition and execution process of the Terraform code.</span>***
<br>

eshop/values.yaml
```yaml
global:
  app:
    name: eshop
    namespace: eshop
# Auth
    url:
      base: << DOMAIN >>         # ex) eshop.mspt3.click  
      domain: .<< DOMAIN NAME >> # ex) .mspt3.click (앞에 "."이 붙어있다).
# Auth
  tls:
    enabled: false          # True to enable TLS (set by deploy-all.ps1)
    issuer: ""
  ingress:                                              # ingress related settings
    entries:
      eshop-frontend: eshop-frontend
      eshop-currencyservice: eshop-currencyservice
      eshop-productservice: eshop-productservice
      eshop-recommendservice: eshop-recommendservice
      eshop-adservice: eshop-adservice
      eshop-backend: eshop-backend
      eshop-cartservice: eshop-cartservice
      # spa: ""                                           # ingress entry for web spa
  svc:
    eshop-frontend: eshop-frontend
    eshop-currencyservice: eshop-currencyservice
    eshop-productservice: eshop-productservice
    eshop-recommendservice: eshop-recommendservice
    eshop-adservice: eshop-adservice
    eshop-backend: eshop-backend
    eshop-cartservice: eshop-cartservice
    # spa: webspa                                       # service name for web spa
  images:
    adservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>            # ex) 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-adservice:latest  
    backend: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>            # ex) 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-backend:latest  
    cartservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>        # ex) 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-cartservice:latest
    frontend: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>           # ex) 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-frontend:latest
    currencyservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>    # ex) 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-currencyservice:latest  
    productservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>    # ex) 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-productservice:latest  
    recommendservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>    # ex) 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-recommendservice:latest 
  appinsights:
    key: ""               # App insights to use
  k8s:                      # inf.k8s defines Kubernetes cluster global config
    dns:  ""                # k8s external  DNS. This value or ip value MUST BE PROVIDED
    local: false            # True when deploying on "local K8s" provided by Docker Desktop.
  hpa:
    minReplicas: 1
    maxReplicas: 18
  misc:                     # inf.misc contains miscellaneous configuration related to infrastructure
    useLoadTest: false      # If running under loading test or not
    useAzureStorage: false  # If catalog api uses azure storage or not
  lightweight:
    kiali-server:
      enabled: true
    prometheus:
      enabled: true
    elasticsearch:
      enabled: true
    grafana:
      enabled: true
  # 아랫부분 추가 대상 (open tracing)
  kibanaEnabled: true
  tracing:
    enabled: true
    servicename: "eshop-jaeger-agent"
    serviceport: "6831"
    traceinterval: "7500"
  # 윗 부분 추가 대상 (open tracing)
  high-availability:
    elasticsearch:
      enabled: false
    istio-ingress:
      enabled: false
# Auth
    keycloak:
      enabled: false
  image:
    registry: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com
    tag: latest
  sql:
    ## @param global.sql.host AWS RDS service endpoint
    ##
    host: << 개인 AWS RDS maria db endpoint >>          # ex) eshop-service-keycloackdb.cnm5l7zxyphs.us-west-2.rds.amazonaws.com  
    ## @param global.sql.port AWS RDS service port
    ##
    port: 3306
    common:
      ## @param global.sql.common.user AWS RDS service username
      ##
      user: admin
      pwd: << 개인 AWS RDS maria db password >>  
      pid: Developer
    authservice:
      db: KeycloakDb        # Keycloak DB
  authservice:
    svc: keycloak-http
    port: 80
    user: keycloak
    pwd: keycloak
keycloak:
  replica : 1
  resources:
    limits:
      cpu: 1500m
      memory: 2000Mi
    requests:
      cpu: 300m
      memory: 300Mi
oauth2-proxy:
  enabled: true
# Auth
# 아랫부분 추가 대상 (open tracing)
jaeger:
  provisionDataStore:
    cassandra: false
  storage:
    type: elasticsearch
    elasticsearch:
      host: eshop-coordinating-only
      port: 9200
elasticsearch:
  master:
    replicas: 1
  coordinating:
    replicas: 1
  data:
    replicas: 1 
# Add object to the upper part (open tracing)
```
> Compared to the existing PaC, additional values such as Domain, DB Host, and DB admin PW must be replaced.

<br>

- eshop/charts/kiali-server/values.yaml
   => Parameterized parts require personalization
```yaml
(...생략...)
external_services:
  prometheus:
    url: http://eshop-prometheus-server
    custom_metrics_url: http://eshop-prometheus-server
  tracing:
    in_cluster_url: http://eshop-jaeger-query/jaeger
    url: https://<< DOMAIN >>/jaeger
  custom_dashboards:
    enabled: true
(...생략...)
```
> If you performed the required task on the 3rd day, but it has been newly overwritten with the PaC for the challenge, a new setting is required.
>
> << DOMAIN >>: Replaced with personal domain value

<br>

3. Distribute the eshop app (the version of the app with all challenges completed) through argocd.

<br>

**Create an eshop application complete with Helm Chart on the argocd web screen.**

❗❗ Precautions when creating eshop application❗❗

<br>

When distributing eshop through Helm Chart in this course and future courses, the Application Name must be set to 'eshop'. This is because the Helm Chart to be designed in the future has settings dependent on the application name.

<br>

+New App creation task

Step 1) Enter GENERAL items
|Item|Content|Action|
|------|---|---|
|➕ Application Name |`eshop`|Copy & Paste|
|➕ Project |`default`|Select select box|
|➕ SYNC POLICY | `Manual` |Select select box (default)|
|➕ SYNC OPTIONS |`AUTO-CREATE NAMESPACE`|Select checkbox|

<br>

Step 2) Enter SOURCE items
|Item|Content|Action|
|------|---|---|
|➕Repository URL |`https://github.com/<< GITHUB USER NAME >>/eshop-PaC.git`|Select select box|
|➕Revision| `feature-c3_1` branch | In Revision, type `f` and select the select box with `feature-c3_1` branch|
|➕Path|`eshop`|Select select box|

<br>

Step 3) Enter DESTINATION items
|Item|Content|Action|
|------|---|---|
|➕ Cluster URL |`<< Service EKS Cluster Endpoint >>`|Select select box|
|➕ Namespace |`eshop`|Copy & Paste|

<br>

Step 4) Helm > VALUES FILES > Select the `values.yaml` select box

<br>


</details>

<br>

<details>
<summary>[Performance 3 - Expand👇] “Confirm” the istio-discovery extensionProviders settings in the provided istio helm chart and restart istio-ingressgateway </summary>

<br>

It is already applied in the istio-discovery sub helm chart in the provided istio helm chart, so you just need to check if it is set to the values below.

**eshop-istio/istio-discovery/values.yaml**
```yaml
(...skip...)
envoyExtAuthzHttp:
   service: "oauthproxy-service.eshop.svc.cluster.local"
(...skip...)
```
> oauthproxy-service is a service that runs within the istio and eshop namespace, and proxyes the authentication-related flow between istio's AuthorizationPolicy and Keycloak. In other words, the above settings can be seen as the connection process between istio and oauth2 proxy service.

<br>

Lastly, you need to restart the istio-ingressgateway deployment workload and map the istio ingress-ingressgateway to the newly applied `oauthproxy-service.eshop.svc.cluster.local` service in the eshop application PaC.

The mapping method is to restart the `istio-ingressgateway` workload within the istio application and apply it to the istio LB (Network ELB).

Argocd > Enter istio App > istio-ingressgateway Click ‘Restart’ among the additional actions. Relevant workloads are restarted within a few seconds.

![](../media2/istio_restart_01.png)

<br>

---

🗎 Note. How to restart with kubectl command

The above process can also be performed with the kubectl command in the admin server as shown below.


< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl rollout restart deployment istio-ingressgateway -n istio-system
```

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-201:~$ kubectl rollout restart deployment istio-ingressgateway -n istio-system
deployment.apps/istio-ingressgateway restarted
```

---

<br>

</details>

<br>
<br>



<br>
<br>


### List of Access Credentials and URLs after deployment

<br>

After performing all of the solution methods, finally call the personal eshop service FQDN and check whether the call is normal. (Check service normal call)

ex) Access the https://eshop.mspt3.click URL in the browser. (Example domain)

<br>

If all processes have been performed normally, a redirect is made to authenticate when accessing the URI service of OSS tools branching from istio.

![](../media2/authentication_01.png)

<br>

[Basic Credential]

To authenticate on the login screen above, see below.

➕ Email: `admin@samsung.com`
➕ Password: `123456`
> You can use the default value as is, but see `🗎 below for information on how to change the PW for the admin@samsung.com account. Please refer to the ‘Changing account password for KeyCloak authentication’ section.

<br>

Access each of the ‘applicable URLs’ below and check whether authentication and authorization are set.

<br>

Service URL <br>
https://<< DOMAIN >>

rabbitmq management URL <br>
https://<< DOMAIN >>/rabbitmq/
> Be careful that an additional `/` must be added.

jaeger URL <br>
https://<< DOMAIN >>/jaeger

kiali URL <br>
https://<< DOMAIN >>/kiali

kibana URL <br>
https://<< DOMAIN >>/kibana

prometheus URL <br>
https://<< DOMAIN >>/prometheus

grafana URL (in the case of grafana, ID/PW authentication of grafana itself (defined as helm value) as before) <br>
https://<< DOMAIN >>/grafana


<br>
<br>

---

### 🗎 Note. Change account password for KeyCloak authentication
<br>

<details>
<summary>[Expand👇] Change “admin@samsung.com” account password </summary>

> In order to log in to Kiali, Kibana, Jaeger UI, etc. using Oauth, you must access KeyCloak's admin page and change the user password of the emarket-admin realm.

For reference, the default password for the `admin@samsung.com` account saved in Keycloak is `123456`, and you can use this information to log in.
 
> ❗ For details on account and authority management through Keycloak, refer to the KeyCloak content related to authentication/authorization in the 4th day of T3 development training.

> If the JWT Token is valid in the browser session, it is possible to access various OSS tools with Authorization settings through SSO. On the other hand, if authentication is not performed, a redirect is made to the login window for authentication.

<br>

1. Access KeyCloak Web UI and click ‘Administration Console’

     → Connection URL: https://<< DOMAIN >>/identity/connect/auth/
     <br>
     (e.g. eshop.mspt3.click/identity/connect/auth/)
    
     ![](../media2/2022-05-14_235600.png)

<br>

2. Log in by entering KeyCloak default User/Password

    ➕ Username or email: `keycloak`

    ➕ Password: `keycloak`

     ![](../media2/2022-05-15_240000.png)

<br>

3. Click on `emarket-admin` Realm
   
    ![](../media2/2022-05-15_241700.png)

<br>

4. On the details screen of Emarket-admin Realm, click ‘Users’ on the left.

    ![](../media2/2022-05-15_241900.png)

<br>

5. Click the `View all users` button
   
    ![](../media2/2022-05-15_242100.png)

<br>

6. Click `ID` of `admin@samsung.com` account
   
    ![](../media2/2022-05-15_242200.png)

<br>

7. Click the ‘Credentials’ tab at the top, then register your individual password in the Reset Password section below and save it by clicking the ‘Reset Password’ button. If saved successfully, you can check the `Success!` pop-up.

    ➕ Temporary: Select `OFF`
   
    ![](../media2/2022-05-15_242300.png)
    ![](../media2/2022-05-15_242400.png)
    ![](../media2/2022-05-15_242500.png)


<br>

8. Access is authorized by accessing several OSS monitoring URLs and authenticating with the `admin@samsung.com` account and PW set in the above process.

(e.g. eshop.mspt3.click/kiali)
(e.g. eshop.mspt3.click/kibana)
(e.g. eshop.mspt3.click/jaeger)

</details>

---

<br>

**😃 Challenge Completed!!!**

<br>

---


<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
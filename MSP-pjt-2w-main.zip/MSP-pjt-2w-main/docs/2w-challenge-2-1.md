## Current status of the program

<br>

## 🤔 Challenge 2-1

### Topic: IaC

<br>

📌 [Additional notes to use during challenges]

📌 [Slack setting information (challenge)]<br>
➕ workspace name ( `<< WORKSPACE >>` ) : <br>
➕ `#ci-notice` channel id ( `<< CHANNEL ID >>` ) : <br>
➕ slack token ( `<< SLACK TOKEN >>`): <br>

<br>

***

📌 Check Slack Workspace name - workspace name ( `<< WORKSPACE >>` )

![](../media1/image37-1.png)

> You can check the Sub Domain of the workspace by clicking the workspace name in the upper left corner of the Slack workspace.

<br>

📌 Check CI result Noti channel id - `#ci-notice` channel id ( `<< CHANNEL ID >>` )

![](../media1/image37-2.png)

> If you right-click the `#ci-notice` channel among the channels in the Slack workspace and click `View Channel Details`, the channel ID will appear at the bottom. Be sure to record the value.
> This value is the actual value of the `<< CHANNEL ID >>` variable that needs to be replaced, so record it separately.

<br>

📌 Check individual member ID within the workspace - Individual ID within the workspace (`<< member ID >>`)

![](../media1/copy_member_id.png)

> If you click on your personal profile in the Slack workspace, click `⫶`, and then click `Copy member ID`, the individual’s member ID will be copied to the clipboard. Be sure to record that value. (The Slack workspace of the T3 actual project and the Slack workspace of the T3 development process are different, so it is not the same as the member ID used at that time)

<br>

***

<br>

Hipster Shop (eshop) is an online shopping mall where you can purchase a variety of products.

The management of Hipster shop (eshop) has moved the service to **public cloud** and **container-based microservice** and is operating it somewhat stably.

It is predicted that IaC Pipelines will be performed frequently as the VPC area of the service expands.

Accordingly, the operation team internally reviewed adding the ‘Slack Noti’ function to the IaC Pipeline.

Let’s ‘build’ the function according to the customer’s needs.

**reference. It is a challenge that builds a CI Pipeline and can be performed in an environment where all Jenkins Slack settings have been completed.**

<br>
<br>


## solution

<br>

<details>
<summary>[Performance 1 - Expand👇] Proceed with Slack-related settings in Jenkins. </summary>

<br>

### Set Jenkins Management > System Settings > Slack items.


[Configure System > Slack]

Workspace : `<< WORKSPACE >>`

Default channel / member id: `<< CHANNEL ID >>` Enter the name of a specific Slack channel (example: C040PGGUG05) for each team.

<br>

[Jenkins Credentials Provider: Jenkins] Pop-up screen

Kind: Secret Text

Secret: `<< SLACK TOKEN >>`

ID: slack

Description: slack

<br>

✔ Registration and Test Procedure

![](../media1/image37-3.png)

> In `Secret`, enter the Slack Noti authentication token (`<< SLACK TOKEN >>`) announced in advance in the `#PracticeTextbook-Material Sharing` channel in the Slack workspace.
>
> Enter the Slack information obtained in the above process.

<br>

***

<br>

</details>

<br>

<details>
<summary>[Performance 2 - Expand👇] Modify eshop-service-IaC Jenkinsfile_apply</summary>

<br>

reference. The `<< CHANNEL ID >>` variable is replaced with the `#ci-notice` channel ID.

eshop-service-IaC/Jenkinsfile_apply

```groovy
pipeline {
    agent {
        kubernetes {
            yaml '''
              apiVersion: v1
              kind: Pod
              spec:
                containers:
                - name: terraform
                  image: hashicorp/terraform
                  command:
                  - cat
                  tty: true
            '''
        }
    }

    stages {
        stage('terraform init'){
            steps{
                container('terraform'){
                    withCredentials([[
                        $class: 'AmazonWebServicesCredentialsBinding',
                        credentialsId: 'awsCredentials',
                        accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                        secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                        ]]) {
                              sh 'terraform init'
                    }
                }
            }
        }
        stage('terraform plan'){
            steps{
                container('terraform'){
                    withCredentials([[
                        $class: 'AmazonWebServicesCredentialsBinding',
                        credentialsId: 'awsCredentials',
                        accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                        secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                        ]]) {
                              sh 'terraform plan -out tfplan'
                              sh 'terraform show -no-color tfplan > tfplan.txt'
                    }
                }
            }
        }
        stage('Approval') {
            when {
                branch 'main'
            }
            steps {
                script {
                    def plan = readFile 'tfplan.txt'
                    input message: "Do you want to apply the plan?",
                        parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
                }
            }
        }
        stage('terraform apply'){
           when {
                branch 'main'
            }
            steps{
                container('terraform'){
                    withCredentials([[
                        $class: 'AmazonWebServicesCredentialsBinding',
                        credentialsId: 'awsCredentials',
                        accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                        secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                        ]]) {
                              sh 'echo test'
                              sh 'terraform apply -auto-approve'
                    }
                }
            }
            post {
                success { 
                    slackSend(channel: '<< CHANNEL ID >>', color: 'good', message: 'service IaC Pipeline Apply Success')
                }
                failure {
                    slackSend(channel: '<< CHANNEL ID >>', color: 'danger', message: 'service IaC Pipeline Apply fail')
                }
            }
        }
    }
}
```


</details>

<br>

<details>
<summary>[Execution 3 - Expand👇] Modify eshop-service-IaC Jenkinsfile_destroy</summary>

<br>

reference. The `<< CHANNEL ID >>` variable is replaced with the `#ci-notice` channel ID.

eshop-service-IaC/Jenkinsfile_destroy

```groovy
pipeline {
    agent {
        kubernetes {
            yaml '''
              apiVersion: v1
              kind: Pod
              spec:
                containers:
                - name: terraform
                  image: hashicorp/terraform
                  command:
                  - cat
                  tty: true
            '''
        }
    }

    stages {
        stage('terraform init'){
            steps{
                container('terraform'){
                    withCredentials([[
                        $class: 'AmazonWebServicesCredentialsBinding',
                        credentialsId: 'awsCredentials',
                        accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                        secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                        ]]) {
                              sh 'terraform init'
                    }
                }
            }
        }
        stage('terraform plan -destroy'){
            steps{
                container('terraform'){
                    withCredentials([[
                        $class: 'AmazonWebServicesCredentialsBinding',
                        credentialsId: 'awsCredentials',
                        accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                        secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                        ]]) {
                              sh 'terraform plan -destroy -out tfplan'
                              sh 'terraform show -no-color tfplan > tfplan.txt'
                    }
                }
            }
        }
        stage('Approval') {
            when {
                branch 'main'
            }
            steps {
                script {
                    def plan = readFile 'tfplan.txt'
                    input message: "Do you want to apply the plan?",
                        parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
                }
            }
        }
        stage('terraform destroy'){
           when {
                branch 'main'
            }
            steps{
                container('terraform'){
                    withCredentials([[
                        $class: 'AmazonWebServicesCredentialsBinding',
                        credentialsId: 'awsCredentials',
                        accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                        secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                        ]]) {
                              sh 'echo test'
                              sh 'terraform destroy -auto-approve'
                    }
                }
            }
            post {
                success { 
                    slackSend(channel: '<< CHANNEL ID >>', color: 'good', message: 'service IaC Pipeline Destroy Success')
                }
                failure {
                    slackSend(channel: '<< CHANNEL ID >>', color: 'danger', message: 'service IaC Pipeline Destroy fail')
                }
            }
        }
    }
}
```

</details>

<br>

<details>
<summary>[Execution 4 - Expand👇] eshop-service-IaC Jenkinsfile Copy</summary>

<br>

Go to the directory you want to work in

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```

<br>

Change Jenkinsfile to apply or destroy depending on your situation

(when applying)

< WSL environment >
```bash
cp Jenkinsfile_apply Jenkinsfile
```
> When applying, if there are no changes in the separate resource declaration, the plan will proceed with “No Change”.

</details>

<br>

After applying the solution, it is reflected in the eshop-service-IaC Github main branch as shown below and then the pipeline is performed. When a push is made to github, you can see that the Jenkins blue ocean pipeline is automatically triggered.


Go to the directory you want to work in

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```

<br>

Push changes to eshop-service-IaC github main branch

< WSL environment >
```bash
git add .; git commit -m "apply IaC slack notification"; git push origin main
```

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
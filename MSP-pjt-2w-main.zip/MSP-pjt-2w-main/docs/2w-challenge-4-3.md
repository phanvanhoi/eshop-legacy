## Current status of the program

<br>

## 🤔 Challenge 4-3

### Topic: Deployment (Blue/Green)

<br>

## Practice Objectives
- Install Argo rollout, the Argo Project's distribution plugin, and perform blue/green distribution using it.
- (Optional) Try performing SSH Tunneling using Mobaxterm or Putty.

<br>

## Applying Blue/Green distribution strategy using Argo rollout

argo rollout is a collection of Kubernetes controllers and CRDs to support deployment of Blue/Green, Canary, etc. in Kubernetes.

The combination of Argocd and Argo rollout, developed by CNCF's Argo camp, allows perfect Blue/Green deployment by applying supplements to the existing Kubernetes deployment strategy.

---

🗎 Note. CRD
> <https://kubernetes.io/ko/docs/concepts/extend-kubernetes/api-extension/custom-resources/>

---

<br>

❗Main functions
- Blue/Green distribution
- Canary distribution
- Automated rollback and deployment
- Progressive deployment using custom metric queries
- Ingress Controller integration: Nginx, ALB
- Service Mesh integration: Istio, Linkerd, SMI
- Metric provider integration: Prometheus, Graphite, Datadog, Kubernetes Jobs

The method of using Argo rollout and the basic Kubernetes deployment method seem similar in blue/green deployment, but are somewhat different.

<br>

[Basic Kubernetes Blue/Green deployment]

First, if there are two or more Pods, rolling update is performed on one Pod each.

In other words, it operates in the following order.

```
2 Blue / 0 Green
1 Blue / 1 Green ← At that point, 2 versions of Pod exist at the endpoint of the service.
0 Blue / 2 Green (became the new Blue)
```

In case 2 of the above operation, one Blue Pod to be deleted and one Green Pod to be newly deployed receive traffic through the same service. Therefore, there will be a point where two versions of the Pod operate simultaneously, even if only briefly.

If you want to prevent this and are distributing through Argo CD, you can solve it by using a library called Argo Rollouts.

<br>

[Argo Rollouts Blue/Green Distribution]

<br>

If you modify it to be distributed in Blue/Green method using the Argo Rollouts library, it will work as follows.

```
2 Blue / 0 Green
2 Blue / 2 Green ← At that point, the service endpoint is immediately transferred to 2 Green.
0 Blue / 2 Green
```

---

🗎 Note. 💡 Blue/Green distribution strategy
> <https://argoproj.github.io/argo-rollouts/features/bluegreen/>

---

<br>

### Argo roll-out and plugin installation

**: In reality, blue/green deployment requires installation in an eshop cluster (Service Cluster).**

<br>

For further details, you may refer to the guide on the argo roll out site.

However, as shown in the guide below, you must install version 1.2.2 of argo roll out, which is compatible with the AWS EKS cluster Version 1.24 environment, which is the current practice environment.

---

🗎 Note. How to install argo rollout
> <https://argoproj.github.io/argo-rollouts/installation/>

**(However, when referring to the above site, darwin in the script must be replaced with linux.)**

**(The commands below are scripts modified for Linux)**

---

<br>

**ESHOP CONTEXT**

**: Proceed with installation so that CRD (`kind: Rollout`) can be deployed normally in ESHOP Context.**

Connect to the Admin server and switch to the context of eshop eks cluster.

< EC2 environment - admin server >
```bash
kubectl config use-context eshop
```

<br>

Create argo-rollouts namespace

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl create namespace argo-rollouts
```

<br>

Create argo-rollouts

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl apply -n argo-rollouts -f https://github.com/argoproj/argo-rollouts/releases/download/v1.2.2/install.yaml
```

<br>

Download argo rollout kubectl plugin

< EC2 environment - admin server >
```bash
curl -LO https://github.com/argoproj/argo-rollouts/releases/download/v1.2.2/kubectl-argo-rollouts-linux-amd64
```

<br>

Grant execution permission to non-root account

< EC2 environment - admin server >
```bash
chmod +x ./kubectl-argo-rollouts-linux-amd64
```

<br>

Command environment variable settings

< EC2 environment - admin server >
```bash
sudo mv ./kubectl-argo-rollouts-linux-amd64 /usr/local/bin/kubectl-argo-rollouts
```

<br>

autocomplete

< EC2 environment - admin server >
```bash
source <(kubectl-argo-rollouts completion bash)
```

<br>

Normal installation and version confirmation

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl-argo-rollouts version
```

<br>

Start Dashboard

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl argo rollouts dashboard -n argo-rollouts
```

<br>

---

🗎 Note. How to delete <span style="color:red">**(For reference only. Do not execute)**</span>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl delete -n argo-rollouts -f https://github.com/argoproj/argo-rollouts/releases/download/v1.2.2/install.yaml
```

---

<br>

**MGMT CONTEXT**

**: If deployment is performed using only CLI, it is not necessary to install argo rollout in the MGMT Cluster, but installation of argo rollout is necessary to ensure that CRD (`kind: Rollout`) is displayed without error on the Argocd Server UI. do.**

<br>

Connect to the Admin server and switch to the context of mgmt eks cluster.

< EC2 environment - admin server >
```bash
kubectl config use-context mgmt
```

<br>

Create argo-rollouts namespace

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl create namespace argo-rollouts
```

<br>

Create argo-rollouts

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl apply -n argo-rollouts -f https://github.com/argoproj/argo-rollouts/releases/download/v1.2.2/install.yaml
```

<br>

Normal installation and version confirmation

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl-argo-rollouts version
```

<br>

---

🗎 Note. How to delete <span style="color:red">**(For reference only. Do not execute)**</span>

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl delete -n argo-rollouts -f https://github.com/argoproj/argo-rollouts/releases/download/v1.2.2/install.yaml
```

---

<br>
<br>

### After installing argo rollout in the mgmt context, check that a new rollouts-related API resource type has been created.

< EC2 environment - admin server >
```bash
kubectl config use-context mgmt
```

<br>


< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl api-resources | grep rollouts
```

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-82:~$ kubectl api-resources | grep rollouts
rollouts ro argoproj.io/v1alpha1 true Rollout
```

<br>


#### Apply and implement blue/green deployment strategy of eshop-currencyservice, a Node.js module

Argo roll out provides powerful features for deployment using CRD (Custom Resource Definition) called “Rollout”. In this lab, we will implement the Blue/Green deployment strategy.

<br>

---

🗎 Note. The following example is an example of Argo rollout blue/green CRD, and you can see that the kind is Rollout.
> If argo rollout in the eshop context was not installed in the previous process, argocd cannot properly recognize the CRD below.
>
>```
>argoproj.io/v1alpha1/Rollout
>```
>
> If argo rollout is not installed in the eshop context, a Sync error may occur for the manifest declared as `Rollout` CRD in argocd as shown below.
>
><< Example >>
>```
> SyncFailed // eshop-currencyservice // the server could not find the requested resource
>```
>
><br>
>
>
>```yaml
>apiVersion: argoproj.io/v1alpha1
>kind: Rollout
>metadata:
> name: rollout-bluegreen
>spec:
> replicas: 2
> revisionHistoryLimit: 2
> selector:
>matchLabels:
> app: rollout-bluegreen
>template:
> metadata:
> labels:
> app: rollout-bluegreen
>spec:
>containers:
> - name: rollouts-demo
> image: argoproj/rollouts-demo:green
> imagePullPolicy: Always
>ports:
> - containerPort: 8080
> strategy:
>blueGreen:
> activeService: rollout-bluegreen-active
> autoPromotionEnabled: false
>---
>kind: Service
>apiVersion: v1
>metadata:
> name: rollout-bluegreen-active
>spec:
> selector:
> app: rollout-bluegreen
>ports:
> - protocol: TCP
> port: 80
> targetPort: 8080
>```
>
> Rollout-bluegreen-active can be seen as a service with a blue/green distribution target.
>
> `autoPromotionEnabled: false` prevents traffic from being automatically routed to green. For reference, even when actually operating the working group, the final traffic conversion is done manually, so it would be better to use the above option.
>

---

<br>

---


### To utilize the Argo rollout UI, tunneling settings must be performed as follows.

For reference, deployment can be performed using only CLI without using the UI. The detailed guide below provides guidance on both 'UI' and 'CLI', so individuals can choose a work environment that is comfortable for them.

#### Tunneling settings

<details>
<summary>[Reference - Expand👇] SSH Tunneling settings to check Argo Rollout’s UI</summary>

<br>

Tunneling is a function provided by almost all SSH connection tools, and can be performed using MobaXterm as shown below.

`Use of MobaXterm`

<br>

---

🗎 Note. What is SSH Tunneling?
> <https://storycode.tistory.com/293>

---

<br>

1. Perform the task of opening Security Group Inbound to enable communication with service port `3100` of argo rollout dashboard with bastion server => admin server (so that admin server can accept port communication from bastion server).
> eshop-mgmt-IaC Work is performed through Terraform IaC.


Add Inbound to MGMT VPC > Admin Server > Security Group.

This is the process of adding the entry below to the ‘Security Group’ assigned to the Admin Server.
> Source: security group of bastion server
>
> Port: 3100

<br>

eshop-mgmt-IaC/main.tf
> Uncomment lines 222 to 230

```terraform
...(skip)...
resource "aws_security_group_rule" "admin-argo-rollout" {
   description = "from bastion server"
   type = "ingress"
   from_port = 3100
   to_port = 3100
   protocol = "TCP"
   security_group_id = aws_security_group.admin_sg.id
   source_security_group_id = aws_security_group.bastion_sg.id
}
...(skip)...
```

After the above work, perform the plan and apply.

```
terraform plan
```

<br>


```
terraform apply -auto-approve
```

<br>

2. Set the Tunneling item in MobaXterm, access localhost:13100, and finally set up port 3100 to communicate with the admin server.

<br>

**Step1) Click the MobaXterm Tunnel button**

![](../media2/tunnel1.png)


**Step2) Edit and save local port forwarding**

- For the IP of the remote server, enter the private IP of the personal admin server.
- For SSH Connect IP, enter the public IP of your personal bastion server.
- Save after entering

![](../media2/tunnel2.png)


**Step3) SSH Pem Key Setting**

- Specify the location of the personal pem key (MyKeyPair.pem) file and save.
- Click Start all tunnels

![](../media2/tunnel3.png)


After completing all settings, if you access <http://localhost:13100> with a local browser and the following page appears, the installation and settings have been completed successfully.

![](../media2/image76.png)

<br>

*** [Reference 👆] Settings for ‘2) How to use UI’ ***

---

<br>

</details>


---

<br>

### Distribution operation steps

Let’s begin the blue/green distribution work for eshop-currencyservice in earnest.

1. `Add` or `Uncomment` the `eshop-PaC/eshop/charts/eshop-currencyservice/template/deployment-bluegreen.yaml` CRD manifest in the eshop-PaC repo as shown below and push it to the main branch.

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: eshop-currencyservice
spec:
  replicas: 2
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: eshop-currencyservice
  template:
    metadata:
      labels:
        app: eshop-currencyservice
    spec:
      terminationGracePeriodSeconds: 5
      containers:
      - name: eshop-currencyservice
        #기존
        image: {{ .Values.global.images.currencyservice }}
        #신규
        #image: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-currencyservice:threecurrencies
        imagePullPolicy: Always
        ports:
        - containerPort: 8094
        env:
        - name: PORT
          value: "8094"
        resources:
          requests:
            cpu: 100m
            memory: 64Mi
          limits:
            cpu: 200m
            memory: 128Mi
  strategy:
    blueGreen: 
      activeService: eshop-currencyservice
      autoPromotionEnabled: false
```

`eshop-PaC/eshop/charts/eshop-currencyservice/template/deployment-bluegreen.yaml` file `add` or `uncomment` the existing `eshop-PaC/eshop/charts/eshop-currencyservice/template/deployment. yaml` file is commented out and then `Prune Sync` is performed.

```yaml
# apiVersion: apps/v1
# kind: Deployment
# metadata:
#   name: eshop-currencyservice
# spec:
#   selector:
#     matchLabels:
#       app: eshop-currencyservice
#   template:
#     metadata:
#       labels:
#         app: eshop-currencyservice
#     spec:
#       terminationGracePeriodSeconds: 5
#       containers:
#       - name: eshop-currencyservice
#         image: {{ .Values.global.images.currencyservice }}
#         ports:
#         - containerPort: 8094
#         env:
#         - name: PORT
#           value: "8094"
#         resources:
#           requests:
#             cpu: 100m
#             memory: 64Mi
#           limits:
#             cpu: 200m
#             memory: 128Mi
```

<br>

It can be seen that the existing Deployment manifest has been changed to Rollout.

Looking at the settings above, the image of the current service is being performed using the image URI and TAG of the value of the Helm variable (usually the `latest` Tag). `{{ .Values.global.images.currencyservice }}` Helm variable maps the image value specified in `values.yaml`.

[New distribution target]
   - The new distribution target uses a public image that has changed the exchange rate information of eshop-currencyservice/data/initial-data.json into three images.

-> Public image: `505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-currencyservice:threecurrencies`

The image above is a 'public image' that has been modified so that eshop-currencyservice responds to only the three currencies below.

Therefore, if you deploy eshop-currencyservice by applying the image above and then call the GET /api/currencies API, only the three currency values below will come out.

![](../media2/image78.png)

This can be easily compared to the existing case where there are a total of 33 currencies.

Starting from the process below, we will implement uninterrupted distribution through the Blue/Green strategy to simplify the existing 33 currencies to 3 currencies.

<br>

2. Replace the `eshop-PaC/eshop/charts/eshop-currencyservice/template/deployment-bluegreen.yaml` file with the public image `threecurrencies tag` as shown below and reflect it in the main branch.

![](../media2/image82_new.png)

<br>

3. After SYNCing the eshop app in ArgoCD, you can see that the rollout type eshop-currencyservice is added by selecting the "Rollout" type in argocd as shown below.

![](../media2/bluegreen_suspended_1.png)

<br>

4. Also, at this point, you can check whether the pods of the 2 existing replicas and 2 new replicas specified in the manifest are running normally. If you click on each Pod in the screen below, you can easily check what image URI and TAG it is.

```bash
#Existing (personal image)
image: {{ .Values.global.images.currencyservice }}
```

```bash
#New (public image)
image: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-currencyservice:threecurrencies
```

![](../media2/bluegreen_suspended_2.png)

<br>

5. If you go to the argo roll out Dashboard again, you can confirm that a rollout for eshop-currency has been created.

<br>

This is the current Blue Pod and can be seen as being in operation.

<br>

(Additional information) If you perform the method using UI 2), if the Dashboard in the eshop namespace is not confirmed, be sure to restart the argo rollout Dashboard in the `eshop` context.

### Restart Dashboard

context switch
```bash
kubectl config use-context eshop
```
> Can be replaced with alias 'ec'

<br>

```bash
kubectl argo rollouts dashboard -n argo-rollouts
```

![](../media2/image80_new.png)

<br>

6. Rollout inquiry is possible from this point on.

`1) Method of using CLI`

Check rollout details
```bash
kubectl-argo-rollouts get rollouts eshop-currencyservice -n eshop
```

When you check the detailed rollout information, it can be displayed in the form below. Images marked with `(stable, active)` can be viewed as the URI of the image currently in service. In the example below, the latest tag of the individual ECR URI, `224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-currencyservice:latest`, can be seen as being in service.

✔ **(Example of execution code/result)**
```bash
Name:            eshop-currencyservice
Namespace:       eshop
Status:          ॥ Paused
Message:         BlueGreenPause
Strategy:        BlueGreen
Images:          505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-currencyservice:threecurrencies
                 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-currencyservice:latest (stable, active)
Replicas:
  Desired:       2
  Current:       4
  Updated:       2
  Ready:         2
  Available:     2

NAME                                               KIND        STATUS     AGE  INFO
⟳ eshop-currencyservice                            Rollout     ॥ Paused   75m
├──# revision:2
│  └──⧉ eshop-currencyservice-7f7dcd4c64           ReplicaSet  ✔ Healthy  70m
│     ├──□ eshop-currencyservice-7f7dcd4c64-78stc  Pod         ✔ Running  70m  ready:2/2
│     └──□ eshop-currencyservice-7f7dcd4c64-mvn8t  Pod         ✔ Running  70m  ready:2/2
└──# revision:1
   └──⧉ eshop-currencyservice-66f7976c7b           ReplicaSet  ✔ Healthy  75m  stable,active
      ├──□ eshop-currencyservice-66f7976c7b-2cw2n  Pod         ✔ Running  75m  ready:2/2
      └──□ eshop-currencyservice-66f7976c7b-lvdqw  Pod         ✔ Running  75m  ready:2/2
```


`2) Method of using UI`

Afterwards, if you go to the argo roll out Dashboard, you can see the Blue / Green replicas floating at the same time as shown below.

In other words, it can be seen as the stage just before converting actual operational traffic.

![](../media2/image81.png)


<br>


7. If you go to Argocd in this situation, you can confirm that the eshop app is in a suspended state as follows.

The meaning of this situation is that the rollout of eshop-currencyservice has not yet converted operational traffic, and the actual traffic conversion (Promote) task is waiting.

![](../media2/bluegreen_2.png)

<br>

8. Perform Promote actions

`1) Method of using CLI`

promote: The latest revision is applied in the current state
```bash
kubectl-argo-rollouts promote eshop-currencyservice -n eshop
```

✔ **(Example of execution code/result)**

```bash
ubuntu@ip-10-0-10-82:~$ kubectl-argo-rollouts promote eshop-currencyservice -n eshop
rollout 'eshop-currencyservice' promoted
```

<br>

`2) Method of using UI`

![](../media2/image77.png)

Press the orange ‘Promote’ button and then press ‘Sure’.

![](../media2/image85.png)

<br>

9. The entire conversion to the new version has been completed, and eshop is now in a healthy state again on Argocd.

![](../media2/bluegreen_3.png)

<br>

10. When you call the GET /api/currencies API for the service during the deployment process and after deployment is complete, only the three currency values below are displayed.

![](../media2/image78.png)

<br>

11. Rollout inquiry after distribution

`1) Method of using CLI`

Check rollout details
```bash
kubectl-argo-rollouts get rollouts eshop-currencyservice -n eshop
```

✔ **(Example of execution code/result)**
```bash
Name:            eshop-currencyservice
Namespace:       eshop
Status:          ✔ Healthy
Strategy:        BlueGreen
Images:          505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-currencyservice:threecurrencies (stable, active)
Replicas:
  Desired:       2
  Current:       2
  Updated:       2
  Ready:         2
  Available:     2

NAME                                               KIND        STATUS        AGE  INFO
⟳ eshop-currencyservice                            Rollout     ✔ Healthy     91m
├──# revision:2
│  └──⧉ eshop-currencyservice-7f7dcd4c64           ReplicaSet  ✔ Healthy     86m  stable,active
│     ├──□ eshop-currencyservice-7f7dcd4c64-78stc  Pod         ✔ Running     86m  ready:2/2
│     └──□ eshop-currencyservice-7f7dcd4c64-mvn8t  Pod         ✔ Running     86m  ready:2/2
└──# revision:1
   └──⧉ eshop-currencyservice-66f7976c7b           ReplicaSet  • ScaledDown  91m
```

`2) Method of using UI`

![](../media2/bluegreen_4.png)

<br>

12. RollBack operation

Additionally, Blue/Green's greatest strength is that it allows for quick rollback.
    
`1) Method of using CLI`
> Perform in the order of undo => promote


undo: Creates a revision that is not active in the current state as a new revision
```bash
kubectl-argo-rollouts undo eshop-currencyservice -n eshop
```

promote: The latest revision is applied in the current state
```bash
kubectl-argo-rollouts promote eshop-currencyservice -n eshop
```

<br>

`2) Method of using UI`

You can easily restore the original revision by simply pressing the Rollback button and then pressing the Sure button.

In fact, you can check whether there is no interruption and the smoothness of rollback by continuously calling the GET /api/currencies API to the domain using your own browser.


<br>

**😃 Challenge Completed!!!**

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
# **Week 2 (Outer Architecture and GitOps Ops) Day 4**

- [**Week 2 (Outer Architecture and GitOps Ops) Day 4**](#Week 2outer-architecture-and-gitops-ops-Day 4)
- [**Day 4 - Deployment management in Service EKS Cluster environment**](#Day 4---Service-eks-cluster-environment-deployment-management)
   - [Practice Goal Structure](#Practice-Goal-Structure)
   - [Practice Goal](#Practice-Goal)
   - [🚨 List of required tasks 🚨](#-Required tasks-list-)
   - [🤔 Day 4 Full Challenge List 🤔](#-Day 4-Full-Challenge-List-)
   - [❗❗ Precautions when practicing on the 4th day❗❗](#-4th-day-practice-precautions)
     - [Notes](#Notes)
       - [GitOps review by structure at the current time] (#current-current-gitops-by-structure-review)
       - [Introduction to non-disruptive deployment architecture] (#non-disruptive-deployment-architecture-introduction)
       - [Introduction to AWS Fargate](#aws-fargate-introduction)
       - [**Meaning of distributed tracking and telemetry**](#Meaning of distributed tracking and telemetry)
       - [**Distributed Tracing Overview**](#Distributed-Tracking-Overview)
       - [**🗎 Reference. \[Jaeger\]**](#-note-jaeger)
   - [🚨Required Assignment 4-1](#Required Assignment-4-1)
   - [**Lab 4-1. Applying distributed tracing (Spring Boot)**](#lab-4-1-Applying distributed tracing-spring-boot)
     - [4-1-0. eshop PaC Helm Chart configuration for open tracing](#4-1-0-eshop-pac-helm-chart-configuration for open-tracing)
     - [Prerequisites - Required](#Prerequisites---Required)
     - [4-1-1. adservice(Spring Boot app) Apply jaeger opentracing to monitor application transaction](#4-1-1-adservicespring-boot-app-jaeger-opentracing-apply-application-transaction-monitoring)
     - [jaeger-tracing properties](#jaeger-tracing-properties)
   - [Challenge 4-1](#Challenge-4-1)
   - [Challenge 4-2](#Challenge-4-2)
   - [🚨Required Assignment 4-2](#Required Assignment-4-2)
   - [**Lab 4-2. Non-disruptive deployment operation - Canary deployment**](#lab-4-2-Non-disruptive-deployment operation---canary-deployment)
     - [4-2-0. Pre-tasks for performing canary deployment](#4-2-0-pre-tasks-for-performing-canary-deployment)
     - [4-2-1. Canary deployment using istio](#4-2-1-canary-distribution using istio)
     - [4-2-2. Completely change to new version of canary distribution](#4-2-2-canary-distribution-completely change to new version)
     - [4-2-3. Rolling back canary deployment](#4-2-3-canary-deployment-rollback-)
   - [Challenge 4-3](#Challenge-4-3)
   - [Challenge 4-4](#Challenge-4-4)
   - [Challenge 4-5](#Challenge-4-5)
   - [Challenge 4-6](#Challenge-4-6)
   - [**Evaluation**](#evaluation)
- [ \[list\] ](#-list-)

---

# **Day 4 - Deployment management in Service EKS Cluster environment**

<br>

📌 [Notes to be used during this lab]

📌 [GITHUB]<br>
➕ << GITHUB USER NAME >> : <br>
➕ << GITHUB TOKEN >> : <br>

📌 [AWS Access Key]<br>
➕ << Access key >> : <br>
➕ << Secret Access key >> : <br>

📌 [ECR URI]<br>
➕ << ECR URI >> : <br>

<br>

## Practice goal structure

![](../media2/image58.png)

<br>

## Practice Objectives
- Apply application distributed tracing (open tracing) through Kiali and Jaeger.
- Apply modifications to apply Open Tracing to the application.
- Understand the canary and blue/green methods of non-stop service deployment among k8s deployment strategies.
- Canary deployment method using Istio DestinationRule and Virtual Service is applied.

<br>

## 🚨 List of required tasks 🚨

1. [[Open Tracing] Applying Distributed Tracing to App - adservice (Spring Boot)](#🚨Required Task-4-1)
2. [[Deployment] Canary deployment using Istio DestinationRule and Virtual Service](#🚨Required Task-4-2)

<br>

## 🤔 Day 4 Full Challenge List 🤔
🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

1. [[Open Tracing] Applying distributed tracing to NodeJS-based Express App and Python Flask App](#Challenge-4-1)<a href="./2w-challenge-4-1.md">(Challenge 4-1) </a>
2. [[Open Tracing] Applying app distributed tracing RabbitMQ asynchronous section tracing - backend (Spring Boot), cartservice (Spring Boot)](#Challenge-4-2)<a href="./2w-challenge-4 -2.md">(Challenge 4-2) </a>
3. [[Deployment] Install Argo rollout and deploy Blue/Green using it](#Challenge-4-3)<a href="./2w-challenge-4-3.md">(Challenge 4-3) </a>
4. [[Deployment] Install Argo rollout and deploy Canary using it](#Challenge-4-4) <a href="./2w-challenge-4-4.md">(Challenge 4- 4) </a>
5. [[Deployment] Deploy eshop on Serverless container service using AWS Fargate EKS service](#Challenge-4-5) <a href="./2w-challenge-4-5.md">(Challenge 4-5)</a>
6. [[Deployment] Additional deployment of new microservice functions. (Provides review function for each product)](#Challenge-4-6) <a href="./2w-challenge-4-6.md">(Challenge 4-6)</a>

<br>

## ❗❗ Precautions for practice on the 4th day❗❗

★★★ The Jenkins CI Pipeline configured on Day 1 must be run ‘one at a time’. ★★★

=> During the deployment-related practice on the 4th day, we plan to build some microservices among the CI Pipelines configured on the 1st day. At this time, due to the insufficient capacity of the Worker Nodes in the MGMT environment, if multiple Jenkins CI Pipelines are executed at once, the entire Node resources are consumed. There is a possibility that a shortage may cause a row.

<br>

### Note

<br>

#### Review of current GitOps structures

<https://www.weave.works/blog/gitops-operations-by-pull-request>

<https://www.samsungsds.com/kr/insights/gitops.html>
> Push vs Pull Deploy Type

<br>

#### Introduction to non-disruptive deployment architecture

<https://www.samsungsds.com/kr/insights/1256264_4627.html>
> Practical projects practice Canary and Blue/Green

<br>

#### Introduction to AWS Fargate

---

🗎 Reference document.
<https://docs.aws.amazon.com/ko_kr/AmazonECS/latest/userguide/what-is-fargate.html>

🗎 Reference document. <https://aws.amazon.com/ko/fargate/>

🗎 Reference document.
<https://aws.amazon.com/ko/premiumsupport/knowledge-center/eks-alb-ingress-controller-fargate/?nc1=h_ls>

---

<br>


#### **Meaning of distributed tracking and telemetry**

<br>

![](../media2/image3.png)

<br>

![](../media2/image2.png)

- Dictionary meaning of telemetry

> Collecting data from sensors, etc. by measuring it remotely. Telemetry is a technology that performs various observations and acquires data from a point distant from the object of observation.

- It can be seen as the ‘technology that enables distributed tracking in the Cloud Native environment’ mentioned above.

- The term telemetering is also used.

- What telemetry means from a DevOps/SRE perspective
  
> This means collecting various metrics from application and infrastructure environments to increase **observability** of the system.

#### **Distributed Tracing Overview**

- In a microservice architecture, as the number of microservices in operation increases, it becomes difficult to accurately diagnose and resolve performance problems in applications.
  
- When looking for the cause of a specific API suddenly slowing down, it is impossible to know which section is delayed, so the only way to find out which section is delayed is to call each section separately.
  
- If service calls overlap a lot, tracking all services by section becomes too complicated.

- You must be able to see at a glance how much time it took to perform what task in which section of a user request.
  
- Tracking function is required in a distributed environment

- Distributed tracing records service call tree information (e.g. start time, end time, etc.) each time a request is processed.

- You can check what work the service did while processing external requests, at what point and how much time it took.

![](../media2/image5.png)

<br>

**Implementation of distributed tracking**

- Whenever an external request comes in, a unique ID (span ID) is given to the request. When making an internal call, the request includes the span ID.

- Each service transmits the processing results for the span ID to the distributed tracking server. The service operator searches the distributed tracking server for the processing results for each section of the request.

![](../media2/image6.png)

- Jaeger was selected as the OSS to be used for distributed tracking practice in actual projects.

<br>

---

#### **🗎 Note. [Jaeger]**

> This is an OSS that will be used for monitoring applications in a distributed environment, which will be covered in a later course.
>
> Confirm that the relationship between eshop app, jaeger collector, jaeger query UI, etc. is formed with the structure below.
>
> ![](../media2/image14.png)
>
> Source. <https://twofootdog.tistory.com/67>
>
> Jaeger was initially developed as an open source project by Uber, a ride-sharing service company, in 2015, was adopted as a CNCF (Cloud Native Computing Foundation) Incubation project in 2017, and was approved as a formal project in 2019.
>
> 1. Trace: Data/execution path through the system. It consists of one or more spans. To put it simply, a trace can be understood as the period from when a client requests a specific function until a response is returned.
>
> 2. Span: Jaeger’s logical work unit. Each Span contains information such as task name, start time, and period. Span may be nested or ordered.
>

---

<br>
<br>


## 🚨Required task 4-1
> Lab 4-1 Overall work

## **Lab 4-1. Applying distributed tracking (Spring Boot)**

<br>


### 4-1-0. eshop PaC Helm Chart configuration for Open Tracing

<br>

### Prerequisites<span style="color:red"> - Required</span>
Activate the jaeger-agent setting in eshop-PaC/eshop/values.yaml as shown below. Adds tracing sub-options to the same depth as the global sub-app. (Content between `## Add` comments)
> For reference, if you use the <s3://t2hubintern/3rd_eshop-PaC.tar.gz> reference, the `tracing:` item has already been added.

<br>


**eshop-PaC/eshop/values.yaml**
```yaml
global:
  app:
  (...생략...)
  lightweight:
    kiali-server:
      enabled: true
    prometheus:
      enabled: true
    elasticsearch:
      enabled: true
    grafana:
      enabled: true
  kibanaEnabled: true
  ## 추가
  tracing:
    enabled: true
    servicename: "eshop-jaeger-agent"
    serviceport: "6831"
    traceinterval: "7500"
  ## 추가
  high-availability:
    elasticsearch:
      enabled: false
    istio-ingress:
      enabled: false
  (...생략...)
```

<br>

<details>
<summary>[Reference - Expand👇] Completed eshop-PaC/eshop/values.yaml format</summary>

```yaml
## << 변수 >> 치환 필요

## << ECR URI >>      : ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com
## << SERVICE NAME >> : ex) eshop-backend
## << TAG >>          : ex) latest

global:
  rabbitmq:
    # << Amazon MQ AMQP Endpoint >>값 예시) amqps://b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com:5671 값 중 프로토콜, 포트값을 뺀 값이 필요한 값 => b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com
    #host: << Amazon MQ AMQP Endpoint >>      # Amazon MQ 도전과제 시 주석해제 후 << Amazon MQ Web Console Endpoint >>에 값 치환
    host: rabbitmq                                   # Amazon MQ 도전과제 시 주석처리
  app:
    name: eshop
    namespace: eshop
  tls:
    enabled: false          # True to enable TLS (set by deploy-all.ps1)
    issuer: ""
  ingress:                                              # ingress related settings
    entries:
      eshop-frontend: eshop-frontend
      eshop-currencyservice: eshop-currencyservice
      eshop-productservice: eshop-productservice
      eshop-recommendservice: eshop-recommendservice
      eshop-adservice: eshop-adservice
      eshop-backend: eshop-backend
      eshop-cartservice: eshop-cartservice
      # spa: ""                                           # ingress entry for web spa
  svc:
    eshop-frontend: eshop-frontend
    eshop-currencyservice: eshop-currencyservice
    eshop-productservice: eshop-productservice
    eshop-recommendservice: eshop-recommendservice
    eshop-adservice: eshop-adservice
    eshop-backend: eshop-backend
    eshop-cartservice: eshop-cartservice
    # spa: webspa                                       # service name for web spa
  images:
    adservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    backend: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>                                           # Amazon MQ 도전과제 시 주석처리
    cartservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>                                       # Amazon MQ 도전과제 시 주석처리
    # backend: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-backend:amqtest            # Amazon MQ 도전과제 시 주석해제
    # cartservice: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-cartservice:amqtest    # Amazon MQ 도전과제 시 주석해제
    frontend: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    currencyservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    productservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    recommendservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
  appinsights:
    key: ""               # App insights to use
  k8s:                      # inf.k8s defines Kubernetes cluster global config
    dns:  ""                # k8s external  DNS. This value or ip value MUST BE PROVIDED
    local: false            # True when deploying on "local K8s" provided by Docker Desktop.
  hpa:
    minReplicas: 1
    maxReplicas: 18
  misc:                     # inf.misc contains miscellaneous configuration related to infrastructure
    useLoadTest: false      # If running under loading test or not
    useAzureStorage: false  # If catalog api uses azure storage or not
  lightweight:
    kiali-server:
      enabled: true
    prometheus:
      enabled: true
    elasticsearch:
      enabled: true
    grafana:
      enabled: true
  kibanaEnabled: true
  tracing:
    enabled: true
    servicename: "eshop-jaeger-agent"
    serviceport: "6831"
    traceinterval: "7500"
  high-availability:
    elasticsearch:
      enabled: false
    istio-ingress:
      enabled: false
jaeger:
  provisionDataStore:
    cassandra: false
  storage:
    type: elasticsearch
    elasticsearch:
      host: eshop-coordinating-only
      port: 9200
elasticsearch:
  master:
    replicas: 1
  coordinating:
    replicas: 1
  data:
    replicas: 1
```

</details>

---

<br>

### 4-1-1. adservice (Spring Boot app) Monitoring application transactions by applying jaeger opentracing

<br>

1. Disable Jaeger's AuthorizationPolicy

     - Since Jaeger-query does not provide authentication such as Token / ID / PW by default, the policy below is applied except at the time of testing.

     - For testing, comment out the policy below and push it to the Github main branch. And as shown in the image below, when `Sync` of Argocd, `Prune` is `checked` and `Sync` is performed.
   

<br>

**eshop-PaC/eshop/charts/istio-authz/templates/jaeger-auth-policy.yaml**

```yaml
# apiVersion: security.istio.io/v1beta1
# kind: AuthorizationPolicy
# metadata:
#   name: jaeger-ingress-policy
#   namespace: istio-system
# spec:
#   selector:
#     matchLabels:
#       app: istio-ingressgateway
#   action: DENY
#   rules:
#     # IP Base ACL 미동작
#     # - from:
#     #   - source:
#     #       ipBlocks:
#     #       - 121.133.133.0/24
#     #       - 221.167.219.0/24
#     - to:
#       - operation:
#           paths: [
#             "/jaeger*"
#           ]
```

<br>

 ![](../media1/argocd-prune-sync.png)

2. In order to distribute and track Spring Boot apps and other services, settings at the application level, that is, the Client, are required.

<br>

The modification items for when `Challenge 1-3` is performed and when not performed are different as follows.

1) If performed: `eshop-MSA-CI/eshop-adservice/build.gradle`
2) If not done: `eshop-MSA/eshop-adservice/build.gradle`

<br>

Inject the dependency for jaeger tracing into `eshop-adservice/build.gradle` as shown below.

<br>

**eshop-adservice/build.gradle**
```java
//for jaeger tracing
compile group: 'io.opentracing.contrib', name: 'opentracing-spring-jaeger-web-starter', version: '3.1.2' // jaeger
```

<br>

![](../media2/image15.png)

Additionally, proceed with jaeger collection server and sender related settings in the `eshop-adservice/src/main/resources/application.properties` file.

<br>

The modification items for when `Challenge 1-3` is performed and when not performed are different as follows.

1) If performed: `eshop-MSA-CI/eshop-adservice/src/main/resources/application.properties`
2) If not done: `eshop-MSA/eshop-adservice/src/main/resources/application.properties`

<br>

### jaeger-tracing properties

**eshop-adservice/src/main/resources/application.properties**
```java
# jaeger-tracing properties
opentracing.jaeger.service-name=eshop-adservice.eshop
opentracing.jaeger.enabled=true
opentracing.jaeger.log-spans=true
opentracing.jaeger.http-sender.url=http://eshop-jaeger-collector:14268/api/traces
```

Here, the service-name item is written in the format `<<service name>>.<< Namespace >>`, and for adservice, enter `eshop-adservice.eshop` as in the example above.

<br>

For sender settings, two transaction transmission methods are provided: HTTP and UDP.

<br>

In this exercise, we will select http sender and perform the exercise.

<br>

---

🗎 Note. Spring Boot (Java) series Jaeger integration link
> <https://github.com/opentracing-contrib/java-spring-jaeger>

---

<br>

3. Creation of new image of eshop-adservice for Open Tracing

<br>

Merge the reflections into the main branch of your personal github and manually run the CI build pipeline completed on day 1 (Jenkins Classic Pipeline), or if the Blue Ocean Pipeline (if you have completed Challenges 1-3) has been built, approve the proceeding after the trigger. Do it.

<br>

The image of eshop-adservice to apply jaeger tracing is built and pushed to ECR.

![](../media2/image16.png)


<br>

4. Application of eshop-adservice for Open Tracing

<br>

After the CI Pipeline work is completed, connect to Argocd of the currently reflected eshop Application and restart adservice deployment.

![](../media2/image17.png)

<br>

Alternatively, you can restart adservice deployment using the command below.

< EC2 environment - admin server >
```bash
kubectl config use-context eshop
```

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl -n eshop rollout restart deployment eshop-adservice
```

When restarting, the latest latest tag image pushed through CI just before was pulled according to the image pull policy always policy applied by default, and the latest application is distributed.

First, let's check the log to see if http sending to jaeger-collector is normal after deployment.

![](../media2/image18.png)

A Span Report is captured every time the API is called, and you can see that the Trace is "1" and is loaded normally into the Collector, as shown below.

![](../media2/image19.png)

source. <https://twofootdog.tistory.com/67>

<br>

5. Monitoring adservice after applying Open Tracing

<br>

Now, let's trace the actual microservice traffic transaction by actually generating a loader and calling adservice.

**load-generator-1**

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl run -i --tty load-generator-1 --rm --image=busybox --restart=Never -- /bin/sh -c "while sleep 0.01; do wget -q -O- http://< < DOMAIN >>/api/ads; done"
```
> << DOMAIN >> value must be replaced with the FQDN domain of the personal eshop service.

<br>

When load is generated, a large amount of Service Pod application logs are generated.

![](../media2/image20.png)

You can look at the logs of the corresponding Pod through Argocd.

<br>

6. Tracking with Jaeger

<br>

You can check whether the adservice.eshop service is actually collected through Jaeger Query UI.

<br>

If Jaeger Istio Virtual Service setup is complete, remove Jaeger's Istio AuthorizationPolicy and try connecting to https://<< DOMAIN >>/jaeger.

How many ms did the API call take, and the time taken for each section is checked.
This will be able to implement the previously introduced Trace and Span by extending it to the Spring Boot App and build more detailed transaction tracking.

![](../media2/image21.png)

<br>

Now that the base data has been accumulated, you can experience monitoring visualization.

<br>

Connect to Kiali Dashboard and look at the adservice trace.

<br>

You can observe the actual API processing time per case, basic API URI, and HTTP Status.

<br>

![](../media2/image22.png)

<br>

After completing the test, shut down the load machine.

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl delete pod load-generator-1
```

<br>
<br>

***

## Challenge 4-1

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

Applying distributed tracking to NodeJS-based Express App and Python Flask App <a href="./2w-challenge-4-1.md">(Challenge 4-1)</a>


***
## Challenge 4-2

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

Applying app distributed tracking RabbitMQ asynchronous section tracking - backend (Spring Boot), cartservice (Spring Boot) <a href="./2w-challenge-4-2.md">(Challenge 4-2)</a>

***

<br>
<br>

## 🚨Required task 4-2
> Lab 4-2 overall work

## **Lab 4-2. Non-disruptive deployment - Canary deployment**

<br>

### 4-2-0. Preliminary tasks for performing a canary deployment
For smooth canary deployment practice, we plan to use eshop-frontend, which allows changes to be easily checked in the UI.
However, due to the current build structure of eshop-frontend, canary deployment practice may be difficult, so modify the build settings.

After building eshop-frontend, change js and css files to be inline in one index.html

Although it may highlight the shortcomings of SPA (Single Page Application), it is performed for smooth learning.

- Instead of bundling with multiple js files, we changed index.html to include all js and css content inline, which increases the capacity of index.html. Because of this, when first loading, the load time may increase due to increased capacity.

Depending on whether `1-3 challenge` is performed, work is done on the personal Github eshop-MSA-CI/eshop-frontend or eshop-MSA/eshop-frontend path.
**eshop-frontend/package.json**
- Add dependency (html-webpack-plugin, react-dev-utils)
- Due to a webpack version compatibility issue, if running via npm install, execute the command below.
  - npm install -D html-webpack-plugin@4 && npm install -D react-dev-utils
```json
{
  "name": "frontend",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "serve": "vue-cli-service serve",
    "build": "vue-cli-service build",
    "lint": "vue-cli-service lint"
  },
  "dependencies": {
    "axios": ">=0.21.1",
    "bootstrap-vue": "^2.8.0",
    "core-js": "^3.6.4",
    "dotenv": "^8.2.0",
    "lodash": "^4.17.15",
    "vue": "^2.6.11",
    "vue-router": "^3.1.5",
    "vuex": "^3.1.3"
  },
  "devDependencies": {
    "@vue/cli-plugin-babel": "~4.2.0",
    "@vue/cli-plugin-eslint": "~4.2.0",
    "@vue/cli-plugin-router": "^4.2.3",
    "@vue/cli-plugin-vuex": "^4.2.3",
    "@vue/cli-service": "~4.2.0",
    "babel-eslint": "^10.0.3",
    "eslint": "^6.7.2",
    "eslint-plugin-vue": "^6.1.2",
    "html-webpack-plugin": "^4.5.2",
    "react-dev-utils": "^12.0.1",
    "vue-cli-plugin-axios": "0.0.4",
    "vue-template-compiler": "^2.6.11"
  },
  "eslintConfig": {
    "root": true,
    "env": {
      "node": true
    },
    "extends": [
      "plugin:vue/essential",
      "eslint:recommended"
    ],
    "parserOptions": {
      "parser": "babel-eslint"
    },
    "rules": {}
  },
  "browserslist": [
    "> 1%",
    "last 2 versions"
  ]
}
```

**eshop-frontend/vue.config.js**
- Added webpack settings
- Copy & paste the contents at the bottom.
```javascript
const HtmlWebpackPlugin = require('html-webpack-plugin');
const InlineChunkHtmlPlugin = require('react-dev-utils/InlineChunkHtmlPlugin');
const webpack = require('webpack');

module.exports = {
    css: {
        extract: false,
    },
    configureWebpack: {
        output: {
            filename: "app.js",
            chunkFilename: '[id].js'
        },
        plugins: [
            new webpack.optimize.LimitChunkCountPlugin({
                maxChunks: 1,
            }),
            new HtmlWebpackPlugin({
                title: "frontend",
                inject: true,
                template: 'public/index.html',
                favicon: 'public/favicon.ico'
            }),
            new InlineChunkHtmlPlugin(HtmlWebpackPlugin, [/\.(js|css)$/]),
        ],
    }
}
```

**eshop-frontend/public/index.html**
- Delete line 8
```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <base href="/" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><%= htmlWebpackPlugin.options.title %></title>
  </head>
  <body>
    <noscript>
      <strong>We're sorry but <%= htmlWebpackPlugin.options.title %> doesn't work properly without JavaScript enabled. Please enable it to continue.</strong>
    </noscript>
    <div id="app"></div>
    <!-- built files will be auto injected -->
  </body>
</html>

```
<br>

### 4-2-1. Canary deployment using istio

In your personal Github eshop-MSA-CI/eshop-frontend or eshop-MSA/eshop-frontend path
Modify line 6 of the eshop-frontend/src/components/Home.vue file as follows. (This is the process of creating a personal new version latest image.)

![](../media2/image59.png)

Commit and push the code by entering the following:

```bash
git add .
git commit -m “change frontend title”
git push origin main
```

**(The process below can be viewed as the build process after completing the construction of the Blue Ocean Pipeline, the first day's challenge.)**

**(If you have not built the Blue Ocean Pipeline for the Day 1 challenge, perform the build using the Jenkins default CI Pipeline.)**

![](../media2/image60.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media2/image61.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media2/image62.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media2/image63.png)

<br>

<p align="center">⬇️</p>

<br>

After the build is completed and Slack Noti, the post build, is confirmed as Success, check the tag of the eshop-frontend image just pushed in the ECR menu.

The existing version image (v1) should use the shared public image of the public ECR below.

`505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-frontend:previous`

(The existing version (v1) image above has permissions open to everyone, so it is recommended to use it as is.)

It was confirmed that the new version (v2) tag was written by an individual as latest.

![](../media2/image64.png)

In the eshop-PaC repository that you cloned or inited
Create two deployment versions in eshop-PaC/eshop/charts/eshop-frontend/templates/deployment.yaml.

In the image field, accurately enter your image registry, previous tag for existing version v1, and new version (latest) tag for v2.

For reference, the eshop root(parent) helm variable value is {{ .Values.global.images.frontend }} Helm Chart values are set to face the latest shape. Do not modify this separately.

However, when writing below, be sure to hard code the image URI of the existing version (v1).

That is, it takes the form below.

- v1: Existing public image with previous Tag (frontend source without changes)
> `505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-frontend:previous`

- v2: New image created by each individual with latest Tag (frontend source changed in the above process)
> `<< ECR URI >>/eshop-frontend:latest`

**eshop-PaC/eshop/charts/eshop-frontend/templates/deployment.yaml**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-frontend-v1
spec:
  selector:
    matchLabels:
      app: eshop-frontend
  template:
    metadata:
      labels:
        app: eshop-frontend
        version: v1
    spec:
      containers:
        - name: eshop-frontend
          image: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-frontend:previous
          imagePullPolicy: Always
          ports:
          - containerPort: 8080
          resources:
            requests:
              cpu: 100m
              memory: 64Mi
            limits:
              cpu: 200m
              memory: 128Mi
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-frontend-v2
spec:
  selector:
    matchLabels:
      app: eshop-frontend
  template:
    metadata:
      labels:
        app: eshop-frontend
        version: v2
    spec:
      containers:
        - name: eshop-frontend
          image: {{ .Values.global.images.frontend }}
          imagePullPolicy: Always
          ports:
          - containerPort: 8080
          resources:
            requests:
              cpu: 100m
              memory: 64Mi
            limits:
              cpu: 200m
              memory: 128Mi
```

eshop-PaC/eshop/charts/istio-vs/templates/drs.yaml Add DestinationRule and modify the eshop-frontend routing part in VirtualService, which is eshop-PaC/eshop/charts/istio-vs/templates/eshop-vs, and set the traffic weight to 50% for v1 and v2 subsets.
**eshop-PaC/eshop/charts/istio-vs/templates/eshop-vs.yaml**
```yaml
(...생략...)
  - match:
    - uri:
        exact: /
    - uri:
        exact: /favicon.ico
    - uri:
        prefix: /css
    - uri:
        prefix: /js
    route:
    - destination:
        host: eshop-frontend
        subset: v1
        port:
          number: 8080
      weight: 50
    - destination:
        host: eshop-frontend
        subset: v2
        port:
          number: 8080
      weight: 50
```


eshop-PaC/eshop/charts/istio-vs/templates/drs.yaml add.

**eshop-PaC/eshop/charts/istio-vs/templates/drs.yaml**

```yaml
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: eshop-frontend
spec:
  host: eshop-frontend
  trafficPolicy:
    tls:
      mode: DISABLE
  subsets:
  - name: v1
    labels:
      version: v1
  - name: v2
    labels:
      version: v2
```

다음과 같이 입력하여 코드를 커밋하고 푸시한다.

```bash
git add .
git commit -m "frontend canary deploy 50,50"
git push origin main
```

<br>
When you click 'SYNC' at the top of the application details screen, sync is performed and confirm that the existing eshop-frontend deployment is removed and eshop-frontend-v1 and eshop-frontend-v2 are started. (When performing sync, proceed by checking the Prune checkbox.)

![](../media1/argocd-prune-sync.png)

![](../media2/image66.png)

If you access the browser using your domain and refresh it several times, you can see that the old version's screen and the new version's screen are displayed at a similar ratio.

[Existing, v1(previous)]
![](../media2/image67.png)

[신규, v2(latest)]
![](../media2/image68.png)Additionally, connect to the kiali monitoring service and generate the following load.

**load-generator-1**

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl run -i --tty load-generator-1 --rm --image=busybox --restart=Never -- /bin/sh -c "while sleep 0.01; do wget -q -O- http://< < DOMAIN >>; done"
```
> << DOMAIN >> value must be replaced with the FQDN domain of the personal eshop service.

<br>

If you look at the eshop-frontend service in kiali in detail, you can see the traffic flow with the v1 and v2 ratio being almost 50:50.
(Activate Traffic Animation and Traffic distribution in kiali’s Graph item.)

<br>



<br>

### 4-2-2. Canary distribution Complete change to new version

Modify the eshop-frontend routing part in VirtualService of eshop-PaC/eshop/charts/istio-vs/templates/eshop-vs.yaml and change the traffic weight of v1 and v2 subset to 0 and 100.
**eshop-PaC/eshop/charts/istio-vs/templates/eshop-vs.yaml**
```yaml
(...생략...)
  - match:
    - uri:
        exact: /
    - uri:
        exact: /favicon.ico
    - uri:
        prefix: /css
    - uri:
        prefix: /js
    route:
    - destination:
        host: eshop-frontend
        subset: v1
        port:
          number: 8080
      weight: 0
    - destination:
        host: eshop-frontend
        subset: v2
        port:
          number: 8080
      weight: 100
```

Commit and push the code by entering the following:

```
git add .
git commit -m "frontend change v2 weight to 100"
git push origin main
```

Click 'REFRESH' at the top of the ArgoCD Application details screen to confirm that synchronization is complete.

![](../media2/image66.png)

If you refresh your browser several times with a domain mapped to your Istio-Ingressgateway, you can see that only the new (v2, latest) version of the screen is displayed.

[New, v2(latest)]
![](../media2/image68.png)

<br>

### 4-2-3. Rolling back a canary deployment

Due to the canary deployment exercise, two frontend deployments have been created. In the future, when performing challenges, etc., resource shortage issues may occur in the Eshop cluster, so the contents will be rolled back after the canary deployment exercise is completed.

1. Delete the drs.yaml file.

**eshop-PaC/eshop/charts/istio-vs/templates/drs.yaml**

2. Rollback eshop-vs.yaml changes

**eshop-PaC/eshop/charts/istio-vs/templates/eshop-vs.yaml**

- Change the route to be the same as before.

```yaml
(...생략...)
  - match:
    - uri:
        exact: /
    - uri:
        exact: /favicon.ico
    - uri:
        prefix: /css
    - uri:
        prefix: /js
    route:
    - destination:
        host: eshop-frontend
        port:
          number: 8080
```

3. Rollback eshop-frontend/deployment.yaml changes

**eshop-PaC/eshop/charts/eshop-frontend/templates/deployment.yaml**

- Change the part about deployment.yaml to be the same as before.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eshop-frontend
spec:
  selector:
    matchLabels:
      app: eshop-frontend
  template:
    metadata:
      labels:
        app: eshop-frontend
    spec:
      containers:
        - name: eshop-frontend
          image: {{ .Values.global.images.frontend }}
          imagePullPolicy: Always
          ports:
          - containerPort: 8080
          resources:
            requests:
              cpu: 100m
              memory: 64Mi
            limits:
              cpu: 200m
              memory: 128Mi
```

4. Reflect changes on Github

- Commit and push the code by entering the following:

```bash
git add .
git commit -m “rollback canary deployment configure”
git push origin main
```

5. Connect to ArgoCD and perform Prune Sync for eshop application.

- When `Sync`ing Argocd, `Check` `Prune` and then `Sync` it.

![](../media1/argocd-prune-sync.png)


***

## Challenge 4-3

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

Install Argo rollout and deploy Blue/Green using it <a href="./2w-challenge-4-3.md">(Challenge 4-3)</a>

***

<br>

***

## Challenge 4-4

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

Install Argo rollout and deploy Canary using it <a href="./2w-challenge-4-4.md">(Challenge 4-4)</a>

***

<br>

***
## Challenge 4-5

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

Eshop deployment in the EKS Fargate environment, a Serverless Container Service <a href="./2w-challenge-4-5.md">(Challenge 4-5)</a>

***

<br>

***
## Challenge 4-6

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

Additional deployment of new microservice functions. (Provides review function for each product) <a href="./2w-challenge-4-6.md">(Challenge 4-6)</a>

***

<br>
<br>

## **Evaluation**
---
- Configured istio on the EKS cluster.
- Implemented uninterrupted service deployment using Istio.
- Canary distribution was implemented by adjusting the traffic weight.
- We applied the Blue/Green uninterrupted distribution strategy through Argo rollout. (Challenge)
- Experienced in smooth rollback of Blue/Green distribution strategy. (Challenge)
- We have experience deploying eshop in an EKS Serverless (Fargate) environment, and we will check the differences from existing methods to create an optimal environment for each service. (Challenge)
---

<br>

---

😃 **Day 4 completed!!!**

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
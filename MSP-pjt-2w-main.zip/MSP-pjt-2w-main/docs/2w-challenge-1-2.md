## Current status of the program

<br>

## 🤔 Challenge 1-2

### Topic: K8s Secret

<br>

## Apply ECR authentication token as secret instead of configmap and pass data to Jenkins build container

<br>

1. Modify the crontab command section to the contents below:

```bash
0 */6 * * * /home/ubuntu/bin/kubectl config use-context mgmt;/home/ubuntu/bin/kubectl delete secret jenkinscred -n jenkins;/home/ubuntu/bin/kubectl create secret generic jenkinscred --from-literal=ECR_CREDENTIAL_JSON=$(aws ecr get-login-password --region us-east-1) -n jenkins
```

<br>

2. Manually execute the command below once to create a K8s secret.

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl create secret generic jenkinscred --from-literal=ECR_CREDENTIAL_JSON=$(aws ecr get-login-password --region us-east-1) -n jenkins
```

<br>

3. Modify references in the Jenkinsfile of Java-related microservices (modify the configMapKeyRef part to secretKeyRef!!)

```yaml
(...skip...)
     env:
       # Define the environment variable
       - name: CRED
         valueFrom:
           secretKeyRef:
             name: jenkinscred
             key: ECR_CREDENTIAL_JSON
(...skip...)
```

<br>
When using K8S Secret, just change **configMapKeyRef** of spec.containers.env.valueFrom in the above source to **secretKeyRef**. (Secret must be created instead of configMap, and periodic update is required through Crontab as done above.)

<br>

enclosure. Try base64 decoding the saved `jenkinscred` K8s Secret value.

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl -n jenkins get secret jenkinscred -o yaml
```
> First, check the base64 encoded `jenkinscred` secret value and json format.

<br>


✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-114:~$ kubectl -n jenkins get secret jenkinscred -o yaml
apiVersion: v1
data:
  ECR_CREDENTIAL_JSON: (... base64 Encoding 형태로 표출 ...)
kind: Secret
metadata:
  creationTimestamp: "2024-03-14T07:39:51Z"
  name: jenkinscred
  namespace: jenkins
  resourceVersion: "864173"
  uid: 6f9e0b24-838b-4956-aac2-b19d76c2a171
type: Opaque
```

<br>
Using the above command, it was confirmed that it was in the `{.data.ECR_CREDENTIAL_JSON}` Path format. Now that the Path has been confirmed, you can base64 decode the Secret with the command below.

<br>

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl -n jenkins get secret jenkinscred -o jsonpath="{.data.ECR_CREDENTIAL_JSON}" | base64 -d; echo
```
> Base64 decode the `{.data.ECR_CREDENTIAL_JSON}` secret value in base64 encoded state.

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-114:~$ kubectl -n jenkins get secret jenkinscred -o jsonpath="{.data.ECR_CREDENTIAL_JSON}" | base64 -d; echo
eyJw...omitted...MTkwfQ==
```
> `aws ecr get-login-password --region us-east-1` The decoded value will be displayed as a Plain Text value of the ECR Token called with AWS CLI.

<br>

**😃 Challenge Completed!!!**

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
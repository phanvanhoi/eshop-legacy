# **Week 2 (Outer Architecture and GitOps Ops) Day 1**

- [**Week 2 (Outer Architecture and GitOps Ops) Day 1**](#Week 2outer-architecture-and-gitops-ops-Day 1)
- [**Day 1 - Management EKS Cluster environment configuration**](#Day 1---management-eks-cluster-environment-configuration)
   - [❗❗ Precautions during practice on day 1❗❗](#-Day 1-Practice-precautions)
   - [🚨 List of required tasks 🚨](#-Required tasks-list-)
   - [🤔 Day 1 full challenge list 🤔](#-Day 1-full-challenge-list-)
   - [**Lab 1-1. Management environment configuration**](#lab-1-1-management-environment-configuration)
   - [Lab 1-1 practice goal](#lab-1-1-practice goal)
   - [🚨Required Assignment 1-1](#Required Assignment-1-1)
     - [1-1-0. Create S3 bucket for IaC Terraform Backend settings](#1-1-0-iac-terraform-backend-set-for-s3-bucket-creation)
     - [1-1-1. Configuring eshop-mgmt-eks-cluster through Terraform](#1-1-1-eshop-mgmt-eks-cluster-configuration through Terraform)
   - [🚨Required Assignment 1-2](#Required Assignment-1-2)
       - [Connection settings to Admin server (Workstation)] (#admin-Server workstation-Connection-Settings)
       - [Admin server (Workstation) settings] (#admin-serverworkstation-settings)
   - [🚨Required Assignment 1-3](#Required Assignment-1-3)
     - [🗎 Reference. What is ArgoCD?](#-Reference What is argoCD)
   - [Check Argocd initial password](#argocd-initial-password-check)
   - [Challenge 1-1](#Challenge-1-1)
   - [🚨Required Assignment 1-4](#Required Assignment-1-4)
     - [1-1-2. Installing Jenkins for management configured with helm chart through Argocd](#1-1-2-Installing jenkins for management configured with helm chart through argocd)
   - [🚨Required Assignment 1-5](#Required Assignment-1-5)
     - [1-1-3.❗💡※ Argocd, Jenkins security-related work](#1-1-3-argocd-jenkins-security-related-task)
     - [1-1-4. Prepare a source reference for the Modern Application complete with MSA conversion of eshop to be used in future practice in WSL.](#1-1-4-Modern Application- complete with msa conversion of eshop to be used in future practice in WSL. (Prepare source-reference)
   - [**Lab 1-2. Building Gradle CI Pipeline within EKS Management Cluster**](#lab-1-2-eks-management-cluster-building-gradle-ci-pipeline-building)
   - [Lab 1-2 practice goal](#lab-1-2-practice goal)
     - [1-2-1. Check ECR authentication token by executing AWS CLI command](#1-2-1-aws-cli-command-perform-ecr-authentication-token-check)
   - [🚨Required Assignment 1-6](#Required Assignment-1-6)
     - [1-2-2. Utilizing k8s Configmap to actualize ECR Token value in .auth.password, one of jib's required fields](#1-2-2-ecr-token value in authpassword, one of jib's required fields -utilize-k8s-configmap-for-currentization)
     - [Run the Crontab registration script manually once] (#crontab-register-script-manually-run once)
     - [🗎 Reference.Crontab command](#-Referencecrontab-command)
     - [1-2-3. Jenkinsfile final code (adservice example)](#1-2-3-jenkinsfile-final-codeadservice-example)
     - [1-2-4. Jenkins Credential settings (for github access)](#1-2-4-jenkins-credential-settings-github-access)
     - [Create Github Personal Access Token Credential](#github-personal-access-token-credential-create)
     - [1-2-5. Jenkins pipeline configuration](#1-2-5-jenkins-pipeline-config)
   - [Challenge 1-2](#Challenge-1-2)
   - [**Lab 1-3. Establishment of Kaniko CI Pipeline in EKS Management Cluster**](#lab-1-3-eks-management-cluster-in-kaniko-ci-pipeline-construction)
   - [Lab 1-3 practice goal](#lab-1-3-practice goal)
     - [1-3-1. Jenkins web screen access](#1-3-1-jenkins-web screen-connection)
     - [1-3-2. Modify Jenkinsfile (frontend example)](#1-3-2-jenkinsfile-modifyfrontend-example)
     - [1-3-3. Jenkins pipeline configuration](#1-3-3-jenkins-pipeline-config)
   - [🚨Required Task 1-7 (Assignment to solve on your own by referring to the hints, the correct answer will be revealed during Slack or Wrap-Up time during practice)](#Required Task-1-7-Try to solve it on your own by referring to the hints -assignment-practice-during-slack-or-wrap-up-time-answer-disclosed-to-be)
     - [1-3-4. Refer to the hint below and add an ECR Pushable Policy to the eks node group-related role in the eshop-mgmt-IaC Terraform code.](#1-3-4-Refer to the hint below to add eshop-mgmt -Add-ecr-push-enabled-policy to-eks-node-group-related-role in-iac-terraform-code)
     - [1-3-5. Create the next remaining pipelines in the same way.](#1-3-5-Create the next remaining pipelines in the same way)
     - [1-3-6. **Check the difference in the authentication method for AWS ECR between Gradle and Kaniko**](#1-3-6 Check the difference in the authentication method for AWS ECR between Gradle-vs-kaniko)
   - [Challenge 1-3](#Challenge-1-3)
     - [Description of the eshop-MSA-CI complete source used in Challenge 1-3] (#About the eshop-msa-ci-complete source used in Challenge 1-3) explanation)
     - [eshop-MSA vs eshop-MSA-CI](#eshop-msa-vs-eshop-msa-ci)
   - [Challenge 1-4](#Challenge-1-4)
- [ \[list\] ](#-list-)


---


# **Day 1 - Management EKS Cluster environment configuration**

<br>

📌 [Notes to be used during this lab]

📌 [GITHUB]<br>
➕ << GITHUB USER NAME >> : <br>
➕ << GITHUB TOKEN >> : <br>

📌 [AWS Access Key]<br>
➕ << Access key >> : <br>
➕ << Secret Access key >> : <br>

📌 [ECR URI]<br>
➕ << ECR URI >> : <br>

📌 [MGMT VPC Nat Gateway IP]<br>
***Lab 1-1 Required Assignment 1-1 Expressed as output of eshop-mgmt-IaC terraform***<br>
➕ << MGMT VPC Nat Gateway IP >> : <br>

📌 [Argocd Service Endpoint]<br>
***Lab 1-1 Required Assignment 1-3 Displayed after installing Argocd Server***<br>
➕ << ARGOCD ENDPOINT >> : <br>
➕ << ARGOCD PASSWORD >> : <br>

📌 [Jenkins Service Endpoint]<br>
***Lab 1-1 Required Assignment 1-4 Display after installing Jenkins Server***<br>
➕ << JENKINS ENDPOINT >> : <br>
➕ << JENKINS PASSWORD >> : <br>

📌 [S3 Information]<br>
***Name of S3 (Terraform backend) bucket created in Lab 1-1***<br>
➕ <<Personal Bucket>> : <br>

<br>

## ❗❗ Precautions for day 1 practice❗❗

★★★ The Jenkins CI Pipeline configured on Day 1 must be run ‘one at a time’. ★★★

=> Since this is a practice environment, if multiple Jenkins CI Pipelines are executed at once due to insufficient worker node capacity in the MGMT environment, there is a possibility that a hang may occur due to a lack of overall node resources.

<br>

## 🚨 List of required tasks 🚨
1. [IaC] Provisioning of Outer Architecture infrastructure of management infrastructure by performing MGMT IaC (Terraform)
2. [AWS] MGMT VPC environment Workstation server (Admin server) settings
3. [Argocd] Install Argocd in MGMT EKS Cluster environment
4. [Jenkins] MGMT EKS Cluster environment Jenkins installation
5. [Security task] Access control to Argocd and Jenkins installed in the MGMT EKS Cluster environment
6. [K8s Configmap] Application of k8s configmap for current ECR authentication token
7. [AWS IAM] Add ECR Push policy to role related to eks node group in eshop-mgmt-IaC code.

<br>
## 🤔 Full list of challenges for Day 1 🤔
🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

1. [[Test] Perform eshop test deployment in MGMT EKS Cluster environment](#Challenge-1-1) <a href="./2w-challenge-1-1.md"> (Challenge 1-1) </a>

2. [[K8s Secret] Passing data to Jenkins build container by applying secret to ECR authentication token instead of configmap](#Challenge-1-2) <a href="./2w-challenge-1-2.md "> (Challenge 1-2) </a>

3. [[CI Pipeline Automation] Repo separation for each microservice and integration with Blue Ocean CI Pipeline (part that automates CI Pipeline Trigger)](#Challenge-1-3) <a href="./2w-challenge-1 -3.md"> (Challenge 1-3) </a>
   
4. [[CI Pipeline] Link Jenkins CI Pipeline and Slack Notification](#Challenge-1-4) <a href="./2w-challenge-1-4.md"> (Challenge 1-4) </a>

<br>
<br>

## **Lab 1-1. Management environment configuration**

<br>

## Lab 1-1 Practice Objectives
1. Run ‘IaC’ that creates a VPC for management purposes. (Terraform)
2. Install ‘CI/CD tools’ required for management. (Jenkins, Argocd)
3. Perform ‘security settings’ required for the management environment. (AWS Security Group)
4. Proceed with eshop ‘service test deployment’ in the management environment. (🤔 Challenge)

<br>
<br>

## 🚨Required task 1-1
> 1-1-0: Create S3 for Terraform Backend
>
> 1-1-1: mgmt IaC Terraform execution and admin server default settings // Tasks 1 to 3

<br>

### 1-1-0. Create S3 bucket to set up IaC Terraform Backend

<br>

1. Access AWS Console > S3 service.

<br>

![](../media1/S3_create_1.png)

2. After connecting, click ‘Create bucket’.

<br>

![](../media1/s3_create_230607.png)

**A bucket is created by the only S3 person in the world. At the same time, note down the name specified in the `<<Personal Bucket>>` memo value. The bucket type is set to General Purpose and the bucket region is set to us-east-1**

<br>

### 1-1-1. Configuring eshop-mgmt-eks-cluster through Terraform

<br>

[Diagram]
![](../media1/3-1-1.png)

<br>

❗❗ Keep in mind that the environment in which eshop-mgmt-IaC Terraform is run is a ‘WSL environment’❗❗

<br>

❗❗ Precautions regarding EC2 KeyPair to be used in Terraform❗❗

<br>

> During the T3 deployment area exercise process, an EC2 Key Pair named "MyKeyPair" has already been created in the us-east-1 N.Virginia Region, so use it as is unless you delete it separately.
>
>If it has been deleted, create it with the same name as “MyKeyPair” through “Create New KeyPair”, save it, and proceed.

<br>
<br>

❗❗ Precautions regarding IAM Access Key for AWS Configure to be used in Terraform❗❗

> Use the Access Key / Secret Access Key created as the AWS IAM User `mspuser` created during the T3 construction exercise process.
>
> If deleted, a new one is issued and recorded as follows.

<br>

---

<details>
<summary> [🗎 Note - Expand👇] Issuing an access key from IAM</summary>

<br>

- Create an access key issued by the IAM service to call commands to AWS resources through aws-cli in the future.
  
<br>

1. Go to AWS `IAM` service.

![](../media1/2022-03-06-15-09-00.png)


<br>

2. Click ‘Users’ on the left side of the IAM service, and then click the user named **(student: mspuser)** / (instructor: mspmanager).

![](../media1/2022-03-06-15-09-51.png)

<br>

3. Click the `Security credentials` tab and click the `Create access key` button.

![](../media1/2022-03-06-15-10-53.png)

<br>

4. (Step 1) Click `Command Line Interface (CLI)` and
Check ‘I understand the above recommendation and want to proceed to create an access key.’ at the bottom of the screen and press the ‘Next’ button.

![](../media1/2023-01-24-17-300.png)

<br>

5. (Step 2) Press `Create access key` without writing a separate tag value.

![](../media1/2023-01-24-17-330.png)

<br>

6. (Step 3) Click the `Download .csv file` button to save the created key and click `Show` to copy and save it.

📌 Note **Access Key ID and Secret access key** separately.

❗ **Be sure to click the `Download .csv file` button to save it in local storage**. Key information cannot be checked after closing the screen!

![](../media1/2023-01-24-17-350.png)

<br>

</details>

---

<br>
<br>

1. Pre-configuration for mgmt IaC Terraform code execution

Before personalizing the public reference source related to eshop-mgmt-IaC in the `WSL environment`, check the aws configure setting and perform the corresponding task if it is not set.

<br>

[Check aws configure settings]

< WSL environment >
```bash
aws configure list
```

✔ **(Example of execution code/result)**

If it is not set, it is displayed as not set as shown below. In this case, perform the settings below.

```bash
       Name Value Type Location
       ---- ----- ---- --------
    profile <not set> None None
access_key <not set> None None
secret_key <not set> None None
     region <not set> None None
```

<br>

[aws configure settings]

**Be sure to confirm that the individual AWS IAM account that will issue the access key is `mspuser`.**

When working with AWS configure below, enter the value recorded by the individual as the access key id / secret access key of the personal IAM account.

region is not set. (For region and output, skip the input and press the Enter key.)

**It is provided to include the region item in all future AWS CLI scripts, so it is not necessary to set the region item in AWS configure.**

< WSL environment >
```bash
configure aws
```
> After running, enter the Access key and Secret Access key
>
> Use the ‘Access Key’ and ‘Secret Access Key’ issued in the T3 basic course construction area.

<br>

```bash
AWS Access Key ID [****************None]: << Access key >>
AWS Secret Access Key [****************None]: << Secret Access key >>
Default region name [None]: << Enter as is >>
Default output format [None]: << Enter as is >>
```

<br>

❗ Perform Github (Private Repository) personalization
> eshop-mgmt-IaC
>
>---
>
> Reference Reference
>
> <s3://t2hubintern/eshop-mgmt-IaC.tar.gz>

<br>

[Personalize `eshop-mgmt-IaC` reference source]
<span style="color:red">Create a Private Repoistory named `eshop-mgmt-IaC` in your personal Github in advance.</span>

<span style="color:red">※ When creating a repository, be sure to create it as `Private` Type. (Be careful not to create it as a `Public` Type.)</span>

<br>

< WSL environment >
```bash
cd ~
```

<br>

< WSL environment >
```bash
mkdir t3-msp-pjt && cd ~/t3-msp-pjt
```
> Creating and moving the actual MSP PJT workspace directory. For reference, the `t3-msp-pjt` directory created in the current course can be considered the basic workspace directory for the 2nd week practical project practice.

<br>

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/eshop-mgmt-IaC.tar.gz .
```
> Perform reference downloads with AWS S3 Download CLI

<br>


< WSL environment >
```bash
git clone https://github.com/<< GITHUB USER NAME >>/eshop-mgmt-IaC.git
```
> << GITHUB USER NAME >>: Variables are replaced with individual values

<br>

< WSL environment >
```bash
tar xvfz eshop-mgmt-IaC.tar.gz
```
> Decompress references

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-mgmt-IaC
```

<br>

---

<br>

**Install Terraform in your personal WSL environment.**
> 🗎 Note. If the version is not specified separately in the apt-get install terraform command, the latest version is installed.

< WSL environment >
```bash
curl -fsSL https://apt.releases.hashicorp.com/gpg | sudo apt-key add -
sudo apt-add-repository "deb [arch=amd64] https://apt.releases.hashicorp.com $(lsb_release -cs) main"
sudo apt-get update
sudo apt-get install terraform
```

<br>

2. In the mgmt IaC Terraform code, ‘check’ the region where resources will be created, and ‘substitute’ with the S3 bucket name to be used as the terraform backend in the provider.tf source.

<br>

       2-1. Check the region settings inside the terraform.tfvars file.

         - Make sure that “us-east-1” is set in the region setting.
         - Since it is already set in the reference source provided, there is no need to modify it separately.**
terraform.tfvars
```bash
aws_region = "us-east-1" # Specify the region to use
```

<br>

       2-2. Replace the <<personal bucket>> variable in the provider.tf file with the actual bucket name created by the individual. ex) bucket = "mspt3"

         - This is the process of replacing the `<<personal bucket>>` variable inside the `provider.tf` file with a personal value. Be sure to edit the 3rd line of the source code and then delete the 5th line. - If you do not do this, an error will occur during the `terraform init` process.

provider.tf
```bash
terraform {
   backend "s3" {
     bucket = "<<Personal Bucket>>" # Actual name of S3 bucket created by an individual ex) bucket = t3msp
     key = "mgmt/terraform.tfstate" # tfstate file storage path for mgmt infrastructure (fixed value)
     Replace the <<Personal Bucket>> variable in the 3rd line with the actual bucket name created by the individual, and then delete the 5th line as well. ex) bucket = "t3msp" -- (replace the bucket value in the 3rd line of provider.tf && delete the entire current 5th line)
     region = "us-east-1" # region where S3 exists
     skip_s3_checksum=true # Additional parameters starting from Terraform 1.6 or higher
     skip_requesting_account_id=true # Additional parameters starting from Terraform 1.6 and above
   }
   required_version = ">=1.1.3"
}
(...skip...)
```

<br>

**Push changes and confirmations to the sources performed in the previous process to the main branch of the personal Github Repo (eshop-mgmt-IaC).**

https://github.com/<< GITHUB USER NAME >>/eshop-mgmt-IaC
> Since the actual value of << GITHUB USER NAME >> is different for each individual, please note that the url format of each individual github repository is as above.

<br>

< WSL environment >
```bash
git add .
```

<br>

< WSL environment >
```bash
git commit -m "MGMT IaC Init Setting"
```

<br>

< WSL environment >
```bash
git branch -M main
```

<br>

< WSL environment >
```bash
git push -u origin main
```

<br>


3. Creating infrastructure by executing mgmt IaC Terraform code

<br>

Move Terraform Workspace directory<br>
< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-mgmt-IaC
```

<br>

Terraform Workspace Environment Configuration<br>
< WSL environment >
```bash
terraform init
```

<br>

✔ **(Example of execution code/result)**
```bash
Initializing the backend...

Successfully configured the backend "s3"! Terraform will automatically
use this backend unless the backend configuration changes.
Initializing modules...
- eks in eks_module
- sg in sg_module
- vpc in vpc_module
- vpc_endpoints in ep_module

Initializing provider plugins...
- Finding hashicorp/aws versions matching "~> 4.0"...
- Finding latest version of hashicorp/http...
- Finding latest version of hashicorp/tls...
- Installing hashicorp/aws v4.67.0...
- Installed hashicorp/aws v4.67.0 (signed by HashiCorp)
- Installing hashicorp/http v3.4.2...
- Installed hashicorp/http v3.4.2 (signed by HashiCorp)
- Installing hashicorp/tls v4.0.5...
- Installed hashicorp/tls v4.0.5 (signed by HashiCorp)

Terraform has created a lock file .terraform.lock.hcl to record the provider
selections it made above. Include this file in your version control repository
so that Terraform can guarantee to make the same selections by default when
you run "terraform init" in the future.

Terraform has been successfully initialized!

You may now begin working with Terraform. Try running "terraform plan" to see
any changes that are required for your infrastructure. All Terraform commands
should now work.

If you ever set or change modules or backend configuration for Terraform,
rerun this command to reinitialize your working directory. If you forget, other
commands will detect it and remind you to do so if necessary.
```
>If init was performed normally, the above type of text will be displayed, and the following two elements (files and directories registered in .gitignore, so they are in an Untrack state on Github) will be created in the directory where init was performed.
>
> - .terraform directory
> - .terraform.lock.hcl file

<br>

Check Terraform Plan<br>
< WSL environment >
```bash
terraform plan
```

✔ **(Example of execution code/result)**
```bash
(...생략...)
Plan: 44 to add, 0 to change, 0 to destroy.

Changes to Outputs:
  + admin_server_private_ip  = (known after apply)
  + bastion_server_public_ip = (known after apply)
  + mgmt_vpc_id              = (known after apply)
  + my_ip                    = "221.167.219.186"
  + nat_gateway_ip           = (known after apply)
```
>A total of 44 resources will be created, so if the Plan appears, it can be considered normal.

<br>

Run Terraform (type “yes” at the confirmation prompt)<br>
< WSL environment >
```bash
terraform apply
```
> After executing the above command, you must enter “yes” in the prompt window asking whether you want to actually run Terraform.
>
> On the other hand, if you execute the command below, you do not need to enter “yes” separately.
>
> - terraform apply -auto-approve

<br>

After executing Terraform and completing execution (📌time required: approximately 25 to 35 minutes), `admin server's private IP` and `bastion server's public IP` are displayed as output under `Outputs:` as shown below. Additionally, the `My IP` value and the created `MGMT VPC's Nat Gateway's Public IP` are also displayed. These values will be used when setting up the next process or when setting up a connection using a shell connection program such as Mobaxterm, so be sure to record them separately.

🗎 Note. If `My IP` is changed during future practice, if you execute the `terraform refresh` command, the changed `My IP` will be displayed. <br>

<br>

✔ **(Example of execution code/result)**
```bash
(...생략...)
Apply complete! Resources: 44 added, 0 changed, 0 destroyed.

Outputs:

admin_server_private_ip = "10.0.10.201"
bastion_server_public_ip = "3.87.189.54"
mgmt_vpc_id = "vpc-0c5829d7118df6c92"
my_ip = "221.167.219.186"
nat_gateway_ip = "3.231.34.71"
```

<br>

---


🗎 reference. The value of `mgmt_vpc_id` displayed as output is a reference value when performing VPC Peering. This value is required when setting up VPC peering between the Service VPC created on the 2nd day and the currently created MGMT VPC, and does not necessarily need to be recorded.

---

<br>

---

🗎 reference. The value of `my_ip` displayed as output is allowed in the ACL of the MGMT EKS Cluster to be created, allowing API calls from the registered Source IP to the K8s API Server. (public_access_cidrs variable assign part in the source below)

`nat_gateway_ip` The value of will be allowed in the ACL of the Service EKS Cluster to be configured in another region (us-west-2) on the second day and will be used to enable context access in the Multi Region - Multi VPC environment. We recommend that you keep good records of the Terraform Output results.
main.tf
```bash
(...skip...)
module "eks" {
  
   depends_on = [module.vpc]

(...skip...)

   endpoint_private_access = true
   endpoint_public_access = true
   #Allow My IP to public ACL with EKS API Server.
   public_access_cidrs = ["${chomp(data.http.get_my_public_ip.response_body)}/32"]
```

In other words, public access is possible in the ‘Local WSL environment’, and private access is possible through the VPC Endpoint in the ‘admin server created in a VPC in the AWS cloud’. This means that items allowed in the ACL can be accessed through the API Endpoint of MGMT EKS Cluster. (Control possible through kubectl command)
> This means that the K8s Workstation server can be used as a personal WSL environment in addition to the admin server created with EC2.

---

<br>

Additionally, you can check all resources created with Terraform using the state list command as shown below.<br>

< WSL environment >
```bash
terraform state list
```

<br>

---

🗎 Note. When Terraform is completed, the following resources are created.

>[Example]
>```
>IaC Code Performance Details
>1) Create and set up VPC, Subnet, Route Table, and Nat/Internet Gateway for management
>2) Creation and setup of EKS Cluster / EKS Node Group for management
>3) Creation of Admin Server (for performing kubectl) for management, tree, unzip, awscli, terraform, kubectl installed
>```

---

<br>

## 🚨Required assignment 1-2
> 1-1-1 // Task 4

4. After connecting to the Admin EC2 server (Workstation) created by executing the mgmt IaC Terraform code, configure AWS cli and aws configure for EKS Cluster authentication.

<br>

#### Connection settings to Admin server (Workstation)

<br>

After checking the admin server connection method below, connect to the Admin Server created through the Mobaxterm tool.

<br>

Step 1) After running MobaXterm, click the Sessions item in the upper left corner to start creating.

![](../media1/session_create01.png)

<br>

Step 2) Since you are connecting via SSH, click SSH session settings and set the IP for connecting to the admin server in `Remote host value` to the `admin_server_private_ip` value confirmed in the terraform output of the previous process. Check the checkbox for `Specify username` and enter `ubuntu`.

![](../media1/session_create02.png)
> Please note that `10.0.10.114` entered in the remote host in the picture above is only an example of an input value, and in reality, it must be set to the `admin_server_private_ip` value confirmed by the user.

<br>

Step 3) Afterwards, check Use private key in the Advanced SSH settings tab below and specify the location of the ‘MyKeyPair.pem file’.

![](../media1/session_create05.png)

<br>

Step 4) After clicking the Network settings tab, enter `SSH gateway (jump host)` and proceed with Bastion Server related settings. The gateway host value is set to the `bastion_server_public_ip` value confirmed through the terraform output of the previous process.

Additionally, check the `Use SSH Key` checkbox and then specify the location of the `MyKeyPair.pem file`.

![](../media1/session_create03.png)

![](../media1/session_create04.png)
> Please note that the `54.163.144.75` entered in the Gateway host in the picture above is only an example of an input value, and in reality, it must be set to the `bastion_server_public_ip` value you confirmed. The `bastion_server_public_ip` value can be checked with terraform output.

<br>

***For security reasons, avoid using the ID/PW method directly using the root account when connecting via ssh to the bastion server. Therefore, connect using the Key Pair authentication method.***

<br>

After mgmt IaC creation is completed, access to the bastion server is done using the `ubuntu` account and Key Pair (`MyKeyPair.pem`) authentication method.
> Connect to the admin server from the bastion server through ssh tunneling using the `ubuntu` account.

<br>

#### Admin server (workstation) settings

<br>

Below is a guide to performing AWS Configure in Admin Server, a server for workstation purposes built in the AWS EC2 cloud environment.

Register the Access Key and Secret Access Key issued to your IAM account during the third day of the personal `mspuser` T3 construction process.

When working with AWS configure below, enter the value recorded by the individual as the access key id / secret access key of the personal IAM account.

region is not set. (For region and output, skip the input and press the Enter key.)

**It is provided to include the region item in all future AWS CLI scripts, so it is not necessary to set the region item in AWS configure.**

<br>

Perform aws configure settings in `EC2 - Admin Server environment`. For reference, aws configure settings were made in the 'WSL environment' in the previous week 1 process, but this can be seen as a process of additional settings in the 'EC2 - Admin Server environment', which is the workstation server of the management environment newly created today.

<br>


---

🗎 Note. AWS Credential information must be set (aws configure task) to register AWS EKS Cluster (Context) information on the server through AWS CLI.

---
<br>
[Check aws configure settings]

< WSL environment >
```bash
aws configure list
```

✔ **(Example of execution code/result)**

If it is not set, it is displayed as not set as shown below. In this case, perform the settings below.

```bash
       Name Value Type Location
       ---- ----- ---- --------
    profile <not set> None None
access_key <not set> None None
secret_key <not set> None None
     region <not set> None None
```

<br>

[aws configure settings]

**Be sure to confirm that the individual AWS IAM account that will issue the access key is `mspuser`.**

When working with AWS configure below, enter the value recorded by the individual as the access key id / secret access key of the personal IAM account.

region is not set. (For region and output, skip the input and press the Enter key.)

**It is provided to include the region item in all future AWS CLI scripts, so it is not necessary to set the region item in AWS configure.**

< WSL environment >
```bash
configure aws
```
> After running, enter the Access key and Secret Access key
>
> Use the ‘Access Key’ and ‘Secret Access Key’ issued in the T3 basic course construction area.

<br>

```bash
AWS Access Key ID [****************None]: << Access key >>
AWS Secret Access Key [****************None]: << Secret Access key >>
Default region name [None]: << Enter as is >>
Default output format [None]: << Enter as is >>
```

<br>

5. Add mgmt eks cluster context (kubeconfig update) task

After connecting to the Admin Server, proceed with the settings for obtaining MGMT EKS Cluster authentication information.

< EC2 environment - admin server >
```bash
aws eks --region=us-east-1 update-kubeconfig --name=eshop-mgmt-eks-cluster --alias=mgmt
```

<br>

***

🗎 Note. Easily change context with Linux alias

> The process below is set up so that you can easily perform tasks by using abbreviations rather than typing the entire command when multi-context switching in the future, and is an item that is automatically set through user data settings in Terraform mgmt IaC. (Separate work) Since this is not the content to be discussed, `just for reference.`)

<br>

Several environment variables can be specified for each user in the file in the `~/.bashrc` path, and you can check whether they have been added at the bottom of the file. If it is added, it can be considered permanently applied to the session.

< EC2 environment - admin server >
```bash
# check .bashrc
vi ~/.bashrc
```

< EC2 environment - admin server >
```bash
# add alias
alias mc='kubectl config use-context mgmt'
alias ec='kubectl config use-context eshop'
alias ef='kubectl config use-context eshop-fg'

#WhereAmI
alias wai='kubectl config get-contexts'
```

```bash
# Enable (switch to mgmt)
mc
```

```bash
# Use (check current context)
wai
```

***

<br>

## 🚨Required assignment 1-3
> 1-1-1 // Tasks 6 to 9

6. Install Argocd Server in mgmt eks cluster (as LoadBalancer type)

![](../media1/image5.png)

<br>

---

### 🗎 Reference.What is ArgoCD?


[ArgoCD](https://argoproj.github.io/argo-cd/) is a GitOps-based CD Tool that can deploy Kubernetes resources in a declarative manner.

![](../media1/image3.gif)

Source: <https://argoproj.github.io/argo-cd/assets/argocd-ui.gif>

ArgoCD looks at the Repository and deploys any changes to the Kubernetes cluster.

![](../media1/image4.png)

Source: <https://argoproj.github.io/argo-cd/assets/argocd_architecture.png>

---

<br>

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl create namespace argocd
```

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/v2.4.28/manifests/install.yaml
```

***Change the service to LoadBalancer Type and access it in the local environment.***

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl patch service argocd-server -n argocd -p '{"spec": {"type": "LoadBalancer"}}'
```

<br>

## Verify Argocd initial password

7. Check and note the installed Argocd initial password (📌<< ARGOCD PASSWORD >>).

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d; echo
```

<br>

8. Check and note **🤓 Argocd endpoint(📌<< ARGOCD ENDPOINT >>)** for future access and practice.

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl get service -n argocd
```

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-158:~$ kubectl get service -n argocd
NAME                                      TYPE           CLUSTER-IP       EXTERNAL-IP                                                              PORT(S)                      AGE
argocd-applicationset-controller          ClusterIP      172.20.108.198   <none>                                                                   7000/TCP,8080/TCP            7d4h
argocd-dex-server                         ClusterIP      172.20.60.167    <none>                                                                   5556/TCP,5557/TCP,5558/TCP   7d4h
argocd-metrics                            ClusterIP      172.20.10.246    <none>                                                                   8082/TCP                     7d4h
argocd-notifications-controller-metrics   ClusterIP      172.20.122.89    <none>                                                                   9001/TCP                     7d4h
argocd-redis                              ClusterIP      172.20.147.118   <none>                                                                   6379/TCP                     7d4h
argocd-repo-server                        ClusterIP      172.20.243.35    <none>                                                                   8081/TCP,8084/TCP            7d4h
argocd-server                             LoadBalancer   172.20.115.65    a8acd56e127894b888a013646c4a79c6-516718709.us-east-1.elb.amazonaws.com   80:31628/TCP,443:30001/TCP   7d4h
argocd-server-metrics                     ClusterIP      172.20.248.250   <none>                                                                   8083/TCP                     7d4h
```

> The value of the EXTERNAL-IP column of argocd-server can be viewed as an endpoint. In the example above, it can be viewed as `a8acd56e127894b888a013646c4a79c6-516718709.us-east-1.elb.amazonaws.com`.


<br>

---

## Challenge 1-1

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

**Perform eshop test deployment in MGMT EKS Cluster environment** <a href="./2w-challenge-1-1.md"> (Challenge 1-1) </a>

---

<br>
<br>

## 🚨Required Assignments 1-4
> 1-1-2 // Tasks 0~2

### 1-1-2. Install Jenkins for management consisting of helm chart through Argocd

![](../media1/image6.png)


<br>


0. Connect to the Argocd Endpoint identified in the above process through a browser.

<br>

ⓘ When accessing the Chrome browser, click “Advanced” > “Go to site” as shown below.

![](../media1/2022-06-07-19-55-41.png)

![](../media1/2022-06-07-19-56-50.png)

ⓘ argocd connection screen

![](../media1/2022-03-04-19-59-54.png)

<br>

ID
```bash
admin
```

Password<br>
[Check Argocd initial password](#argocd-initial-password-check)


<br>

1. Install using the Jenkins Helm Chart (download the public reference source and configure a personal github private repo to work.)

<br>

Step 1) Personalize Jenkins in the individual `eshop-jenkins` Github Repository.

<br>

❗ Perform Github (Private Repository) personalization
> eshop-jenkins
>
>---
>
> Reference Reference
>
> <s3://t2hubintern/eshop-jenkins.tar.gz>

<br>

[Personalize `eshop-jenkins` reference source]

<span style="color:red">Create a Private Repoistory named `eshop-jenkins` in your personal Github in advance.</span>

<span style="color:red">※ When creating a repository, be sure to create it as `Private` Type. (Be careful not to create it as a `Public` Type.)</span>

<br>

Import `eshop-jenkins` source

< WSL environment >
```bash
cd ~/t3-msp-pjt
```

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/eshop-jenkins.tar.gz .
```

< WSL environment >
```bash
tar xvfz eshop-jenkins.tar.gz
```

< WSL environment >
```bash
rm eshop-jenkins.tar.gz
```

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-jenkins
git init
git add .
git commit -m "initial commit"
git branch -M main

git remote add origin https://github.com/<< GITHUB USER NAME >>/eshop-jenkins.git
```
> << GITHUB USER NAME >>: Variables are replaced with individual values

<br>

< WSL environment >
```bash
git push -u origin main
```
> Push to main branch

<br>

Step2) Add Jenkins’ helm chart repository provided below in argocd settings > repositories.

`https://github.com/<< GITHUB USER NAME >>/eshop-jenkins.git`

![](../media1/argocd_setting_repo_1.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media1/argocd_setting_repo_2.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media1/argocd_setting_repo_3.png)

<br>

Create a new Jenkins application on the argocd web screen.

+New App creation task

Step 1) Enter GENERAL items
|Item|Content|Action|
|------|---|---|
|➕ Application Name | `jenkins` |Copy & Paste|
|➕ Project | `default` |Select select box|
|➕ SYNC POLICY | `Manual` |Select select box (default)|
|➕ SYNC OPTIONS | `AUTO-CREATE NAMESPACE` |Select checkbox|

<br>

Step 2) Enter SOURCE items
|Item|Content|Action|
|------|---|---|
|➕Repository URL | `https://github.com/<< GITHUB USER NAME >>/eshop-jenkins` |Select the select box|
|➕Revision| `main` or `HEAD` |Select select box|
|➕Path| `.` |Select select box|

<br>

Step 3) Enter DESTINATION items
|Item|Content|Action|
|------|---|---|
|➕ Cluster URL | `https://kubernetes.default.svc` |Select select box|
|➕ Namespace | `jenkins` |Copy & Paste|

<br>

Step 4) Helm > VALUES FILES > Select the `values.yaml` select box

<br>

Step 5) Click the CREATE button on the top left

<br>

Step 6) Click the sync button in the created argocd
![](../media1/jenkins-argocd-sync.png)

<br>

---

🗎 Note. https://kubernetes.default.svc Meaning

> It can be viewed as the DNS Name of the API SERVER of the local k8s cluster to which the specific application belongs.
>
> For example, the k8s Cluster where argocd is currently installed is the MGMT EKS Cluster, and from the argocd Application perspective, the API SERVER DNS Name of its local k8s cluster is the API SERVER of the MGMT EKS Cluster.

---

<br>
<br>

---

🗎reference. Jenkins Secret Changes Settings that will be ignored in the argocd UI.

<br>

You can change the Live Manifest by going to the installed jenkins App Details > Manifests > Edit in the Argocd UI. Paste ignoreDifferences below to the same Depth as syncPolicy.

```yaml
ignoreDifferences:
   -kind: Secret
     jsonPointers:
       - /data/jenkins-admin-password
```

---

<br>

2. Check and note the **🤓 Jenkins endpoint (📌<< JENKINS ENDPOINT >>)** for future access and practice.

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl get service -n jenkins
```

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-114:~$ kubectl get service -n jenkins
NAME TYPE CLUSTER-IP EXTERNAL-IP PORT(S) AGE
jenkins LoadBalancer 172.20.137.19 abeea4f18e12b464ab0f669731f60334-282451088.us-east-1.elb.amazonaws.com 8080:31627/TCP 115m
jenkins-agent ClusterIP 172.20.72.167 <none> 50000/TCP 115m
```

> The value of the EXTERNAL-IP column in Jenkins can be viewed as an endpoint. In the example above, it can be viewed as `abeea4f18e12b464ab0f669731f60334-282451088.us-east-1.elb.amazonaws.com`. For reference, Jenkins' Service Port is 8080, so to access it in the above example, call the following URL in the browser to connect. `http://abeea4f18e12b464ab0f669731f60334-282451088.us-east-1.elb.amazonaws.com:8080`

<br>

3. For future access, check and note **🤓 Jenkins initial PW (📌<< JENKINS PASSWORD >>)**.

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl get secret jenkins -n jenkins -o jsonpath="{.data.jenkins-admin-password}" | base64 -d; echo
```

<br>
<br>


---

🗎 Note. How to change Jenkins language settings (Korean => English)
> Basically, the language of Jenkins UI follows the language setting of the browser you are using. In the general case, it will be displayed in Korean like the textbook guide. However, you may need to change the language settings as needed. (For example, Korean => English) In that case, you can change the language settings as follows.

Below is an example of changing to English. After logging in to Jenkins as admin, go to Jenkins Management > System. If you scroll down a bit, you will find the “Locale” item. Enter the `en` value in the Locale field as shown below, then check the checkbox and click “Save.” When you save, you can immediately see that it is changed to English.

![](../media1/jenkins_locale_1.png)

---

<br>


## 🚨Required tasks 1-5
> 1-1-3 full operation


### 1-1-3.❗💡※ Argocd, Jenkins security-related work

As shown below, security tasks can be performed using AWS CLI or in the AWS Console UI. (Choice 1 OR Choice 2) Select one of the two methods to perform the task.

<br>

**❗💡※ (Option 1) Mandatory performance of security-related work. (Working with UI)**

<br>

> After installing Argocd and Jenkins, be sure to perform the following security-related tasks. The task of restricting firewall (Security Group) access to only source IPs that actually require access to each service.

<br>

***

<br>

**Inbound access to Argocd limited (ports 80 and 443)**

<br>

***Inbound settings are required to access argocd web UI only in the student's local development environment***

<br>


Set the Security Group on the Load Balancer of the created argocd.

- Anyone can access without any restrictions as long as they know the Load Balancer endpoint of argocd.
   Strengthen security by setting up a security group to allow access only from specific PCs and environments.

<br>

Step 1) In the AWS console, select ‘Load Balancers’ at the bottom of the EC2 left menu, and select argocd’s Load Balancer from the list that appears on the screen.

<br>

Step 2) Select the Load Balancer whose name is the first part of the Argocd Endpoint URL identified in ‘Task 8 of 1-1-1’.

     *In the case of the picture below, you can see that the first part, a7310f8be46134bcbb69ca83f0ba1c9d, is displayed as the Name in a7310f8be46134bcbb69ca83f0ba1c9d-2044841693.us-east-1.elb.amazonaws.com of the argocd url.*

![](../media1/2022-06-07-16-18-47.png)


<br>

Step 3) Click Security Group ID in Security in the middle of the screen.

![](../media1/image-2022-04-06-21-07-00.png)

<br>

Step 4) Check the Security group ID and Name on the screen above, and click Security group ID.

![](../media1/image-2022-04-06-21-10-50.png)

<br>

Step 5) On the security group details screen, click the `Edit inbound rules` button on the Inbound rules tab.

![](../media1/image-2022-04-06-21-15-43.png)

<br>

Step 6) Change the Inbound rule as shown below and click the `Save rules` button.

     ➖ Delete 2 existing Any Opens as `0.0.0.0/0` for `HTTP` and `HTTPS`

     ➕ To connect from a personal PC, select **`My IP`** as the Source item and add 2 `HTTP` and `HTTPS`

<br>

Step 7) `The addition of this entry is done in advance to prevent errors from occurring during the practice on the second day.` Allow https(443) port for logging in through argocd cli on Admin Server

**Check the nat gateway IP/32** in your personal MGMT VPC and allow that IP value to the Security Group.

---

🗎reference. View the Nat Gateway Public IP of the MGMT VPC in the us-east-1 region created in the previous process AWS CLI

>< WSL environment >
>```bash
>aws ec2 describe-nat-gateways --region us-east-1 | grep PublicIp
>```
>
> Register the public IP of the nat gateway of MGMT VPC (us-east-1) confirmed in the AWS CLI command above to the Security Group. (In other words, the IP confirmed by the above command can be seen as the actual value of the `<< MGMT VPC Nat Gateway IP >>` variable.)
> <br><br><br>
>✔ **(Example of execution code/result)**
>```bash
>$ aws ec2 describe-nat-gateways --region us-east-1 | grep PublicIp
> "PublicIp": "18.209.203.233"
>$
>```
> In the example above, the value of "PublicIp", 18.209.203.233, can be considered the Nat Gateway IP of MGMT VPC.

---

<br>

***

**To perform login via argocd cli on the Admin Server, the Inbound Entry that must be added to the Security Group of Argocd ELB is as follows.**

Source: << MGMT VPC Nat Gateway IP >>/32<br>
Port: 443<br>
Protocol: TCP

***

<br>
<br>

**Limited inbound access to Jenkins (port 8080)**

<br>

***Inbound settings are required to access Jenkins web UI only in the student's local development environment***

<br>

Since anyone can access the created Jenkins Load Balancer without any restrictions, change the Security Group settings.

Step 1) In the AWS Console, select 'Load Balancers' at the bottom of the left menu of EC2, and select Jenkins' Load Balancer from the list that appears on the screen.

<br>

Step 2) Select the Load Balancer whose name is the first part of the Jenkins Endpoint URL identified in ‘Task 2 of 1-1-2’.
  
     *In the picture below, the first part of the jenkins url, aa7279a6d766c4098b65d6e0b8f70024-637012450.us-east-1.elb.amazonaws.com, is displayed as Name*
  
![](../media1/2022-06-14-10-41-00.png)

<br>

Step 3) Click Security Group ID in Security in the middle of the screen.
  
![](../media1/image-2022-04-11-002.png)

<br>

Step 4) Check the Security group ID and Name on the screen above, and click Security group ID.

![](../media1/image-2022-04-11-003.png)

<br>

Step 5) On the security group details screen, click the `Edit inbound rules` button on the Inbound rules tab.
  
![](../media1/image-2022-04-11-004.png)

<br>

Step 6) Change the Inbound rule as shown below and click the `Save rules` button.

     ➖ Delete 1 existing Any Open as `0.0.0.0/0` for `TCP` and `8080 Port`
  
     ➕ To connect from a personal PC, select the Source item as **My IP** and add 1 `TCP`/`8080 Port`


<br>
<br>
<br>


**❗💡※ (Option 2) Mandatory performance of security-related work. (Working with AWS CLI)**
> Since aws configure has been performed in the WSL environment, control of personal AWS cloud resources can be performed through CLI.

<br>

> After installing Argocd and Jenkins, be sure to perform the following security-related tasks. The task of restricting firewall (Security Group) access to only source IPs that actually require access to each service.

<br>

***

<br>

**Inbound access to Argocd limited (ports 80 and 443)**

<br>

1. Remove 80 and 443 Anyopen entries

Command 1) 80 Remove Anyopen

< WSL environment >
```bash
aws ec2 revoke-security-group-ingress \
--region us-east-1 --group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
--query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
--ip-permissions IpProtocol=tcp,FromPort=80,ToPort=80,IpRanges=[{CidrIp=0.0.0.0/0}]
```

✔ **(Example of execution code/result)**
```bash
ubuntu@DESKTOP-JEBSJQ4:~$ aws ec2 revoke-security-group-ingress \
> --region us-east-1 --group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
> --query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
> --ip-permissions IpProtocol=tcp,FromPort=80,ToPort=80,IpRanges=[{CidrIp=0.0.0.0/0}]
ubuntu@DESKTOP-JEBSJQ4:~$
```
> No separate output for performance results

<br>

Command 2) 443 Remove Anyopen

< WSL environment >
```bash
aws ec2 revoke-security-group-ingress \
--region us-east-1 --group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
--query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
--ip-permissions IpProtocol=tcp,FromPort=443,ToPort=443,IpRanges=[{CidrIp=0.0.0.0/0}]
```

✔ **(Example of execution code/result)**
```bash
ubuntu@DESKTOP-JEBSJQ4:~$ aws ec2 revoke-security-group-ingress \
> --region us-east-1 --group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
> --query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
> --ip-permissions IpProtocol=tcp,FromPort=443,ToPort=443,IpRanges=[{CidrIp=0.0.0.0/0}]
ubuntu@DESKTOP-JEBSJQ4:~$
```
> No separate output for performance results


<br>


2. Added 80 and 443 MyIP entries

Command 1) Add 80 MyIP

< WSL environment >
```bash
aws ec2 authorize-security-group-ingress \
--region us-east-1 \
--group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
--query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
--ip-permissions '[{"IpProtocol":"tcp","FromPort":80, "ToPort":80,"IpRanges":[{"CidrIp":"'$(curl https://ifconfig.me )'/32","Description":"http myip"}]}]'
```

✔ **(execution code/result example)**
```bash
ubuntu@DESKTOP-JEBSJQ4:~$ aws ec2 authorize-security-group-ingress \
> --region us-east-1 \
> --group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
> --query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
> --ip-permissions '[{"IpProtocol":"tcp","FromPort":80, "ToPort":80,"IpRanges":[{"CidrIp":"'$(curl https://ifconfig.me)'/32","Description":"http myip"}]}]'
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100    15  100    15    0     0     60      0 --:--:-- --:--:-- --:--:--    60
```
> There is no separate output for the performance results

<br>


Command 2) Add 443 MyIP
< WSL environment>
```bash
aws ec2 authorize-security-group-ingress \
	--region us-east-1 \
	--group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
	--query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
	--ip-permissions '[{"IpProtocol":"tcp","FromPort":443, "ToPort":443,"IpRanges":[{"CidrIp":"'$(curl https://ifconfig.me)'/32","Description":"https myip"}]}]'
```

✔ **(execution code/result example)**
```bash
aws ec2 authorize-security-group-ingress \
> --region us-east-1 \
> --group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
> --query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
> --ip-permissions '[{"IpProtocol":"tcp","FromPort":443, "ToPort":443,"IpRanges":[{"CidrIp":"'$(curl https://ifconfig.me)'/32","Description":"https myip"}]}]'
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100    15  100    15    0     0     75      0 --:--:-- --:--:-- --:--:--    75
```
> There is no separate output for the performance results

<br>

Command 3) 443 MyIP - Add Nat Gateway IP

`The addition of this entry is done in advance to prevent errors from occurring during the second day of practice.` Allow https(443) port for logging in through argocd cli on Admin Server

< WSL environment >
```bash
aws ec2 authorize-security-group-ingress \
	--region us-east-1 \
	--group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
	--query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
	--ip-permissions '[{"IpProtocol":"tcp","FromPort":443, "ToPort":443,"IpRanges":[{"CidrIp":"<< MGMT VPC NAT Gateway IP >>/32","Description":"https nat gw ip"}]}]'
```
> <<MGMT VPC NAT Gateway IP >> The variable value is replaced with the actual IP value of nat_gateway_ip among the terraform output values from the previous process.

✔**(execution code/result example)**
```bash
aws ec2 authorize-security-group-ingress \
> --region us-east-1 \
> --group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
> --query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
> --ip-permissions '[{"IpProtocol":"tcp","FromPort":443, "ToPort":443,"IpRanges":[{"CidrIp":"34.224.162.191/32","Description":"https nat gw ip"}]}]'
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100    15  100    15    0     0     75      0 --:--:-- --:--:-- --:--:--    75
```
> In the example above, you can see that the command was executed by changing the << MGMT VPC NAT Gateway IP >> value to 34.224.162.191.

<br>
<br>


**Inbound access limit to Jenkins (port 8080)**

<br>

1. 8080 Anyopen entry removal

< WSL environment>
```bash
aws ec2 revoke-security-group-ingress \
	--region us-east-1 --group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(jenkins/jenkins)* \
	--query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
	--ip-permissions IpProtocol=tcp,FromPort=8080,ToPort=8080,IpRanges=[{CidrIp=0.0.0.0/0}]
```

<br>


✔ **(execution code/result example)**
```bash
ubuntu@SEAN-OFFICE-LAPTOP:~$ aws ec2 revoke-security-group-ingress \
> --region us-east-1 --group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(jenkins/jenkins)* \
> --query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
> --ip-permissions IpProtocol=tcp,FromPort=8080,ToPort=8080,IpRanges=[{CidrIp=0.0.0.0/0}]
ubuntu@SEAN-OFFICE-LAPTOP:~$
```
> There is no separate output for the performance results

<br>

2. 8080 MyIP Add entry

< WSL environment >
```bash
aws ec2 authorize-security-group-ingress \
	--region us-east-1 \
	--group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(jenkins/jenkins)* \
	--query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
	--ip-permissions '[{"IpProtocol":"tcp","FromPort":8080, "ToPort":8080,"IpRanges":[{"CidrIp":"'$(curl https://ifconfig.me)'/32","Description":"http 8080 jenkins myip"}]}]'
```

<br>

✔ **(execution code/result example)**
```bash
ubuntu@SEAN-OFFICE-LAPTOP:~$ aws ec2 authorize-security-group-ingress \
	--region us-east-1 \
	--group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(jenkins/jenkins)* \
	--query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
	--ip-permissions '[{"IpProtocol":"tcp","FromPort":8080, "ToPort":8080,"IpRanges":[{"CidrIp":"'$(curl https://ifconfig.me)'/32","Description":"http 8080 jenkins myip"}]}]'
ubuntu@SEAN-OFFICE-LAPTOP:~$
```
> There is no separate output for the performance results

<br>
<br>


<details>
<summary> [Options - Expand👇] Specify subdomain for argocd and jenkins using Route53 service </summary>

<br>

After deploying argocd and jenkins on the MGMT EKS Cluster, map the domain to make it easier to remember each endpoint to access so that you can call the domain when accessing in the future.

ex)

argocd : argocd.mspt3.click
jenkins : jenkins.mspt3.click:8080

<br>

Step 1) AWS > Route53 > Personal domain Hosted Zone > Click `Create record`

![](../media1/route53_create_record.png)

※ The number of records already created in the actual student environment may differ from the figure.


<br>


Step 2) Subdomain settings
|Item|Content|Action|
|------|---|---|
|➕Record name | `argocd` or `jenkins` |input|
|➕Record type| `CNAME` |Select select box|
|➕Value| Enter the Service Endpoint identified with the command below for `argocd` or `jenkins`, respectively |Enter|


**argocd**
```bash
kubectl get service -n argocd
```

**jenkins**
```bash
kubectl get service -n jenkins
```

![](../media1/route53_create_subdomain.png)

<br>

Step 3) Actual execution of `Create record`

※ When creating a record in the Route53 service, the domain (subdomain) is propagated for up to 60 seconds. Approximately one minute after registration, try accessing each service using the registered domain.

---

🗎 Note. https://aws.amazon.com/ko/route53/faqs/

> Q. How quickly do changes I make to DNS settings in Amazon Route 53 propagate globally?
>
> Amazon Route 53 is designed to propagate updates to DNS records across a global network of authoritative DNS servers in less than 60 seconds under typical conditions. If the API call returns a list of INSYNC statuses, the change has been propagated successfully to the world.
>
> Caching of DNS resolvers is not under the control of the Amazon Route 53 service; it caches resource record sets based on time to live (TTL). The INSYNC or PENDING status of a change only represents the status of Amazon Route 53's authoritative DNS servers.

---

<br>

</details>

***

<br>
<br>

### 1-1-4. Prepare a Modern Application source reference that has completed MSAization of eshop to be used in future practice in WSL.

<br>

❗ Perform Github (Private Repository) personalization
> eshop-MSA
>
>---
>
> Reference Reference
>
> <s3://t2hubintern/eshop-MSA.tar.gz>

<br>

Based on the reference described above, personalize it as a Private Repoistory on your personal Github. The name of the Private Repository created is `eshop-MSA`.

<br>

※When creating a repository, be sure to create it as `Private`.

<br>


< WSL environment >
```bash
cd ~
```

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt
```
> Go to actual MSP PJT workspace directory

<br>

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/eshop-MSA.tar.gz .
```
> Perform reference downloads with the AWS S3 Download CLI

<br>

[Personalize `eshop-MSA` reference source]

<span style="color:red">Create a Private Repoistory named `eshop-MSA` in your personal Github in advance.</span>

<span style="color:red">※ When creating a repository, be sure to create it as `Private` Type. (Be careful not to create it as a `Public` Type.)</span>

<br>

---

< WSL environment >
```bash
git clone https://github.com/<< GITHUB USER NAME >>/eshop-MSA.git
```
> << GITHUB USER NAME >>: Variables are replaced with individual values

<br>


< WSL environment >
```bash
tar xvfz eshop-MSA.tar.gz
```
> Decompress references


<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-MSA
```
> Go to reference directory

<br>

< WSL environment >
```bash
code.
```
> After running VSCode, you can look at the reference structure.

<br>

[Structure during decompression of eshop-MSA]

![](../media1/eshop-MSA.png)


<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-MSA
```
> Go to reference directory

<br>

< WSL environment >
```bash
git add .
```

<br>

< WSL environment >
```bash
git commit -m "initial commit"
```

<br>

< WSL environment >
```bash
git branch -M main
```

<br>

< WSL environment >
```bash
git push -u origin main
```

<br>
<br>

---

## **Lab 1-2. Establishment of Gradle CI Pipeline within EKS Management Cluster**

![](../media1/image13.png)


<br>

## Lab 1-2 Practice Objectives
1. Build a Gradle CI Pipeline.
2. Apply and understand the Jib build method.
3. Understand how to obtain and implement ECR certification.
4. Configure CI Pipeline in the management environment, build images of Micro Services and push them to ECR.
5. Establish automation of CI Pipeline in the management environment. (🤔 Challenge)
<br>

### 1-2-1. Check ECR authentication token by executing AWS CLI command

<br>

※ Check authentication token


> <WSL environment> or <EC2 environment - admin server>
>```
>aws ecr get-login-password --region us-east-1
>```

<br>

**❗ << Region used >>**

us-east-1 N.Virginia

<br>

**Example code for building an image with gradle jib (no docker daemon) (eshop-backend)**

```bash
cd ~/t3-msp-pjt/eshop-MSA/eshop-backend
```

```bash
./gradlew jib --no-daemon --image << ECR URI >>/<< SERVICE NAME >>:localtest -Djib.to.auth.username=AWS -Djib.to.auth.password=$(aws ecr get-login-password --region us-east-1)
```

<br>

Below is an example code, so you need to personalize the actual variables and run it.

※ 명령어 예시

> < WSL environment >
>```bash
>cd ~/t3-msp-pjt/eshop-MSA/eshop-backend
>```
>```bash
>./gradlew jib --no-daemon --image 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-backend:localtest -Djib.to.auth.username=AWS -Djib.to.auth .password=$(aws ecr get-login-password --region us-east-1)
>```


In the case of Java services, it is possible to push images to the Repository in a convenient way through the jib library, but as shown in the example code above, authentication information must be entered when executing the gradle jib command for it to work.

AWS ecr tokens are only valid for a total of 12 hours as described in the AWS document below.

<https://docs.aws.amazon.com/ko_kr/AmazonECR/latest/userguide/registry_auth.html>

Therefore, it is designed to automate the periodic updating of the Token value in the Config Map of k8s and use it in the Build task after passing the data when starting the jnlp Gradle container.

<br>
<br>

## 🚨Required assignment 1-6
> 1-2-2 to 1-2-5 full operation

### 1-2-2. Utilize k8s Configmap to make ECR Token value current in .auth.password, one of the required fields of jib

Example) ECR Token is renewed every 12 hours, and crontab task of ubuntu account is added to update ConfigMap every 6 hours (4 times a day)

< EC2 environment - admin server >
```bash
0 */6 * * * /home/ubuntu/bin/kubectl config use-context mgmt;/home/ubuntu/bin/kubectl delete configmap jenkinscred -n jenkins;/home/ubuntu/bin/kubectl create configmap jenkinscred --from -literal=ECR_CREDENTIAL_JSON=$(aws ecr get-login-password --region us-east-1) -n jenkins
```

<br>


### Manually run Crontab registration script once

❗❗ The Crontab registration above is a setting for scheduling, so for immediate use, you need to manually run the script below to create a ConfigMap ❗❗

< EC2 environment - admin server >
```bash
kubectl config use-context mgmt
```

<br>

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl create configmap jenkinscred --from-literal=ECR_CREDENTIAL_JSON=$(aws ecr get-login-password --region us-east-1) -n jenkins
```

<br>

---

### 🗎 Reference.Crontab command

1. Crontab query (ubuntu account)

< EC2 environment - admin server >
```bash
crontab -l -u ubuntu
```

2. Edit Crontab (ubuntu account)

< EC2 environment - admin server >
```bash
crontab -e -u ubuntu
```

2-1. When editing, you can use an editor that is convenient for you. (default vim is number 2)

---

<br>


### 1-2-3. Jenkinsfile final code (adservice example)

After modifying the Jenkinsfile, push to the personal Github main branch. <br>
In the case of image tag names (<< TAG >>), it is recommended to create them as `latest`.

---

🗎 Note. Reason for recommending latest TAG name

> If you use the latest tag, the pulling always policy is applied at every deployment and the image with the newly pushed latest tag is pulled from the Image Registry. This must be selected appropriately according to each service operation policy.
>
> When the latest tag is not used, the image pull policy must be separately set to always to ensure proper distribution.
>
> Please refer to the link below for K8s' basic image pull policy.
>
> https://kubernetes.io/ko/docs/concepts/containers/images/#imagepullpolicy-defaulting

---

**eshop-adservice/Jenkinsfile**
```bash
pipeline {
  agent {
    kubernetes {
              yaml """
        apiVersion: v1
        kind: Pod
        metadata:
          labels:
            name: gradle
        spec:
          containers:
          - name: gradle
            image: gradle:6.3.0-jdk11
            command:
            - cat
            tty: true
            env:
              # Define the environment variable
              - name: CRED
                valueFrom:
                  configMapKeyRef:
                    name: jenkinscred
                    key: ECR_CREDENTIAL_JSON
          restartPolicy: Never
        """      
    }
  }
  
  stages {
    stage('build and push docker image') {
                  
      steps {
        container('gradle') {
          dir('eshop-adservice') {
            sh 'gradle jib --no-daemon --image << ECR URI >>/eshop-adservice:<< TAG >> -Djib.to.auth.username=AWS -Djib.to.auth.password=$CRED'  
          }
        }
      }
    }
  }
}
```

<br>

---
**※ 🗎 Note. The configmap is not consumed by kubectl replace, so it is deleted and recreated**

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl delete configmap jenkinscred -n jenkins
```

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl create configmap jenkinscred --from-literal=ECR_CREDENTIAL_JSON=$(aws ecr get-login-password --region us-east-1) -n jenkins
```

---

<br>

---

**➡️ 🗎 Note. Individual tasks completed on Github (Java service)**

https://github.com/<< GITHUB USER NAME >>/eshop-MSA/tree/main/eshop-adservice       
https://github.com/<< GITHUB USER NAME >>/eshop-MSA/tree/main/eshop-backend    
https://github.com/<< GITHUB USER NAME >>/eshop-MSA/tree/main/eshop-cartservice    

---

<br>
### 1-2-4. Jenkins Credential settings (for github access)

<br>

Jenkins fetches source code from github and automatically creates a container for build work. Therefore, information for github access is required.

<br>

### Generate Github Personal Access Token Credential

Select the Jenkins Management > Credentials menu.

![](../media1/jenkins1.png)

<br>

Select Domains (global).

![](../media1/3-2-4.2.png)

<br>

Click the `+ Add Credentials` button at the top right of the screen and enter the following. In Password, enter the `Github Personal Access Token` value created earlier.

<br>

|Item|Content|Action|
|---|---|---|
|➕ Kind | `Username with password`|Select select box|
|➕ Username | `<< GITHUB USER NAME >>`|Input|
|➕ Password |`<< GITHUB TOKEN >>`|Enter|
|➕ ID |`github`|Input|
|➕ Description |`for github login`|Input|
> Note. << GITHUB TOKEN >>: This refers to the Github Developer Token (valid for 60 days) value created during Github setup on the first day. Replace with the recorded value.

<br>

< example picture>
![](../media1/3-2-4.3.jpg)

<br>

Credentials were created as follows.

![](../media1/3-2-4.4.png)

<br>

### 1-2-5. Jenkins pipeline configuration

Create ‘Pipeline’ with the name eshop-adservice.

![](../media1/image18.png)

Select the GitHub project checkbox and enter the URL of the repository you cloned or inited.

![](../media1/image19.png)

Select GitHub hook trigger for GITScm polling as Build Triggers.

![](../media1/image20.png)

Select 'Pipeline script from SCM' in Pipeline settings and enter Git repository information. Credentials use the Personal Access Token created when installing Jenkins. Set the branch to build to ‘*/main’.

![](../media1/image21.png)

Microservices basically configure separate repositories for each service, but since this lab was configured with a single repository, Additional Behaviors are added in the build pipeline to use Sparse Checkout.

Sparse Checkout checks out only the subpaths set when retrieving source code.

Also, set 'Polling Ignores commits in certain paths' so that the build does not run automatically when the source code in other paths is changed. (ex. eshop-adservice/.* )
 
![](../media1/3-2-5-1.png)

Modify the Script Path to build with the Jenkinsfile in the eshop-adservice directory.
 
![](../media1/3-2-5-2.png)

When you save the settings, the eshop-adservice pipeline is created as follows.

![](../media1/3-2-5.7.png)

Create the following pipelines in the same way.

- eshop-backend

- eshop-cartservice

When creating a pipeline, you can clone an existing pipeline by selecting 'New Item' and entering the name of the already created pipeline in 'Copy from' at the bottom. Modify the directory path in the cloned pipeline.

![](../media1/image23.png)

We created a build pipeline as follows.

Execute each created pipeline. You can confirm that the build is performed normally.


❗❗ Precautions

- If the following phrase appears in the Console Output log when running CI Pipeline, wait until the Build Pod is created, as this may take some time depending on the scheduling situation of the MGMT Cluster Pod workload.

```
Still waiting to schedule task
Waiting for next available executor
```

- If an error similar to the following occurs during pipeline execution, try applying solutions 1) and 2) in order from the `## Jenkins` section of Trouble Shooting.

```bash
java.io.IOException
```
   > <a href="../etc/2w-reference-0-trouble_shootings.md"> 2nd week practice environment troubleshooting </a></li>

<br>

***

## Challenge 1-2

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

**Apply secret to ECR authentication token instead of configmap to pass data to Jenkins build container** <a href="./2w-challenge-1-2.md"> (Challenge 1-2) </a>

***

<br>
<br>

## **Lab 1-3. Establishment of Kaniko CI Pipeline within EKS Management Cluster**

![](../media1/image13.png)

<br>

## Lab 1-3 Practice Objectives
1. Build Kaniko CI Pipeline.
2. Apply and understand the Kaniko build method.
3. Understand and apply EKS Node Group’s ECR authentication method.
4. Configure CI Pipeline in the management environment, build images of Micro Services and push them to ECR.
5. Establish automation of CI Pipeline in the management environment. (🤔 Challenge)

<br>
### 1-3-1. Connect to Jenkins web screen

After running the web browser, connect to Jenkins endpoint

### 1-3-2. Edit Jenkinsfile (frontend example)

After modifying the Jenkinsfile under the service directory you want to deploy, push it to the main branch of your personal Github.

**eshop-frontend/Jenkinsfile** 

```groovy
/*
<< 변수 >> 치환 필요

<< ECR URI >>      => ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com
<< TAG >>          => ex) latest
*/
pipeline {
  agent {
    kubernetes {
      yaml """
kind: Pod
spec:
  containers:
  - name: kaniko
    image: gcr.io/kaniko-project/executor:debug
    imagePullPolicy: Always
    command:
    - /busybox/cat
    tty: true
"""
    }
  }
  environment {
    IMAGE_REGISTRY = "<< ECR URI >>"
  }
  stages {
    stage('Build with Kaniko') {
      steps {
        container(name: 'kaniko', shell: '/busybox/sh') {
          dir('eshop-currencyservice') {
            sh '''#!/busybox/sh
            /kaniko/executor \
            --git branch=main \
            --context=. \
            --destination=${IMAGE_REGISTRY}/eshop-frontend:<< TAG >>
            '''   
          }
        }
      }
    }
  }
}
```

<br>
### 1-3-3. Jenkins pipeline configuration

Create the following service in the same way as the job creation task performed on day 3.

Create a ‘Pipeline’ with the name eshop-frontend.

![](../media1/image24.png)

<br>

Select the GitHub project checkbox and enter the URL of the repository you cloned or inited.

![](../media1/image19.png)

<br>

Select GitHub hook trigger for GITScm polling as Build Triggers.

![](../media1/image20.png)

<br>

Select 'Pipeline script from SCM' in Pipeline settings and enter Git repository information. Credentials use the Personal Access Token created when installing Jenkins. Set the branch to build (Branch Specifier (blank for 'any') to '*/main'.

![](../media1/image21.png)

<br>

Microservices basically configure separate repositories for each service, but since this lab was configured with a single repository, Additional Behaviors are added in the build pipeline to use Sparse Checkout.

<br>

Sparse Checkout checks out only the subpaths set when retrieving source code.

<br>

Also, set 'Polling Ignores commits in certain paths' so that the build does not run automatically when the source code in other paths is changed. (ex. eshop-frontend/.* )
 
![](../media1/3-2-5-3.png)

<br>
Modify the Script Path to build with the Jenkinsfile in the eshop-frontend directory.

![](../media1/image26.png)

<br>

When you save the settings, the eshop-frontend pipeline is created as follows.

![](../media1/3-3-3.1.png)

<br>

However, as it stands, you may experience the following error in Kaniko CI Pipeline.

***
![](../media1/image28.png)
***

<br>

## 🚨Required Assignment 1-7 (Assignment to solve on your own by referring to the hints, the answer will be revealed during Slack or Wrap-Up time during practice)
> 1-3-4 full operation

### 1-3-4. Refer to the hint below and add an ECR Pushable Policy to the role related to eks node group in the eshop-mgmt-IaC Terraform code.


Hint 1. Find the required Permission (AWS Policy) in the Kaniko official github path below.
<https://github.com/GoogleContainerTools/kaniko#pushing-to-amazon-ecr>


<br>


Hint 2. In the eks node group related module source below, find the IAM Role, add the necessary policy found above inside the role, and perform terraform apply.

<br>

```
eshop-mgmt-IaC/eks_module/eks-worker-nodes.tf
```

<br>

### 1-3-5. Create the remaining pipelines in the same way.

- eshop-currencyservice

- eshop-productservice

- eshop-recommendservice

When creating a pipeline, you can clone an existing pipeline by selecting 'New Item' and entering the name of the already created pipeline in 'Copy from' at the bottom. Modify the directory path in the cloned pipeline.

![](../media1/image23_kaniko.png)

<br>

We created a build pipeline as follows.

<br>

Execute each created pipeline. You can confirm that the build is performed normally.

![](../media1/image29.png)

<br>

If you check Container Registry in the AWS console, you can see that the images have been built and the repository has been created. (adservice)

![](../media1/image30.png)


<br>

❗❗ Precautions

- If the following phrase appears in the Console Output log when running CI Pipeline, wait until the Build Pod is created, as this may take some time depending on the scheduling situation of the MGMT Cluster Pod workload.

```
Still waiting to schedule task
Waiting for next available executor
```

- If an error similar to the following occurs during pipeline execution, try applying solutions 1) and 2) in order from the `## Jenkins` section of Trouble Shooting.

```bash
java.io.IOException
```
   > <a href="../etc/2w-reference-0-trouble_shootings.md"> 2nd week practice environment troubleshooting </a></li>

<br>

---


<br>

### 1-3-6. **Check the difference in authentication method for AWS ECR between Gradle and Kaniko**

Looking at the differences in the authentication method for each Pipeline attribute of Gradle and Kaniko to the ECR Private Image Repository, the differences are as follows.

<br>

Gradle's authentication method - mspuser (User with full access policy) Authentication is obtained with the Token value obtained through `aws ecr~~` AWS CLI with a key issued through AWS Configure. In other words, since it is authenticated using the Access Key and Secret Access Key, there is no need to add additional ECR-related policies to the IAM Role of the Worker Node.

<br>

Kaniko's authentication method - Since it is a method of authenticating to AWS resources entirely through the IAM role of the Worker Node (EKS Node Group), Push cannot be performed with only the existing Read Only permission, and Write permission must be granted. (Add EC2InstanceProfileForImageBuilderECRContainerBuilds permission)

<br>

---

**➡️🗎 Note. Individual work completed on Github (non-Java service)**

https://github.com/<< GITHUB USER NAME >>/eshop-MSA/tree/main/eshop-currencyservice    
https://github.com/<< GITHUB USER NAME >>/eshop-MSA/tree/main/eshop-frontend    
https://github.com/<< GITHUB USER NAME >>/eshop-MSA/tree/main/eshop-productservice    
https://github.com/<< GITHUB USER NAME >>/eshop-MSA/tree/main/eshop-recommendservice    

---

<br>
<br>

***

## Challenge 1-3

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

**Repo separation for each microservice and integration with Blue Ocean CI Pipeline (part that automates CI Pipeline Trigger)** <a href="./2w-challenge-1-3.md"> (Challenge 1-3) < /a>

<br>

When performing Challenge 1-3, the service source is managed with eshop-MSA-CI, not eshop-MSA.

<br>

---

**🗎 Note. Challenge 1-3 settings completed**<br>
> Download and refer to it through AWS CLI.
>
> <s3://t2hubintern/eshop-MSA-CI.tar.gz>

---

<br>

### Description of the eshop-MSA-CI complete version (Source) used in Challenges 1-3
Service Source Repository for Cloud/MSA CI/CD practice

> The difference from the existing eshop-MSA reference is that the Github Repository for each microservice is managed separately.

### eshop-MSA vs eshop-MSA-CI

![](../media1/Github-MSA-CI.png)

<br>
<br>

***

## Challenge 1-4

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

**Link Jenkins CI Pipeline and Slack Notification** <a href="./2w-challenge-1-4.md"> (Challenge 1-4) </a>

***

<br>


😃 **Day 1 completed!!!**

<br>

⏩ [Move] to the next exercise (2w-2-Production_Configure.md).

<br>
<br>
<br>

# <center> <a href="../README.md">[List]</a> </center>
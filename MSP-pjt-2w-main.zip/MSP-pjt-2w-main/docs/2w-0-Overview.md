# **Week 2 (Outer Architecture and GitOps Ops)**

- [**Week 2(Outer Architecture and GitOps Ops)**](#Week 2outer-architecture-and-gitops-ops)
- [**Week 2 Outer Architecture Overview**](#Week 2-outer-architecture-overview)
     - [Kubernetes](#kubernetes)
     - [AWS EKS](#aws-eks)
     - [Cluster, Context, Namespace](#cluster-context-namespace)
     - [Ingress-controllers](#ingress-controllers)
     - [Certification and Authorization](#Certification and Authorization)
     - [Precautions when conducting practice!!](#Precautions when conducting practice)
- [**Terminology and common variable guide**](#Terminology-and-common variable guide)
- [**Related S3 Information**](#Related-s3-Information)
- [**MSP practical PJT flowchart**](#msp-practical-pjt-flowchart)
- [**Information related to practice performance**](#Practice performance-related-information)
- [**Github-related information**](#github-related-information)
- [**Microservice image tag-related**](#microservice-image-tag-related)
- [**Final completed Outer Architecture structure (all challenges completed)**](#final-completed-outer-architecture-structure-challenge-all-complete)
- [ \[list\] ](#-list-)

---

<br>

# **Week 2 Outer Architecture Overview**

<br>

- Select Kubernetes as an environment that can stably operate MSA applications.

   To conveniently build Kubernetes on AWS, use EKS, a fully managed service. (FMS)

   Divided into an environment for deploying and operating the actual application (eshop-service-cluster) and a management environment for performing tasks for deploying the application (eshop-mgmt-cluster).
- Establishment of management environment/service environment infrastructure on AWS in IaC form => Utilization of terraform
- Automation of a series of tasks such as building the completed source code into an image, pushing it to ECR (CI), and distributing the pushed image to a Kubernetes cluster (CD)
   <br>
   => Automate GitOps-based build/deployment by building a CI/CD pipeline in the management cluster
- A series of tasks to improve observability of the Service Cluster environment (applying multiple OSS monitoring systems)
- Using various AWS services or OSS required for operation in a Service Cluster environment, practice distributed tracking, non-stop deployment, performance management, service pattern analysis, failure management, and inter-architecture connection.

<br>

### Kubernetes

What is Kubernetes?

> Kubernetes background & role: https://kubernetes.io/ko/docs/concepts/overview/
>
> Basic concepts of Kubernetes, containers, and Docker: https://www.samsungsds.com/kr/insights/220222_kubernetes1.html
>
> Kubernetes components: https://www.samsungsds.com/kr/insights/kubernetes-3.html
>
> Kubernetes Glossary: https://kubernetes.io/ko/docs/reference/glossary/?all=true#term-control-plane
>
> kebectl cheat sheet: https://kubernetes.io/ko/docs/reference/kubectl/cheatsheet/


<br>
<br>

### AWS EKS

What is Amazon EKS?
> Amazon Elastic Kubernetes Service (Amazon EKS) is a managed service that eliminates the need to install, operate, and maintain a Kubernetes control plane on Amazon Web Services (AWS). Kubernetes is an open source system that automates the management, scaling, and deployment of containerized applications.

Features of Amazon EKS
>Key features of Amazon EKS include:
> <br><br>
>**Secure Networking and Authentication**
>
>Amazon EKS integrates Kubernetes workloads with AWS networking and security services. It also provides authentication for Kubernetes clusters through integration with AWS Identity and Access Management (IAM).
> <br><br>
>**Easy cluster scaling**
>
>Amazon EKS makes it easy to scale your Kubernetes cluster based on workload demands. Amazon EKS supports horizontal pod autoscaling based on CPU or custom metrics, and cluster autoscaling based on overall workload demand.
> <br><br>
>**Managed Kubernetes experience**
>
You can make changes to your Kubernetes cluster using >eksctl, the AWS Management Console, AWS Command Line Interface (AWS CLI), API, kubectl, and Terraform.
> <br><br>
>**High Availability**
>
>Amazon EKS provides high availability for the control plane across multiple Availability Zones.
> <br><br>
>**Integration with AWS services**
>
>Amazon EKS integrates with other AWS services to provide a comprehensive platform for deploying and managing containerized applications. You can also easily troubleshoot your Kubernetes workloads through a variety of observability tools.

Reference link. https://docs.aws.amazon.com/ko_kr/eks/latest/userguide/what-is-eks.html

<br>
<br>

### Cluster, Context, Namespace

- Cluster: A set of worker machines called nodes that run containerized applications. Every cluster has at least one worker node.

   Worker nodes host pods, the components of an application. The control plane manages worker nodes and pods within the cluster.

   The control plane maintains the cluster in the desired state, such as which applications to run and which container images the applications will use.
   
   Nodes actually run applications and workloads.

- Namespace: An abstract concept used in Kubernetes to support isolation of resource groups within a cluster.
 
   A namespace provides a way to organize a cluster's objects and separate the cluster's resources.

- Context: An environment for accessing the cluster and a work area for delivering commands to the Kubernetes Cluster.

   Once your cluster, users, and context are defined in one or more configuration files, you can quickly make changes to your cluster using the kubectl config use-context command.

   The file used to configure access to the cluster is called the kubeconfig file (default: $HOME/.kube/config).
   
   The kubectl command-line tool uses the kubeconfig file to find the information it needs to select a cluster and communicate with the cluster's API server.

<br>

Update cluster information created in kube config (context specified through alias)

```bash
aws eks update-kubeconfig --region=<< region name >> --name=<< cluster NAME >> --alias=<< specify alias >>
```

<br>

### Ingress-controllers

- What is Ingress?
> An object that can receive traffic such as service calls from outside the K8s Cluster.

For Ingress resources to function, K8s Cluster requires a running Ingress-controller.

- As a project, Kubernetes supports and maintains Ingress-controller implementations developed by several vendors, including AWS, GCE, and nginx.
> <https://kubernetes.io/ko/docs/concepts/services-networking/ingress-controllers>

<br>

example. Week 1 practice: ingress controller used in Minikube environment
- The NGINX Ingress Controller for Kubernetes works with the NGINX webserver (as a proxy).
> https://www.nginx.com/products/nginx-ingress-controller

<br>
<br>


### Certification and Authorization
||Authentication|Authorization|
|------|---|---|
|Function |Check Credentials|Grant/Deny Permissions|
|How it works|Password, biometric, one-time pin or app, token|Use settings managed by your security team (e.g. Istio AuthorizationPolicy)|


- Authentication: Access is permitted when appropriate credentials are entered in relation to the selected authentication requirements.
   <br>
   **abbreviation) authn**

- Authorization: When authentication is completed, permission to access files for each authenticated entity is granted.
   <br>
   ex) When company executives and employees access an authorized system, the information they can access is limited for each department they belong to.
   <br>
   **abbreviation) authz**

- It is necessary to build an environment that can support certification and authorization. (AWS IAM, AWS Key, Istio AuthX)

<br>
<br>

### <span style="color:red">Precautions</span> during practice!!

- Be sure to check whether the `github developer token` (name: `t2_hub`) issued during the T3 construction process is valid.

- When connecting to the git repository, two types of authentication information are used: username and `github developer token`. Please note that personal github password information is not used. (In other words, I think it only uses tokens.)

- When unsaved changes occur in VSCode, a '●' mark appears to the right of the file name at the top. This means ***changes have not been saved***, so make sure to save before performing the operation. Keep in mind.
  
- Check the EC2 vCPU Limit values for each of the two AWS regions (us-east-1, us-west-2) that will be used in the experiment. Check if it is set to `32` or higher.

<br>

---

🗎 Note. Adjust vCPU Limit value
   > << How to tune vCPU >>
   >
   > Search for `Service Quotas` in the AWS console and move the service
   >
   > Click `AWS services` on the left menu > Select `Amazon Elastic Compute Cloud (Amazon EC2)` from the list on the right
   >
   > Search for `Running On-Demand Standard (A, C, D, H, I, M, R, T, Z) instances` (Code: L-1216C47A)
   >
   > If the `Applied quota value` is less than 32, click `Request quota increase` and set it to 32 and click Request.

---

<br>

- The environment to be executed in the command line command code block is classified as WSL or Admin Server, so check before executing it.

<br>
<br>



# **Terminology and common variable information**

<br>

※ EKS Cluster for management: MGMT EKS Cluster

※ Service EKS Cluster: Service EKS Cluster

※ OSS: Open Source Software

※ << ECR URI >>: URI of ECR Repository in personal AWS account
> ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com

※ << SERVICE NAME >>: (directory) name of the microservice
> ex) eshop-backend

※ << TAG >>: Tag of image in each Image Repository
> ex) latest

※ << GITHUB USER NAME >>: Refers to personal Github username.

※ << DOMAIN >>: FQDN (Fully Qualified Domain Name) of each individual eshop service
> ex) eshop.mspt3.click

※ << DOMAIN NAME >>: Name of the domain issued by the individual through the Route53 service (Hosted Zone name)
> ex) mspt3.click

※ << MyIP >>: Public IP of the network environment where practice is performed
> If you search for ‘IP address’ in Naver, you can search for the public IP address of each individual network environment.
> You can also check by accessing the `https://api.ipify.org` URL in your browser.

※ In addition, all items that exist in the form of `<< >>` are variable parts, so individual values must be entered to suit the environment.
> You can check it by searching for the `<<` symbol in VSCode. When searching within one page, use the shortcut keys `ctrl + f`, and when searching the entire folder, use the shortcut keys `ctrl + shift + f`.

<br>

# **Related S3 Information**

The materials for reference in the 2nd week of eshop GitOps ‘construction process (days 1 to 2)’ are as follows.

**(IaC) MGMT EKS Cluster IaC**

<br>

<s3://t2hubintern/eshop-mgmt-IaC.tar.gz>

※ eshop-mgmt-IaC: IaC Terraform code reference for configuring MGMT VPC and EKS Cluster

<br>

**(IaC) Service EKS Cluster IaC(IaC Pipeline)**

<br>

<s3://t2hubintern/eshop-service-IaC.tar.gz>

※ eshop-service-IaC: IaC Terraform code reference for configuring SERVICE VPC and EKS Cluster

<br>

**(Etc) Jenkins Helm Chart**
<br>
<s3://t2hubintern/eshop-jenkins.tar.gz>

※ eshop-jenkins: Jenkins Helm Chart reference to be used for CI Pipeline configuration practice.

<br>

**(Etc) Istio Helm Chart**

<br>

<s3://t2hubintern/eshop-istio.tar.gz>

※ eshop-istio: Service Mesh implementation istio reference to be used in practice.

<br>

**(Service) eshop MSA conversion complete status and Jenkins file addition Service**
<br>
<s3://t2hubintern/eshop-MSA.tar.gz>

※ eshop-MSA: Reference to the MSA version completed in week 1 and the k8s manifest definition for distribution to the cloud.

<br>


**(Service) eshop MSA conversion completion status and Jenkinsfile branch service for each microservice**

<br>

<s3://t2hubintern/eshop-MSA-CI.tar.gz>

※ eshop-MSA-CI: When completing the first day challenge, reference to the separate repository for each microservice

<br>
<br>

Additional reference materials for the 2nd week eshop GitOps ‘Operation Process (Days 2 to 5)’ are as follows.

<br>

※ eshop-PaC: eshop’s final PaC form repository name

<br>

**(Service PaC) eshop final operation form Service Repo (Istio, Helm, metrics-server installed and applied version, completed on day 2)**

<br>

<s3://t2hubintern/2nd_eshop-PaC.tar.gz>

<br>

**(Service PaC)eshop final operational form of Service Repo (Istio, Helm, OSS full installation application completed version, completed on the 3rd day)**
<br>
<s3://t2hubintern/3rd_eshop-PaC.tar.gz>

<br>

Reference materials for the 2nd week eshop GitOps <span style="color:red">🤔 Challenge</span> are as follows.

**(IaC) Service EKS Cluster IaC(IaC Pipeline)**

<br>

<s3://t2hubintern/eshop-service-IaC-oauth2.tar.gz>

> IaC Terraform code reference to configure existing SERVICE VPC and EKS Cluster and create additional RDS resources for Keycloak

<br>

**Service Repo (Istio, Helm) of (Service PaC)eshop final operation form + Keycloak Oauth2 authentication applied, final completed**

<br>

<s3://t2hubintern/chal_3-1_eshop-PaC.tar.gz>

> Challenge 3-1 completed PaC

<br>

**Completion of all challenges by the 5th day of (Service PaC)eshop final operational service repo (Istio, Helm)**

<br>

<s3://t2hubintern/5th_eshop-PaC.tar.gz>

> Complete all challenges PaC

<br>
<br>

# **MSP practical PJT flowchart**

![](../media1/image1.png)

<br>
<br>

# **Information on practice performance**

🚨 Required tasks
> Be sure to carry out this task as it is a must-perform task on the day of practice and during the future practice process.

<br>

🤔 Challenges
> On the day of practice and during the future practice process, practice additional methods that are different from the required tasks, and perform them when time allows.

<br>

📌 Notes
> Actual values of individually saved variables to be used in the day's practice course (required tasks/challenges) or reference script.

<br>

🗎 Note
> This section describes commands and notes related to practice execution. Use for simple reference.

<br>

# **Github-related information**
<br>

- All reference sources provided are personalized and used in a personal Github repository.
- When personalizing, you must create and utilize a `Private` Type Repository.


<br>
<br>


# **Related to microservice image tags**

❗ It is recommended that the image tag to be reflected to be used in the service during actual project practice is latest.

<br>

Please refer to the link below for the basic image pull policy.

https://kubernetes.io/ko/docs/concepts/containers/images/#imagepullpolicy-defaulting

> If you use the latest tag, the pulling always policy is applied at every deployment and the image with the newly pushed latest tag is pulled from the Image Registry. This must be selected appropriately according to each service operation policy.

<br>
<br>

# **Finally completed Outer Architecture structure (all challenges completed)**

![](../media1/AWS-2w-5-fin.drawio-datadog.png)


<br>
<br>
<br>

---

<br>

⏩ [Move] to the next exercise (2w-1-Management_Configure.md).

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
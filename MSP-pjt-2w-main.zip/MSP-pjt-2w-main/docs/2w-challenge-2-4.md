## Current status of the program

<br>

## 🤔 Challenge 2-4

### Topic: Helm Chart

<br>

## Observability-related OSS download (Helm Pull) in Helm Chart format

<br>

## Practice Objectives
- Download the monitoring OSS Helm Chart template using the Helm command.

- Check how the separately provided compressed files for each individual OSS Helm Chart are created.

<br>


❗❗ Caution <br>
This course is only for practicing pulling the Helm Template, and does not reflect the actual pulled Helm Chart Template in eshop-PaC. (Only Helm Pull practice)


<br>

< WSL environment >

Based on Jaeger among OSS, try downloading a new version as a templated file using various Helm commands such as `helm repo add` and `helm search` and then `helm pull`.

> AS-IS) 1.20.0 (currently available app version)
>
> TO-BE) 1.37.0

<br>

Prior) Check whether the Helm Client in the Admin Server is installed normally.

Day 1 Just check whether the installation was successful using the User Data in the mgmt IaC Terraform code.

< EC2 environment - admin server >
```bash
helm version
```

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-201:~$ helm version
WARNING: Kubernetes configuration file is group-readable. This is insecure. Location: /home/ubuntu/.kube/config
WARNING: Kubernetes configuration file is world-readable. This is insecure. Location: /home/ubuntu/.kube/config
version.BuildInfo{Version:"v3.8.2", GitCommit:"6e3701edea09e5d55a8ca2aae03a68917630e91b", GitTreeState:"clean", GoVersion:"go1.17.5"}
```
> You can ignore the WARNING statement, and if the version information comes out as 3.8.2, it can be considered as a normal installation.

<br>

[Helm Chart - jaeger Pull example]

1. Add Helm Repo.

< WSL environment >
```bash
helm repo add jaegertracing https://jaegertracing.github.io/helm-charts
```

<br>

2. Check the added Helm Repo.

< WSL environment >
```bash
helm repo list
```

> Results
>```
> NAME URL
>
> jaegertracing/jaeger https://jaegertracing.github.io/helm-charts
>```

<br>

3. Check the detailed information of the Helm repo currently added to personal WSL. (The latest version as of now is displayed.)

< WSL environment >
```bash
helm search repo jaegertracing/jaeger
```

> Results
>```
> NAME CHART VERSION APP VERSION DESCRIPTION
> jaegertracing/jaeger 0.65.4 1.39.0 A Jaeger Helm chart for Kubernetes
>```

<br>

4. Perform the task to retrieve the Helm template file.
In general, if you use the helm pull command without a separate version parameter, the latest version is pulled.

< WSL environment >
```bash
mkdir ~/t3-msp-pjt/helm
cd ~/t3-msp-pjt/helm
helm pull jaegertracing/jaeger
```

> Example results
>```
> => jaeger-0.65.4.tgz Downloaded (A newer version may be released than at the time the textbook was written, so a higher version may be downloaded.)
>```

<br>

---

🗎 Note. Helm pull by version.
>
>(List of all chart versions and OSS versions)
>
>< WSL environment >
>```bash
>helm search repo jaegertracing -l
>```
>
>(Pull a specific chart version, example: jaeger chartver: 0.61.0 // appver: 1.37.0 version)
>
>< WSL environment >
>```bash
>helm pull jaegertracing/jaeger --version 0.61.0
>```

---

<br>

5. Unzip the compressed file.

< WSL environment >
```bash
tar xvfz jaeger-0.61.0.tgz
```

<br>

6. Verify the downloaded Helm template form.

< WSL environment >
```bash
cd ~/t3-msp-pjt/helm/jaeger
#Below is the template verification
helm lint .
#Below is Helm rendering verification (meaning overriding with a yaml file after -f)
helm template. -f values.yaml
```

> Results
> The results below show no significant differences.
>```
> ==> Linting.
> 1 chart(s) linted, 0 chart(s) failed
>```

If no errors are displayed in both the lint and template commands, they can be considered normal.


<br>


7. Run and work with VS Code to set the latest Helm settings.


< WSL environment >
```bash
cd ~/t3-msp-pjt/helm/jaeger
code.
```

<br>


![](../media1/image26_1.png)

<br>

---

🗎 Note. Helm command
> <https://helm.sh/ko/docs/helm/helm/>

---

<br>

**😃 Challenge Completed!!!**

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
## Current status of the program

<br>

## 🤔 Challenge 3-4

### Topic: Observability

<br>

📌 [Additional notes to use during challenges]

📌 [rabbitmq management UI DOMAIN information (challenge)]<br>
***ELB DNS Name of rabbitmq Management UI LoadBalancer Type***<br>
➕ << rabbitmq management CLB DNS Name >> : <br>

<br>

## RabbitMQ version minor upgrade and management UI monitoring environment construction

<br>

Hipster Shop (eshop) is an online shopping mall where you can purchase a variety of products.

The management of Hipster shop (eshop) has moved the service to **public cloud** and **container-based microservice** and is operating it somewhat stably.

During operation, it was detected that the rabbitmq server reached `Memory Watermark` after a certain period of time after deploying or restarting the entire service, and the entire rabbitmq cluster was experiencing hangs.

reference. Memory and watermark default settings in rabbitmq
https://www.rabbitmq.com/memory.html

There were requirements for ‘monitoring enhancement’ and ‘version up’ specialized for rabbitmq, a component related to the asynchronous function of Hipster shop (eshop).

The requirements for version upgrade are as follows.
  - There is a bug in 3.8.9 currently in use that causes a 'memory leak' when processing certain business logic of eshop.
  - 3.11.4, an improved minor upgrade version, is a version in which all relevant issues are resolved and a ‘version minor upgrade’ is required.

The requirements for the monitoring system are as follows.

  - The monitoring system must be easily accessible from the outside (operator environment) as if accessing a service endpoint (domain or load balancer name).
  - There must be inbound restrictions so that access is only possible from the `Operation Team Internal IP Bound`.
 

In summary, the goals of the operation team are as follows.
  - Related keywords: version upgrade (error improvement), strengthening monitoring
  - Minor upgrade of the version of rabbitmq currently in use from `3.8.9` to `3.11.4`
  - Strengthen rabbitmq-specific monitoring by exposing rabbitmq management UI to `HTTP*(80) port of Load Balancer Type` in AWS EKS Cluster.
  - The monitoring environment is ‘restricted’ to allow access only to the IP (MyIP) of the operation team that is absolutely necessary.

<br>
<br>


## solution

<br>

<details>
<summary>[Performance 1 - Expand👇] Change rabbitmq helm chart deployment (version upgrade)</summary>

<br>

Upgrade the version of the image. At this time, you need to select an image version with management functions.

Existing 3.8.9 => 3.11.4 (including management function)

Change `image` in the deployment definition as shown below.

**eshop-PaC/eshop/charts/rabbitmq/templates/deployment.yaml**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
   name: rabbitmq
spec:
   selector:
     matchLabels:
       app: rabbitmq
   template:
     metadata:
       labels:
         app: rabbitmq
     spec:
       containers:
       - name: rabbitmq
         image: rabbitmq:3.11.4-management-alpine
         ports:
         - containerPort: 5672
```
</details>


<br>


<details>
<summary>[Performance 2 - Expand👇] Change rabbitmq helm chart service (monitoring strengthening)</summary>

<br>

Internal communication should be possible through port 5672 as before, and port 15672 for the management UI is added as a service port.

Add content to the file below.

**eshop-PaC/eshop/charts/rabbitmq/templates/service.yaml**

[addition]
```yaml
---
apiVersion:v1
kind: Service
metadata:
   name: rabbitmq-management
spec:
   type: LoadBalancer
   selector:
     app: rabbitmq
   ports:
   - port: 80
     name: management
     targetPort: 15672
```


[Completed version]

```yaml
apiVersion:v1
kind: Service
metadata:
   name: rabbitmq
spec:
   type: ClusterIP
   selector:
     app: rabbitmq
   ports:
   - port: 5672
---
apiVersion:v1
kind: Service
metadata:
   name: rabbitmq-management
spec:
   type: LoadBalancer
   selector:
     app: rabbitmq
   ports:
   - port: 80
     name: management
     targetPort: 15672
```

</details>

<br>

<details>
<summary>[Performance 3 - Expand👇] Sync operation through Argocd</summary>

<br>

If a change has occurred in the manifest for the eshop rabbitmq helm chart and it has been merged into Github's main branch, the defined resources are created through Argocd's Sync.

</details>

<br>

<details>
<summary>[Execution 4 - Expand👇] Limit LoadBalancer Inbound</summary>

<br>

http://<< rabbitmq management CLB DNS Name >>

change Security Group of CLB
-) 0.0.0.0/0 80
+) MyIP/32 80

</details>

<br>

<details>
<summary>[Performance 5 (Optional) - Expand👇] Assign Subdomain to LoadBalancer DNS Name</summary>

<br>

Connect to the personal domain `Hosted Zone` of the Route53 service and perform `Create Record`.

> |Item|Content|
> |---|---|
> |➕ Record name | `eshop-rabbitmq` |
> |➕ Record type | `CNAME` |
> |➕ Value |`CLB's DNS Name`|

</details>

<br>

After performing all of the solution methods, the final DNS Name confirmation method is calculated as follows.

[Within eshop context]
```
kubectl get svc -n eshop | grep rabbitmq-management
```

<br>

Access the calculated Load Balancer DNS Name or domain (eshop-rabbitmq. personal domain). As before, both id and pw can be accessed as guests.

>❗❗However, during this process, you can set up access to istio's Virtual Service rather than access mapping to Public ELB. For detailed settings, please check the challenge reference below.
>
> When registering as istio's Virtual Service, you can access the RabbitMQ Management UI through a TLS (HTTPS) call and utilize various authentication and authorization-related security functions of the istio service mesh implementation.
>
> Note. rabbitmq management domain example
>
> <https://eshop.mspt3.click/rabbitmq/>
>
> <br>
>
> ❗❗ Refer to the final challenge when applying rabbitmq management UI istio Virtual Service ❗❗
>
>

<br>

In the actual eshop website UI, when you place an item in the cart and place an order, you can detect changes in Message Rates.

<br>

In addition, the actual usage of Nodes' Memory (WaterMark value can also be checked), which was a requirement of the project, can be checked in real time every 5 seconds.

<br>

![](../media2/Week 4-Challenge.png)

<br>

Detailed monitoring of the `eshop-queue` topic is possible (publish, consuming, ack status, bytes per message, etc.)

<br>

![](../media2/Week 4-Challenge_0.png)

<br>
<br>

## Access URL after construction

Service URL <br>
https://<< DOMAIN >>

rabbitmq management URL <br>
http://eshop-rabbitmq.<< DOMAIN NAME >>

<br>

**😃 Challenge Completed!!!**

<br>

---


<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
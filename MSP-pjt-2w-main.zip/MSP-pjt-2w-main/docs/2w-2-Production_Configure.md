# **Week 2 (Outer Architecture and GitOps Ops) Day 2**

- [**Week 2 (Outer Architecture and GitOps Ops) Day 2**](#Week 2outer-architecture-and-gitops-ops-Day 2)
- [**Day 2 - Service EKS Cluster IaC environment configuration and operation system construction**](#Day 2---service-eks-cluster-iac-environment-configuration-and-operation system construction)
   - [🚨 List of required tasks 🚨](#-Required tasks-list-)
   - [🤔 Day 2 Full Challenge List 🤔](#-Day 2-Full-Challenge-List-)
   - [**Lab 2-1. Service EKS Cluster Environment Infra Provisioning**](#lab-2-1-service-eks-cluster-environment-infra-provisioning)
   - [Lab 2-1 practice goal](#lab-2-1-practice goal)
   - [🚨Required Assignment 2-1](#Required Assignment-2-1)
     - [2-1-1. github repository configuration](#2-1-1-github-repository-configuration)
   - [❗❗❗](#)
     - [2-1-2. Create a pipeline for deploying Service EKS Cluster in Jenkins] (#2-1-2-jenkins-create pipeline for deployment of service-eks-cluster)
   - [Challenge 2-1](#Challenge-2-1)
     - [2-1-3. Service EKS Cluster Creation (Step 3 of 2-1-2 📌Time required: Approximately 25 to 35 minutes)](#2-1-3-service-eks-cluster-Creation-Step 3 of 2-1-2 Course-Time required-approximately 25--35 minutes)
     - [2-1-4. Add newly created Service EKS Cluster to argocd](#2-1-4-add newly-created-service-eks-cluster to argocd)
   - [Challenge 2-2](#Challenge-2-2)
   - [**Lab 2-2. Service Mesh deployment in Service EKS Cluster environment**](#lab-2-2-service-eks-cluster-environment-service-mesh- deployment)
   - [Lab 2-2 Practice Goals](#lab-2-2-Practice Goals)
   - [Notes](#Notes)
     - [Service Mesh, Sidecar, istio conceptual introduction](#service-mesh-sidecar-istio-conceptual-introduction)
     - [Istio Traffic Management](#istio-traffic-management)
     - [Use of Istio Side Car Pattern](Use of #istio-side-car-pattern)
     - [metrics-server](#metrics-server)
     - [2-2-0. ❗❗❗Things to do before starting Lab 2-2❗❗❗](#2-2-0-lab-2-2-Things to do before starting)
   - [🚨Required Assignment 2-2](#Required Assignment-2-2)
     - [2-2-1. Install Istio](#2-2-1-istio-install)
     - [❗❗ AWS ACM-related precautions❗❗](#-aws-acm-related-cautions)
     - [2-2-2. Setting up istio-ingressgateway](#2-2-2-istio-ingressgateway-setting)
     - [2-2-3. After performing istio deployment, set Route53 Record, confirm access, and delete application](#2-2-3-istio-distribute-perform-set-route53-record-then-access-check-then-delete-application)
   - [**Lab 2-3. Deploying the eshop application as a Helm chart**](#lab-2-3-eshop-application as a Helm chart)
   - [Lab 2-3 practice goals](#lab-2-3-practice goals)
   - [Lab 2-3 Practice Goals Structure Chart](#lab-2-3-Practice Goals-Structure Chart)
   - [Notes](#Notes-1)
     - [Helm Chart](#helm-chart)
     - [Learn about Helm Chart format](#helm-chart-format-Learn about)
     - [Disadvantages of operating a service with K8s yaml manifest] (#Disadvantages of operating a service with k8s-yaml-manifest)
     - [Two representative advantages of Helm Chart](#Two representative advantages of Helm Chart)
   - [🚨Required Assignment 2-3](#Required Assignment-2-3)
     - [2-3-1. Configure eshop-PaC in Helm Chart form](#2-3-1-eshop-pac in Helm Chart form)
     - [❗❗ Precautions when creating eshop Application❗❗](#-eshop-application-Caution-when-creating-precautions)
   - [Challenge 2-3](#Challenge-2-3)
   - [Challenge 2-4](#Challenge-2-4)
- [**Evaluation**](#evaluation)
- [**Infrastructure constructed to date**](#Infrastructure constructed to date)
- [ \[list\] ](#-list-)

---
# **Day 2 - Service EKS Cluster IaC environment configuration and operation system construction**

<br>

📌 [Notes to be used during this lab]

📌 [GITHUB]<br>
➕ << GITHUB USER NAME >> : <br>
➕ << GITHUB TOKEN >> : <br>

📌 [AWS Access Key]<br>
➕ << Access key >> : <br>
➕ << Secret Access key >> : <br>

📌 [ECR URI]<br>
➕ << ECR URI >> : <br>

📌 [MGMT VPC Nat Gateway IP]<br>
***Lab 1-1 Required Assignment 1-1 Expressed as output of eshop-mgmt-IaC terraform***<br>
➕ << MGMT VPC Nat Gateway IP >> : <br>

📌 [Argocd Service Endpoint]<br>
***Lab 1-1 Required Assignment 1-3 Displayed after installing Argocd Server***<br>
➕ << ARGOCD ENDPOINT >> : <br>
➕ << ARGOCD PASSWORD >> : <br>

📌 [Jenkins Service Endpoint]<br>
***Lab 1-1 Required Assignment 1-4 Display after installing Jenkins Server***<br>
➕ << JENKINS ENDPOINT >> : <br>
➕ << JENKINS PASSWORD >> : <br>

📌 [S3 Information]<br>
***Name of S3 (Terraform backend) bucket created in Lab 1-1***<br>
➕ <<Personal Bucket>> : <br>

📌 [eiparn]<br>
***Expressed as output of Lab 2-1 eshop-service-IaC terraform, used when distributing Lab 2-2 istio***<br>
➕ << EIP arn output value after performing service IaC >> : <br>

📌 [sslcert]<br>
***AWS Certificate Manager certificate information created on day 1 of week 1 (MSP-pjt-1w/1w-0-Environment_setup.md), used when distributing Lab 2-2 istio***<br>
➕ << arn of the arn cert value created in the us-west-2 region in week 1 >>: <br>

<br>

![](../media1/image42.png)

<br>

## 🚨 List of required tasks 🚨
1. [[IaC] Establish and perform Service IaC (Terraform) Pipeline to provision Outer Architecture infrastructure](#🚨Required Task-2-1)
2. [[Istio] Applying istio Service Mesh to eshop service](#🚨Required Task-2-2)
3. [[Helm] Changing the PaC format of eshop Application to Helm Chart format](#🚨Required Task-2-3)

<br>

## 🤔 Day 2 Full Challenge List 🤔
🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥
1. [[IaC] Apply Slack Noti function to Jenkins IaC Pipeline](#Challenge-2-1)<a href="./2w-challenge-2-1.md"> (Challenge 2-1) < /a>
2. [[Test] Deploy eshop test through argocd on Service EKS Cluster (eshop-MSA configuration)](#Challenge-2-2) <a href="./2w-challenge-2-2.md "> (Challenge 2-2) </a>
3. [[Helm] Change the format of eshop PaC from yaml manifest to Helm Chart format using the Helm command.](#Challenge-2-3) <a href="./2w-challenge-2-3. md"> (Challenge 2-3) </a>
4. [[Helm] Download (Helm Pull) Observability-related OSS in Helm Chart format](#Challenge-2-1) <a href="./2w-challenge-2-4.md"> (Challenge Task 2-4) </a>


<br>
<br>

## **Lab 2-1. Service EKS Cluster Environment Infra Provisioning**

<br>

## Lab 2-1 Practice Objectives
1. Build a VPC for service through IaC and use S3 as Terraform’s backend.
2. Create an IaC Pipeline to manage infrastructure for service and provision it.
3. Add context to control Service EKS Cluster.
4. Apply Slack Noti function to Jenkins IaC Pipeline. (🤔 Challenge)

<br>

## 🚨Required task 2-1
> 2-1-1 to 2-1-4 full operation

### 2-1-1. GitHub Repository Configuration

1. Personalize eshop-service-IaC downloaded from S3 with your account’s private git (in the same way as personalizing eshop-mgmt-IaC previously).

<br>

❗ Perform Github (Private Repository) personalization
> eshop-service-IaC
>
>---
>
> Reference Reference
>
> <s3://t2hubintern/eshop-service-IaC.tar.gz>

<br>

[`eshop-service-IaC` reference source personalization]

<span style="color:red">Create a Private Repoistory named `eshop-service-IaC` in your personal Github in advance.</span>

<span style="color:red">※ When creating a repository, be sure to create it as `Private` Type. (Be careful not to create it as a `Public` Type.)</span>

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt
```

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/eshop-service-IaC.tar.gz .
```

< WSL environment >
```bash
tar xvfz eshop-service-IaC.tar.gz
```

< WSL environment >
```bash
rm eshop-service-IaC.tar.gz
```

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
git init
git add .
git commit -m "initial commit"
git branch -M main

git remote add origin https://github.com/<< GITHUB USER NAME >>/eshop-service-IaC.git
```
> << GITHUB USER NAME >>: Variables are replaced with individual values

< WSL environment >
```bash
git push -u origin main
```
> Push to main branch

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```
> Move to the directory to edit the source.

< WSL environment >
```bash
code.
```
> Run VSCode to edit the source.

<br>

2. Modify the terraform code of service IaC using VSCode.


     Source to be modified

     - terraform.tfvars
     -provider.tf

<br>

**[Edit terraform.tfvars] Be sure to check “us-west-2” in the region setting and replace the variable value with the MGMT VPC Nat Gateway IP value.**

```bash
aws_region = "us-west-2" # Set the region where the service VPC will be created
mgmt_nat_gw_ip = "<< MGMT VPC NAT Gateway IP >>"
```
> << MGMT VPC NAT Gateway IP >> The value must be replaced with the actual value.
>
> Example) Change the << MGMT VPC NAT Gateway IP >> value to 18.209.203.233, which is the actual public IP of the Nat Gateway of MGMT VPC.
>
> ```bash
> aws_region = "us-west-2" # Set the region where the service VPC will be created
> mgmt_nat_gw_ip = "18.209.203.233"
> ```

<br>

---

🗎 Note. View the Nat Gateway Public IP of the MGMT VPC in the us-east-1 region created in the previous process AWS CLI

>< WSL environment >
>```bash
>aws ec2 describe-nat-gateways --region us-east-1 | grep PublicIp
>```
>
> Register the public IP of the nat gateway of MGMT VPC (us-east-1) confirmed in the AWS CLI command above to the Security Group. (In other words, the IP confirmed by the above command can be seen as the actual value of the `<< MGMT VPC Nat Gateway IP >>` variable.)
> <br><br><br>
>✔ **(Example of execution code/result)**
>```bash
>$ aws ec2 describe-nat-gateways --region us-east-1 | grep PublicIp
> "PublicIp": "18.209.203.233"
>$
>```
> In the example above, the value of "PublicIp", 18.209.203.233, can be considered the Nat Gateway IP of MGMT VPC.

---

<br>

**[provider.tf modification] Confirm that the S3 region is "us-east-1" and replace the <<private bucket>> variable.**

- The S3 bucket is created in the us-east-1 (N.Virginia) region.
- Modify bucket name in provider.tf
- Delete the 5th line of provider.tf
```bash
terraform {
   backend "s3" {
     bucket = "<<Personal Bucket>>" # Actual name of S3 bucket created by an individual ex) bucket = t3msp
     key = "service/terraform.tfstate" # path to save tfstate file of service infrastructure (fixed value)
     Replace the <<Personal Bucket>> variable in the 3rd line with the actual bucket name created by the individual, and then delete the 5th line as well. ex) bucket = "t3msp" -- (replace the bucket value in the 3rd line of provider.tf && delete the entire current 5th line)
     region = "us-east-1" # region where S3 exists
     skip_s3_checksum=true # Additional parameters starting from Terraform 1.6 or higher
     skip_requesting_account_id=true # Additional parameters starting from Terraform 1.6 and above
   }
   required_version = ">=1.1.3"
}

provider "aws" {
   region = var.aws_region
}
```

3. **Check whether the Terraform code of service IaC is planned well.**

※ First, manually run terraform init > plan in WSL to check if the plan is working properly. (Only until the plan!!)

---
❗❗❗<span style="color:red"> In the case of infrastructure for service purposes, the Jenkins IaC Pipeline will be configured and operated in the future, so in the WSL environment, you only need to check Init > Plan, but if you also perform Apply in the WSL environment, you must Must be carried out until destruction.</span>
❗❗❗
---

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```
> Go to the service IaC directory. (Move to the directory where you want to perform the task)

<br>

< WSL environment >
```bash
terraform init
```
> Run terraform init.

<br>


✔ **(Example of execution code/result)**
```bash
Initializing the backend...

Successfully configured the backend "s3"! Terraform will automatically
use this backend unless the backend configuration changes.
Initializing modules...
- eks in eks_module
- sg in sg_module
- vpc in vpc_module
- vpc_endpoints in ep_module

Initializing provider plugins...
- Finding hashicorp/aws versions matching "~> 4.0"...
- Finding latest version of hashicorp/tls...
- Installing hashicorp/aws v4.67.0...
- Installed hashicorp/aws v4.67.0 (signed by HashiCorp)
- Installing hashicorp/tls v4.0.5...
- Installed hashicorp/tls v4.0.5 (signed by HashiCorp)

Terraform has created a lock file .terraform.lock.hcl to record the provider
selections it made above. Include this file in your version control repository
so that Terraform can guarantee to make the same selections by default when
you run "terraform init" in the future.

Terraform has been successfully initialized!

You may now begin working with Terraform. Try running "terraform plan" to see
any changes that are required for your infrastructure. All Terraform commands
should now work.

If you ever set or change modules or backend configuration for Terraform,
rerun this command to reinitialize your working directory. If you forget, other
commands will detect it and remind you to do so if necessary.
```

<br>

< WSL environment >
```bash
terraform plan
```
> Perform terraform plan.

<br>

The result of `terraform plan` can be output as follows. Since you only need to confirm that the plan is working well, proceed to step 4.

<br>

✔ **(Example of execution code/result)**
```bash
Plan: 36 to add, 0 to change, 0 to destroy.
```

<br>


4. **If it has been confirmed that the service IaC Terraform code is well planned**, push the changes to the main branch in the personalized eshop-service-IaC Repository.

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```

< WSL environment >
```bash
git add .; git commit -m "ready to service IaC terraform apply"; git push origin main
```

<br>

### 2-1-2. Create pipeline for deploying Service EKS Cluster in Jenkins

<br>


1. Before performing this process, create the Jenkins AWS Credential described below.

<br>

Dashboard > Jenkins Management > Credentials > System Global credentials (unrestricted)

You must create Jenkins awsCredentials in advance. (Acquire AWS permissions by reading the id value called `awsCredentials` in the terraform Jenkinsfile)

- Be sure to add the ID value as `awsCredentials`
- Click `Add Credentials` and create AWS credentials.
- Create infrastructure for eshop using terraform in Jenkins pipeline. To do this, register the AWS IAM user's access key

> |Item|Content|Action|
> |---|---|---|
> |➕ Kind | `AWS Credentials` | select|
> |➕ ID | `awsCredentials` | input|
> |➕ Description | `AWS` | input|
> |➕ Access Key ID | << Access Key >> | 📌 Enter memo value |
> |➕ Secret Access Key | << Secret Access key >> | 📌 Enter memo value |

<br>

2. Set up a webhook from the personal GitHub eshop-service-IaC Repository to personal Jenkins.

<br>

Within the Admin Server, you can check the endpoint of Jenkins ELB, that is, the << JENKINS ENDPOINT >> of the individual Jenkins service, using the command below.

< EC2 environment - admin server - mgmt context(mc) >
``` bash
kubectl get service -n jenkins
```

<br>

<< JENKINS ENDPOINT >> varies from person to person. You can use `ELB DNS Name`, and if you registered the domain through Route53, you can enter it in the form `jenkins.<< DOMAIN NAME >>`.
> Note. << DOMAIN NAME >>: The name of the domain issued through the Route53 service for each individual (Hosted Zone name) <br>
> ex) mspt3.click

<br>

Enter the value below into the payload url and specify the content type as application/json.
> Jenkins' service port is `8080`, so you must add the service port (`8080`) after the endpoint.

<br>

After performing `Add webhook`, enter the payload url.<br>
`http://<< JENKINS ENDPOINT >>:8080/github-webhook/`


<br>

In the previous process, enter the normal url value and check if the green check mark (✔️) appears after `Add webhook`.

![](../media1/image34.png)

<br>

***

## Challenge 2-1

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

> The challenge is to apply Slack Notice to the IaC Pipeline by changing the Jenkins file of eshop-service-IaC before creating the Blue Ocean IaC Pipeline in step 3 below.

**Apply Slack Noti function to Jenkins IaC Pipeline** <a href="./2w-challenge-2-1.md"> (Challenge 2-1) </a>

***

<br>

❗❗❗
***<span style="color:red">At this point, be sure to check the items below and proceed to the next step. If at least the two types of Jenkins Credentials below have not been created, check the creation time for each, create them, and then perform step 3.</span>***

<br>

After entering the Jenkins Management > Manage Credentials screen, check that at least the following two types of credentials have been created.

|Item ID|credential Kind|Creation Time|
|---|---|-----|
|`github`|`Username with password`| Creation is performed in the first day process `1-2-4`. |
|`awsCredentials`|`AWS Credentials`| Creation is performed in process ‘1’ of the second day process ‘2-1-2’.|

<br>

3. Create a Blue Ocean Pipeline (Multi branch Pipeline).

<br>

open blueocean > Create a new Pipeline > github > Select my account/repository (eshop-service-IaC) > Create pipeline

<br>

- Blue Ocean

![](../media1/jenkins_blue_ocean_1.png)

- Blue Ocean > New pipeline

![](../media1/jenkins_blue_ocean_2.png)

- Blue Ocean > New Pipeline > Create
> Select personal Github Username and select `eshop-service-IaC` and create pipeline
![](../media1/jenkins_blue_ocean_3_aws.png)

=> When created, the IaC Pipeline is waiting for approval in the approval stage, so confirm by clicking the `proceed` button to activate the pipeline. (📌Time required: approximately 25 to 35 minutes)

<br>

![](../media1/jenkins_blue_ocean_proceed.png)

<br>

After this process, the Outer Architecture infrastructure for the service actually begins to be created in the cloud environment, and the entire operation takes approximately 25 to 35 minutes.

<br>

### 2-1-3. Creating a Service EKS Cluster (Step 3 of 2-1-2 📌 Time required: approximately 25 to 35 minutes)

`3 of 2-1-2. If about 25 to 35 minutes have passed since completing the process of creating a Blue Ocean Pipeline (Multi branch Pipeline), the creation of the Outer Architecture infrastructure environment for the service will have been completed, unless it is a special case. If an error occurs during the process, check the cause, take action, and try again.

If you click the square button in the picture below on the failed pipeline, it will be re-executed.

![](../media1/jenkins_blue_ocean_rerun.png)

<br>

If there are no problems and the IaC Pipeline has not yet been completed, Terraform logs will be displayed as shown below, and the infrastructure will be created sequentially.

![](../media1/jenkins_blue_ocean_applying.png)

<br>

If the infrastructure through the IaC Pipeline has been created, the color of the Blue Ocean Pipeline becomes green as shown below, and the performance details of the pipeline can be viewed.

![](../media1/jenkins_blue_ocean_complete.png)

<br>

1. After the Terraform Service IaC pipeline is executed, record the output as below.

<br>

example)

**eip_allocation_id = << EOT**
```
eipalloc-0f5xxxxxxx,eipalloc-04dxxxxxxx
```
> The recorded eip allocation ids will be used when installing istio service mesh.

<br>


2. After completing the service cluster terraform, add the context of the service cluster. (Oregon-based eks cluster context added (named eshop))

<br>

***
🗎 Note. AWS structure diagram to be created after IaC operation (red squared part)

![](../media1/image43.png)
> The VPC area required for the service is created.

***

<br>

< EC2 environment - admin server ><br>

```bash
aws eks --region=us-west-2 update-kubeconfig --name=eshop-service-eks-cluster --alias=eshop
```

<br>

***

🗎 Note. Easily change context with Linux alias

> The process below is set up so that you can easily perform tasks by using abbreviations rather than typing the entire command when multi-context switching in the future, and is an item that is automatically set through user data settings in Terraform mgmt IaC. (Separate work) Since this is not the content to be discussed, `just for reference.`)

<br>

Several environment variables can be specified for each user in the file in the `~/.bashrc` path, and you can check whether they have been added at the bottom of the file. If it is added, it can be considered permanently applied to the session.

< EC2 environment - admin server >
```bash
# check .bashrc
vi ~/.bashrc
```

< EC2 environment - admin server >
```bash
# add alias
alias mc='kubectl config use-context mgmt'
alias ec='kubectl config use-context eshop'
alias ef='kubectl config use-context eshop-fg'

#WhereAmI
alias wai='kubectl config get-contexts'
```

```bash
# Enable (switch to mgmt)
mc
```

```bash
# Use (switch to eshop)
ec
```

```bash
# Use (check current context)
wai
```

***

<br>

Check adding service cluster context<br>
< EC2 environment - admin server >
```bash
cat ~/.kube/config
```

<br>

Check the context of the selected eks cluster related to the current individual's work<br>
< EC2 environment - admin server >
```bash
kubectl config get-contexts
```
> The above command can be replaced with wai
>
> mgmt => argocd, Jenkins related operations
>
> eshop => Service cluster related operations

<br>

context switch command (example changed to mgmt)

< EC2 environment - admin server >
```bash
kubectl config use-context mgmt
```
> The above command can be replaced with mc

<br>

Check cluster info of service cluster (check eks api endpoint)

< EC2 environment - admin server >
```bash
kubectl config use-context eshop
kubectl cluster-info
```
> The API endpoint of the service cluster will be added to argocd cluster in the future.

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-17:~$ kubectl cluster-info
Kubernetes control plane is running at https://CDB5A641ACE235764B8548629E8B1F88.sk1.us-west-2.eks.amazonaws.com
CoreDNS is running at https://CDB5A641ACE235764B8548629E8B1F88.sk1.us-west-2.eks.amazonaws.com/api/v1/namespaces/kube-system/services/kube-dns:dns/proxy
```

<br>

### 2-1-4. Add newly created Service EKS Cluster to argocd

0. **Check additional Security Group Inbound of Argocd ELB (ports 80, 443)**
> This process is performed in advance through the `1-1-3.❗💡※ Argocd, Jenkins security-related tasks` course in the first day course, but if not performed, the task must be performed.
>
> Related guide (Day 1 textbook)
>
> ❗💡※ (Option 1) Mandatory performance of security-related work. `Step7)` of (Working with UI)
>
> ❗💡※ (Option 2) Mandatory performance of security-related work. `Command 3)` in (Working with AWS CLI)

<br>

Step 0, ‘Additional confirmation of Argocd ELB’s Security Group Inbound (port 80, 443)’ is a task to allow calls to the argocd endpoint from the admin server through ***argocd cli.***

<br>

---

**🗎 Note. How to check nat gateway IP in VPC of personal eshop-mgmt-eks-cluster and how to register Security Group through CLI**

>```bash
>aws ec2 describe-nat-gateways --region us-east-1 | grep PublicIp
>```
>
> Check the public IP of the nat gateway of MGMT VPC (us-east-1) confirmed in the above command.

Execute the command by substituting the `<< MGMT VPC NAT Gateway IP >>` variable with the actual value of the public IP of the Nat Gateway confirmed above. If you execute the command below, an entry for port 443 required for https communication of Nat Gateway Public IP will be added to the Security Group. (This process is guided by `Command 3)` in ❗💡※ (Option 2) Essentially performing security-related work. (Working with AWS CLI) in the textbook on Day 1.)

<br>

The command to register the Nat Gateway IP of MGMT VPC to the Security Group is as follows.

< WSL environment >
```bash
aws ec2 authorize-security-group-ingress \
--region us-east-1 \
--group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
--query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
--ip-permissions '[{"IpProtocol":"tcp","FromPort":443, "ToPort":443,"IpRanges":[{"CidrIp":"<< MGMT VPC NAT Gateway IP >>/32 ","Description":"https nat gw ip"}]}]'
```
> << MGMT VPC NAT Gateway IP >> The variable value is replaced with the actual IP value of nat_gateway_ip among the terraform output values from the previous process.

✔ **(Example of execution code/result)**
```bash
aws ec2 authorize-security-group-ingress \
> --region us-east-1 \
> --group-id $(aws ec2 describe-security-groups --filter Name=description,Values=*(argocd/argocd-server)* \
> --query 'SecurityGroups[*].[GroupId]' --output text --region us-east-1) \
> --ip-permissions '[{"IpProtocol":"tcp","FromPort":443, "ToPort":443,"IpRanges":[{"CidrIp":"34.224.162.191/32","Description" :"https nat gw ip"}]}]'
   % Total % Received % Xferd Average Speed Time Time Time Current
                                  Dload Upload Total Spent Left Speed
100 15 100 15 0 0 75 0 --:--:-- --:--:-- --:--:-- 75
```
> If you look at the example above, you can see that the command was executed by changing the << MGMT VPC NAT Gateway IP >> value to 34.224.162.191.

---

<br>
1. Check argocd cli installation (verification only)

***argocd cli is used to register the SERVICE EKS CLUSTER created on the 2nd day to the argocd server installed on the 1st day. (For reference, the mgmt IaC performed on day 1 is configured to be automatically installed on the admin server.)***

< EC2 environment - admin server >
```bash
argocd version
```
> Execute the version check command to check whether cli was installed properly.

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-114:~$ argocd version
argocd:v2.4.28+598f792
   BuildDate: 2023-03-23T15:19:33Z
   GitCommit: 598f79236ae4160325b37342434baef4ff95d61c
   GitTreeState: clean
   GoVersion: go1.18.10
   Compiler: gc
   Platform: linux/amd64
FATA[0000] Argo CD server address unspecified
```
> If the version information is displayed well as shown above, it can be considered that the installation has been successful. Since you have not yet logged in to the argocd server, the message `FATA[0000] Argo CD server address unspecified` appears, but this can be considered a normal situation.

<br>

2. Change the context to mgmt using the context switch command.

< EC2 environment - admin server >
```bash
kubectl config use-context mgmt
```

<br>

3. Check argocd endpoint (check EXTERNAL IP)

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl get service argocd-server -n argocd
```

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-114:~$ kubectl get service -n argocd
NAME TYPE CLUSTER-IP EXTERNAL-IP PORT(S) AGE
argocd-applicationset-controller ClusterIP 172.20.4.111 <none> 7000/TCP,8080/TCP 21m
argocd-dex-server ClusterIP 172.20.199.169 <none> 5556/TCP,5557/TCP,5558/TCP 21m
argocd-metrics ClusterIP 172.20.193.183 <none> 8082/TCP 21m
argocd-notifications-controller-metrics ClusterIP 172.20.149.65 <none> 9001/TCP 21m
argocd-redis ClusterIP 172.20.62.33 <none> 6379/TCP 21m
argocd-repo-server ClusterIP 172.20.124.117 <none> 8081/TCP,8084/TCP 21m
argocd-server LoadBalancer 172.20.124.105 a8ddd2d6a21d8492db717be049810246-460711733.us-east-1.elb.amazonaws.com 80:30047/TCP,443:32637/TCP 21m
argocd-server-metrics ClusterIP 172.20.92.88 <none> 8083/TCP 21m
```
> If the service of `LoadBalancer` TYPE appears in the list as above, you can check the endpoint normally. In the example above, it is equivalent to `a8ddd2d6a21d8492db717be049810246-460711733.us-east-1.elb.amazonaws.com`.

<br>

4. Log in with argocd cli
> This is the process of logging in through argocd cli with << ARGOCD ENDPOINT >> confirmed in the above process.

< EC2 environment - admin server >
```bash
argocd login << ARGOCD ENDPOINT >> --username admin --insecure --grpc-web
```
> password: input
>
> << ARGOCD ENDPOINT >>: If you registered a personal argocd service subdomain through route53, you can enter the FQDN of the domain.
>
> In password, enter the initial password (the value of `<< ARGOCD PASSWORD >>` you noted down) that you confirmed on Day 1 (`7. Confirm the initial password of the installed Argocd`). (Please note that nothing appears when you enter it in the password prompt window. So be careful.)

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-114:~$ argocd login a8ddd2d6a21d8492db717be049810246-460711733.us-east-1.elb.amazonaws.com --username admin --insecure --grpc-web
Password:
'admin:login' logged in successfully
```

<br>

< EC2 environment - admin server >
```bash
argocd version
```
> This is a command to check argocd client and logged in server information after logging in.

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-114:~$ argocd version
argocd:v2.4.28+598f792
   BuildDate: 2023-03-23T15:19:33Z
   GitCommit: 598f79236ae4160325b37342434baef4ff95d61c
   GitTreeState: clean
   GoVersion: go1.18.10
   Compiler: gc
   Platform: linux/amd64
argocd-server: v2.4.28+598f792
   BuildDate: 2023-03-23T14:58:46Z
   GitCommit: 598f79236ae4160325b37342434baef4ff95d61c
   GitTreeState: clean
   GoVersion: go1.18.10
   Compiler: gc
   Platform: linux/amd64
   Kustomize Version: v4.4.1 2021-11-11T23:36:27Z
   Helm Version: v3.8.1+g5cb9af4
   Kubectl Version: v0.23.1
   Jsonnet Version: v0.18.0
```
> Since this is after logging in to the argocd server, the information of `argocd-server` is also displayed properly. If it is displayed like this, it can be considered that you have logged in to the server normally.

<br>

5. Check with argocd cluster list command

< EC2 environment - admin server >
```bash
argocd cluster list
```
> ※ Can also be checked on the argocd web screen (Settings > Clusters)

<br>

6. Add eshop cluster with argocd cluster add command

< EC2 환경 - admin server >
```bash
argocd cluster add eshop
```
> `eshop` alias로 추가했던 Service EKS Cluster를 argocd에 추가하는 작업이다.

✔ **(수행 코드/결과 예시)**
```bash
ubuntu@ip-10-0-10-17:~$ argocd cluster add eshop
WARNING: This will create a service account `argocd-manager` on the cluster referenced by context `eshop` with full cluster level privileges. Do you want to continue [y/N]? y
INFO[0022] ServiceAccount "argocd-manager" created in namespace "kube-system"
INFO[0022] ClusterRole "argocd-manager-role" created
INFO[0022] ClusterRoleBinding "argocd-manager-role-binding" created
Cluster 'https://CDB5A641ACE235764B8548629E8B1F88.sk1.us-west-2.eks.amazonaws.com' added
```

<br>

***
## Challenge 2-2

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

**Deploy eshop application test to Service EKS Cluster via argocd (eshop-MSA configuration)** <a href="./2w-challenge-2-2.md"> (Challenge 2-2) </a>

***

<br>
<br>

## **Lab 2-2. Service Mesh deployment in Service EKS Cluster environment**

<br>

## Lab 2-2 Practice Objectives
1. Build a Service Mesh using istio in the Service EKS Cluster environment.
2. Set up the istio ingress gateway in the Service EKS Cluster environment.
3. Apply side car (envoy proxy) to pods related to eshop service in the Service EKS Cluster environment.
> envoy: Open source side car technology used in istio implementation


<br>

## Note

<br>

### Conceptual introduction to Service Mesh, Sidecar, and istio
https://www.samsungsds.com/kr/insights/service_mesh.html

<br>

### Istio Traffic Management
: Istio traffic management components largely consist of Gateway, VirtualService, and DestinationRule. For more details, refer to the blog below.

https://bcho.tistory.com/1367

<br>

### Purpose of Istio Side Car Pattern

https://sarc.io/index.php/cloud/1994-sidecar-pattern

<br>


### metrics-server

: Provides the ability to collect resource usage of cluster nodes or containers.

https://nangman14.tistory.com/81

<br>

### 2-2-0. ❗❗❗Things to do before starting Lab 2-2❗❗❗

1. Modify eshop-service-IaC code to node group 2 => 3 and redistribute (terraform)
> When applying istio and side car pattern, the resources required by the application may increase, so this is a process of expanding the resources of the outer architecture before applying istio.

This is the process of expanding resources to Terraform using the service IaC Pipeline.

Step 1) Edit Terraform code

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```
> Go to service IaC Terraform code local repo

<br>

< WSL environment >
```bash
code.
```
> Open vscode

<br>

Change the following part of the **eshop-service-IaC/vars.tf** file

```terraform
...
variable "node_desired_size" {
   default = 3 //Change to 2=>3
   type = number
   description = "eks-node desired size"
}

variable "node_max_size" {
   default = 3 //Change to 2=>3
   type = number
   description = "eks-node max size"
}

variable "node_min_size" {
   default = 3 //Change to 2=>3
   type = number
   description = "eks-node desired size"
}
...
```

<br>


Step 2) Push Terraform code modifications to git main branch

< WSL environment >
```bash
git add .; git commit -m "worker nodes scale out 2 to 3"; git push origin main
```
> git add & git stage commit & git remote push

<br>


Step 3) When you git push, the pipeline automatically runs through a webhook, so `Proceed` the service IaC pipeline in Jenkins.


<br>

2. Access the Github site and create a ‘github private repository’ with the name eshop-PaC.

<br>

[Personalize `eshop-PaC` reference source]

<span style="color:red">Create a Private Repoistory named `eshop-PaC` in your personal Github in advance.</span>

<span style="color:red">※ When creating a repository, be sure to create it as `Private` Type. (Be careful not to create it as a `Public` Type.)</span>
> 🗎 Note. eshop-PaC: eshop's PaC form that will be used in earnest from the 3rd day.

<br>

3. Copy the existing `eshop-MSA/k8s` directory under `eshop-PaC`.

< WSL environment >
```bash
cd ~/t3-msp-pjt
```
> Go to workspace directory


< WSL environment >
```bash
mkdir eshop-PaC
```
> Create a new eshop-PaC directory


< WSL environment >
```bash
cp -R ~/t3-msp-pjt/eshop-MSA/k8s ~/t3-msp-pjt/eshop-PaC/
```
> Copy eshop-MSA/k8s to the eshop-PaC/k8s location.

<br>

4. Delete the eshop-PaC/k8s/ingress.yaml file and then git push it to reflect it in the main branch. (After applying istio, istio ingressgateway will be deleted instead of ingress-nginx, so remove the definition.)

> Ultimately, it is structured as follows.
>
> eshop-PaC/k8s/adservice.yaml
>
> eshop-PaC/k8s/backend.yaml
>
> eshop-PaC/k8s/cartservice.yaml
>
> eshop-PaC/k8s/currencyservice.yaml
>
> eshop-PaC/k8s/frontend.yaml
>
> eshop-PaC/k8s/mongodb.yaml
>
> eshop-PaC/k8s/postgresql.yaml
>
> eshop-PaC/k8s/productservice.yaml
>
> eshop-PaC/k8s/rabbitmq.yaml
>
> eshop-PaC/k8s/recommendservice.yaml
>
> eshop-PaC/k8s/redis.yaml

<br>

![](../media1/3-5.png)

<br>

5. ‘Personalize’ the image path of yaml files in the eshop-PaC/k8s directory.

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC
```
> Move to msp pjt workspace


< WSL environment >
```bash
code.
```
> Open vscode

Personalize by modifying the value of `image:` of **eshop-PaC/k8s/*.yaml** files (related to a total of 7 microservices).
> List of files requiring personalization
>
> eshop-PaC/k8s/adservice.yaml
>
> eshop-PaC/k8s/backend.yaml
>
> eshop-PaC/k8s/cartservice.yaml
>
> eshop-PaC/k8s/currencyservice.yaml
>
> eshop-PaC/k8s/frontend.yaml
>
> eshop-PaC/k8s/productservice.yaml
>
> eshop-PaC/k8s/recommendservice.yaml

```yaml
## << variable >> substitution required

## << ECR URI >> => ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com
## << SERVICE NAME >> => ex) eshop-backend
## << TAG >> => ex) latest

## << ECR URI >>/<< SERVICE NAME >>:<< TAG >> => ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com/eshop-backend:latest

(...)
image: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
(...)
```

<br>

6. Create a Github Local Repository in the newly created `eshop-PaC` Repository while reflecting changes made to date.

<br>

❗ Perform Github (Private Repository) personalization
> eshop-PaC
>
>---
> Reflect on Github based on the work performed up to step 5 of the above process, 2-2-0.


Step 1) Go to eshop-PaC directory

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC
```
> Go to eshop-PaC github local repo



Step 2) Git initialize and push to main branch

< WSL environment >
```bash
git init
```

< WSL environment >
```bash
git add .; git commit -m "initial"
```

< WSL environment >
```bash
git branch -M main
```

< WSL environment >
```bash
git remote add origin https://github.com/<< GITHUB USER NAME >>/eshop-PaC.git
```

< WSL environment >
```bash
git push -u origin main
```

<br>

7. Deploy eshop Application (eshop-PaC Repository) through Argocd.
> After distributing eshop in yaml format, we plan to apply the side car pattern.

❗ It is necessary to add your personal eshop-PaC Repository to Argocd’s Git Repository before deployment.

+New App creation task

Step 1) Enter GENERAL items
|Item|Content|Action|
|------|---|---|
|➕ Application Name |`eshop-k8s`|Copy & Paste|
|➕ Project |`default`|Select select box|
|➕ SYNC POLICY | `Manual` |Select select box (default)|
|➕ SYNC OPTIONS |`AUTO-CREATE NAMESPACE`|Select checkbox|

<br>

Step 2) Enter SOURCE items
|Item|Content|Action|
|------|---|---|
|➕Repository URL |`https://github.com/<< GITHUB USER NAME >>/eshop-PaC.git`|Select select box|
|➕Revision|`main` or `HEAD`|Select select box|
|➕Path|`k8s`|Input|

<br>

Step 3) Enter DESTINATION items
|Item|Content|Action|
|------|---|---|
|➕ Cluster URL |`<< Service EKS Cluster Endpoint >>`|Select select box|
|➕ Namespace |`eshop`|Copy & Paste|

<br>

Step 4) Select Directory (It is not Helm Format, so it is not recognized as Helm in Argocd.)

<br>
<br>


## 🚨Required task 2-2
> 2-2-1 to 2-2-3 full operation

### 2-2-1. Install Istio

**Istio Helm Chart is provided in S3.**

<br>

1. Personalize the content in the eshop-istio directory as a Github personal private repository.


❗ Perform Github (Private Repository) personalization
> eshop-istio
>
>---
>
> Reference Reference
>
> <s3://t2hubintern/eshop-istio.tar.gz>

<br>

[Personalize `eshop-istio` reference source]

<span style="color:red">Create a Private Repoistory named `eshop-istio` in your personal Github in advance.</span>

<span style="color:red">※ When creating a repository, be sure to create it as `Private` Type. (Be careful not to create it as a `Public` Type.)</span>

<br>

Edit the **eshop-istio/values.yaml** file and merge it into the github main branch.

```
global:
   eiparn: << EIP arn output value after performing service IaC >>
   sslcert: << arn of the arn cert value created in the us-west-2 region in week 1 >>
```
> << EIP arn output value after performing service IaC >>: Output value recorded in step 1 of 2-1-3

❗❗ Both of the above values must be resources created in the `us-west-2 region`.


<br>

Import `eshop-istio` source

< WSL environment >
```bash
cd ~/t3-msp-pjt
```

< WSL environment >
```bash
aws s3 cp s3://t2hubintern/eshop-istio.tar.gz .
```

< WSL environment >
```bash
tar xvfz eshop-istio.tar.gz
```

< WSL environment >
```bash
rm eshop-istio.tar.gz
```

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-istio
git init
git add .
git commit -m "initial commit"
git branch -M main

git remote add origin https://github.com/<< GITHUB USER NAME >>/eshop-istio.git
```
> << GITHUB USER NAME >>: Variables are replaced with individual values

<br>

< WSL environment >
```bash
git push -u origin main
```
> Push to main branch

<br>

2. Install istio

### ❗❗ Notes regarding AWS ACM❗❗

For the arn of the ACM certificate, which is one of the values used in the installation below, use the one issued to the us-west-2 (Oregon) region during the first week of the actual project.

<br>

Create an istio application to install istio.

❗ It is necessary to add your personal eshop-istio Repository to Argocd’s Git Repository before deployment.

In argocd settings > repositories, add the istio helm chart repository personalized in the above process.

`https://github.com/<< GITHUB USER NAME >>/eshop-istio.git`

![](../media1/argocd_setting_repo_1.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media1/argocd_setting_repo_2.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media1/argocd_setting_repo_3.png)

<br>

If Argocd Repositories has been registered, perform the actual app creation process below.

<br>

Step 1) Enter GENERAL items

|Item|Content|Action|
|------|---|---|
|➕ Application Name |`istio`|Input|
|➕ Project |`default`|Select select box|
|➕ SYNC POLICY |`Manual`|Select select box (default)|
|➕ SYNC OPTIONS |`AUTO-CREATE NAMESPACE`|Select checkbox|

<br>

Step 2) Enter SOURCE items
|Item|Content|Action|
|------|---|---|
|➕ Repository URL|`https://github.com/<< GITHUB USER NAME >>/eshop-istio.git`|Select select box|
|➕ Revision|`main` or `HEAD`|Select select box|
|➕ Path|`.`|Select select box|

<br>

Step 3) Enter DESTINATION items
|Item|Content|Action|
|------|---|---|
|➕ Cluster URL|`<< Service EKS Cluster Endpoint >>`|Select select box|
|➕ Namespace|`istio-system`|Input|

<br>

Step 4) Enter Helm items
|Item|Content|Action|
|------|---|---|
|➕ VALUES FILES|`values.yaml`|Select|
|➕ global.eiparn|`Enter two EIP ARN values connected with , (comma)`|
|➕ global.sslcert|[ARN value of the ACM certificate] created in the us-west-2 region (#❗❗-aws-acm-related-notes❗❗)|Input|
> ★ How to check eiparn value
>
> Method 1) Check the eshop-service-IaC pipeline's execution log in Jenkins and check the eip_allocation_id value of the output (see sample below)
> ```bash
>Outputs:
>
> eip_allocation_id = <<EOT
>eipalloc-1234567aae8f05e56,eipalloc-123456ad18e539288
>
>EOT
> ```
>
> Method 2) Enter the EC2 > Elastic IPs screen in the us-west-2 region in the AWS console and check the allocation ID of eshop-service-terraform-EIP1 and eshop-service-terraform-EIP2.
> <br>

<br>

---

🗎 Note. istio's Intermittent OutofSync Solution
>
>- Reference url. https://argo-cd.readthedocs.io/en/release-1.8/user-guide/diffing/
>
>- Reference url. https://github.com/argoproj/argo-cd/issues/4276
>- istio manifest
>
>```yaml
>(...omitted...)
>syncPolicy:
> syncOptions:
> - CreateNamespace=true
>(input)
>```
>- argocd (CD tool) detects changes in dynamically deleting the caBundle value of istio's ValidatingWebhookConfiguration and MutatingWebhookConfiguration. In situations where there is no Auto Pruning, OutofSync occurs due to frequent istio settings (caBundle, failurePolicy) that need to be deleted. If you add an option to ignore this to the manifest as shown below, argocd will not detect the change.
>
>- When you press the App Details button in istio and then click Edit in the Manifest tab, the manifest is displayed as shown above.
>- After that, enter the code below in the (input) field of the Manifest (ignoreDifferences is the same depth as syncPolicy)
>
>```yaml
>ignoreDifferences:
> - group: admissionregistration.k8s.io
> kind: ValidatingWebhookConfiguration
>jsonPointers:
> - /webhooks/0/clientConfig/caBundle
> - /webhooks/0/failurePolicy
> - group: admissionregistration.k8s.io
> kind: MutatingWebhookConfiguration
>jsonPointers:
> - /webhooks/0/clientConfig/caBundle
> - /webhooks/1/clientConfig/caBundle
> - /webhooks/2/clientConfig/caBundle
> - /webhooks/3/clientConfig/caBundle
>```
>

---

<br>


---

🗎 Note. HPA does not work after installing istio

> ❗❗ If all of the above processes were performed normally, the HPAs will not be able to operate normally after the istio app is created. The reason is that the hpa applied to istiod and istio-ingressgateway does not work, and it can be confirmed that the status is changed to normal through the installation of metrics-server in the future process. For reference, in order for hpa to operate, metrics-server must be installed in the cluster. ❗❗
>
><br>
>
>For reference, before installing metrics-server, which is the third day of the process, the TARGETS >column will display something like `<unknown>/80%`.
>
><br>
>
>Before installing metrics-server, which is the third day of the process, continuous events occur when events are searched for istio's hpa resources in argocd, as shown in the picture below. **After installing metrics-server, which is the third day of the process,* * Last Occurred (event update) no longer occurs even after a long time.
>
>
>![](../media1/istio_hpa_1.png)
>
><br>
>
>< EC2 environment - admin server - eshop context(ec) >
>```
>kubectl get hpa -n istio-system
>```
>
> If you look up the current status, it is as follows.
>
>✔ **(Example of execution code/result)**
>```bash
>NAME REFERENCE TARGETS MINPODS MAXPODS REPLICAS AGE
>istio-ingressgateway Deployment/istio-ingressgateway <unknown>/80% 1 5 1 3h35m
>istiod Deployment/istiod <unknown>/80% 1 5 1
>```

---

<br>

---

🗎 Note. HPA
> To apply HPA, metrics-server must be installed in the cluster.
> <https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/>

---

<br>

3. Add istio injection to the eshop namespace and check that the label has been added through kubectl. (eshop sidecar pattern applied)

<br>

< EC2 environment - admin server >
```bash
kubectl config use-context eshop
```
> Switch to SERVICE EKS CLUSTER Context.

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl label namespaces eshop istio-injection=enabled
```
> istio injection into eshop namespace

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get namespaces -L istio-injection
```
> Check istio-injection in eshop namespace

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl describe ns eshop
```
> Check injection enabled label in eshop namespace

<br>

✔ **(Example of execution code/result)**
```
Name: eshop
Labels: istio-injection=enabled
               kubernetes.io/metadata.name=eshop
Annotations: <none>
Status: Active

No resource quota.

No LimitRange resource.
```

<br>

4. If you check through kubectl, the sidecar has not been injected yet. (eshop sidecar pattern applied)

<br>

The sidecar is injected only when the pod is restarted.

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl get pods -n eshop
```

<br>


✔ **(Example of execution code/result)**
```bash
NAME                                     READY   STATUS    RESTARTS   AGE
eshop-adservice-6db6cdb684-89vc7         1/1     Running   0          4h11m
eshop-backend-8477c5657c-kk498           1/1     Running   0          4h11m
eshop-cartservice-76d569475d-842px       1/1     Running   0          4h11m
eshop-currencyservice-67fb79f754-qc97t   1/1     Running   0          4h11m
eshop-frontend-69d974c7ff-nmkv8          1/1     Running   0          4h11m
eshop-productservice-5c59b454c4-g78dc    1/1     Running   0          4h11m
eshop-recommendservice-c8cccff5d-twt4h   1/1     Running   0          4h11m
mongodb-0                                1/1     Running   0          4h11m
postgres-6f4fd54855-smsvv                1/1     Running   0          4h11m
rabbitmq-5fbd5d6494-djg5x                1/1     Running   0          4h11m
redis-5d6cf5746d-dnmfn                   1/1     Running   0          4h11m
```

<br>
5. Enter the following to restart the pod in the eshop namespace. (eshop sidecar pattern applied)

In order to inject a sidecar into an eshop application, there is a way to `restart all workloads` as shown in the command below, and even if you `delete the eshop-k8s app from argocd and recreate it`, the sidecar pattern (envoy proxy) is applied to all workloads. ) applies.
<br>

< EC2 환경 - admin server - eshop context(ec) >
```bash
kubectl -n eshop rollout restart deployment eshop-adservice
kubectl -n eshop rollout restart deployment eshop-backend
kubectl -n eshop rollout restart deployment eshop-cartservice
kubectl -n eshop rollout restart deployment eshop-currencyservice
kubectl -n eshop rollout restart deployment eshop-frontend
kubectl -n eshop rollout restart deployment eshop-productservice
kubectl -n eshop rollout restart deployment eshop-recommendservice
kubectl -n eshop rollout restart deployment postgres
kubectl -n eshop rollout restart deployment rabbitmq
kubectl -n eshop rollout restart deployment redis
kubectl -n eshop rollout restart statefulset mongodb
```

<br>

6. After restarting the entire app or recreating the app, check that the sidecar (envoy proxy) has been properly injected (`2/2` Running) as follows.

<br>

< EC2 environment - admin server - eshop context(ec) >
```bash
kubectl -n eshop get pod
```

<br>


✔ **(Example of execution code/result)**
```bash
NAME                                      READY   STATUS    RESTARTS   AGE
eshop-adservice-7f765c47d4-cdtfh          2/2     Running   2          48s
eshop-backend-7db87d7bb4-tcgn7            2/2     Running   0          47s
eshop-cartservice-8667b49b48-mgfh9        2/2     Running   0          46s
eshop-currencyservice-775864b48-9qcn6     2/2     Running   0          46s
eshop-frontend-57fdd5b5f6-jl4fn           2/2     Running   0          45s
eshop-productservice-8b954b558-rqxvs      2/2     Running   0          44s
eshop-recommendservice-574d87fffc-4nrr5   2/2     Running   0          43s
mongodb-0                                 2/2     Running   0          30s
postgres-64d7b85f7b-mbvjf                 2/2     Running   0          42s
rabbitmq-85c549d549-stlsw                 2/2     Running   0          42s
redis-7c8d56ffbd-74f5c                    2/2     Running   0          41s
```

<br>

### 2-2-2. Setting up istio-ingressgateway

<br>

After applying istio, ingress-nginx will not be used, and service traffic will be received through istio-ingressgateway.
(This is why eshop-PaC/k8s/ingress.yaml was deleted earlier.)

<br>

Modify the service to use the newly configured istio-ingressgateway instead of nginx ingress controller.

Create an ingress-gateway.yaml file in k8s of each GitOps repository with the following content.
> Corresponds to Gateway among istio traffic management functions

<br>

**eshop-PaC/k8s/ingress-gateway.yaml**
```yaml
apiVersion: networking.istio.io/v1alpha3
kind: Gateway
metadata:
  name: ingress-gateway
spec:
  selector:
    istio: ingressgateway # use istio default controller
  servers:
  - port:
      number: 80
      name: http
      protocol: HTTP
    hosts:
    - "*"
    tls:
      httpsRedirect: false
```

Additionally, create an eshop-vs.yaml file to define the URI between apps.
> Corresponds to VirtualService among istio traffic management functions
**eshop-PaC/k8s/eshop-vs.yaml**
```yaml
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: eshop-virtual-service
  namespace: eshop
spec:
  hosts:
  - "*"
  gateways:
  - ingress-gateway
  http:
  - match:
    - uri:
        prefix: /api/carts
    route:
    - destination:
        host: eshop-cartservice
        port:
          number: 8091
  - match:
    - uri:
        prefix: /api/products
    route:
    - destination:
        host: eshop-productservice
        port:
          number: 8092
  - match:
    - uri:
        prefix: /api/recommends
    route:
    - destination:
        host: eshop-recommendservice
        port:
          number: 8093
  - match:
    - uri:
        prefix: /api/currencies
    route:
    - destination:
        host: eshop-currencyservice
        port:
          number: 8094
  - match:
    - uri:
        prefix: /api/ads
    route:
    - destination:
        host: eshop-adservice
        port:
          number: 8095
  - match:
    - uri:
        prefix: /api
    route:
    - destination:
        host: eshop-backend
        port:
          number: 8090
  - match:
    - uri:
        prefix: /static
    route:
    - destination:
        host: eshop-backend
        port:
          number: 8090         
  - match:
    - uri:
        exact: /
    - uri:
        exact: /favicon.ico
    - uri:
        prefix: /css
    - uri:
        prefix: /js
    route:
    - destination:
        host: eshop-frontend
        port:
          number: 8080

```

Merge the source code into the main branch and sync the application using ArgoCD.
< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC
git add .
git commit -m "add istio ingressgateway and virtualservice"
git push
```

![](../media1/image46.png)


You can check the istio-ingressgateway's connection path (EXTERNAL-IP) by entering the following in the Admin Server.

< EC2 환경 - admin server - eshop context(ec) >
```bash
kubectl get svc -n istio-system 
```

✔ **(execution code/result example)**
```bash
NAME                   TYPE           CLUSTER-IP       EXTERNAL-IP                                                                          PORT(S)                                      AGE
istio-ingressgateway   LoadBalancer   10.100.86.170    aae99232d78ae4e36bcdd92bb8470cd8-67585acbcf52b26f.elb.us-west-2.amazonaws.com   15021:30529/TCP,80:32080/TCP,443:30223/TCP   38h
istiod                 ClusterIP      10.100.210.157   <none>                                                                               15010/TCP,15012/TCP,443/TCP,15014/TCP        38h
```
> In the example above, the ELB DNS Name of istio ingressgateway can be seen as `aae99232d78ae4e36bcdd92bb8470cd8-67585acbcf52b26f.elb.us-west-2.amazonaws.com`.


If you use a web browser to connect to Ingress' Load Balancer using the ELB DNS Name confirmed above, you can confirm that you can access the service normally.

![](../media1/image47.png)

Next, proceed with the process of `specifying the domain of the eshop service` and calling it in `2-2-3 process`.


<br>

### 2-2-3. After performing istio deployment, set Route53 Record, confirm access, and delete application

<br>

1. Register the eshop service domain record in the Route53 service.
> Specify the FQDN of each individual eshop (FQDN: Fully Qualified Domain Name)

- record name: eshop.<< DOMAIN NAME >>
> alias switch on
> Select Alias to Network Load Balancer
> Select Oregon(us-west-2)
> Select Network LoadBalancer
> : Maps the record to the Network LoadBalancer for the service in the us-west-2 region through alias.

<br>

---

🗎 Note. Domain-specific variables
> ※ << DOMAIN >>: FQDN (Fully Qualified Domain Name) of each individual eshop service
>
> ex) eshop.mspt3.click

> ※ << DOMAIN NAME >>: The name of the domain issued through the Route53 service for each individual (Hosted Zone name)
>
> ex) mspt3.click

---

<br>

2. Confirm normal access to the registered domain (FQDN)

Call the FQDN of the individual eshop you set earlier through the browser. In the process of testing the connection, try accessing via TLS call (https) to check whether normal access is possible.

> ex) https://eshop.mspt3.click

<br>

3. Delete the `eshop-k8s` application (distributed using yaml) using Argocd.

❗❗ <span style="color:red">***Please delete* the `eshop-k8s` application in advance through Argocd.**</span> ❗❗
> In Lab 2-3, eshop PaC will eventually be converted to Helm Chart format and distributed and operated, so this is the process of deleting the information distributed in yaml.

<br>



<br>
<br>

## **Lab 2-3. Deploy eshop application as Helm chart**

<br>

## Lab 2-3 Practice Objectives
1. Change the format of eshop PaC from yaml manifest to Helm Chart format.
2. Change the format of eshop PaC from yaml manifest to Helm Chart format (using Helm command) (🤔 Challenge)
3. Install metrics-server consisting of Helm Chart in the eshop Application of Service EKS Cluster.

<br>

## Lab 2-3 Practice Objective Structure Chart

<br>

![](../media1/image45.png)

<br>

![](../media1/4w_arch.png)

> ※ Service(Helm Chart) repo
>
> eshop-PaC: Repository in the form of Helm Chart PaC that will be utilized in earnest when operating eshop services


<br>

## Note

<br>

### Helm Chart

https://bcho.tistory.com/m/1337
> A blog that briefly describes the basic format and overall contents of Helm Chart

<br>

---

🗎 Note. Create a sample Helm Chart
> [Create a Kubernetes Helm chart in 10 minutes (sk.com)](https://devocean.sk.com/experts/techBoardDetail.do?ID=163262&page=&searchData=Kubernetes&subIndex=&idList=%5B164093%2C+164049 %2C+164043%2C+164027%2C+163909%2C+163803%2C+163784%2C+163707%2C+163634%2C+163607%2C+163593%2C+163569%2C+163529%2C +163476%2C +163436%2C+163434%2C+163430%2C+163420%2C+163350%2C+163338%2C+163281%2C+163266%2C+163262%2C+163244%2C+163196%2C+163191%2C+163 189 %2C+163168%2C+163103%2C+163029%2C+160623%2C+160620%2C+158482%2C+55053%5D)

---

<br>

### Learn about Helm Chart format

https://helm.sh/ko/docs/chart_template_guide/getting_started/

<br>


### Disadvantages of operating a service with K8s yaml manifest

1. There are many management points because yaml file sets for all environments must be managed separately.
2. When changes to the application are necessary, there is a large scope for modification and the dependency between yaml definitions increases.


<br>

### Two representative advantages of Helm Chart

1. Using Helm variables or overriding functions, you can variableize, deploy and operate multiple environments (DEV, STG, PRODUCTION) just by managing one Helm Chart (Template).

2. Programs provided in Helm Chart format can be easily installed and expanded.

     ex) Easily install and expand Obaservability OSS with Helm Chart

<br>

---

🗎 Note. Why should I use Helm Chart?
> Infrastructure video lecture (about 13 minutes)
>
> : This is a video that explains the advantages of using Helm Chart in an easy-to-understand manner with examples, so I recommend you watch it.
>
> [Infron] The mainstream is Kubernetes [Helm] - Why should I use Helm?
>
> <https://www.youtube.com/watch?v=m7iZtjeIHJw>

---

<br>


Previously, eshop was defined through a yaml manifest file in the k8s folder and workload deployment such as deployment, service, and pod was performed.

From now on, we will convert eshop into a Helm Chart and distribute it.

In the future, metric-server and monitoring OSS will be managed with Helm Chart and maintained in PaC format.

<br>

## 🚨Required assignment 2-3
> 2-3-1 full operation

Please use the references below.

---

🗎 Note. A version that completes the Helm charting and metrics-server installation process on the second day.
> <s3://t2hubintern/2nd_eshop-PaC.tar.gz>

---

<br>

### 2-3-1. Configure eshop-PaC in Helm Chart format

<br>

1. Download the necessary references.

< WSL environment >

```bash
cd ~/t3-msp-pjt
```
> Move to msp pjt workspace

< WSL environment >

```bash
aws s3 cp s3://t2hubintern/2nd_eshop-PaC.tar.gz .
```
> Download Day 2 Reference

<br>

2. Unzip the contents in the eshop-PaC directory.


< WSL environment >

```bash
tar xvfz 2nd_eshop-PaC.tar.gz
```
> Day 2 reference extraction
> When unzipped, two directories, eshop and fargate, are added.

<br>

3. Check that two directories, eshop and fargate, are added under the individual eshop-PaC directory and that there is an existing k8s directory.

<br>

[Current eshop-PaC structure]

![](../media1/2nd_eshop-PaC.png)

<br>

4. `Delete` the eshop-PaC/k8s directory that is not used after applying Helm Chart.


< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC
```
> Move to msp pjt workspace

<br>

< WSL environment >
```bash
rm -rf k8s
```
> Delete unnecessary k8s directories

<br>

5. Personalize eshop-PaC configured with Helm Chart.
> Personalizing images in values.yaml

<br>

6. The changes made to date are ‘reflected’ to the eshop-PaC Github main branch.

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC
```
> Move to msp pjt workspace

< WSL environment >
```bash
git add .; git commit -m "init eshop Helm Chart PaC"; git push origin main
```
> git add & git stage commit & git remote push


<br>

7. Deploy the eshop Application to PaC (eshop-PaC Repository) configured with Helm Chart through Argocd.
 
❗ It is necessary to add your personal eshop-PaC Repository to Argocd’s Git Repository before deployment.

In argocd settings > repositories, add the eshop-PaC helm chart repository personalized in the above process.

`https://github.com/<< GITHUB USER NAME >>/eshop-PaC.git`

![](../media1/argocd_setting_repo_1.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media1/argocd_setting_repo_2.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media1/argocd_setting_repo_3.png)

<br>

If Argocd Repositories has been registered, perform the actual app creation process below.

<br>

**Create an eshop application complete with Helm Chart on the argocd web screen.**

### ❗❗ Precautions when creating eshop application❗❗

<br>

When distributing eshop through Helm Chart in this course and future courses, the Application Name must be set to 'eshop'. This is because the Helm Chart to be designed in the future has settings dependent on the application name.

<br>

+New App creation task

Step 1) Enter GENERAL items
|Item|Content|Action|
|------|---|---|
|➕ Application Name |`eshop`|Copy & Paste|
|➕ Project |`default`|Select select box|
|➕ SYNC POLICY | `Manual` |Select select box (default)|
|➕ SYNC OPTIONS |`AUTO-CREATE NAMESPACE`|Select checkbox|

<br>

Step 2) Enter SOURCE items
|Item|Content|Action|
|------|---|---|
|➕Repository URL |`https://github.com/<< GITHUB USER NAME >>/eshop-PaC.git`|Select select box|
|➕Revision| `main` or `HEAD` |Select select box|
|➕Path|`eshop`|Select select box|

<br>

Step 3) Enter DESTINATION items
|Item|Content|Action|
|------|---|---|
|➕ Cluster URL |`<< Service EKS Cluster Endpoint >>`|Select select box|
|➕ Namespace |`eshop`|Copy & Paste|

<br>

Step 4) Helm > VALUES FILES > Select the `values.yaml` select box

<br>

**If deployment has been completed normally, try calling the eshop app through the FQDN domain of the individual eshop specified earlier.**

<br>

***

## Challenge 2-3

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

> This challenge is a process of constructing ‘Essential Tasks 2-3’ yourself, and should be completed when you have time.

Change the format of eshop PaC from yaml manifest to Helm Chart format using the Helm command. <a href="./2w-challenge-2-3.md"> (Challenge 2-3) </a>

***

<br>

***

## Challenge 2-4

🔥🔥🔥`Challenge tasks are not mandatory.`🔥🔥🔥

Observability-related OSS download (Helm Pull) in Helm Chart format <a href="./2w-challenge-2-4.md"> (Challenge 2-4) </a>

***

<br>
<br>
# **Evaluation**
- We built and implemented a CI/CD pipeline by setting up components in each area of MGMT EKS Cluster and Service EKS Cluster.
- An istio service mesh environment was built on the eshop inner architecture.
- Helm Temlplating of eshop application completed.

<br>
<br>


# **Infrastructure built to date**

From day 3, we will cover a new type of Service Repository (commonly referred to as PaC). The Repository is a Helm Chart template, and components necessary for service operation are added/deleted in Helm Chart form.

![](../media2/image1.png)

<br>

---

😃 **Day 2 completed!!!**

<br>

⏩ [Move] to the next exercise (2w-3-Observability_Configure.md).

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
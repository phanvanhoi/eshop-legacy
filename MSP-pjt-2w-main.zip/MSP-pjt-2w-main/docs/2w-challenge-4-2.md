## Current status of the program

<br>

## 🤔 Challenge 4-2

### Topic: Open Tracing

<br>

## Practice Objectives
- Apply application distributed tracing (open tracing) through Kiali and Jaeger.
- Apply modifications to apply Open Tracing to the application.


<br>

## Apply distributed tracking to asynchronous communication sections of backend and cartservice

<br>

1. In order to distribute and track Spring Boot apps and other services, settings at the application level, that is, the Client, are required.

<br>

In the guide below, replace the << SERVICE NAME >> variable with eshop-backend and eshop-cartservice.

<br>

The modification items for when `Challenge 1-3` is performed and when not performed are different as follows.

1) If performed: `eshop-MSA-CI/<< SERVICE NAME >>/build.gradle`
2) If not done: `eshop-MSA/<< SERVICE NAME >>/build.gradle`

<br>

Inject the dependency for jaeger tracing into `<< SERVICE NAME >>/build.gradle` as shown below.

<br>

**<< SERVICE NAME >>/build.gradle**
```java
//for jaeger tracing
compile group: 'io.opentracing.contrib', name: 'opentracing-spring-jaeger-web-starter', version: '3.1.2' // jaeger
```

<br>

![](../media2/image15.png)


<br>

2. Additional application of rabbitmq opentracing

<br>

Add one more dependency to build.gradle

<br>

```java
//for jaeger tracing
compile group: 'io.opentracing.contrib', name: 'opentracing-spring-rabbitmq-starter', version: '3.0.1' // jaeger
```
> 🗎 Note. https://github.com/opentracing-contrib/java-spring-rabbitmq


Additionally, configure the jaeger collection server and sender related settings in the `<< SERVICE NAME >>/src/main/resources/application.properties` file.

<br>

The modification items for when `Challenge 1-3` is performed and when not performed are different as follows.

1) If performed: `eshop-MSA-CI/<< SERVICE NAME >>/src/main/resources/application.properties`
2) If not done: `eshop-MSA/<< SERVICE NAME >>/src/main/resources/application.properties`

<br>

**<< SERVICE NAME >>/src/main/resources/application.properties**
```java
# jaeger-tracing properties
opentracing.jaeger.service-name=<< SERVICE NAME >>.eshop
opentracing.jaeger.enabled=true
opentracing.jaeger.log-spans=true
opentracing.jaeger.http-sender.url=http://eshop-jaeger-collector:14268/api/traces
```

Here, the service-name item is written in the format `<<service name>>.<< Namespace >>`, and for adservice, enter `<< SERVICE NAME >>.eshop` as in the example above.

<br>

For sender settings, two transaction transmission methods are provided: HTTP and UDP.

<br>

In this exercise, we will select http sender and perform the exercise.

<br>

---

🗎 Note. Spring Boot (Java) series Jaeger integration link
> <https://github.com/opentracing-contrib/java-spring-jaeger>

---

<br>

**😃 Challenge Completed!!!**

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
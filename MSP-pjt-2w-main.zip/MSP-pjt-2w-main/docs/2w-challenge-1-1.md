## Current status of the program

<br>

## 🤔 Challenge 1-1

### Topic: Test

<br>

📌 [Notes to be used during this lab]

📌 [ECR URI]<br>
➕ << ECR URI >> : <br>

<br>

## Test deployment with MSA inner on eshop-mgmt-eks-cluster (Fully manual operation)

<br>

**❗ Standard source (Service code completed with MSA in week 1 of actual project)**

<s3://t2hubintern/eshop-MSA.tar.gz>

> Using the reference from the above standard source, personalize the repository into a private repository on your personal github.

<br>

repository url after personalization

`https://github.com/<< GITHUB USER NAME >>/eshop-MSA.git`

<br>

**❗❗❗ There are two ways to push images: manually in WSL and using the CI Pipeline of Jenkins created. Below, we present how to build manually in WSL as a review of the first week of the actual project.❗❗❗**

<br>

1. Build image (performed in WSL local environment as in week 1)

[Java module building method, jib]

< WSL environment >
```bash
#eshop-adservice
#eshop-backend
#eshop-cartservice

./gradlew jibDockerBuild -Djib.to.tags=latest
```

<br>

---

**💡※ 🗎 Note.**
Official github for the jib library used above

<https://github.com/GoogleContainerTools/jib/tree/master/jib-gradle-plugin>

---

<br>


[Non-Java module building method, docker build]
< WSL environment >
```bash
#eshop-currencyservice
docker build -t eshop-currencyservice:latest .

#eshop-frontend
docker build -t eshop-frontend:latest .

#eshop-productservice
docker build -t eshop-productservice:latest .

#eshop-recommendservice
docker build -t eshop-recommendservice:latest .
```

<br>

2. Image tag

**common**

<br>

< WSL environment >
```bash
docker tag eshop-adservice:latest << ECR URI >>/eshop-adservice:latest
docker tag eshop-backend:latest << ECR URI >>/eshop-backend:latest
docker tag eshop-cartservice:latest << ECR URI >>/eshop-cartservice:latest
docker tag eshop-currencyservice:latest << ECR URI >>/eshop-currencyservice:latest
docker tag eshop-frontend:latest << ECR URI >>/eshop-frontend:latest
docker tag eshop-productservice:latest << ECR URI >>/eshop-productservice:latest
docker tag eshop-recommendservice:latest << ECR URI >>/eshop-recommendservice:latest
```

ECR Login

< WSL environment >
```bash
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin << ECR URI >>
```

<br>

3. Push to Image Repository

**common**

< WSL environment >
```bash
docker push << ECR URI >>/eshop-adservice:latest
docker push << ECR URI >>/eshop-backend:latest
docker push << ECR URI >>/eshop-cartservice:latest
docker push << ECR URI >>/eshop-currencyservice:latest
docker push << ECR URI >>/eshop-frontend:latest
docker push << ECR URI >>/eshop-productservice:latest
docker push << ECR URI >>/eshop-recommendservice:latest
```

<br>

4. Modify the Image path in the eshop-MSA/k8s/*.yaml Manifest file and push to the main branch of your personal Github repository (eshop-MSA).

**(Example of frontend.yaml below)**

**frontend.yaml**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
   name: eshop-frontend
spec:
   selector:
     matchLabels:
     app: eshop-frontend
   template:
     metadata:
       labels:
         app: eshop-frontend
     spec:
       containers:
         - name: eshop-frontend
           image: 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-frontend:latest
           ports:
...skip...
```

<br>

5. Installation and activation of ingress-nginx controller in MGMT EKS Cluster

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.3.0/deploy/static/provider/aws/deploy.yaml
```

<br>

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl -n ingress-nginx describe svc ingress-nginx-controller
```

<br>

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl -n ingress-nginx patch service ingress-nginx-controller -p '{"spec":{"externalTrafficPolicy":"Cluster"}}'
```

💡Related links on why you need to run the command `kubectl -n ingress-nginx patch service ingress-nginx-controller -p '{"spec":{"externalTrafficPolicy":"Cluster"}}'`

<https://aws.amazon.com/premiumsupport/knowledge-center/eks-unhealthy-worker-node-nginx/?nc1=h_ls>
> Since the externalTrafficPolicy is basically `Local`, only the Target Group that goes to the Worker Node where the workload actually runs is in a Healthy state, so reset the externalTrafficPolicy policy to the entire `Cluster`.

<br>

Check if ingress-nginx is installed properly
> If the service endpoint is created as shown in the example below, you can see that the installation was successful.

<br>

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl -n ingress-nginx get svc
```

<br>

✔ **(Example of execution code/result)**
```bash
kubectl -n ingress-nginx get svc
NAME TYPE CLUSTER-IP EXTERNAL-IP PORT(S) AGE
ingress-nginx-controller LoadBalancer 172.20.153.199 a543be52e171347c8aeea5ff57f0e240-c7493bbfb2745d2c.elb.us-east-1.amazonaws.com 80:30651/TCP,443:31713/TCP 2m31s
ingress-nginx-controller-admission ClusterIP 172.20.173.151 <none> 443/TCP 2m31s
```

<br>


6. Distribution test work through Argocd

<br>

Before performing distribution work through argocd, add the personalized eshop-MSA repository in argocd settings > repositories.

Repository URL: `https://github.com/<< GITHUB USER NAME >>/eshop-MSA.git`

![](../media1/argocd_setting_repo_1.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media1/argocd_setting_repo_2.png)

<br>

<p align="center">⬇️</p>

<br>

![](../media1/argocd_setting_repo_3.png)
> The items in the red box above are the individual's `<< GITHUB TOKEN >>` value.

***<span style="color:red">After registering the repository, check if it is successful. In case of failure, re-registration is required after disconnection</span>***

<br>

+New App creation task

Step 1) Enter GENERAL items

|Item|Content|Action|
|------|---|---|
|➕ Application Name |`eshop-k8s`|Copy & Paste|
|➕ Project |`default`|Select select box|
|➕ SYNC POLICY | `Manual` |Select select box (default)|
|➕ SYNC OPTIONS |`AUTO-CREATE NAMESPACE`|Select checkbox|

<br>

Step 2) Enter SOURCE items

|Item|Content|Action|
|------|---|---|
|➕ Repository URL|`https://github.com/<< GITHUB USER NAME >>/eshop-MSA.git`|Select select box|
|➕ Revision|`main` or `HEAD`|Select select box|
|➕ Path|`k8s`|Input|

<br>

Step 3) Enter DESTINATION items

|Item|Content|Action|
|------|---|---|
|➕ Cluster URL|`https://kubernetes.default.svc`|Select select box|
|➕ Namespace|`eshop`|Copy & Paste|

---
🗎 Note. https://kubernetes.default.svc Meaning

> It can be viewed as the DNS Name of the API SERVER of the local k8s cluster to which the specific application belongs.
>
> For example, the k8s Cluster where argocd is currently installed is the MGMT EKS Cluster, and from the argocd Application perspective, the API SERVER DNS Name of its local k8s cluster is the API SERVER of the MGMT EKS Cluster.

---

<br>

Step 4) Select Directory (since it is not Helm Format, it is not recognized as Helm in Argocd.)

<br>

7. After test deployment and operation testing are completed, remove unnecessary resources.

Step1) App deletion operation

Delete the Eshop App from Argocd.

<br>

Step2) Ingress-nginx controller deletion operation

< EC2 environment - admin server - mgmt context(mc) >
```bash
kubectl delete -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.3.0/deploy/static/provider/aws/deploy.yaml
```

<br>

**😃 Challenge Completed!!!**



<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
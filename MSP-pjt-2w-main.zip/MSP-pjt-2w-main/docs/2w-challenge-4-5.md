## Current status of the program

So far, we have managed AWS EKS's On Demand Data Plane (Worker Node) and performed deployment and management tasks.

<br>

## 🤔 Challenge 4-5

### Topic: Deployment (Fargate)

<br>

## Practice Objectives
- Deploy eshop on a Serverless container service using AWS Fargate EKS service.
- Understand the profile of AWS Fargate EKS service.
- Let’s use AWS Application Load Balancer as Ingress of eshop service.
- Add the certificate and HTTPS Listener created through ACM to the AWS Application Load Balancer.
- Try adding a path-based rule to AWS Application Load Balancer.
- Try controlling the security group of AWS Application Load Balancer.

<br>

## eshop deployment in EKS Fargate environment, a Serverless Container Service

<br>

Additionally, we will reduce the management points of the Data Plane (Worker Node) in the AWS EKS environment and apply the parts that enable eshop application deployment in a serverless environment.

The service in the environment described above is the AWS Fargate service.

In the case of AWS EKS Fargate, it has the advantage of reducing infrastructure management points from the user's perspective, but it does not support certain K8s types, such as Daemonset.

Due to the nature of the service, the trade-off between serverless environment and on-demand management is determined so that the optimal method can be selected.

<br>

Reference document. <https://blog.iron.io/aws-fargate/>

<br>

AWS Fargate: Pros and Cons

AWS Fargate is an exciting technology, but does it really live up to the hype? Below, we'll discuss some of the advantages and disadvantages of using AWS Fargate.

Pros:

Less Complexity

Better Security

Lower Costs (Maybe)

<br>

Cons:

Less Customization

Higher Costs (Maybe)

Region Availability

<br>

Reference document.
<https://docs.aws.amazon.com/ko_kr/AmazonECS/latest/userguide/what-is-fargate.html>

Reference document. <https://aws.amazon.com/ko/fargate/>

Reference document.
<https://aws.amazon.com/ko/premiumsupport/knowledge-center/eks-alb-ingress-controller-fargate/?nc1=h_ls>

<br>

![](../media2/fargate.png)

First, as a way to build EKS Ingress in a serverless environment, apply the method to activate AWS ALB Ingress Controller as follows.

Create a cluster for Fargate in the us-west-2 (Oregon) Region.

<br>

The K8s Manifest to be used in this exercise can be checked using the textbook and provided references.

1) Textbook
- See <a href="../etc/2w-reference-4-fargate.yaml">🗎. eshop fargate deployment manifest</a>
- <a href="../etc/2w-reference-4-fargate-clusterip.yaml">🗎 Reference. eshop(ClusterIP) fargate deployment manifest</a>

2) Reference PaC provided on the 3rd day
  
You can also refer to the yaml file under the fargate directory in eshop-PaC reference PaC.
> <s3://t2hubintern/3rd_eshop-PaC.tar.gz>
>
> eshop-PaC Reference Refer to the manifest file for fargate, which is a yaml file under the fargate directory in PaC.
>
> Requires personalization of the bottom part of each deployment page.
>
>```yaml
>(...omitted...)
>- image: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
>(...omitted...)
>```

<br>
<br>


Practice environment

Cluster Region: us-west-2(Oregon)

Cluster Name: eshop-service-fargate-cluster

<br>

Install eksctl for work in advance.

<br>

---

🗎 Note. install eksctl
> <https://docs.aws.amazon.com/ko_kr/eks/latest/userguide/eksctl.html>

<br>

< EC2 environment - admin server >
- Download and unzip the latest release of eksctl with the following command.

```bash
curl --silent --location "https://github.com/weaveworks/eksctl/releases/latest/download/eksctl_$(uname -s)_amd64.tar.gz" | tar xz -C /tmp
```

< EC2 environment - admin server >
- Move the unzipped binary file to /usr/local/bin.
```bash
sudo mv /tmp/eksctl /usr/local/bin
```

< EC2 environment - admin server >
- Test whether the installation was successful with the following command.
```bash
eksctl version
```

---

<br>

1. When creating an Amazon EKS cluster for Fargate using eksctl, create a VPC for Fargate and configure other settings through CloudFormation.

After connecting to the Admin Server, move to Ubuntu Home Directory

< EC2 environment - admin server >
```bash
cd ~
```

<br>

For reference, the work done through eksctl executes stacks defined in AWS CloudFormation sequentially. (Supported by AWS)

<br>

< EC2 environment - admin server >
```bash
eksctl create cluster --name eshop-service-fargate-cluster --version 1.24 --region us-west-2 --fargate
```
> Create the components of EKS Fargate Cluster through eksctl cli.


<br>

✔ **(Example of execution code/result)**
```bash
$ eksctl create cluster --name eshop-service-fargate-cluster --version 1.24 --region us-west-2 --fargate
2024-02-21 14:31:49 [ℹ]  eksctl version 0.171.0
2024-02-21 14:31:49 [ℹ]  using region us-west-2
2024-02-21 14:31:49 [ℹ]  setting availability zones to [us-west-2d us-west-2a us-west-2b]
2024-02-21 14:31:49 [ℹ]  subnets for us-west-2d - public:192.168.0.0/19 private:192.168.96.0/19
2024-02-21 14:31:49 [ℹ]  subnets for us-west-2a - public:192.168.32.0/19 private:192.168.128.0/19
2024-02-21 14:31:49 [ℹ]  subnets for us-west-2b - public:192.168.64.0/19 private:192.168.160.0/19
2024-02-21 14:31:49 [ℹ]  using Kubernetes version 1.24
2024-02-21 14:31:49 [ℹ]  creating EKS cluster "eshop-service-fargate-cluster" in "us-west-2" region with Fargate profile
2024-02-21 14:31:49 [ℹ]  if you encounter any issues, check CloudFormation console or try 'eksctl utils describe-stacks --region=us-west-2 --cluster=eshop-service-fargate-cluster'
2024-02-21 14:31:49 [ℹ]  Kubernetes API endpoint access will use default of {publicAccess=true, privateAccess=false} for cluster "eshop-service-fargate-cluster" in "us-west-2"
2024-02-21 14:31:49 [ℹ]  CloudWatch logging will not be enabled for cluster "eshop-service-fargate-cluster" in "us-west-2"
2024-02-21 14:31:49 [ℹ]  you can enable it with 'eksctl utils update-cluster-logging --enable-types={SPECIFY-YOUR-LOG-TYPES-HERE (e.g. all)} --region=us-west-2 --cluster=eshop-service-fargate-cluster'
2024-02-21 14:31:49 [ℹ]
2 sequential tasks: { create cluster control plane "eshop-service-fargate-cluster",
    2 sequential sub-tasks: {
        wait for control plane to become ready,
        create fargate profiles,
    }
}
2024-02-21 14:31:49 [ℹ]  building cluster stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:31:51 [ℹ]  deploying stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:32:21 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:32:51 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:33:52 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:34:53 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:35:53 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:36:54 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:37:55 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:38:56 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:39:57 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:40:58 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:41:58 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 14:44:03 [ℹ]  creating Fargate profile "fp-default" on EKS cluster "eshop-service-fargate-cluster"
2024-02-21 14:46:15 [ℹ]  created Fargate profile "fp-default" on EKS cluster "eshop-service-fargate-cluster"
2024-02-21 14:46:46 [ℹ]  "coredns" is now schedulable onto Fargate
2024-02-21 14:47:52 [ℹ]  "coredns" is now scheduled onto Fargate
2024-02-21 14:47:52 [ℹ]  "coredns" pods are now scheduled onto Fargate
2024-02-21 14:47:52 [ℹ]  waiting for the control plane to become ready
2024-02-21 14:47:53 [✔]  saved kubeconfig as "/home/ubuntu/.kube/config"
2024-02-21 14:47:53 [ℹ]  no tasks
2024-02-21 14:47:53 [✔]  all EKS cluster resources for "eshop-service-fargate-cluster" have been created
2024-02-21 14:47:54 [ℹ]  kubectl command should work with "/home/ubuntu/.kube/config", try 'kubectl get nodes'
2024-02-21 14:47:54 [✔]  EKS cluster "eshop-service-fargate-cluster" in "us-west-2" region is ready
```
> It takes some time to create (about 15 minutes or more), and when everything is done as above, you can say that you are ready to use Fargate Cluster.

<br>


If creation is complete, execute the AWS CLI command to save the information of the created EKS Fargate Cluster in .kube/config.

< EC2 environment - admin server >
```bash
aws eks --region us-west-2 update-kubeconfig --name eshop-service-fargate-cluster --alias eshop-fg
```
> Add the newly created EKS Fargate Cluster information to the .kube/config file under the Home Directory of the linux account.

<br>

✔ **(Example of execution code/result)**
```bash
$ aws eks --region us-west-2 update-kubeconfig --name eshop-service-fargate-cluster --alias eshop-fg
Added new context eshop-fg to /home/ubuntu/.kube/config
```
> When added properly, results similar to the output example above are displayed.

<br>

***

🗎 Note. You can see below how to easily switch context with Linux alias.

```bash
# Enable (switch to mgmt)
mc
```

```bash
# Use (switch to eshop)
ec
```

```bash
# Use (switch to eshop-fg, a fargate cluster)
ef
```

```bash
# Use (check current context)
wai
```

***

<br>

<details>
<summary> [🗎 Note - Expand👇] How to delete the created EKS Fargate Cluster configuration (for reference only, do not execute)</summary>

<br>

This is the command that will be performed after completing all future exercises. If it was a step that was normally performed, ***just refer to it and do not perform it.***

---

#Delete command <span style="color:red">**(for reference only, not executed)**</span>

< EC2 environment - admin server >
```bash
eksctl delete cluster --name eshop-service-fargate-cluster --region us-west-2
```

---

</details>

<br>

After performing step 1, you can actually check the creation of the cluster in the path below in the AWS Console.

AWS > EKS > Clusters

[Example screen]
![](../media2/fargate_cluster_1.png)

<br>

2. To allow the EKS Fargate Cluster service account to use AWS Identity and Access Management (IAM), run this command.

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
eksctl utils associate-iam-oidc-provider --cluster eshop-service-fargate-cluster --region us-west-2 --approve
```

<br>

✔ **(Example of execution code/result)**
```bash
$ eksctl utils associate-iam-oidc-provider --cluster eshop-service-fargate-cluster --region us-west-2 --approve
2024-02-21 15:54:14 [ℹ] will create IAM Open ID Connect provider for cluster "eshop-service-fargate-cluster" in "us-west-2"
2024-02-21 15:54:15 [✔] created IAM Open ID Connect provider for cluster "eshop-service-fargate-cluster" in "us-west-2"
```

<br>

3. Run this command to download an IAM policy that allows the AWS Load Balancer Controller in your EKS Fargate Cluster to call AWS APIs on your behalf.

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
curl -o iam_policy.json https://raw.githubusercontent.com/kubernetes-sigs/aws-load-balancer-controller/v2.5.3/docs/install/iam_policy.json
```
> iam_policy.json is downloaded to the location where the command is executed.

<br>

✔ **(Example of execution code/result)**
```bash
$ curl -o iam_policy.json https://raw.githubusercontent.com/kubernetes-sigs/aws-load-balancer-controller/v2.5.3/docs/install/iam_policy.json
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100  8386  100  8386    0     0  27051      0 --:--:-- --:--:-- --:--:-- 27051
```

<br>

4. Run this command to create an IAM policy using the policy file (iam_policy.json) downloaded in step 3.

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
aws iam create-policy \
   --policy-name AWSLoadBalancerControllerIAMPolicy \
   --policy-document file://iam_policy.json
```
> iam_policy.json It should be performed where it exists.

<br>

✔ **(execution code/result example)**
```bash
$ aws iam create-policy \
>    --policy-name AWSLoadBalancerControllerIAMPolicy \
>    --policy-document file://iam_policy.json
{
    "Policy": {
        "PolicyName": "AWSLoadBalancerControllerIAMPolicy",
        "PolicyId": "ANPATIMLCBK7GQYY7QNN3",
        "Arn": "arn:aws:iam::224166808254:policy/AWSLoadBalancerControllerIAMPolicy",
        "Path": "/",
        "DefaultVersionId": "v1",
        "AttachmentCount": 0,
        "PermissionsBoundaryUsageCount": 0,
        "IsAttachable": true,
        "CreateDate": "2024-02-21T06:54:39Z",
        "UpdateDate": "2024-02-21T06:54:39Z"
    }
}
```
> This is a command that creates an AWS IAM Policy with the contents of the downloaded json file.

<br>

5. Run this command to create a Service Account named aws-load-balancer-controller in the kube-system namespace for the AWS Load Balancer Controller. <span style="color:red">**(Replace << AWS ACCOUNT ID >> in the command below with your personal Account ID)**</span>
< EC2 환경 - admin server - eshop fargate context(ef) >
```bash
eksctl create iamserviceaccount \
  --cluster=eshop-service-fargate-cluster \
  --namespace=kube-system \
  --name=aws-load-balancer-controller \
  --attach-policy-arn=arn:aws:iam::<< AWS ACCOUNT ID >>:policy/AWSLoadBalancerControllerIAMPolicy \
  --override-existing-serviceaccounts \
  --region=us-west-2 \
  --approve
```

<br>

✔ **(수행 코드/결과 예시)**
```bash
$ eksctl create iamserviceaccount \
>   --cluster=eshop-service-fargate-cluster \
>   --namespace=kube-system \
>   --name=aws-load-balancer-controller \
>   --attach-policy-arn=arn:aws:iam::224166808254:policy/AWSLoadBalancerControllerIAMPolicy \
>   --override-existing-serviceaccounts \
>   --region=us-west-2 \
>   --approve
2024-02-21 15:55:08 [ℹ]  1 iamserviceaccount (kube-system/aws-load-balancer-controller) was included (based on the include/exclude rules)
2024-02-21 15:55:08 [!]  metadata of serviceaccounts that exist in Kubernetes will be updated, as --override-existing-serviceaccounts was set
2024-02-21 15:55:08 [ℹ]  1 task: {
    2 sequential sub-tasks: {
        create IAM role for serviceaccount "kube-system/aws-load-balancer-controller",
        create serviceaccount "kube-system/aws-load-balancer-controller",
    } }2024-02-21 15:55:08 [ℹ]  building iamserviceaccount stack "eksctl-eshop-service-fargate-cluster-addon-iamserviceaccount-kube-system-aws-load-balancer-controller"
2024-02-21 15:55:08 [ℹ]  deploying stack "eksctl-eshop-service-fargate-cluster-addon-iamserviceaccount-kube-system-aws-load-balancer-controller"
2024-02-21 15:55:09 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-addon-iamserviceaccount-kube-system-aws-load-balancer-controller"
2024-02-21 15:55:39 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-addon-iamserviceaccount-kube-system-aws-load-balancer-controller"
2024-02-21 15:55:40 [ℹ]  created serviceaccount "kube-system/aws-load-balancer-controller"
```

<br>

6. To verify that the new service role in EKS Fargate Cluster has been created, run this command.

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
kubectl get serviceaccount aws-load-balancer-controller --namespace kube-system
```

<br>

✔ **(Example of execution code/result)**
```bash
$ kubectl get serviceaccount aws-load-balancer-controller --namespace kube-system
NAME SECRETS AGE
aws-load-balancer-controller 0 22s
```
> If the above service role creation command was executed normally, the serviceaccount will be displayed as shown in the example above.

<br>

7. Check whether the Helm Client in the Admin Server is installed normally.

Day 1 Just check whether the installation was successful using the User Data in the mgmt IaC Terraform code.

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
helm version
```

<br>

✔ **(Example of execution code/result)**
```bash
ubuntu@ip-10-0-10-201:~$ helm version
WARNING: Kubernetes configuration file is group-readable. This is insecure. Location: /home/ubuntu/.kube/config
WARNING: Kubernetes configuration file is world-readable. This is insecure. Location: /home/ubuntu/.kube/config
version.BuildInfo{Version:"v3.8.2", GitCommit:"6e3701edea09e5d55a8ca2aae03a68917630e91b", GitTreeState:"clean", GoVersion:"go1.17.5"}
```
> You can ignore the WARNING statement, and if the version information comes out as 3.8.2, it can be considered as a normal installation.

<br>

8. Next, run this command to add the Amazon EKS chart to the Helm Repo to install the aws load balancer controller on the EKS Fargate Cluster.

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
helm repo add eks https://aws.github.io/eks-charts
```

<br>

✔ **(Example of execution code/result)**
```bash
$ helm repo add eks https://aws.github.io/eks-charts
WARNING: Kubernetes configuration file is group-readable. This is insecure. Location: /home/ubuntu/.kube/config
WARNING: Kubernetes configuration file is world-readable. This is insecure. Location: /home/ubuntu/.kube/config
"eks" has been added to your repositories
```

<br>

9. To install the TargetGroupBinding custom resource definition (CRD) in the EKS Fargate Cluster, run this command.

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
kubectl apply -k "github.com/aws/eks-charts/stable/aws-load-balancer-controller//crds?ref=master"
```

<br>

✔ **(Example of execution code/result)**
```bash
$ kubectl apply -k "github.com/aws/eks-charts/stable/aws-load-balancer-controller//crds?ref=master"
customresourcedefinition.apiextensions.k8s.io/ingressclassparams.elbv2.k8s.aws created
customresourcedefinition.apiextensions.k8s.io/targetgroupbindings.elbv2.k8s.aws created
```

<br>

10. Install AWS load balancer controller using Helm Chart in EKS Fargate Cluster <span style="color:red">** (When installing, set the vpcId to your own, enter the ID value of the VPC created in step 1 above. .)**</span>

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
    --set clusterName=eshop-service-fargate-cluster \
    --set serviceAccount.create=false \
    --set region=us-west-2 \
    --set vpcId=<<개인 VPC ID>> \
    --set serviceAccount.name=aws-load-balancer-controller \
    -n kube-system
```

---

🗎reference. AWS CLI command to query private eshop-service-fargate-cluster VPC ID
> < EC2 environment - admin server >
> ```
> aws ec2 describe-vpcs --region us-west-2 --filters Name=tag:Name,Values=eksctl-eshop-service-fargate-cluster-cluster/VPC | grep VpcId
> ```

---

<br>

<Example>
```bash
helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
    --set clusterName=eshop-service-fargate-cluster \
    --set serviceAccount.create=false \
    --set region=us-west-2 \
    --set vpcId=vpc-030b027a9b292e195 \
    --set serviceAccount.name=aws-load-balancer-controller \
    -n kube-system
```

<br>

✔ **(execution code/result example)**
```bash
NAME: aws-load-balancer-controller
LAST DEPLOYED: Thu Aug 25 04:00:47 2022
NAMESPACE: kube-system
STATUS: deployed
REVISION: 1
TEST SUITE: None
NOTES:
AWS Load Balancer controller installed!
```


If you get a result similar to the output example above, the ALB Ingress Controller has been activated in the AWS EKS Fargate Cluster situation.

The process below deploys a sample application and eshop application in AWS EKS Fargate with the ALB Ingress Controller enabled.

<br>

<details>
<summary> [🗎 Note - Expand 👇] How to delete the aws loadbalancer controller installed by Helm (for reference only, do not run)</summary>

---

<br>

#Uninstall <span style="color:red">**(For reference only. Do not run)**</span>

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
helm uninstall -n kube-system aws-load-balancer-controller
```

#Upgrade & Install <span style="color:red">** (For reference only. Do not run. When installing, set the vpcId to your own)**</span>

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
helm upgrade --install aws-load-balancer-controller eks/aws-load-balancer-controller \
    --set clusterName=eshop-service-fargate-cluster \
    --set serviceAccount.create=false \
    --set region=us-west-2 \
    --set vpcId=<<개인 VPC ID>> \
    --set serviceAccount.name=aws-load-balancer-controller \
    -n kube-system
```

<br>
<br>

---

</details>

<br>

[eshop test distribution]

11. Create fargate profile

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
eksctl create fargateprofile --cluster eshop-service-fargate-cluster --region us-west-2 --name eshop --namespace eshop-fg
```

<br>

12. Deploy eshop within EKS Fargate Cluster

Before deployment, be sure to place it in the `eshop-fg` Context.

< EC2 environment - admin server >
```bash
kubectl config use-context eshop-fg
```

<br>


Create an `eshop-fargate.yaml` file using a vi editor, etc. in an appropriate location (/home/ubuntu/eshop-fargate.yaml, etc.) in the Admin Server.
Afterwards, perform deployment using the kubectl apply command.

<br>

When creating a file in the Admin Server guided above, refer to the yaml manifest files located under the fargate directory path under the individual's eshop PaC. You may use either the `ClusterIP` or `NodePort` Type below.

(However, variables such as << ECR URI >>, << SERVICE NAME >>, and << TAG >> must be replaced with personal values.)
> eshop-PaC/fargate/eshop-fargate.yaml
>
> eshop-PaC/fargate/eshop-fargate-clusterip.yaml

<br>

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
kubectl apply -f eshop-fargate.yaml
```

<br>

If the above command is executed normally, the output will be similar to the example below. ***For normal operation, variables in the eshop-fargate.yaml file must be replaced with correct individual values.***

✔ **(Example of execution code/result)**
```bash
$ kubectl apply -f eshop-fargate.yaml
namespace/eshop-fg created
deployment.apps/eshop-frontend created
service/eshop-frontend created
deployment.apps/eshop-backend created
service/eshop-backend created
deployment.apps/eshop-cartservice created
service/eshop-cartservice created
deployment.apps/eshop-productservice created
service/eshop-productservice created
deployment.apps/eshop-adservice created
service/eshop-adservice created
deployment.apps/eshop-currencyservice created
service/eshop-currencyservice created
deployment.apps/eshop-recommendservice created
service/eshop-recommendservice created
ingress.networking.k8s.io/eshop-ingress created
deployment.apps/postgres created
service/postgres created
statefulset.apps/mongodb created
service/mongodb created
deployment.apps/rabbitmq created
service/rabbitmq created
deployment.apps/redis created
service/redis created
```

<br>

13. Check eshop ingress in EKS Fargate Cluster

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
kubectl get ingress/eshop-ingress -n eshop-fg
```

<br>

✔ **(Example of execution code/result)**
```
NAMESPACE NAME CLASS HOSTS ADDRESS PORTS AGE
eshop-fg eshop-ingress alb * k8s-eshopfg-eshoping-ac3782643a-106561112.us-west-2.elb.amazonaws.com 80 3m22s
```

<br>

14. Check eshop nodes in EKS Fargate Cluster (fargate nodes)

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
kubectl get nodes
```

<br>

✔ **(Example of execution code/result)**
```bash
$ kubectl get nodes
NAME                                                    STATUS   ROLES    AGE     VERSION
fargate-ip-192-168-107-7.us-west-2.compute.internal     Ready    <none>   96m     v1.24.17-eks-680e576
fargate-ip-192-168-124-6.us-west-2.compute.internal     Ready    <none>   96m     v1.24.17-eks-680e576
fargate-ip-192-168-141-17.us-west-2.compute.internal    Ready    <none>   3m8s    v1.24.17-eks-680e576
fargate-ip-192-168-142-37.us-west-2.compute.internal    Ready    <none>   17m     v1.24.17-eks-680e576
fargate-ip-192-168-143-63.us-west-2.compute.internal    Ready    <none>   3m      v1.24.17-eks-680e576
fargate-ip-192-168-143-78.us-west-2.compute.internal    Ready    <none>   3m5s    v1.24.17-eks-680e576
fargate-ip-192-168-151-147.us-west-2.compute.internal   Ready    <none>   3m12s   v1.24.17-eks-680e576
fargate-ip-192-168-152-249.us-west-2.compute.internal   Ready    <none>   17m     v1.24.17-eks-680e576
fargate-ip-192-168-154-55.us-west-2.compute.internal    Ready    <none>   3m16s   v1.24.17-eks-680e576
fargate-ip-192-168-158-219.us-west-2.compute.internal   Ready    <none>   3m5s    v1.24.17-eks-680e576
fargate-ip-192-168-162-70.us-west-2.compute.internal    Ready    <none>   3m12s   v1.24.17-eks-680e576
fargate-ip-192-168-166-77.us-west-2.compute.internal    Ready    <none>   3m8s    v1.24.17-eks-680e576
fargate-ip-192-168-167-203.us-west-2.compute.internal   Ready    <none>   3m12s   v1.24.17-eks-680e576
fargate-ip-192-168-170-174.us-west-2.compute.internal   Ready    <none>   3m13s   v1.24.17-eks-680e576
fargate-ip-192-168-98-139.us-west-2.compute.internal    Ready    <none>   3m5s    v1.24.17-eks-680e576
```

<br>

15. Check overall distribution status of eshop in EKS Fargate Cluster

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
kubectl get all -A
```
In the case of eshop-related pods, they are displayed as normally deployed in the eshop-fg pod, and AWS ALB and DNS-related matters are distributed to the kube-system namespace to confirm that deployment to each Serverless environment has been completed.


<br>

In normal cases, it will be displayed in a form similar to the output example below.

✔ **(Example of execution code/result)**
```bash
$ kubectl get all -A
NAMESPACE     NAME                                               READY   STATUS    RESTARTS        AGE
eshop-fg      pod/eshop-adservice-676dffd59d-wbjxj               1/1     Running   0               5m28s
eshop-fg      pod/eshop-backend-74f7d4858-pt569                  1/1     Running   0               5m31s
eshop-fg      pod/eshop-cartservice-57df959446-tw2bt             1/1     Running   0               5m30s
eshop-fg      pod/eshop-currencyservice-5b669dd7ff-k4ztz         1/1     Running   0               5m27s
eshop-fg      pod/eshop-frontend-5bb59d45b4-8wlbn                1/1     Running   0               5m32s
eshop-fg      pod/eshop-productservice-544d8c5d45-l84qf          1/1     Running   1 (4m16s ago)   5m29s
eshop-fg      pod/eshop-recommendservice-697697b9fb-gbpl5        1/1     Running   0               5m26s
eshop-fg      pod/mongodb-0                                      1/1     Running   0               5m23s
eshop-fg      pod/postgres-5c57d65b7d-tq8w9                      1/1     Running   0               5m24s
eshop-fg      pod/rabbitmq-59f6846bbc-rx79l                      1/1     Running   0               5m22s
eshop-fg      pod/redis-655d9fd58c-lss69                         1/1     Running   0               5m21s
kube-system   pod/aws-load-balancer-controller-f698cdff9-88jxh   1/1     Running   0               20m
kube-system   pod/aws-load-balancer-controller-f698cdff9-9gjct   1/1     Running   0               20m
kube-system   pod/coredns-774b5d65b4-m9hdc                       1/1     Running   0               98m
kube-system   pod/coredns-774b5d65b4-qqw24                       1/1     Running   0               98m

NAMESPACE     NAME                                        TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)          AGE
default       service/kubernetes                          ClusterIP   10.100.0.1       <none>        443/TCP          107m
eshop-fg      service/eshop-adservice                     NodePort    10.100.173.1     <none>        8095:32022/TCP   5m29s
eshop-fg      service/eshop-backend                       NodePort    10.100.165.214   <none>        8090:30002/TCP   5m32s
eshop-fg      service/eshop-cartservice                   NodePort    10.100.61.201    <none>        8091:32274/TCP   5m31s
eshop-fg      service/eshop-currencyservice               NodePort    10.100.184.211   <none>        8094:30542/TCP   5m28s
eshop-fg      service/eshop-frontend                      NodePort    10.100.245.25    <none>        8080:31008/TCP   5m33s
eshop-fg      service/eshop-productservice                NodePort    10.100.48.196    <none>        8092:32226/TCP   5m30s
eshop-fg      service/eshop-recommendservice              NodePort    10.100.129.166   <none>        8093:32647/TCP   5m27s
eshop-fg      service/mongodb                             ClusterIP   None             <none>        <none>           5m24s
eshop-fg      service/postgres                            ClusterIP   10.100.191.101   <none>        5432/TCP         5m25s
eshop-fg      service/rabbitmq                            ClusterIP   10.100.44.235    <none>        5672/TCP         5m23s
eshop-fg      service/redis                               ClusterIP   10.100.194.32    <none>        6379/TCP         5m22s
kube-system   service/aws-load-balancer-webhook-service   ClusterIP   10.100.30.31     <none>        443/TCP          20m
kube-system   service/kube-dns                            ClusterIP   10.100.0.10      <none>        53/UDP,53/TCP    105m

NAMESPACE     NAME                        DESIRED   CURRENT   READY   UP-TO-DATE   AVAILABLE   NODE SELECTOR   AGE
kube-system   daemonset.apps/aws-node     0         0         0       0            0           <none>          105m
kube-system   daemonset.apps/kube-proxy   0         0         0       0            0           <none>          105m

NAMESPACE     NAME                                           READY   UP-TO-DATE   AVAILABLE   AGE
eshop-fg      deployment.apps/eshop-adservice                1/1     1            1           5m29s
eshop-fg      deployment.apps/eshop-backend                  1/1     1            1           5m32s
eshop-fg      deployment.apps/eshop-cartservice              1/1     1            1           5m31s
eshop-fg      deployment.apps/eshop-currencyservice          1/1     1            1           5m28s
eshop-fg      deployment.apps/eshop-frontend                 1/1     1            1           5m33s
eshop-fg      deployment.apps/eshop-productservice           1/1     1            1           5m30s
eshop-fg      deployment.apps/eshop-recommendservice         1/1     1            1           5m27s
eshop-fg      deployment.apps/postgres                       1/1     1            1           5m26s
eshop-fg      deployment.apps/rabbitmq                       1/1     1            1           5m23s
eshop-fg      deployment.apps/redis                          1/1     1            1           5m22s
kube-system   deployment.apps/aws-load-balancer-controller   2/2     2            2           20m
kube-system   deployment.apps/coredns                        2/2     2            2           105m

NAMESPACE     NAME                                                     DESIRED   CURRENT   READY   AGE
eshop-fg      replicaset.apps/eshop-adservice-676dffd59d               1         1         1       5m29s
eshop-fg      replicaset.apps/eshop-backend-74f7d4858                  1         1         1       5m32s
eshop-fg      replicaset.apps/eshop-cartservice-57df959446             1         1         1       5m31s
eshop-fg      replicaset.apps/eshop-currencyservice-5b669dd7ff         1         1         1       5m28s
eshop-fg      replicaset.apps/eshop-frontend-5bb59d45b4                1         1         1       5m33s
eshop-fg      replicaset.apps/eshop-productservice-544d8c5d45          1         1         1       5m30s
eshop-fg      replicaset.apps/eshop-recommendservice-697697b9fb        1         1         1       5m27s
eshop-fg      replicaset.apps/postgres-5c57d65b7d                      1         1         1       5m26s
eshop-fg      replicaset.apps/rabbitmq-59f6846bbc                      1         1         1       5m23s
eshop-fg      replicaset.apps/redis-655d9fd58c                         1         1         1       5m22s
kube-system   replicaset.apps/aws-load-balancer-controller-f698cdff9   2         2         2       20m
kube-system   replicaset.apps/coredns-774b5d65b4                       2         2         2       98m
kube-system   replicaset.apps/coredns-7f8f664559                       0         0         0       105m

NAMESPACE   NAME                       READY   AGE
eshop-fg    statefulset.apps/mongodb   1/1     5m25s
```

<br>

<details>
<summary> [🗎 Note - Expand👇] Apply TLS certificate to ALB (It is not required.)</summary>

<br>

Next, let's apply the ACM certificate created in the `us-west-2` Region to the ALB activated in the EKS Fargate Cluster to enable SSL/TLS API and service URL calls.

<br>

---

🗎 Note. Refer to the AWS official document below and perform steps 1) to 4) below.
> <https://docs.aws.amazon.com/ko_kr/elasticloadbalancing/latest/application/listener-update-rules.html>

<br>

1) Refer to the existing rules for port 80 and apply the same rules to port 443.

![](../media2/fargate_action.png)
> Action is set to 404 by default.

![](../media2/fargate_rule.png)

<br>

2) Add rules for port 443 through Add listener.

The certificate selects the ACM created on the 1st day of week 1.

![](../media2/fargate_tls.png)

<br>


3) Open an entry to Port 443 to allow HTTPS calls to the ALB's security group.

![](../media2/fargate_sg.png)

<br>

4) Proceed with settings to make TLS calls through alias domain mapping of the Route53 service.

ex) `eshop-fg.mspt3.click`

![](../media2/fargate_route53.png)
![](../media2/fargate_cert.png)

---

<br>

</details>

<br>

16. Delete all eshop components deployed on EKS Fargate Cluster

```bash
kubectl delete -f eshop-fargate.yaml
```

<br>

17. Delete the `eshop` Fargate Profile.
> Deleting a Fargate Profile basically takes a long time, so wait to see if the previous step was performed successfully before performing the next step.

<br>

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
eksctl delete fargateprofile --cluster eshop-service-fargate-cluster --region us-west-2 --name eshop
```

<br>

✔ **(Example of execution code/result)**
```bash
$ eksctl delete fargateprofile --cluster eshop-service-fargate-cluster --region us-west-2 --name eshop
2024-02-21 16:36:29 [ℹ] deleted Fargate profile "eshop" on EKS cluster "eshop-service-fargate-cluster"
```
> Even if the above result is obtained, it takes some time to delete the actual Fargate profile, so proceed to the next step after checking whether eshop is deleted from Fargate profiles in AWS > EKS > Cluster Lists > eshop-service-fargate-cluster > Compute. . (Check whether it was actually deleted in the AWS Console)

<br><br>

< EC2 environment - admin server - eshop fargate context(ef) >
```bash
eksctl delete fargateprofile --cluster eshop-service-fargate-cluster --region us-west-2 --name fp-default
```

<br>

✔ **(Example of execution code/result)**
```bash
$ eksctl delete fargateprofile --cluster eshop-service-fargate-cluster --region us-west-2 --name fp-default
2024-02-21 16:40:36 [ℹ] no fargate stack to delete
2024-02-21 16:40:36 [ℹ] deleted Fargate profile "fp-default" on EKS cluster "eshop-service-fargate-cluster"
```
> Even if the above results are obtained, it takes some time to delete the Fargate profile, so proceed to the next step after checking whether fp-default is deleted from Fargate profiles in AWS > EKS > Cluster Lists > eshop-service-fargate-cluster > Compute. do. (Check whether it was actually deleted in the AWS Console)

<br>

18. Finally, delete the EKS Cluster and VPC for Fargate created through CloudFormation.

<br>

< EC2 environment - admin server >
```bash
eksctl delete cluster --name eshop-service-fargate-cluster --region us-west-2
```
> Delete the components of the EKS Fargate Cluster created through eksctl cli.

<br>

✔ **(Example of execution code/result)**
```bash
$ eksctl delete cluster --name eshop-service-fargate-cluster --region us-west-2
2024-02-21 16:44:21 [ℹ]  deleting EKS cluster "eshop-service-fargate-cluster"
2024-02-21 16:44:23 [ℹ]  deleted 0 Fargate profile(s)
2024-02-21 16:44:24 [✔]  kubeconfig has been updated
2024-02-21 16:44:24 [ℹ]  cleaning up AWS load balancers created by Kubernetes objects of Kind Service or Ingress
2024-02-21 16:44:29 [ℹ]
2 sequential tasks: {
    2 sequential sub-tasks: {
        2 sequential sub-tasks: {
            delete IAM role for serviceaccount "kube-system/aws-load-balancer-controller",
            delete serviceaccount "kube-system/aws-load-balancer-controller",
        },
        delete IAM OIDC provider,
    }, delete cluster control plane "eshop-service-fargate-cluster" [async]
}
2024-02-21 16:44:29 [ℹ]  will delete stack "eksctl-eshop-service-fargate-cluster-addon-iamserviceaccount-kube-system-aws-load-balancer-controller"
2024-02-21 16:44:29 [ℹ]  waiting for stack "eksctl-eshop-service-fargate-cluster-addon-iamserviceaccount-kube-system-aws-load-balancer-controller" to get deleted
2024-02-21 16:44:29 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-addon-iamserviceaccount-kube-system-aws-load-balancer-controller"
2024-02-21 16:45:00 [ℹ]  waiting for CloudFormation stack "eksctl-eshop-service-fargate-cluster-addon-iamserviceaccount-kube-system-aws-load-balancer-controller"
2024-02-21 16:45:00 [ℹ]  deleted serviceaccount "kube-system/aws-load-balancer-controller"
2024-02-21 16:45:01 [ℹ]  will delete stack "eksctl-eshop-service-fargate-cluster-cluster"
2024-02-21 16:45:02 [✔]  all cluster resources were deleted
```
> eksctl cli를 통해 EKS Fargate Cluster 구성요소들을 전체 삭제하는 과정에 다소 시간이 소요됨을 참고한다.

AWS > EKS > Clusters

[Example screen]
![](../media2/fargate_cluster_delete.png)

<br>

19. In AWS > IAM > Policies, the "AWSLoadBalancerControllerIAMPolicy" item appears on the first screen. Delete the policy.

AWS Console > Enter IAM service > Policies > Select Cumstomer Managed Type > Select `AWSLoadBalancerControllerIAMPolicy` radio box > Perform `Delete`

[Example screen]
![](../media2/fargate_iam_policy_delete.png)

<br>
<br>

**😃 Challenge Completed!!!**

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
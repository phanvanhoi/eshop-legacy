## Current status of the program

<br>

## 🤔 Challenge 3-5

### Topic: Amazon MQ (rabbitMQ broker)

<br>

📌 [Additional notes to use during challenges]

📌 [Amazon MQ AMQP Endpoint (Challenge)]<br>
***Value of mq_web_console_url among terraform output results of chal_rabbitmq_eshop-service-IaC.tar.gz IaC code***<br>
➕ << Amazon MQ AMQP Endpoint >> : <br>

<br>

## Take advantage of Amazon MQ Fully Managed Service

<br>

Hipster Shop (eshop) is an online shopping mall where you can purchase a variety of products.

The management of Hipster shop (eshop) has moved the service to **public cloud** and **container-based microservice** and is operating it somewhat stably.

Discussions were held on applying the ‘Fully Managed Service (FMS) service’ provided by public cloud (AWS), which reduces the management points for rabbitMQ containers during operation and provides ease of cluster configuration, and ‘decided to apply’ It became.

Among the Amazon MQ services provided by AWS, we create an infrastructure using the rabbitMQ broker and link microservices related to 'asynchronous logic processing' such as 'eshop-backend' and 'eshop-cartservice' with the broker.

<br>

---

🗎 Note. AWS AmazonMQ Service
<https://docs.aws.amazon.com/ko_kr/amazon-mq/latest/developer-guide/welcome.html>

---

<br>

Apply the FMS service specialized for rabbitMQ, a component related to the asynchronous function of Hipster shop (eshop), and perform the broker creation conditions as follows. Create an Amazon MQ broker with the following conditions using the provided Terraform code.

Creating an Amazon MQ RabbitMQ Broker with Terraform
  - Broker type: `RabbitMQ` engine
  - Region: `us-west-2` (service cluster region)
  - Version: `3.11.20`
  - Broker specifications: `mq.t3.micro` (since this is a practice test, minimum specifications are created)
  - Whether to allow public access: `true` (Because this is a practice test, public access is allowed, but in reality, security group management through private access is required.)
  - Basic Management UI Credentials
    - ID: `admin`
    - PW: `zmffkdnem00!@`
  - Broker settings (using Amazon MQ’s parameter group)
    - `eshop-configuration` (named as `broker name-configuration` by default)
    - Configuration includes all settings for the RabbitMQ broker in Cuttlefish format.
    - https://docs.aws.amazon.com/ko_kr/amazon-mq/latest/developer-guide/rabbitmq-creating-applying-configurations.html

<br>

In summary, the goals of the operation team are as follows.
  - Related keywords: Public cloud FMS application

<br>
<br>


## solution

<br>

<details>
<summary>[Performance 1 - Expand👇] Terraform execution adding Amazon MQ generation code to service IaC</summary>

<br>

In the second day process, a new branch for the challenge is created in the personalized eshop-service-IaC Github Repository. (Branch name: `feature-rabbitmq`)

<br>

---

🗎 Note. Reference IaC source

<s3://t2hubintern/chal_rabbitmq_eshop-service-IaC.tar.gz>

---

<br>

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```
> Go to the workspace directory of service IaC


< WSL environment >
```bash
git branch
```
> Check the branch list of service IaC


✔ **(Example of execution code/result)**
```bash
ubuntu@SEAN-OFFICE-LAPTOP:~/t3-msp-pjt/eshop-service-IaC$ git branch
* main
```
> Usually, it will be designated as the main branch.

< WSL environment >
```bash
git checkout -b feature-rabbitmq
```
> Create and move the feature-rabbitmq branch for the challenge.


✔ **(Example of execution code/result)**
```bash
ubuntu@SEAN-OFFICE-LAPTOP:~/t3-msp-pjt/eshop-service-IaC$ git checkout -b feature-rabbitmq
Switched to a new branch 'feature-rabbitmq'
```
> A new branch called feature-rabbitmq is created and moved to that branch.


< WSL environment >
```bash
git branch
```
> Check the branch list of service IaC again.


```bash
ubuntu@SEAN-OFFICE-LAPTOP:~/t3-msp-pjt/eshop-service-IaC$ git branch
*feature-rabbitmq
   main
```
> At present, it is designated as a branch called feature-rabbitmq.


Once the `feature-rabbitmq` branch has been created, push the source code of eshop-service-IaC required for this challenge to the corresponding branch.


< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```

< WSL environment >
```bash
rm -rf *
```
> Remove the existing main branch reference sources to reflect the new IaC source in the feature-rabbitmq branch.

< WSL environment >
```bash
cd ~/t3-msp-pjt
```
> Move back to the parent directory to the location where you want to download the reference source from S3.

<br>

---

[🗎 Reference. Directories and files maintained]
```
.git
.gitignore
.terraform
.terraform.lock.hcl
```

---

<br>

< WSL environment >
```bash
rm -rf .terraform
rm -rf .terraform.lock.hcl
```
> Additionally, all Terraform-related workspace modules are deleted.


< WSL environment >
```bash
aws s3 cp s3://t2hubintern/chal_rabbitmq_eshop-service-IaC.tar.gz .
```
> Download the service IaC source required for this challenge named chal_rabbitmq_eshop-service-IaC.tar.gz.

< WSL environment >
```bash
tar xvfz chal_rabbitmq_eshop-service-IaC.tar.gz
```
> Unzip the service IaC source required for this challenge named chal_rabbitmq_eshop-service-IaC.tar.gz. When unzipped, the sources are automatically moved under the eshop-service-IaC directory.

< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```

< WSL environment >
```bash
git add .; git commit -m "add feature-rabbitmq"; git push origin feature-rabbitmq
```
> Reflect (push) new source contents to the feature-rabbitmq branch.

---

🗎 Note. The IaC performance of this challenge is to be performed locally in WSL. You can use the Jenkins IaC pipeline by making a Pull Request and merging into the main branch, but to avoid confusion during future practice, we recommend maintaining the main branch and performing local Terraform using a separate branch.

---
< WSL 환경 >
```bash
terraform init
```
> Amazon MQ modules must be loaded, so init is performed.

< WSL environment >
```bash
terraform plan
```

✔ **(Example of execution code/result)**
```
Plan: 1 to add, 0 to change, 0 to destroy.
```
> It depends on whether the challenge is completed, but usually, if only the required tasks on the 3rd day are completed, the plan will be performed as above.
>
> + resource "aws_mq_broker" One resource addition plan related to "service" will be displayed.

< WSL environment >
```bash
terraform apply -auto-approve
```
> Perform Terraform.


✔ **(Example of execution code/result)**
```bash
Apply completely! Resources: 1 added, 0 changed, 0 destroyed.

Outputs:

eip_allocation_id = <<EOT
eipalloc-0ce61725de01f6470,eipalloc-076f0e93374ec9634

EOT
mq_endpoint = tolist([
   "amqps://b-61c8e77d-1461-4269-92b9-57b7135dbc35.mq.us-west-2.amazonaws.com:5671",
])
mq_web_console_url = "https://b-61c8e77d-1461-4269-92b9-57b7135dbc35.mq.us-west-2.amazonaws.com"
```
> If Terraform has completed execution, the output shown above will be displayed.

<br>

---

[🗎 Reference. Things to note during output]
-mq_endpoint
   - Value to be used for rabbitmq.host to be specified in eshop PaC
-mq_web_console_url
   - This is the endpoint of the RabbitMQ Management UI provided by Amazon MQ, and can be accessed after authentication through the ID/PW specified in Terraform.

---

<br>

</details>


<br>


<details>
<summary>[Performance 2 - Expand👇] Change eshop PaC helm chart settings</summary>

<br>

Like service IaC, eshop PaC also creates a separate branch for this challenge. The branch name is `feature-c3_5`, which is a branch name indicating the challenge number. When applying this challenge, it can be seen that `feature-c3_5` will be used instead of `HEAD` revision when distributing through Argocd in the future.


< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC
```
> Go to eshop-PaC’s workspace directory


< WSL environment >
```bash
git branch
```
> Check the branch list of eshop-PaC


✔ **(Example of execution code/result)**
```bash
ubuntu@SEAN-OFFICE-LAPTOP:~/t3-msp-pjt/eshop-PaC$ git branch
* main
```
> Usually, it will be designated as the main branch.

< WSL environment >
```bash
git checkout -b feature-c3_5
```
> Create and move the feature-c3_5 branch for the challenge.


✔ **(Example of execution code/result)**
```bash
ubuntu@SEAN-OFFICE-LAPTOP:~/t3-msp-pjt/eshop-PaC$ git checkout -b feature-c3_5
Switched to a new branch 'feature-c3_5'
```
> A new branch called feature-c3_5 is created and moved to that branch.


< WSL environment >
```bash
git branch
```
> Check the eshop-PaC branch list again.


```bash
ubuntu@SEAN-OFFICE-LAPTOP:~/t3-msp-pjt/eshop-PaC$ git branch
*feature-c3_5
   main
```
> At present, it is designated as a branch called feature-c3_5.


Once the `feature-c3_5` branch has been created, push the eshop-PaC source code required for this challenge to the corresponding branch.


< WSL environment >
```bash
cd ~/t3-msp-pjt/eshop-PaC
```

< WSL environment >
```bash
code.
```
> Run VSCode and apply the modifications below to PaC.


Modify the contents of the file below.

**eshop-PaC/eshop/values.yaml**

[example]
```yaml
(...skip...)
global:
   rabbitmq:
     # << Amazon MQ AMQP Endpoint >>Value example) amqps://b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com:5671 value minus protocol and port values The required value => b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com
     host: b-61c8e77d-1461-4269-92b9-57b7135dbc35.mq.us-west-2.amazonaws.com # When doing the Amazon MQ challenge, uncomment it and substitute the value in << Amazon MQ Web Console Endpoint >>
     #host: rabbitmq # Comment out Amazon MQ challenges
   app:
     name: eshop
     namespace: eshop
(...skip...)
```
> Comment out the existing host: rabbitmq, and replace the variable value of host: << Amazon MQ AMQP Endpoint >> with the remaining value minus the protocol and port values of mq_endpoint confirmed in the terraform output.
>
> Please note that the above value is an example, so keep in mind that the actual value should be replaced with your personal mq_endpoint value.

<br>

Next, apply the images prepared for the challenge of the eshop-backend and eshop-cartservice microservices.

**eshop-PaC/eshop/values.yaml**
```yaml
(...skip...)
images:
     (...skip...)
     #backend: ************.dkr.ecr.us-east-1.amazonaws.com/eshop-backend:latest # Comment out Amazon MQ challenges
     #cartservice: ************.dkr.ecr.us-east-1.amazonaws.com/eshop-cartservice:latest # Comment out Amazon MQ challenges
     backend: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-backend:amqtest # Uncomment for Amazon MQ challenges
     cartservice: 505891794208.dkr.ecr.ap-northeast-2.amazonaws.com/eshop-cartservice:amqtest # Uncomment for Amazon MQ challenges
(...skip...)
```
> This is the part that sets the image to be used in the prepared public ECR rather than specifying an image built by an existing individual. Just comment out the existing personal image and designate it as a public image in the same way as above.

<br>

Once all source code modifications guided above have been completed, reflect them in the github branch.

< WSL environment >
```bash
git add .; git commit -m "add feature-c3_5"; git push origin feature-c3_5
```
> Reflect (push) new sources and modified contents to the feature-c3_5 branch.

</details>

<br>

<details>
<summary>[Performance 3 - Expand👇] Feature-c3_5 branch deployment operation through Argocd</summary>

<br>

**Create an eshop application complete with Helm Chart on the argocd web screen.**

### ❗❗ Precautions when creating eshop application❗❗

<br>

When distributing eshop through Helm Chart in this course and future courses, the Application Name must be set to 'eshop'. This is because the Helm Chart to be designed in the future has settings dependent on the application name.

<br>

+New App creation task

Step 1) Enter GENERAL items
|Item|Content|Action|
|------|---|---|
|➕ Application Name |`eshop`|Copy & Paste|
|➕ Project |`default`|Select select box|
|➕ SYNC POLICY | `Manual` |Select select box (default)|
|➕ SYNC OPTIONS |`AUTO-CREATE NAMESPACE`|Select checkbox|

<br>

Step 2) Enter SOURCE items
|Item|Content|Action|
|------|---|---|
|➕Repository URL |`https://github.com/<< GITHUB USER NAME >>/eshop-PaC.git`|Select select box|
|➕Revision| `feature-c3_5` | Select `feature-c3_5` from the select box that appears when you type `f`|
|➕Path|`eshop`|Select select box|

<br>

Step 3) Enter DESTINATION items
|Item|Content|Action|
|------|---|---|
|➕ Cluster URL |`<< Service EKS Cluster Endpoint >>`|Select select box|
|➕ Namespace |`eshop`|Copy & Paste|

<br>

Step 4) Helm > VALUES FILES > Select the `values.yaml` select box

<br>

Example of argocd app status after deployment

![](../media2/argocd_c_3_5_1.png)

<br>

</details>

<br>

**If all solution processes have been performed and deployment has been completed normally, try calling the eshop app through the FQDN domain of the individual eshop specified earlier. After calling, create an order, which is the part that uses rabbitmq in eshop.**

![](../media2/chal_3_5_order_1.png)

![](../media2/chal_3_5_order_2.png)


**After the ordering logic occurs, you can access the Management UI provided by Amazon MQ to check whether the publishing and consumption of the message queue are operating normally.**

The endpoint of the Management UI can also be checked through the UI as shown below.

AWS > Amazon MQ service > Enter eshop

![](../media2/amazonmq_overview.png)


This can also be confirmed with the output result of Terraform performed previously.

```bash
Apply completely! Resources: 1 added, 0 changed, 0 destroyed.

Outputs:

(...skip...)
mq_web_console_url = "https://b-61c8e77d-1461-4269-92b9-57b7135dbc35.mq.us-west-2.amazonaws.com"
(...skip...)
```

After accessing the verified URL, you can log in with the information below specified in Terraform.

- Basic Management UI Credentials
    - ID: `admin`
    - PW: `zmffkdnem00!@`


After logging in, when the order logic just performed is performed, you can check whether eshop-backend's Publish and eshop-cartservice's Consuming are monitored as follows.

![](../media2/amazonmq_management_1.png)

In this way, by utilizing the MQ service self-managed and provided by AWS, users can apply the convenience of utilizing the FMS service without managing the MQ middleware with the workload within the K8s cluster. Additionally, in this challenge, it was configured as a single node, but a cluster can actually be configured as a multi node.

For reference, just as the AWS RDS service can utilize RDBMS such as MariaDB and MySQL, the Amazon MQ service can utilize Message Queue-related services such as RabbitMQ and ActiveMQ.

However, since this challenge is a simple application exercise, it was set as public access and basic configuration. However, if it is used in practice in the future, only private access should be allowed, and access control must be performed through the Security Group and broker as necessary. Additional customization of the config in terms of performance and operation may be required, such as backlog expansion, overflow handling (reject, etc.), nodelay, etc.

---

🗎 Note. AWS AmazonMQ rabbitMQ Broker Configuration

https://docs.aws.amazon.com/ko_kr/amazon-mq/latest/developer-guide/rmq-configuration.html

---

<br>

After completing all challenges, you can restore the service IaC to its original state (main branch IaC configuration) or maintain the current state (feature-rabbitmq branch IaC configuration).

However, note that the shape of eshop-PaC is different depending on the IaC shape.

Branch mapping structure between IaC and PaC
- IaC(eshop-service-IaC) - `main` <-> PaC(eshop-PaC) - `main`
- IaC(eshop-service-IaC) - `feature-rabbitmq` <-> PaC(eshop-PaC) - `feature-c3_5`

<br>

**😃 Challenge Completed!!!**

<br>

---


<br>
<br>
<br>

# <center> <a href="../README.md">[list]</a> </center>
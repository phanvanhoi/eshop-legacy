## 참고. LB Access Log 분석

### 주제: AWS Athena(Access Log 분석)

<br>

## 실습 목표
- AWS Athena 서비스를 이용하여 AWS S3에 저장되어있는 ELB Access Log를 테이블화 하고 필요한 정보를 쿼리하는 방식을 이해한다.
- AWS VPC Network ACL을 활용하여 VPC 내 특정 IP Bound 차단하는 방식을 이해한다.

<br>

## Service EKS Cluster Load Balancer 로그 분석

### AWS Athena를 이용한 NLB Access Log 이상로그 추출 및 조치 예시

<br>

Athena 서비스 소개 참조

<https://aws.amazon.com/ko/athena/?whats-new-cards.sort-by=item.additionalFields.postDateTime&whats-new-cards.sort-order=desc>

AWS Cloud 환경에서 서비스를 운영하다보면 LoadBalancer에 Traffic이 Spike로 인입될 경우가 있다.(호출이 몰리거나, 기타 예외상황). 앞서 말한 상황은 정상적인 호출인 상황이고 간혹 보안적으로 문제가 될 소지가 있는 특이 호출들이 Spike로 발견될 때가 있다.

![](../media2/image49.png)

Application단 분석을 통해 실제 서비스 호출이 아닌 LB단에서 멈춘 콜이라던지, 특이케이스들을 대용량 로그에서 일일히 다운로드 받고 압축을 풀고 분석을 위해 검색하기엔 쉽지 않은일이다.

방대한 양의 로그를 S3에 저장된 데이터 기반 테이블화 시켜 Query하여 수초안에 대량의 데이터 검색이 가능한 기능인 Athena를 활용하는 예시를 참고한다.

(본 예시에서는 실제로는 대용량의 로그는 아님을 확인)

<br>
<br>

1. NLB Access Log를 저장할 S3 Bucket을 생성한다.(버킷명은 고유해야 한다.)
![](../media2/image50.png)

> 버킷은 NLB가 존재하는 리젼인 `us-west-2(Oregon)`으로 생성한다.

<br>

2. 현재 사용중인 Service VPC 상의 NLB에 Access Log를 활성화하고, S3 URI 항목에는 방금 생성한 bucket URI를 기입한 후 Save Changes 한다.

![](../media2/image109.png)

<br>

3. 생성한 S3 bucket으로의 쓰기 권한이 충분하지 않아 아래와 같은 오류가 발생할 것이다. 

<br>

![](../media2/image110.png)   

<br>

4. Edit bucket policy 에서 아래 내용으로 Statement를 추가한다.

![](../media2/image111.png)   

변수를 아래와 같이 치환한다.
   ```
   <<Account ID>> = 나의 Account ID 12자리
   <<Bucket Name >> = 1에서 생성한 S3 Bucket 이름
   <<ELB Account ID>> = 797873946194 (us-west-2의 ELB account ID)
  ```

<br>

---

Access Log Bucket Policy 관련 참고 링크 아래 참조.

🗎 참고. <https://docs.aws.amazon.com/elasticloadbalancing/latest/classic/enable-access-logs.html#verify-access-logs>

---

<br>

```json
{
	"Version": "2012-10-17",
	"Id": "AWSConsole-AccessLogs-Policy",
	"Statement": [
		{
			"Sid": "AWSConsoleStmt",
			"Effect": "Allow",
			"Principal": {
				"AWS": "arn:aws:iam::<<ELB Account ID>>:root"
			},
			"Action": "s3:PutObject",
			"Resource": "arn:aws:s3:::<<Bucket Name>>/AWSLogs/<<Account ID>>/*"
		},
		{
			"Sid": "AWSLogDeliveryWrite",
			"Effect": "Allow",
			"Principal": {
				"Service": "delivery.logs.amazonaws.com"
			},
			"Action": "s3:PutObject",
			"Resource": "arn:aws:s3:::<<Bucket Name>>/AWSLogs/<<Account ID>>/*",
			"Condition": {
				"StringEquals": {
					"s3:x-amz-acl": "bucket-owner-full-control"
				}
			}
		},
		{
			"Sid": "AWSLogDeliveryAclCheck",
			"Effect": "Allow",
			"Principal": {
				"Service": "delivery.logs.amazonaws.com"
			},
			"Action": "s3:GetBucketAcl",
			"Resource": "arn:aws:s3:::<<Bucket Name>>"
		}
	]
}
```

<br>


5. bucket policy 생성에 성공했다면, 2번에서 진행하던 NLB Edit attributes 을 마저 마무리한다.
   
![](../media2/image112.png)


<br>

※ Access Log를 활성화 시켰으므로, Athena 테스트용 Dummy 로그를 쌓기 위해 TLS로 호출하는 부하기를 단시간 발생시켜 본다.


< EC2 환경 - admin server - eshop context(ec) >
```bash
kubectl run -i --tty load-generator-1 --rm --image=curlimages/curl --restart=Never -- /bin/sh -c "while sleep 0.01; do curl -1 --tlsv1.2 -v https://<< DOMAIN >>; done"
```
> << DOMAIN >> 값은 개인 eshop 서비스의 FQDN 도메인으로 치환해야 한다.

<br>

> `Access Log 로깅 주기인 약 5분정도 위 부하기 호출을 통해 분석 실습용 dummy 로그를 쌓아본다.` 앞서 사용했던, busybox 이미지의 부하기와는 달리, curlimages/curl 이미지를 통해 생성한 부하기로 tlsv1.2로 호출을 한다.
> 
> 그 이유는, Network LoadBalancer에는 실제로 TLS 호출이 되어야 Access Log에 쌓인다.
>
> 🗎 참고. <https://docs.aws.amazon.com/ko_kr/elasticloadbalancing/latest/network/load-balancer-access-logs.html>

<br>

6. 다음은 AWS Athena 서비스에 접속한다.

![](../media2/image51.png)

![](../media2/image52.png)

<br>

**※ 테이블 생성쿼리 실행 전 'Settings'에서 Athena의 쿼리 결과가 저장될 버킷의 Path를 지정해주어야 한다.**

Athena > Query Editor > Settings 경로로 진입한다.

쿼리가 저장될 S3의 경로 지정은 아래 두가지 방식 중 하나를 택해서 지정할 수 있다.
단 2)번 케이스의 경우는 별도의 S3를 생성한 후 진행하면 된다.

1) s3://<< NLB가 쌓이는 Access Log가 쌓이는 S3 >>/AWSLogs/<< ACCOUNT ID >>/elasticloadbalancing/us-west-2/
   
2) s3://<< Athena 쿼리 결과가 쌓이는 전용의 S3 >>/AWSLogs/<< ACCOUNT ID >>/elasticloadbalancing/us-west-2/

![](../media2/athena_setting_1.png)


<br>
<br>


7. NLB Access Log 포맷에 맞게 NLB 관련 테이블을 생성해준다.

---

🗎 참고. <https://docs.aws.amazon.com/ko_kr/athena/latest/ug/networkloadbalancer-classic-logs.html>

---

<br>

<< 테이블 생성 쿼리 >>
```sql
CREATE EXTERNAL TABLE IF NOT EXISTS eshop_nlb_logs (
    type string,
    version string,
    time string,
    elb string,
    listener_id string,
    client_ip string,
    client_port int,
    target_ip string,
    target_port int,
    tcp_connection_time_ms double,
    tls_handshake_time_ms double,
    received_bytes bigint,
    sent_bytes bigint,
    incoming_tls_alert int,
    cert_arn string,
    certificate_serial string,
    tls_cipher_suite string,
    tls_protocol_version string,
    tls_named_group string,
    domain_name string,
    alpn_fe_protocol string,
    alpn_be_protocol string,
    alpn_client_preference_list string,
    tls_connection_creation_time string
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.RegexSerDe'
WITH SERDEPROPERTIES (
    'serialization.format' = '1',
    'input.regex' = 
        '([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*):([0-9]*) ([^ ]*):([0-9]*) ([-.0-9]*) ([-.0-9]*) ([-0-9]*) ([-0-9]*) ([-0-9]*) ([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*)$')
LOCATION 's3://<<버킷명>>/AWSLogs/<<ACCOUNT ID>>/elasticloadbalancing/us-west-2';
```

위 << 테이블 생성 쿼리 >> 에서, 특히 LOCATION 부분에는 2번에서 지정한 Access Log가 쌓이는 버킷명 정보(리젼등)와 개인 AWS Account ID 12자리가 적절하게 들어가야한다.(변수들을 개인의 값으로 치환한다.)

```
LOCATION 's3://<<버킷명>>/AWSLogs/<<ACCOUNT ID>>/elasticloadbalancing/us-west-2'
```

'Run' 을 눌러 정상적으로 'eshop_nlb_logs'라는 테이블이 생성되었는지 확인한다.

![](../media2/image53.png)

<br>

우측 상단 '+' 버튼을 눌러 새로운 쿼리창을 띄우고, 아래와 같은 쿼리들을 실행해본다.

ex1. SELECT * FROM "eshop_nlb_logs" LIMIT 50;  //전체 데이터 50개만 추출

ex2. SELECT COUNT(*) FROM "eshop_nlb_logs";  //전체 데이터 건수

ex3. SELECT * FROM "eshop_nlb_logs" WHERE NOT domain_name IN ('eshop.mspt3.click'); //정상적인 도메인 호출이 아닌 호출건들 추출
> 예시 적용 시 eshop.mspt3.click을 개인 도메인으로 변경한다.

중요한 부분은 3번의 결과를 분석하는 부분이다.

3번 쿼리 수행 후 'Download results'를 통해 결과를 csv 파일로 다운받아 볼 수 있다.

![](../media2/image54.png)

다운받은 csv에서 도메인을 정상적으로 호출하지 않고 포트 스캐닝 콜을 다수를 호출했던 케이스들의 Client IP 컬럼을 추출하여본다.

![](../media2/image55.png)

'202.95.12.40' 클라이언트 IP가 비정상적인 호출을 한 부분이 감지되고, 이를 abuse ip database(<https://abuseipdb.com>)에서 조회해본다.

![](../media2/image56.png)

**아래와 같이 최근에 150건 이상의 레포트가 된 공격자의 IP임이 확실하며, 이를 Public NACL에서 Deny 엔트리에 추가해준다.**

![](../media2/image57.png)


<br>


**엔트리에 추가된 이상 '202.95.12.40/32' 공격자로 확실시되는 Abuse IP는 더이상 개인 Service EKS Cluster(Service EKS VPC)에 접근할 수 없게된다.**

다만 아래 제한 사항에 대해서 확인하고, NACL에 대한 Trade off를 결정해야 한다.

> 문서 상 NACL의 기본 Max limit은 20이고 추가 증설을 할 수 있지만, 증설시에 VPC Network 성능저하등이 있을 수 있고, 기본적으로 최대가 20개라 볼 수 있다.
> 
> <https://docs.aws.amazon.com/vpc/latest/userguide/amazon-vpc-limits.html>

<br>

😃 **참고자료 끝**

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>

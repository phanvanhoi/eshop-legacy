
## 참고. Datadog


### 주제: Observability

<br>

📌 [참고자료 적용 중 사용할 추가 메모사항]

📌 [datadog 키세팅 정보(도전과제)]<br>
➕ datadog API Key ( `<< DATADOG API KEY >>` ) : <br>

## Service EKS Cluster(VPC)에 Datadog 상용 모니터링 툴 적용하기

<br>

<span style="color:red">본 참고자료는 상용 모니터링 솔루션의 간접체험 목적이며, 14일 기간동안 무료인 기간을 활용하여 살펴보는 목적이다. 어떻게 연동이 되며 어떠한 기능들이 있다 정도로 참고만 하기를 권고하며, 만일 연동 적용을 했다면 반드시 14일 내로 해지(연결해제)하는 과정을 가이드대로 수행하도록 한다. 해지(연결해제)는 아래 과정 참조(교재 최 하단)</span>

***🚨 실습자원 정리(Datadog 연결 해제)***

<br>

![](../media1/AWS-2w-5-fin.drawio-datadog.png)

<br>
<br>

## 배경
- Datadog에서는 기본 14일 Free Trial 기간을 제공한다. 해당 기간동안은 Integration 및 다양한 Dashboard, APM, Log 기능들을 체험해볼 수 있다.
- 14일 이후에는 과금설정을 해야하오니 반드시 체험 후 자원정리를 수행해야한다.
- AWS CloudWatch와 같이 상용 솔루션이며, 상용인 만큼 비용부담이 발생하지만 그만큼 손쉬운 Integration 및 다양한 기능들을 제공한다.

<br>

---

<br>

## 가입하기

<https://docs.datadoghq.com/ko/>

상기 사이트에 접속한 후 `무료로 시작하세요` 버튼을 클릭한다.

![](../media2/datadog_sign_up_1.png)

`이메일, 이름, 회사, 패스워드 정도만 입력` 후 `가입한 이메일로 온 verification code`를 입력하면 14일 무료체험 Organization이 활성화된다.

<br>

<span style="color:red">Datadog Region은 현재 실습환경 Service VPC와 물리적 거리가 짧은 US3-West를 택한다.</span>

<br>

`2. Your Stack` 탭에서 `10개` 정도의 서버를 운영한다고 설정 후 목적은 간단히 `DevOps`정도로 입력한다.

![](../media2/datadog_04.png)

<br>

다음은 `3. Agent Setup` 탭에서 Workstation 서버등에 Datadog Agent(ddagent)를 설치하는 가이드가 제공되오나, 실제로 EKS베이스 모니터링을 진행할 예정이므로 참고만 하고 넘어간다. 단, 향후 쓰일 datadog의 `API Key를 기록`해두도록 한다.(가림표시가 되어있고 마우스오버하면 보인다.)

![](../media2/datadog_05.png)

<br>

## 체험사항

Datadog을 이용하여 아래 3개정도의 체험을 해볼 예정이다.

- AWS Integration을 통한 Dashboard 둘러보기
- AWS EKS <-> Datadog agent 연동 후 Container 상세 모니터링 적용하기
- Datadog Monitor 구성하여 메트릭에 따른 알람 발생시켜보기

<br>

### AWS Integration을 통한 Dashboard 둘러보기

Datadog은 AWS Cloud서비스 계정과 Integration이 매우 손쉬우며, Integration이 완료되는 동시에 별도 세팅등을 사용자가 하지 않아도 자동으로 생성되는 Dashboard들이 제공된다.


Step1) AWS Integration을 위해선 가장 우선적으로 `AWS IAM Policy를 아래와 같이 생성`해야한다.

Datadog에서 메트릭 수집, 연계등을 위해 필요한 권한들의 나열이다.
자세한 사항은 아래 공식문서에서 제공하며, 좀 더 자세히 정보를 확인하길 원하는 경우 아래 참고사이트를 방문하여 체크해보도록 한다.

<br>

---

🗎 참고. https://docs.datadoghq.com/ko/integrations/amazon_web_services/#aws-iam-permissions

---

<br>

Policy Name: `DatadogIntegrationPolicy`

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "apigateway:GET",
                "autoscaling:Describe*",
                "backup:List*",
                "budgets:ViewBudget",
                "cloudfront:GetDistributionConfig",
                "cloudfront:ListDistributions",
                "cloudtrail:DescribeTrails",
                "cloudtrail:GetTrailStatus",
                "cloudtrail:LookupEvents",
                "cloudwatch:Describe*",
                "cloudwatch:Get*",
                "cloudwatch:List*",
                "codedeploy:List*",
                "codedeploy:BatchGet*",
                "directconnect:Describe*",
                "dynamodb:List*",
                "dynamodb:Describe*",
                "ec2:Describe*",
                "ec2:GetTransitGatewayPrefixListReferences",
                "ec2:SearchTransitGatewayRoutes",
                "ecs:Describe*",
                "ecs:List*",
                "elasticache:Describe*",
                "elasticache:List*",
                "elasticfilesystem:DescribeFileSystems",
                "elasticfilesystem:DescribeTags",
                "elasticfilesystem:DescribeAccessPoints",
                "elasticloadbalancing:Describe*",
                "elasticmapreduce:List*",
                "elasticmapreduce:Describe*",
                "es:ListTags",
                "es:ListDomainNames",
                "es:DescribeElasticsearchDomains",
                "events:CreateEventBus",
                "fsx:DescribeFileSystems",
                "fsx:ListTagsForResource",
                "health:DescribeEvents",
                "health:DescribeEventDetails",
                "health:DescribeAffectedEntities",
                "kinesis:List*",
                "kinesis:Describe*",
                "lambda:GetPolicy",
                "lambda:List*",
                "logs:DeleteSubscriptionFilter",
                "logs:DescribeLogGroups",
                "logs:DescribeLogStreams",
                "logs:DescribeSubscriptionFilters",
                "logs:FilterLogEvents",
                "logs:PutSubscriptionFilter",
                "logs:TestMetricFilter",
                "organizations:Describe*",
                "organizations:List*",
                "rds:Describe*",
                "rds:List*",
                "redshift:DescribeClusters",
                "redshift:DescribeLoggingStatus",
                "route53:List*",
                "s3:GetBucketLogging",
                "s3:GetBucketLocation",
                "s3:GetBucketNotification",
                "s3:GetBucketTagging",
                "s3:ListAllMyBuckets",
                "s3:PutBucketNotification",
                "ses:Get*",
                "sns:List*",
                "sns:Publish",
                "sqs:ListQueues",
                "states:ListStateMachines",
                "states:DescribeStateMachine",
                "support:DescribeTrustedAdvisor*",
                "support:RefreshTrustedAdvisorCheck",
                "tag:GetResources",
                "tag:GetTagKeys",
                "tag:GetTagValues",
                "xray:BatchGetTraces",
                "xray:GetTraceSummaries"
            ],
            "Effect": "Allow",
            "Resource": "*"
        }
    ]
}
```

<br>


Step2) AWS Integration을 위해 Step1) 과정을 수행한 후 다음으로, `AWS IAM Role을 생성하고 해당 Role에 Policy 부여 및 3rd Party Datadog 측으로 권한을 위임하는 설정을 수행`하여야 한다.


Datadog쪽으로 권한을 위임하는 목적의 AWS IAM Role을 생성 및 설정해야한다.

AWS IAM > Roles > Create Role

아래와 같은 정보로 IAM Role을 생성한다. Role에 부여되는 Policy는 앞선 과정에서 생성한 `DatadogIntegrationPolicy`를 부여하는 것이다.


<br>

[IAM Role 생성화면]

![](../media2/datadog_create_role_1.png)

<br>

(입력항목)

Another AWS Account > Account ID
> Datadog측의 AWS Account ID: `464622532012`

External ID: 아래 화면 중 `Datadog AWS Integration Manually 항목에서 생성된 External ID`를 입력하면 된다.

<br>

[🗎 참고. 입력할 External ID 확인]
> https://us3.datadoghq.com/integrations 접속

---

![](../media2/datadog_aws_int_0.png)

상기 경로로 Integration 메뉴 중 AWS을 인스톨 한다.

![](../media2/datadog_06.png)

AWS 서비스 진입후 Manual 세팅을 선택한다. 그 후 아래와 같은 화면이 나오면, 해당 화면에서 External ID 값을 입력하도록 한다.

[Datadog AWS Integration Manually 항목]

![](../media2/datadog_aws_int_1.png)

---

<br>

이와 같이 External ID를 확인하고 다시 `AWS Console의 Role 생성화면으로 넘어와서 External ID 값을 복사한 후 입력`을 완료했으면 `Next`를 누른 후 Add permissions 에서 앞서 생성한 Policy인 `DatadogIntegrationPolicy`를 추가해주고 `Next`로 넘어간다.


![](../media2/datadog_create_role_2.png)

다음으로 넘어가면 위와 같이 Review 및 Name을 정해주는 단계이며, 아래와 같이 이름을 입력해준 후 `Create role`을 클릭하여 최종 생성을 하면 된다.

Role name: `DatadogIntegrationRole`

<br>

마지막 단계로 다시 Datadog의 Integrations 메뉴에 진입 후 `Enter Your Role Delegation Info` 항목에 개인별 AWS ACCOUNT ID 12자리 및 앞서 생성한 IAM Role인 `DatadogIntegrationRole`이름을 차례대로 입력하도록 한다. 그 후 `Save`를 한다.

![](../media2/datadog_07.png)


이로써 AWS 계정과 Datadog 간의 Integration 설정이 완료되었다.

Step3) Dashboard List 및 Infrastructure List 등등 확인


개인 AWS Account <-> Datadog간의 Integration이 완료된 후 일정시간(넉넉잡아 `5분`정도)이 지나면 AWS Public Cloud상 생성 및 유지되고있는 리소스 현황들에 대한 Dashboard를 확인할 수 있다.

Datadog > Dashboard > Dashboard List에 진입하여 대표적인 Dashboard들을 둘러본다.

<br>

![](../media2/datadog_dashboard_1.png)

AWS Integration만 된 상태라면 전반적인 AWS 상품(EC2, RDS, ELB 등)에 대한 유용한 Dashboard가 `자동으로` 구성되고 지표를 확인할 수 있다.

<br>

예시) AWS Host Map 살펴보기 (리젼별 VM 현황 한눈에 확인 가능)

![](../media2/datadog_hostmap.png)

<br>

예시) AWS ELB 관련 대시보드 살펴보기
> 현재까지 구성된 Argocd ELB, Jenkins ELB, eshop NLB 관련

![](../media2/datadog_dashboard_ELB.png)

<br>

예시) AWS EC2 관련 대시보드 살펴보기
> 현재까지 구성된 EC2(bastion, admin), EKS Node Group에 속한 EC2(Worker Nodes)

![](../media2/datadog_dashboard_EC2.png)

<br>

이와같이 단순히 `계정 연동(Integration)만 했을 뿐인데 유의미한 모니터링 지표들로 구성된 대시보드가 자동으로 제공`된다. 상용 솔루션인 만큼 직접 구성 및 설정을 해야하는 OSS툴과는 다르게 `사용자 편의성`이 제공된다.

<br>
<br>

### AWS EKS <-> Datadog agent 연동 후 Container 상세 모니터링 적용하기

다음은 실습 간 사용하는 AWS EKS 서비스의 Worker Node에 Datadog agent를 활성화하고, eshop PaC Helm Chart로 기동하는 eshop 서비스의 Inner Architecture를 Datadog을 통해 심화 모니터링 해본다.

<br>

Step1) Datadog agent K8s 설치를 위한 API Key 확인


우선적으로 위와 같이 Datadog에 가입 시 자동적으로 API Key가 발급된다.

Datadog > 개인 이메일(ORG) 아이콘 > Personal Settings > Security > Application Keys 진입 후 Key 값을 조회할 수 있다.

![](../media2/datadog_api_key_1.png)

개인별로 각각 다른 해당 값을 `<< DATADOG API KEY >>` 변수에 치환하여 아래 명령어를 수행한다.

<br>

최종적으로 datadog agent를 eshop context(eshop의 SERVICE EKS Cluster)내에 설치하는 과정이다.

<br>

< EC2 환경 - admin server - eshop context(ec) >
```bash
helm install datadog-agent datadog/datadog \
  --set datadog.apiKey=<< Datadog API Key >> \
  --set targetSystem=linux \
  --set datadog.site=us3.datadoghq.com \
  --values values.yaml
```
> 위 명령어 수행으로 eshop Context 즉, Service Cluster내 각각의 Worker Node에 Datadog agent가 설치된다. 참고로, datadog.site 값은 default로 eu 리젼으로 설정되기 때문에 우리가 활성화한 Datadog us-west 리젼에 활성화 하기 위해선 별도 `us3.datadoghq.com` 도메인 값으로 커스터마이징 해줘야 한다.

<br>

Step2) AWS Integration과 유사하게 datadog agent 활성화 만으로 Container 관련 Dashboard가 활성화 된다.


Datadog > Dashboard > Dashboard List에 진입하여 `Containers - Overview` 대시보드를 살펴볼 수 있다.



예시) Container 관련 대시보드 살펴보기

![](../media2/datadog_dashboard_Containers_1.png)


AWS CloudWatch에서 볼 수 있고, 그보다 좀 더 자세하게 세팅된 메트릭들도 한눈에 확인 할 수 있다.

예시) Container 관련 대시보드 살펴보기(Mobile App)

![](../media2/datadog_dashboard_Containers_2.png)

<br>

Datadog 플랫폼은 Mobile App으로도 접근 가능하여 운영중 알람 현황파악등을 모바일로 할 수 있는 장점이 있다. 참고로, AWS 클라우드도 Mobile App을 제공하오나 별도로 Dashboard 구성을 해놓지 않으면 상품별 대시보드만 조회할 수 있다.

그러나, Datadog은 간단한 연동(설치)만으로 유의미한 지표들로 구성된 대시보드를 실시간으로 조회할 수 있는 장점이 있다.

<br>

### Datadog Monitor 구성하여 메트릭에 따른 알람 발생시켜보기

<br>

마지막으로 Datadog을 활용해 서비스를 운영 시 서비스 관련 컨테이너에 걸어둔 특정 지표의 변화 및 임계치 초과 시 알람을 발생시키는 운영성 기능에 대해서도 살펴보도록 한다.

<br>

**CPU 메트릭에 알람을 걸기위해 eshop-productservice에 부하를 주어 cpu 사용률을 높이고, eshop-productservice pod의 cpu 사용률을 임계치로 알람을 설정한다.**

<br>

> << DOMAIN >> 값은 개인 eshop 서비스의 FQDN 도메인으로 치환해야 한다. 개인 서비스 도메인으로 변경하고 부하기를 발생 시킨다.

Admin Server에 접속하여 아래 명령어를 차례대로 수행한다.

< EC2 환경 - admin server - eshop context(ec) >
```bash
kubectl run -i --tty load-generator-1 --rm --image=busybox --restart=Never -- /bin/sh -c "while sleep 0.01; do wget -q -O- http://<< DOMAIN >>/api/products; done"
```
> << DOMAIN >> 값은 개인 eshop 서비스의 FQDN 도메인으로 치환해야 한다.

<br>

**부하가 인입되는 상황의 productservice의 pod의 메트릭 지표 변화의 모습이다.**

![](../media2/datadog_dashboard_Containers_Monitor_1.png)

<br>

**Monitor 알람 테스트를 위해 eshop-productservice의 알람 임계치를 cpu 사용률 50%로 설정하여 진행해본다.**

<br>

Datadog > Monitors > Manage Monitors > `+New Monitor` 클릭 후 설정을 진행한다.

최 상단 Metric 기준으로 선택한다.

![](../media2/datadog_dashboard_Containers_Monitor_2.png)

임계치의 기준은 아래와 같이 설정했다.

- Monitor Name: `productservice cpu`
- K8s Deployment 워크로드 : `eshop-productservice`
- Alert 임계치 : `50,000,000 nano cores`(`50 milli cores`) 초과
- Warning 임계치 : `30,000,000 nano cores`(`30 milli cores`) 초과
- Notification : Slack 특정 채널로 Noti(사전 Slack Integration 설정을 수행)

<br>

[Slack 채널의 Monitor 알람 예시]

![](../media2/datadog_dashboard_Containers_Monitor_3.png)
> eshop-productservice 워크로드가 부하로 인해 Alert 임계치인 50 mcores 사용량을 초과한 상태가 감지되고, 이를 Integration 설정한 Slack 채널로 노티해주는 화면


이와 같이 3rd Party App인 Slack등과도 연동하여 알람을 발생시킬 수 있으며, 손쉽게 서비스 운영시 유용한 모니터링 설정을 할 수 있다.

<br>

알람 수신테스트까지 마쳤으면 생성했던 Monitor 항목인 `productservice cpu`를 삭제한다. `Delete 버튼을 클릭` 후 확인 단계에서 `Delete 버튼을 한번 더 클릭` 하면 삭제된다.

![](../media2/datadog_dashboard_Containers_Monitor_4.png)


최종적으로 부하기도 중단한 후 부하 Pod 삭제도 진행한다.


< EC2 환경 - admin server - eshop context(ec) >
```bash
kubectl delete pod load-generator-1
```
> 부하기 Pod 삭제

<br>

**이로써 총 3가지의 Datadog 기능을 살펴보았다. 3가지 이외에도 APM, Log집계 및 분석, SLO 리포트 등등 다양한 기능이 제공된다. 보다 자세한 내용은 아래 공식 문서를 참고하도록 한다.**

<https://docs.datadoghq.com/ko/>


### 실습자원 정리(Datadog 연결 해제)

- 우선 Slack, AWS등의 Integration을 삭제한다.

![](../media2/datadog_remove_1.png)
![](../media2/datadog_remove_2.png)

- Helm Chart로 설치한 AWS EKS Worker Node에 설치된 Datadog Agent를 삭제한다.


< EC2 환경 - admin server - eshop context(ec) >
```bash
helm uninstall datadog-agent
```

✔ **(수행 코드/결과 예시)**
```bash
ubuntu@ip-10-0-10-201:~$ helm uninstall datadog-agent
WARNING: Kubernetes configuration file is group-readable. This is insecure. Location: /home/ubuntu/.kube/config
WARNING: Kubernetes configuration file is world-readable. This is insecure. Location: /home/ubuntu/.kube/config
release "datadog-agent" uninstalled
```
> 위와 같이 datadog-agent release가 uninstalled 되었다 표출되면 잘 삭제되었다고 볼 수 있다.

- Datadog 연동 설정관련 AWS IAM Role(`DatadogIntegrationRole`), AWS IAM Policy(`DatadogIntegrationPolicy`) 순으로 삭제한다. (Role 먼저 삭제 후 Policy 삭제)

[Role - `DatadogIntegrationRole` 삭제]
![](../media2/datadog_remove_3.png)

[Policy - `DatadogIntegrationPolicy` 삭제]
![](../media2/datadog_remove_4.png)

<br>

<span style="color:red">위 정리사항을 모두 수행했을 시 Datadog의 Dashboard, Monitor, K8s 기능 등에서 더 이상 데이터를 집계할 수 없다. AWS <-> Datadog 연결이 끊겼기 때문이다.</span>

<br>

**😃 완료!!!**

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
# Helm values overriding

<br>

본 참고사항은 eshop-PaC repository(PaC)에서 Helm Chart의 기본 변수값(`values.yaml`) 을 overriding하는 방법을 다룬다.

**Helm Chart는 기본적으로 `values.yaml`을 기반으로 동작한다.**

서비스 운영을 위한 DEV(개발계), STG(검증계), PROD(운영계) 환경이 각각 존재한다고 가정했을 때 각 환경에 맞는 Helm 변수 값들을 정의하여 기존 `values.yaml`의 값들을 override할 수 있다.

아래 예시는 DEV(개발계)에 필요한 값으로 eshop-adservice의 DEV(개발계)에 배포할 때 필요한 값들을 정의하는 것이라 볼 수 있다.

이 부분을 이용하여 아래와 같이 각각의 환경에 맞게 overriding용 values.yaml 파일을 생성하여 템플릿화 한다.

<< 예시 >>

- 공통 변수             : `values.yaml` 정의
- DEV(개발계) 특화 변수  : `dev-values.yaml` 에서 overriding
- STG(검증계) 특화 변수  : `stg-values.yaml` 에서 overriding
- PROD(운영계) 특화 변수 : `prod-values.yaml` 에서 overriding

<br>
<br>

기존 `values.yaml`의 형태는 아래와 같다. 이곳에 정의된 값들은 기본 값들로 Helm Chart 배포 시 정의된 값들이 Helm 변수로 적용된다.

**eshop-PaC/eshop/values.yaml**
```yaml
## << 변수 >> 치환 필요

## << ECR URI >>      : ex) 123456789012.dkr.ecr.us-east-1.amazonaws.com
## << SERVICE NAME >> : ex) eshop-backend
## << TAG >>          : ex) latest

global:
  rabbitmq:
    # << Amazon MQ AMQP Endpoint >>값 예시) amqps://b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com:5671 값 중 프로토콜, 포트값을 뺀 값이 필요한 값 => b-124010ab-6315-439c-8884-5145399855df.mq.us-west-2.amazonaws.com
    #host: << Amazon MQ AMQP Endpoint >>      # Amazon MQ 도전과제 시 주석해제 후 << Amazon MQ Web Console Endpoint >>에 값 치환
    host: rabbitmq                                   # Amazon MQ 도전과제 시 주석처리
  app:
    name: eshop
    namespace: eshop
  tls:
    enabled: false          # True to enable TLS (set by deploy-all.ps1)
    issuer: ""
  ingress:                                              # ingress related settings
    entries:
      eshop-frontend: eshop-frontend
      eshop-currencyservice: eshop-currencyservice
      eshop-productservice: eshop-productservice
      eshop-recommendservice: eshop-recommendservice
      eshop-adservice: eshop-adservice
      eshop-backend: eshop-backend
      eshop-cartservice: eshop-cartservice
      # spa: ""                                           # ingress entry for web spa
  svc:
    eshop-frontend: eshop-frontend
    eshop-currencyservice: eshop-currencyservice
    eshop-productservice: eshop-productservice
    eshop-recommendservice: eshop-recommendservice
    eshop-adservice: eshop-adservice
    eshop-backend: eshop-backend
    eshop-cartservice: eshop-cartservice
    # spa: webspa                                       # service name for web spa
  images:
    adservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    backend: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    cartservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    frontend: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    currencyservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    productservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
    recommendservice: << ECR URI >>/<< SERVICE NAME >>:<< TAG >>
  appinsights:
    key: ""               # App insights to use
  k8s:                      # inf.k8s defines Kubernetes cluster global config
    dns:  ""                # k8s external  DNS. This value or ip value MUST BE PROVIDED
    local: false            # True when deploying on "local K8s" provided by Docker Desktop.
  hpa:
    minReplicas: 1
    maxReplicas: 18
  misc:                     # inf.misc contains miscellaneous configuration related to infrastructure
    useLoadTest: false      # If running under loading test or not
    useAzureStorage: false  # If catalog api uses azure storage or not
  lightweight:
    kiali-server:
      enabled: true
    prometheus:
      enabled: true
    elasticsearch:
      enabled: true
    grafana:
      enabled: true
  kibanaEnabled: true
  tracing:
    enabled: true
    servicename: "eshop-jaeger-agent"
    serviceport: "6831"
    traceinterval: "7500"
  high-availability:
    elasticsearch:
      enabled: false
    istio-ingress:
      enabled: false
jaeger:
  provisionDataStore:
    cassandra: false
  storage:
    type: elasticsearch
    elasticsearch:
      host: eshop-coordinating-only
      port: 9200
elasticsearch:
  master:
    replicas: 1
  coordinating:
    replicas: 1
  data:
    replicas: 1
```

이 상황에서 아래와 같이 `dev-values.yaml`파일을 새로 생성하고 해당 파일안에 아래와 같이 정의를 한 후, 아래 값을 Helm Chart의 파라메터로 넣게되면 아래 `dev-values.yaml`에 정의된 값들이 우선적으로 Helm 변수로 적용되게 된다.

즉, 이 예시 상황에서는 `dev`라는 환경에 알맞은 값들을 overriding하여 Helm Chart를 여러벌 생성하지 않아도 템플릿화하여 활용할 수 있게 된다.

**eshop-PaC/eshop/dev-values.yaml**
```yaml
# dev계 배포를 위한 values.yaml 템플릿으로 가정하여 dev계 배포를 할 시 필요한 값들을 아래 값에 override한다.

global:
  images:
    adservice: ************.dkr.ecr.us-east-1.amazonaws.com/eshop-adservice:default # values.yaml에 이미 정의되어있는 값을 overriding 하여 tag 값을 변경하는 역할을 한다.(latest => default)
eshop-adservice: # eshop-adservice/Chart.yaml에 정의된 name: eshop-adservice 값 하위 Sub Helm Chart의 값을 매핑한다.
  service:
    name: eshop-adservice
    type: ClusterIP
    port: 8095
```

<br>

이와 동시에 아래와 같이 adservice sub helm chart의 template 변수에 값을 매핑하는 정의를 할 수 있다. 즉, 앞서 새로 정의한 eshop-adservice sub chart에 대한 세부 변수값을 지정할 수 있다.

**eshop-PaC/eshop/charts/eshop-adservice/templates/service.yaml**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.service.name }}   # eshop-adservice
spec:
  type: {{ .Values.service.type }}   # ClusterIP
  selector:
    app: {{ .Values.service.name }}  # eshop-adservice
  ports:
  - port: {{ .Values.service.port }} # 8095
```

<br>

## 배포 실행 후 적용 확인하기

1. Argocd를 통한 배포작업

eshop app을 선택 > APP DETAILS 클릭 > PARAMETERS 탭 이동 > EDIT 클릭 > `dev-values.yaml` 파라미터로 선택 > Save 작업 후 app을 다시 `SYNC` 한다.

![](../media2/helm_overriding_1.png)

<br>

`SYNC` 후 argocd를 통해 eshop-adservice의 Pod의 정보를 보게되면 위에서 overriding 했던 tag 값(`default`)으로 이미지가 변경이 된 후 배포가 완료된 것을 확인할 수 있다. 

![](../media2/helm_overriding_2.png)

<br>


2. Helm을 통한 배포작업

만일 위 과정을 argocd 툴이 아닌 Helm Chart의 명령어로 eshop app을 배포했다고 가정한다면, 아래와 같은 Helm 명령어와 동일한 것이라고 볼 수 있다.

설치한 Helm Chart의 Root Directory로 먼저 이동한 후 아래 명령어를 수행한다.

```bash
helm install eshop -f dev-values.yaml .
```
> 여기서 -f 뒤에 오는 파라메터는 보통 overriding 용도의 values 정의 파일이다. 만일 명령어에서 -f {파일} 과정이 없다면 Helm Chart는 기본적으로 values.yaml만 변수값으로 인식한다.

<br>

혹은 기존에 설치된 상태였다면, 아래와 같이 upgrade를 한다.

```bash
helm upgrade eshop -f dev-values.yaml .
```

<br>

---

🗎 참고. Helm Chart의 Rendering이 정상적으로 되는지 검증하는 명령어는 아래와 같으며, 해당 명령어로 Chart가 제대로 구성 되었는지 확인해볼 수 있다.

```bash
helm template eshop -f dev-values.yaml . | grep adservice
```
> 여기서 -f 뒤에 오는 파라메터는 보통 overriding 용도의 values 정의 파일로 검증한다는 의미이다. 만일 명령어에서 -f {파일} 과정이 없다면 Helm Chart는 기본적으로 values.yaml 변수값으로 렌더링 검증을 수행한다.

---

<br>

아래와 같이 adservice의 렌더링된 값들을 살펴봤을 때 `default` tag로 렌더링 된다면 정상적으로 Chart를 작성하였다 볼 수 있다.

<✔ **(수행 코드/결과 예시)**>

```bash
ubuntu@DESKTOP-JEBSJQ4:~/t3-msp-pjt/eshop-PaC/eshop$ helm template eshop -f dev-values.yaml . | grep adservice
WARNING: Kubernetes configuration file is group-readable. This is insecure. Location: /home/ubuntu/.kube/config
WARNING: Kubernetes configuration file is world-readable. This is insecure. Location: /home/ubuntu/.kube/config
coalesce.go:223: warning: destination for jaeger.elasticsearch.image is a table. Ignoring non-table value (docker.elastic.co/elasticsearch/elasticsearch)
coalesce.go:175: warning: skipped value for jaeger.elasticsearch.image: Not a table.
        adservice: 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-adservice:default
          eshop-adservice: eshop-adservice
        eshop-adservice: eshop-adservice
# Source: eshop/charts/eshop-adservice/templates/service.yaml
  name: eshop-adservice
    app: eshop-adservice
# Source: eshop/charts/eshop-adservice/templates/deployment.yaml
  name: eshop-adservice
      app: eshop-adservice
        app: eshop-adservice
        - name: eshop-adservice
          image: 224166808254.dkr.ecr.us-east-1.amazonaws.com/eshop-adservice:default
        host: eshop-adservice
```

<br>

```bash
helm template eshop . | grep adservice
```
> dev-values.yaml에만 선언되어있고, 템플릿이 service.yaml에 정의된 상황에서 만일 values.yaml로만 렌더링 검증을 한다면 아래와 같은 에러를 경험할 수 있다. 그 이유는 템플릿은 선언되어 있으나, 실제 값을 맵핑할 수 없기 때문이다.


<br>


<✔ **(수행 코드/결과 예시)**>

```bash
ubuntu@DESKTOP-JEBSJQ4:~/t3-msp-pjt/eshop-PaC/eshop$ helm template eshop . | grep adservice
WARNING: Kubernetes configuration file is group-readable. This is insecure. Location: /home/ubuntu/.kube/config
WARNING: Kubernetes configuration file is world-readable. This is insecure. Location: /home/ubuntu/.kube/config
coalesce.go:223: warning: destination for jaeger.elasticsearch.image is a table. Ignoring non-table value (docker.elastic.co/elasticsearch/elasticsearch)
coalesce.go:175: warning: skipped value for jaeger.elasticsearch.image: Not a table.
Error: template: eshop/charts/eshop-adservice/templates/service.yaml:4:18: executing "eshop/charts/eshop-adservice/templates/service.yaml" at <.Values.service.name>: nil pointer evaluating interface {}.name

Use --debug flag to render out invalid YAML
```

<br>


## emarket PaC Helm Chart 다시 살펴보기

위와 같이 Helm Chart의 values들의 overriding을 확인한 후, T3 기본과정에서 다룬 emarket PaC(Helm Chart)의 구조를 다시한번 살펴보도록 한다.


`~/emarket_PaC/emarket` 경로 하위를 보면 아래와 같이 파일과 디렉토리가 구성되어있다.


```bash
drwxr-xr-x  4 ubuntu ubuntu 4096 Feb 20 18:10 .
drwxr-xr-x  8 ubuntu ubuntu 4096 Jul 27  2022 ..
-rw-r--r--  1 ubuntu ubuntu  349 Jul 27  2022 .helmignore
-rw-r--r--  1 ubuntu ubuntu 1242 Jul 27  2022 Chart.yaml
drwxr-xr-x 36 ubuntu ubuntu 4096 Jul 27  2022 charts
-rw-r--r--  1 ubuntu ubuntu 6566 Feb 20 18:10 eks-values.yaml
-rw-r--r--  1 ubuntu ubuntu 6358 Jul 27  2022 kubernetes-values.yaml
drwxr-xr-x  2 ubuntu ubuntu 4096 Jul 27  2022 templates
-rw-r--r--  1 ubuntu ubuntu 6986 Jul 27  2022 values.yaml
```

<br>


`eks-values.yaml` 는 기존 `values.yaml`을 overriding 하기위한 용도의 파일이며, eks 환경에 맞게 구성된 변수값들을 선언한 파일이라 볼 수 있다.


<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
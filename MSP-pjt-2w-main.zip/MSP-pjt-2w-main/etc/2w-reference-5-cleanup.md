# ▣ 자원정리

![](media/cleanUp1.png)

아래와 같이 순서대로 Service > Management VPC 순으로 삭제를 진행하도록 한다.

<br>

❗❗ 자원정리 시 Route 53으로 생성한 `Domain` 과 `us-west-2(Oregon)` Region에 Wild Card로 생성한 `ACM` 인증서는 향후 과정에서도 사용할 예정이므로 그대로 유지하도록 한다.

<br>
<br>

# Mgmt, Service Cluster 내 설치된 ingress-nginx 제거

<br>

## mgmt cluster 내에 ingress-nginx 설치 확인
```bash
kubectl config use-context mgmt
```

< EC2 환경 - admin server - mgmt context(mc)>
```bash
kubectl get all -n ingress-nginx
```

<br>

## service cluster 내에 ingress-nginx 설치 확인
```bash
kubectl config use-context eshop
```

< EC2 환경 - admin server - eshop context(ec)>
```bash
kubectl get all -n ingress-nginx
```

<br>

## mgmt cluster 또는 service cluster 내 ingress-nginx 설치 삭제 (설치된 리소스가 있는 경우만)

< EC2 환경 - admin server - mgmt context(mc) or eshop context(ec)>
```bash
kubectl delete -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.3.0/deploy/static/provider/aws/deploy.yaml
```

<br>
<br>

# Service VPC 및 EKS Cluster 정리

1. Argocd > Applications 항목

-  "eshop" 삭제

-  "istio" 삭제

- ★ "jenkins" 는 삭제 금지!!! (Jenkins pipeline 통해서 Service Cluster에 terrafrom destroy 수행 예정)


❗❗ **Service VPC의 Terraform을 통한 자원 정리 시, 2주차 5일차 VPC Peering 과정에서 생성한 아래 VPC Peering Connection과 EC2 및 Security Group을 사전에 삭제해야 한다.** ❗❗

<br>

[VPC Peering Connection]

- Name Tag: my-pc-test


[EC2]

- Name Tag: service-vpc-pc-test

- Security group name: pc-test

<br>


❗❗ **Service VPC의 Terraform을 통한 자원 정리 시, 2주차 5일차 VPC Peering 과정에서 생성한 Route Table에 추가한 경로 및 Security Group `수동삭제` 필요** ❗❗

- us-west-2
- Route Table Name: eshop-service-terraform-public-route
> 10.0.0.0/16	pcx-************

❗ 삭제

<br>

- us-east-1
- Route Table Name: eshop-mgmt-terraform-private-route
> 192.168.0.0/16	pcx-************

❗ 삭제

<br>

- us-west-2
- Security Group Name: pc-test

❗ 삭제

<br>

## 1. Jenkins eshop-service-IaC 디렉토리로 이동

destroy용 Jenkinsfile로 업데이트한다.
```bash
cp Jenkinsfile_destroy Jenkinsfile
```

<br>

## 2. Jenkinsfile 변경사항을 main 브랜치에 Merge한다.

```bash
git add .; git commit -m "Destroy service cluster"; git push origin main
```
    main 브랜치에 Merge가 되면 Github의 Webhook이 Jenkins로 노티 후 동작하여 Jenkins Service IaC Pipeline이 Trigger 된다. 

    이후 Proceed를 눌러 자원삭제를 진행한다.

<br>
<br>

# MGMT VPC 및 EKS Cluster 정리

- Argocd > Applications 항목에서 Jenkins 앱 삭제

- AWS 콘솔 진입 후 Loadbalancer 화면에서 argocd Loadbalancer 의 security group 클릭하여 화면 이동 후 해당 security group delete

- mgmt context로 전환 후 mgmt context 내 argocd를 삭제한다.(삭제되면서 LoadBalancer Type의 서비스도 함께 삭제된다.)

< EC2 환경 - admin server >
```bash
kubectl config use-context mgmt
```

<br>

< EC2 환경 - admin server - mgmt context(mc) >
```bash
kubectl delete -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/v2.4.28/manifests/install.yaml
```

- WSL 에서 MGMT EKS Cluster 생성 시 eshop-mgmt-IaC repository 디렉토리(~/t3-msp-pjt/eshop-mgmt-IaC)로 이동

- terraform plan -destroy 로 Plan 확인 후 terraform destroy -auto-approve 순차적으로 수행

<br>
<br>

# ETC

- S3 : service EKS cluster의 backend로 사용했던 S3(us-east-1)
  
- S3 : accesslog 저장용 / Athena 쿼리결과 저장용 S3(us-west-2)
  > Athena 참고자료 수행한 경우
  
- ECR : us-east-1 리전에 생성했던 ECR 삭제(이미지 및 Private Repository 전체)

- EC2 Key Pair : us-east-1 리전에 생성했던 EC2 Key Pair(`MyKeyPair`) 삭제

- EC2 Key Pair : us-west-2 리전에 생성했던 EC2 Key Pair(`MyKeyPair`) 삭제
  > VPC Peering 참고자료 수행한 경우

- WSL(Ubuntu 20.04.6 LTS) 및 Windows Subsystem for Linux : 실전프로젝트 이후로 WSL은 사용하지 않을 예정이므로 Windows > App 관리에서 WSL 및 Linux용 Windows 하위 시스템을 삭제하도록 한다.

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
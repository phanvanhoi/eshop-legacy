# **실습환경 Trouble Shootings**

<br>
<br>

## 접속환경

1) 실습환경 내에서 SSH의 기본 포트인 22번 포트의 Outbound가 막혀있을 경우가 있다. 실습환경에서 bastion server로 SSH 프로토콜로 접근이 가능하도록 아래와 같은 조치를 취한다. (SSH의 기본 포트를 10022로 변경하여 접속하는 방식이다.)

<br>

Step1. 1차적으로 수행했던 terraform apply를 통해 생성된 클라우드 상의 `bastion server`(AWS EC2)를 Web Shell(클라우드의 UI)을 통해 접속 후 아래 명령어를 수행한다.

<br>

```bash
sudo su -
```
> linux root 계정으로 스위치

<br>

```bash
echo "Port 10022" | tee -a /etc/ssh/sshd_config
service ssh restart
```
> ssh 기본포트 변경

<br>

Step2. mgmt IaC의 main.tf 내 Security Group 포트를 수정한다.

< WSL 환경 >
```bash
resource "aws_security_group_rule" "bastion-ssh-myip"
(...생략...)
from_port         = 10022 # 변경 (22 => 10022)
to_port           = 10022 # 변경 (22 => 10022)
(...생략...)
```

<br>

Step3. mgmt IaC의 terraform을 다시 apply하여 재수행한다.

<br>

## Terraform

1) 만일 WSL이 아닌 클라우드 상의 EC2 또는 Virtual Server 환경에서 mgmt IaC 테라폼을 수행해야하는 경우. 아래와 같이 main.tf에 MyIP를 직접 코드에 입력 후 수행해야한다.

main.tf 내 `${chomp(data.http.get_my_public_ip.response_body)}` 키워드를 `<< MyIP >>의 실제 IP`로 치환한다.

---

🗎 참고. MyIP 변수

<< MyIP >> : 실습을 수행하는 네트워크환경의 Public IP
> Naver에서 `IP주소`로 검색하면 개인별 네트워크환경의 Public IP주소를 조회할 수 있다.
> 브라우져에서 `https://api.ipify.org` URL 접속으로도 확인 가능하다.

---

<br>

## Mgmt Cluster

1) 간혹 실습환경의 공유기가 재기동 되던지, ISP사의 망작업으로 인해 Public IP가 변경되는 경우가 발생할 수 있다. 이 경우 eshop-mgmt-IaC 테라폼 코드를 재수행(apply) 하여 변경된 Public IP로 갱신하는 작업을 수행해야 한다.

< WSL 환경 >
```bash
cd ~/t3-msp-pjt/eshop-mgmt-IaC
```

< WSL 환경 >
```bash
terraform plan
```
> plan 후 bastion server 관련 Security Group의 엔트리에 변화를 확인한다.

< WSL 환경 >
```bash
terraform apply -auto-approve
```
> 다시 apply를 수행하여 bastion server 관련 Security Group의 Inbound에 Public IP 변경을 적용하도록 한다.

<br>

## Jenkins

1) Jenkins의 IaC, CI Pipeline등에서 jnlp 빌드용 pod 스케쥴링이 불가능한 상황이 발생할 수 있다. 또한, Jenkins의 동작이 정상적이지 않을 경우도 발생할 수 있다. 위와 같은 경우에는 Jenkins statefulset을 재기동한 후 다시 Password 조회를 한 후 로그인한 후 다시 사용해본다.

>※ Jenkins statefulset 재기동 스크립트
>```bash
>kubectl rollout restart statefulset jenkins -n jenkins
>```

<br>

>※ Jenkins 초기 Password 조회
>```bash
>kubectl get secret jenkins -n jenkins -o jsonpath="{.data.jenkins-admin-password}" | base64 -d; echo
>```

2) Jenkins CI Pipeline 혹은 IaC Pipeline을 실행했을 때 내부 터널링 통신 50000 포트연결이 되지 않아서 수행이 안될 경우가 있다. 이럴경우에 `1번 솔루션`처럼 `Jenkins 워크로드를 재구동` 한 후에 다시 접속해봤을 때에도 동일하다면, 아래 설정을 해주도록 한다.

< 출력 예시 1 >
```bash
SEVERE: http://jenkins.jenkins.svc.cluster.local:8080/tcpSlaveAgentListener/ is invalid: 404 Not Found
java.io.IOException: http://jenkins.jenkins.svc.cluster.local:8080/tcpSlaveAgentListener/ is invalid: 404 Not Found
	at org.jenkinsci.remoting.engine.JnlpAgentEndpointResolver.resolve(JnlpAgentEndpointResolver.java:221)
	at hudson.remoting.Engine.innerRun(Engine.java:755)
	at hudson.remoting.Engine.run(Engine.java:543)
```

< 출력 예시 2 >
```bash
- jnlp -- terminated (255)
-----Logs-------------
java.io.IOException: Failed to connect to jenkins-agent.jenkins.svc.cluster.local:50000
	at org.jenkinsci.remoting.engine.JnlpAgentEndpoint.open(JnlpAgentEndpoint.java:248)
	at hudson.remoting.Engine.connectTcp(Engine.java:904)
	at hudson.remoting.Engine.innerRun(Engine.java:788)
	at hudson.remoting.Engine.run(Engine.java:543)
Caused by: java.net.ConnectException: Connection refused
	at java.base/sun.nio.ch.Net.connect0(Native Method)
	at java.base/sun.nio.ch.Net.connect(Unknown Source)
	at java.base/sun.nio.ch.Net.connect(Unknown Source)
	at java.base/sun.nio.ch.SocketChannelImpl.connect(Unknown Source)
	at java.base/java.nio.channels.SocketChannel.open(Unknown Source)
	at org.jenkinsci.remoting.engine.JnlpAgentEndpoint.open(JnlpAgentEndpoint.java:206)
```

`솔루션`

▶ 동적으로 jenkins agent를 생성하여, pipeline을 실행시키기 위한 부분들을 설정한다.

<br>

Step1. Jenkins Home으로 이동 후 좌측 메뉴의 Manage Jenkins 클릭한다.

ⓘ 파란 박스 안의 `역방향 프록시가 잘못 설정되어 있다`는 경고는 Jenkins에 설정된 프록시 서버의 주소가 localhost로 설정되어 있어 발생되는 부분이며, `실습에서는 프록시를 사용하지 않으니 무시하시면 됩니다`.

![](../media1/2022-11-02-13-40.png)

<br>

Step2. `Manage Nodes and Clouds` 클릭하고, 좌측에서 `Configure Clouds` 메뉴를 클릭한다.

![](../media1/2022-11-02-14-45-12.png)   

![](../media1/2022-11-02-14-45-13.png)   

<br>

Step3. 하단의 Kubernetes Cloud details 버튼을 클릭하여, jenkins agent가 생성될 cluster 정보를 입력한다.

![](../media1/2022-11-02-14-45-14.png)

<br>

Step4. 아래과 같이 내용 작성하고 `Test connection` 후 `Save` 버튼을 클릭한다.

❗ 저장하기 전에 Test connection 버튼을 눌러 에러가 발생하지 않는지 꼭 확인해주세요 ❗

<br>

>|항목|내용|
>|---|---|
>|➕ WebSocket|✅체크박스 선택|
>|➖ Jenkins tunnel|❌기존 입력되어 있던 값 삭제|

:point_right: 통신이 정상적으로 된다면, 'Connected to Kubernetes ~~' 메시지가 보이니 참고한다.


<br>
    
![](../media1/2022-11-03-11-32-00.png)

<br>

## Service Cluster

1) 3일차 이후 실습에서 Service EKS Cluster에 istio 및 OSS 등이 추가 설치되면 K8s 클러스터의 리소스가 부족할 수 있다. 그럴 경우, 교재의 가이드를 따라 worker node를 Scale Out 해주도록 한다.
> eshop-service-IaC repo의 terraform 코드 수정 후 Jenkins pipeline 통해 apply

2) Service EKS Cluster 삭제 시 eshop-service-IaC repo의 Jenkinsfile을 Jenkinsfile_destroy 파일로 교체한다. (Linux Copy 명령어 사용)
> destroy 전 수행해야 할 작업: argocd 내 Service EKS Cluster로 배포된 Application 모두 삭제, 만일 nginx ingress 가 설치된 상태라면 해당 리소스 제거 (ingress 설치로 생성된 LoadBalancer 제거 확인)

<br>

## eshop 서비스 관련

1) 만일, 다음 그림과 같이 표출되는 상품이 1개만 표출될 경우는 일시적으로 Product Service => MongoDB에 데이터가 잘 Insert되지 않은 경우에 발생할 수 있다.


![](../media1/eshop_1_product.png)

<br>

그럴 경우 아래와 같이 MongoDB와 Product Service들을 순차적으로 재기동을 수행하여 다시 Product Service에서 MongoDB로 상품데이터를 입력하도록 수행해준다.

< EC2 환경 - admin server - eshop context(ec) >
```bash
kubectl rollout restart statefulset mongodb -n eshop
```

< EC2 환경 - admin server - eshop context(ec) >
```bash
kubectl rollout restart deployment eshop-productservice -n eshop
```

<br>

---

<br>
<br>
<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
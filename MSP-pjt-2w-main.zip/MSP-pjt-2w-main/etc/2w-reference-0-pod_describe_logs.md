# Pod Describe 확인 및 Logs 확인

<br>

본 참고사항은 eshop을 배포 시 문제가 발생되고 있는 Pod(Deployment 또는 Statefulset)의 describe를 확인하거나 로그를 확인하고자 할 때 커맨드라인으로 해당 부분을 체크해볼 수 있는 부분을 기술한다.

<br>

치환 대상
- << Micro Service or Backing Service 이름 >>
> 조회하고자 하는 Pod의 명시적인 이름인 eshop-frontend 및 eshop-backend 등과 같은 eshop의 Microservice 이름이나 redis, rabbitmq 등의 backing service 이름으로 치환한다.

<br>

## 특정 MicroService Pod Describe 확인
```bash
kubectl describe pod $(kubectl get pod -l app=<< Micro Service or Backing Service 이름 >> -o jsonpath={.items..metadata.name} -n eshop) -n eshop
```

<br>

<< 예시 eshop-backend pod Describe 확인 >>
```bash
kubectl describe pod $(kubectl get pod -l app=eshop-backend -o jsonpath={.items..metadata.name} -n eshop) -n eshop
```

<br>
<br>

## 특정 MicroService 로그 확인
```bash
kubectl logs -f $(kubectl get pod -l app=<< Micro Service or Backing Service 이름 >> -o jsonpath={.items..metadata.name} -n eshop) -n eshop
```

<br>

<< 예시 eshop-backend pod Log 확인(tail) >>
```bash
kubectl logs -f $(kubectl get pod -l app=eshop-backend -o jsonpath={.items..metadata.name} -n eshop) -n eshop
```

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
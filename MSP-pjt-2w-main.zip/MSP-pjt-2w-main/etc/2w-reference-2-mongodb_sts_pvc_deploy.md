# MongoDB Statefulset의 PVC 배포하기

<br>

본 참고사항은 eshop-PaC repository(eshop의 전체 helm chart화가 완료된 상태)에서 mongodb의 sts의 data disk를 pvc(PersistentVolumeClaim)로 배포하는 과정을 다룬다. 본 과정이 AWS 벤더사 향으로 진행되므로, AWS EBS를 활용하도록 한다.

**k8s 워크로드의 Cloud향 배포 시 실제 Cloud 벤더에서 제공하는 Volume을 Dynamic하게 생성할 수 있다.**

---

🗎 참고. StorageClass
https://kubernetes.io/ko/docs/concepts/storage/storage-classes/

🗎 참고. Persistent Volume
https://kubernetes.io/ko/docs/concepts/storage/persistent-volumes/

---

아래는 Deployment와 같은 stateless와 Statefulset stateful 워크로드의 차이점을 기술한 레퍼런스이다.

> 🗎 참고. https://selfish-developer.com/entry/Kubernetes-Deployment-vs-StatefulSet

> 🗎 참고. 실무적으로 Statefulset은 PVC를 선언하여 실제 물리적인 Persistent Volume에 매핑하여 생성한다. 즉, 초기 레퍼런스에 제공된 Statefulset 정의만 하게되면, app context가 존재하는 동안(eshop app이 argocd에서 삭제되지 않은 상태)에 rollout restart등의 액션을 할 때 stateful을 유지할 수 있으나, app context가 완전히 삭제되는 경우는 결국 휘발된다.

> 반면 PVC를 사용하면, Reclaim 정책을 retain으로 하며 보존하고, 강제로 PV Volume을 삭제하지 않는이상 영원히 데이터를 보존할 수 있다.

<br>
<br>
<br>

<details>
<summary>[참고 - 펼치기👇] 기존 mongodb sts manifest 정의 </summary>

<br>

최초, PVC가 아닌 Statefulset로 배포했던 MongoDB의 manifest 형태이다.

**eshop-PaC/eshop/charts/mongodb/templates/statefulset.yaml**

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: mongodb
spec:
  serviceName: mongodb
  replicas: 1
  selector:
    matchLabels:
      app: mongodb
  template:
    metadata:
      labels:
        app: mongodb
        selector: mongodb
    spec:
      containers:
      - name: mongodb
        image: mongo:4.0.20
        env:
          - name: MONGO_INITDB_ROOT_USERNAME
            value: admin
          - name: MONGO_INITDB_ROOT_PASSWORD
            value: password
---
apiVersion: v1
kind: Service
metadata:
  name: mongodb
  labels:
    app: mongodb
spec:
  clusterIP: None
  selector:
    app: mongodb
```


</details>


<br>
<br>



## 솔루션


<details>
<summary>[수행 - 펼치기👇] pvc 적용을 위한 mongodb sts manifest 추가 정의</summary>

<br>

:point_right: CSI(Container Storage Interface) Kubernetes와 같은 컨테이너 오케스트레이션 시스템의 컨테이너화된 워크로드에 임의의 블록 및 파일 스토리지 시스템을 노출하기 위한 표준으로 개발되었다.

:point_right: StorageClass는 CSI의 구현체를 가리키는 오브젝트이며, 해당 오브젝트 선언에서 다양한 클라우드 벤더사의 볼륨 Provider와 연계한다.

:point_right: CSI는 아래와 같은 다양한 스토리지 Provider를 지원한다. Kubernetes 내에 이미 Provisioner를 제공하거나, 필요 시 deployment, statefulset 등으로 배포하여 볼륨과 연동한다.

=> 위 사항들을 사용하여 본 참고자료에서는 eshop 서비스의 Product 서비스의 데이터를 저장하는 MongoDB Statefulset에 AWS EBS를 데이터 볼륨으로 사용하여 데이터 영속성을 보장한다. 만일, Application 삭제(즉, PVC가 삭제된다 하더라도, PV(EBS)데이터 디스크는 삭제되지 않는 Reclaim 정책을 적용한다.)

1. Manifest 생성 statefulset.yaml(mongodb용)
   
**eshop-PaC/eshop/charts/mongodb/templates/statefulset.yaml**

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: mongodb
spec:
  serviceName: mongodb
  replicas: 1
  selector:
    matchLabels:
      app: mongodb
  template:
    metadata:
      labels:
        app: mongodb
        selector: mongodb
    spec:
      containers:
      - name: mongodb
        image: mongo:4.0.20
        env:
          - name: MONGO_INITDB_ROOT_USERNAME
            value: admin
          - name: MONGO_INITDB_ROOT_PASSWORD
            value: password
        # 볼륨을 마운트하는 부분이 추가된다. /data/db 경로가 EBS 영역  
        volumeMounts:
        - mountPath: /data/db
          name: mongodb
        # 볼륨을 마운트하는 부분이 추가된다. /data/db 경로가 EBS 영역  
      # statefulset manifest에 pvc 선언
      volumes:
      - name: mongodb
        persistentVolumeClaim:
          claimName: mongodb-pvc
      # statefulset manifest에 pvc 선언
---
apiVersion: v1
kind: Service
metadata:
  name: mongodb
  labels:
    app: mongodb
spec:
  clusterIP: None
  selector:
    app: mongodb
```

<br>

2. Manifest 생성 pvc.yaml

**eshop-PaC/eshop/charts/mongodb/templates/pvc.yaml**
```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: mongodb-pvc
spec:
  accessModes:
  - ReadWriteOnce
  resources:
    requests:
      storage: 20Gi
  storageClassName: mongodb-ebs
---
# StorageClass 구현체 정의
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: mongodb-ebs
provisioner: kubernetes.io/aws-ebs
reclaimPolicy: Retain
allowVolumeExpansion: true
parameters:
  type: gp2
  fsType: xfs  # MongoDB 3.X 버젼 이상 Wired Tiger 에 적합한 filesystem은 xfs이다.
# StorageClass 구현체 정의
```

> :point_right: reclaimPolicy: Retain
> 
> => Workload를 삭제하여도 PV(EBS)를 삭제하지 않고 보존한다.
>  
> :point_right: allowVolumeExpansion: true
> 
> => PV의 용량을 동적으로 확장할 수 있는 정책이다.
> 
> :point_right: parameters:
> 
>   type: gp2
> 
>   fsType: xfs
> 
> => PV의 Type과 FileSystem을 파라메터 선언한다.
>
> 


</details>

<br>


솔루션 적용 후 eshop을 배포하게 되면, mongodb 와 관련된 pvc 및 pv를 아래 명령어로 조회해볼 수 있다.

< EC2 환경 - admin server - eshop context(ec) >
```sh
kubectl get pvc -A
```

<br>

< EC2 환경 - admin server - eshop context(ec) >
```sh
kubectl get pv -A
```

<br>

✔ **(수행 코드/결과 예시)**
```
$ kubectl get pvc -A
NAME          STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS   AGE
mongodb-pvc   Bound    pvc-455a1ab0-a0c8-4a24-b39c-5a8f852f2e16   20Gi       RWO            mongodb-ebs    10s
(...생략...)

$ kubectl get pv -A
NAME                                       CAPACITY   ACCESS MODES   RECLAIM POLICY   STATUS   CLAIM                                             STORAGECLASS   REASON   AGE
pvc-455a1ab0-a0c8-4a24-b39c-5a8f852f2e16   20Gi       RWO            Retain           Bound    eshop/mongodb-pvc                               mongodb-ebs             31s
(...생략...)
```

이후 mongodb 실제 컨테이너에 들어가서 데이터 볼륨 path를 확인한다.


1. eshop namespace 내 Running Pod들을 조회한다.

< EC2 환경 - admin server - eshop context(ec) >
```
kubectl get pods -n eshop
```

✔ **(수행 코드/결과 예시)**
```
ubuntu@ip-10-0-10-57:~$ kubectl get pods -n eshop
NAME                                             READY   STATUS    RESTARTS        AGE
eshop-adservice-6d884f5c8d-t698j                 2/2     Running   0               5h42m
eshop-backend-655c58fd8d-hblh5                   2/2     Running   0               5h42m
eshop-cartservice-558c44c79-kqg2f                2/2     Running   0               5h42m
eshop-currencyservice-76cc5d5896-vtkch           2/2     Running   0               5h42m
eshop-frontend-6744cb67f7-qdnq4                  2/2     Running   0               5h42m
eshop-productservice-7d587bf8b-xr947             2/2     Running   0               5h42m
eshop-recommendservice-5b9546c574-h7xxw          2/2     Running   0               5h42m
mongodb-0                                        2/2     Running   0               5h42m
postgres-5c57d65b7d-sbvvm                        2/2     Running   0               5h42m
rabbitmq-798c7669b-rmk4f                         2/2     Running   0               5h42m
redis-655d9fd58c-bdchd                           2/2     Running   0               5h42m
```


2. `mongodb-0` sts pod 내부로 접속한다.

< EC2 환경 - admin server - eshop context(ec) >
```
kubectl exec -it mongodb-0 -n eshop -- /bin/bash
```

`root@mongodb-0` 프롬프트로 변경되며, mongodb sts pod 내부로 접속된다.

✔ **(수행 코드/결과 예시)**
```
ubuntu@ip-10-0-10-57:~$ kubectl exec -it mongodb-0 -n eshop -- /bin/bash
groups: cannot find name for group ID 1337
root@mongodb-0:/#
```

3. `mongodb-0` sts pod 내부에서 실제 Filesystem과 Capacity 및 Mount Path등을 체크해본다.

<< EC2 환경 - admin server - mongodb sts 내부 >>
```
df -hT
```

실제로 manifest에 정의한 `/data/db` Path로 Mount가 되었고, xfs Filesystem 및 20G의 Capacity의 볼륨으로 마운트가 된 것을 확인할 수 있다.

✔ **(수행 코드/결과 예시)**
```
root@mongodb-0:/# df -hT
Filesystem     Type     Size  Used Avail Use% Mounted on
overlay        overlay   20G  8.2G   12G  41% /
tmpfs          tmpfs     64M     0   64M   0% /dev
tmpfs          tmpfs    3.9G     0  3.9G   0% /sys/fs/cgroup
/dev/nvme1n1   xfs       20G  480M   20G   3% /data/db
/dev/nvme0n1p1 xfs       20G  8.2G   12G  41% /etc/hosts
shm            tmpfs     64M     0   64M   0% /dev/shm
tmpfs          tmpfs    7.0G   12K  7.0G   1% /run/secrets/kubernetes.io/serviceaccount
tmpfs          tmpfs    3.9G     0  3.9G   0% /proc/acpi
tmpfs          tmpfs    3.9G     0  3.9G   0% /sys/firmware
```

4. `mongodb-0` sts pod 내부에서 mongodb 데이터들을 Admin서버로 백업하는 작업을 해본다.

    4-1. 2번에서 접속한 Pod 내부에서 Mongodb 데이터 디렉토리로 이동한다.
    ```
    cd /data
    ```
    4-2. 데이터 디렉토리 내부 리스트 확인한다.
    ```
    ls -al
    ```
    ✔ **(수행 코드/결과 예시)**
    ```
    root@mongodb-0:/data# ls -al
    total 1676
    drwxr-xr-x 1 root    root         23 Jan 31 13:59 .
    drwxr-xr-x 1 root    root         52 Jan 31 07:24 ..
    drwxr-xr-x 2 mongodb mongodb       6 Oct 23  2020 configdb
    drwxrwsr-x 4 mongodb    1337    4096 Jan 31 13:52 db
    ```
    4-3. 데이터 디렉토리 전체를 gz으로 압축한다.
    ```
    tar cvfz db.tar.gz db/
    ```
    ✔ **(수행 코드/결과 예시)**
    ```
    root@mongodb-0:/data# tar cvfz db.tar.gz db/
    db/
    db/mongod.lock
    db/journal/
    db/journal/WiredTigerLog.0000000002
    db/journal/WiredTigerPreplog.0000000001
    db/journal/WiredTigerPreplog.0000000002
    db/WiredTiger.lock
    db/WiredTiger
    db/WiredTiger.wt
    db/WiredTiger.turtle
    db/sizeStorer.wt
    db/_mdb_catalog.wt
    db/storage.bson
    db/collection-0-3714044970307453232.wt
    db/index-1-3714044970307453232.wt
    db/collection-2-3714044970307453232.wt
    db/index-3-3714044970307453232.wt
    db/collection-4-3714044970307453232.wt
    db/index-5-3714044970307453232.wt
    db/index-6-3714044970307453232.wt
    db/diagnostic.data/
    db/diagnostic.data/metrics.2023-01-31T07-24-31Z-00000
    db/diagnostic.data/metrics.2023-01-31T07-24-38Z-00000
    db/diagnostic.data/metrics.interim
    db/collection-7-3714044970307453232.wt
    db/index-8-3714044970307453232.wt
    db/index-9-3714044970307453232.wt
    db/WiredTigerLAS.wt
    db/collection-0--4450200651249502333.wt
    db/index-1--4450200651249502333.wt
    db/collection-2--4450200651249502333.wt
    db/index-3--4450200651249502333.wt
    ```
    4-4. 압축된 gz파일을 확인한다.    
    ✔ **(수행 코드/결과 예시)**
    ```
    root@mongodb-0:/data# ls -al
    total 1676
    drwxr-xr-x 1 root    root         23 Jan 31 13:59 .
    drwxr-xr-x 1 root    root         52 Jan 31 07:24 ..
    drwxr-xr-x 2 mongodb mongodb       6 Oct 23  2020 configdb
    drwxrwsr-x 4 mongodb    1337    4096 Jan 31 13:52 db
    -rw-r--r-- 1 root    root    1711180 Jan 31 13:59 db.tar.gz
    ```
    4-5. `mongodb-0` sts pod 내부에서 mongodb 데이터들을 Admin서버로 File Copy를 한다. (Admin의 /home/ubuntu 경로로)

    Admin서버로 다시 프롬프트를 돌리고, kubectl 명령어를 수행 할 준비를 한다.
    ```
    root@mongodb-0:/data# exit
    exit
    command terminated with exit code 127
    ```

    ubuntu 계정의 Home으로 이동
    ```
    cd ~
    ```

    /home/ubuntu/db.tar.gz 경로로 sts pod 내부에 있던 File Copy를 하는 명령어를 수행한다.

    ```
    kubectl cp eshop/mongodb-0:/data/db.tar.gz /home/ubuntu/db.tar.gz
    ```

    ✔ **(수행 코드/결과 예시)**   

    🗎 참고. tar: Removing leading `/' from member names 메세지는 무시해도 되는 메세지이다.

    ```
    ubuntu@ip-10-0-10-57:~$ kubectl cp eshop/mongodb-0:/data/db.tar.gz /home/ubuntu/db.tar.gz
    tar: Removing leading `/' from member names
    ```

    정상적으로 복사 되었는지 확인한다.

    ✔ **(수행 코드/결과 예시)**
    ```
    ubuntu@ip-10-0-10-57:~$ ls -al
    (...생략...)
    -rw-rw-r-- 1 ubuntu ubuntu 1711180 Jan 31 14:16 db.tar.gz
    (...생략...)
    ```

    압축을 풀어보고 정상적으로 데이터 파일들이 있는지 확인해본다.

    ```
    tar xvfz db.tar.gz
    ```

    ✔ **(수행 코드/결과 예시)**
    ```
    ubuntu@ip-10-0-10-57:~$ tar xvfz db.tar.gz
    db/
    db/mongod.lock
    db/journal/
    db/journal/WiredTigerLog.0000000002
    db/journal/WiredTigerPreplog.0000000001
    db/journal/WiredTigerPreplog.0000000002
    db/WiredTiger.lock
    db/WiredTiger
    db/WiredTiger.wt
    db/WiredTiger.turtle
    db/sizeStorer.wt
    db/_mdb_catalog.wt
    db/storage.bson
    db/collection-0-3714044970307453232.wt
    db/index-1-3714044970307453232.wt
    db/collection-2-3714044970307453232.wt
    db/index-3-3714044970307453232.wt
    db/collection-4-3714044970307453232.wt
    db/index-5-3714044970307453232.wt
    db/index-6-3714044970307453232.wt
    db/diagnostic.data/
    db/diagnostic.data/metrics.2023-01-31T07-24-31Z-00000
    db/diagnostic.data/metrics.2023-01-31T07-24-38Z-00000
    db/diagnostic.data/metrics.interim
    db/collection-7-3714044970307453232.wt
    db/index-8-3714044970307453232.wt
    db/index-9-3714044970307453232.wt
    db/WiredTigerLAS.wt
    db/collection-0--4450200651249502333.wt
    db/index-1--4450200651249502333.wt
    db/collection-2--4450200651249502333.wt
    db/index-3--4450200651249502333.wt
    ```

    /home/ubuntu/db 디렉토리 생성여부 및 내부 데이터 파일이 잘 존재하는지 확인한다.

    ✔ **(수행 코드/결과 예시)**
    ```
    ubuntu@ip-10-0-10-57:~/db$ ls -al
    total 456
    drwxrwxr-x  4 ubuntu ubuntu  4096 Jan 31 13:52 .
    drwxr-xr-x 10 ubuntu ubuntu  4096 Jan 31 14:24 ..
    -rw-------  1 ubuntu ubuntu    45 Jan 31 07:24 WiredTiger
    -rw-------  1 ubuntu ubuntu    21 Jan 31 07:24 WiredTiger.lock
    -rw-------  1 ubuntu ubuntu  1070 Jan 31 13:52 WiredTiger.turtle
    -rw-------  1 ubuntu ubuntu 77824 Jan 31 13:52 WiredTiger.wt
    -rw-------  1 ubuntu ubuntu  4096 Jan 31 07:24 WiredTigerLAS.wt
    -rw-------  1 ubuntu ubuntu 36864 Jan 31 13:17 _mdb_catalog.wt
    -rw-------  1 ubuntu ubuntu 16384 Jan 31 07:25 collection-0--4450200651249502333.wt
    -rw-------  1 ubuntu ubuntu 16384 Jan 31 07:24 collection-0-3714044970307453232.wt
    -rw-------  1 ubuntu ubuntu 16384 Jan 31 13:17 collection-2--4450200651249502333.wt
    -rw-------  1 ubuntu ubuntu 32768 Jan 31 07:25 collection-2-3714044970307453232.wt
    -rw-------  1 ubuntu ubuntu 24576 Jan 31 13:49 collection-4-3714044970307453232.wt
    -rw-------  1 ubuntu ubuntu 16384 Jan 31 07:24 collection-7-3714044970307453232.wt
    drwx------  2 ubuntu ubuntu  4096 Jan 31 13:59 diagnostic.data
    -rw-------  1 ubuntu ubuntu 16384 Jan 31 07:25 index-1--4450200651249502333.wt
    -rw-------  1 ubuntu ubuntu 16384 Jan 31 07:24 index-1-3714044970307453232.wt
    -rw-------  1 ubuntu ubuntu 16384 Jan 31 13:17 index-3--4450200651249502333.wt
    -rw-------  1 ubuntu ubuntu 32768 Jan 31 07:25 index-3-3714044970307453232.wt
    -rw-------  1 ubuntu ubuntu 24576 Jan 31 13:49 index-5-3714044970307453232.wt
    -rw-------  1 ubuntu ubuntu 12288 Jan 31 13:51 index-6-3714044970307453232.wt
    -rw-------  1 ubuntu ubuntu 16384 Jan 31 07:24 index-8-3714044970307453232.wt
    -rw-------  1 ubuntu ubuntu 16384 Jan 31 07:24 index-9-3714044970307453232.wt
    drwx------  2 ubuntu ubuntu  4096 Jan 31 07:24 journal
    -rw-------  1 ubuntu ubuntu     2 Jan 31 07:24 mongod.lock
    -rw-------  1 ubuntu ubuntu 36864 Jan 31 13:50 sizeStorer.wt
    -rw-------  1 ubuntu ubuntu   114 Jan 31 07:24 storage.bson
    ```

5. 4번 작업을 통해 백업된 데이터를 통해 향후 Data 마이그레이션을 수행할 수 있으며, 서비스로 산출된 Data 분석에도 활용할 수 있고, 다양한 용도로 활용할 수 있게 된다.

6. eshop app을 argocd에서 삭제해본다. 최종적으로 Reclaim 정책으로 선언했던 `retain` 정책에 의해 eshop app을 argocd를 통해 삭제하더라도 `avaliable`상태로 EBS 볼륨이 남아있음을 확인할 수 있다.

<br>

![](../media2/pvc_aws_00.png)

<br>

![](../media2/pvc_aws_01.png)


<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
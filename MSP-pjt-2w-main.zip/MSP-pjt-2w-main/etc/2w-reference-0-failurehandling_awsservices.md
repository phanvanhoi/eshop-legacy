- [**Service EKS Cluster 장애 대응**](#service-eks-cluster-장애-대응)
  - [실습 목표](#실습-목표)
  - [수행 목록](#수행-목록)
  - [**Lab. Recommend Service 장애 격리 및 복구 실습**](#lab-recommend-service-장애-격리-및-복구-실습)
    - [Kiali의 AuthorizationPolicy 해제](#kiali의-authorizationpolicy-해제)
  - [**Evaluation**](#evaluation)
- [ \[목록\] ](#-목록-)

---

# **Service EKS Cluster 장애 대응**

## 실습 목표
- Istio의 Circuit Breaking 기능을 활용하여 서비스 지연 및 비정상 동작하는 마이크로서비스를 배제시켜본다. (장애전파 최소화)
- 장애상황에서 관련 Backing Service를 정상화시키고 마이크로 서비스를 정상화시켜본다.

<br>

## 수행 목록
1. [Istio Circuit Break] Istio circuit break을 통한 장애 마이크로서비스 격리

<br>
<br>

## **Lab. Recommend Service 장애 격리 및 복구 실습**

<br>

본 실습은 EKS 운영 시 발생할 수 있는 상황인, Backing Service(MongoDB StatefulSet)가 정상동작을 하지 못하는 경우, 연계되는 서비스에 호출을 끊는 개념인 Circuit Breaking 개념에 대해 확인해본다.

> Istio Circuit Breaking
> 
> <https://istio.io/latest/docs/tasks/traffic-management/circuit-breaking/>

분산 시스템 특히 복잡한 유기관계의 MSA 환경에서의 Cascading Faliure는 충분히 발생할 수 있는 가능성이 있다. MSA 서비스들 중 한 컨테이너(파드)에 문제가 발생할 수도 있고, Backing 시스템 중 DB(ex. MongoDB)등의 네트워크, 리소스부족 장애현상 등이 단적인 예이다.

---

> 🗎 참고. Cascading Failure
> 
> https://blog.naver.com/PostView.naver?blogId=sw4r&logNo=221258533149&parentCategoryNo=&categoryNo=179&viewDate=&isShowPopularPosts=false&from=postView

---

이번 실습을 통하여 장애가 발생된 서비스와 연관된 마이크로 서비스를 Istio의 Circuit Break를 통해 격리시키고, 서비스 재 복구를 하는 과정을 진행해본다.

Kiali로 테스트과정을 수행할 것이 때문에 사전에 kiali 접근 deny 정책을 해제(주석처리)한다.

<br>

### Kiali의 AuthorizationPolicy 해제

- Kiali가 기본적으로 anonymous 정책을 사용하도록 설정이 되어있기 때문에 평시에는 적용시키며, 테스트시점에만 아래 정책을 해제시킨다.

<br>

**eshop-PaC/eshop/charts/istio-authz/templates/kiali-auth-policy.yaml**

```yaml
# apiVersion: security.istio.io/v1beta1
# kind: AuthorizationPolicy
# metadata:
#   name: kiali-ingress-policy
#   namespace: istio-system
# spec:
#   selector:
#     matchLabels:
#       app: istio-ingressgateway
#   action: DENY
#   rules:
#     # IP Base ACL 미동작
#     # - from:
#     #   - source:
#     #       ipBlocks:
#     #       - 121.133.133.0/24
#     #       - 221.167.219.0/24
#     - to:
#       - operation:
#           paths: [
#             "/kiali*"
#           ]
```

<br>

- 테스트를 위해 위와 같이 Policy를 주석처리 해준 후 Github main branch에 Push 후 Argocd의 `Sync` 시 `Prune`을 `체크`한 후 `Sync` 해준다.


    ![](../media1/argocd-prune-sync.png)

<br>

![](../media2/image91.png)

위 그림에서 볼 수 있듯이, Recommend Service와 Product Service 그리고 MongoDB Backing 서비스는 서로 유기적으로 연결되어 있는 관계이다.

Recommend Service API가 호출되면, Recommend Service는 Product Service를 호출하며, Product Service는 MongoDB 데이터를 조회하여 Response 해주는 구조이다.

이와 같은 관계에서 MongoDB Pod의 장애상황을 가정한 Circuit Break 동작을 살펴본다.

우선 Recommend Virtual Service와 연관된 Destination Rule을 생성한다.

**eshop-PaC/eshop/charts/istio-vs/templates/drs.yaml**
```yaml
## recommendservice circuit breaker
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: eshop-recommendservice
spec:
  host: eshop-recommendservice
  trafficPolicy:
    tls:
      mode: DISABLE
    outlierDetection: # Circuit Breakers HAVE TO BE SWITCHED ON
      consecutive5xxErrors: 7
      interval: 5s
      baseEjectionTime: 10s
      maxEjectionPercent: 100
```

<br>

➡️ 격리 조건은 아래와 같이 설정했다.
- outlierDetection: 서킷 브레이커 설정
- consecutive5xxErrors: 연속적인 HTTP 5XX 7번 발생
> host가 커넥션 풀에서 제거되기 전의 5xx 오류 갯수(서킷 브레이커 작동 전까지 연속 발생 오류 갯수)
- interval: 5초마다 검사 주기
- baseEjectionTime: 10초간의 서비스 격리(참고로, 7번 에러가 발생이 지속되면 격리시간 10초가 계속 갱신된다.)
> 서킷 브레이커 작동시간, 해당 업스트림으로 리퀘스트를 보내지 않는다.
- maxEjectionPercent: 접속하는 호스트 중 100퍼센트 격리
> 업스트림으로의 네트워크를 차단할 host의 비율

<br>

1. 부하기를 통해 Recommend Service에 부하를 넣어준다.

<br>

< EC2 환경 - admin server - eshop context(ec) >
```bash
kubectl run -i --tty load-generator-1 --rm --image=busybox --restart=Never -- /bin/sh -c "while sleep 0.01; do wget -q -O- http://<< DOMAIN >>/api/recommends; done"
```
> << DOMAIN >> 값은 개인 eshop 서비스의 FQDN 도메인으로 치환해야 한다.

<br>

2. Kiali를 통해 실제로 부하가 정상적으로 들어가고 있는지 확인 한다.

![](../media2/image92.png)

<br>

---

🗎 참고. kiali Graph기능 traffic animation 및 상세정보 시각화 활성화 방법

kiali Graph기능에서 특정 서비스의 트래픽 흐름을 움직임으로 보고 상세한 트래픽의 흐름 및 Namespace 구분등을 시각화 하려면 아래와 같이 Display에서 아래 항목들을 추가 선택해준다.

Show Edge Labels
  - Response Time > 95th Percentile
  - Throughput > Request
  - Traffic Distribution
  - Traffic Rate

Show
  - Cluster Boxes
  - Namespace Boxes
  - Traffic Animation

![](../media2/kiali_new_01.png)

---

<br>

3. MongoDB 장애상황을 연출하기 위하여 MongoDB SVC 정의 및 StatefulSet 정의 를 Argocd에서 삭제한다.

![](../media2/image93.png)

![](../media2/image94.png)

<br>

4. RecommendServices에 Circuit Breaking이 활성화 되어 eshop Namespace에서 사라진다.

RecommendService와 서로 유기적 관계가 있는 ProductService 또한 eshop Namespace에서 unknown으로 이동되고, 결국 Istio-IngressGateway는 두개의 서비스를 격리시켰다고 볼 수 있다. 즉, eshop Namespace내의 Upstream 호스트(워크로드)로 트래픽을 보내지 않고 istio에서 HTTP 503을 리턴하며 서킷브레이커 대상 업스트림 워크로드로 트래픽을 보내지 않는 것을 볼 수 있다.

참고로, Kiali를 통해서 Circuit Break가 정의되어 있는 모듈을 살펴볼 수 있는데 "번개"모양 아이콘이 존재한다면, 해당 Service는 Circuit Breaking이 정의되어있다고 볼 수 있다.

![](../media2/image95.png)

<br>

5. 장애상황 복구를 위해 MongoDB에 조치가 되어 다시 정상화 되었다고 가정하고, MongoDB SVC와 STS 정의를 Sync

![](../media2/image93.png)

![](../media2/image94.png)

<br>

6. MongoDB StatfulSet과 Service 그리고 Pod 정상화

정상화된 후 얼마 지나지 않아 Kiali로 Recommend / Product Service들이 eshop Namespace(eshop App Namespace)에 복귀되고 정상 OK 트래픽 처리가 원활함을 확인할 수 있다.

![](../media2/image96.png)

<br>

7. Istio Circuit Break 정의되지 않은 상황에서의 테스트를 수행해본다.

앞서 생성한 아래 Recommend Virtual Service와 연관된 Destination Rule을 삭제(주석처리)한다.

**eshop-PaC/eshop/charts/istio-vs/templates/drs.yaml**
```yaml
## recommendservice circuit breaker
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: eshop-recommendservice
spec:
  host: eshop-recommendservice
  trafficPolicy:
    tls:
      mode: DISABLE
    outlierDetection: # Circuit Breakers HAVE TO BE SWITCHED ON
      consecutive5xxErrors: 7
      interval: 5s
      baseEjectionTime: 10s
      maxEjectionPercent: 100
```

![](../media2/image97.png)

<br>

8. Github main 브랜치에 변경내용을 Merge하고 Destination Rule을 Sync(Prune) 한다.

![](../media2/image98.png)

<br>

9. MongoDB의 장애상황이 연출되고 RecommendService 워크로드 자원의 리소스 점유율은 높아진다

![](../media2/image99.png)

![](../media2/image100.png)

<br>

10. Kiali를 통하여 현 상황을 살펴본다.

Recommend Service는 격리되지 않았고, 실제로 번개표시의 Circuit Break 설정도 없는 것을 볼 수 있다.

추가로, 트래픽은 온전히 eshop Namespace로 들어가고 있다. 서킷브레이커가 설정되어있지 않으므로 문제가 되고있는 업스트림으로 트래픽을 계속 보내며, 문제가 발생중인 업스트림 호스트에서 HTTP 500을 리턴하는 상황을 볼 수 있다.(eshop Namespace 내 워크로드로 트래픽이 계속 들어간다.) 이는 istio에서 문제가 되는 업스트림 호스트가 정상인 상태와 동일하게 트래픽을 보내게 되는 상황이다.

![](../media2/image101.png)

<br>
<br>

## **Evaluation**
---
- Istio의 Circuit Break의 예제 실습을 수행해보며, 작동방식 및 효과를 이해한다.
- 실제 마이크로 서비스 운영 시 Circuit Break 응용에 대해 검토한다.
---

<br>
<br>

---

<br>

😃 **참고자료 끝**

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
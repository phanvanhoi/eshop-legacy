# Jenkinsfile 내 cat의 의미

<br>

eshop-MSA(eshop-MSA-CI) 서비스나 eshop-service-IaC 배포 시 사용하는 Jenkinsfile에 K8s Pod yaml 부분을 보면 공통적으로 cat 명령어를 실행하도록 되어있다. (gradle, kaniko, terraform 모두)

아무런 인자도 없이 달랑 cat만 실행해서 의미 없는 명령어라고 생각할 수 있지만 나름 역할이 있다.

예를 들어 아래와 같은 구조의 Jenkinsfile groovy script 상에서 `cat command 부분을 지우고 파이프라인을 실행해보면 에러와 함께 파이프라인이 종료`되어 버린다.

```groovy
yaml """
apiVersion: v1
kind: Pod
metadata:
  labels:
    name: gradle
spec:
  containers:
  - name: gradle
    image: gradle:6.3.0-jdk11
    command:
    - cat              <===== 이것!
    tty: true
    env:
      # Define the environment variable
      - name: CRED
        valueFrom:
          secretKeyRef:
            name: jenkinscred
            key: ECR_CREDENTIAL_JSON
  restartPolicy: Never
"""
```

<br>

그 시점에 EKS 클러스터에서 jenkins가 생성한 gradle Pod를 지켜보고 있으면, 아직 이미지 빌드와 같은 step은 진행되기 전 컨테이너 내부 프로세스가 실행되고 Completed 상태로 바뀌면서 Pod가 사라진다.

`cat 프로세스가 모든 파이프라인 단계가 완료될 때 까지 Pod의 컨테이너를 일종의 홀딩 상태로 유지`해주는 역할을 한다고 볼 수 있다.

<br>

*아무런 인자 없이 실행할 수 있는 만만한(?) 명령어라 거의 암묵적 표준 처럼 cat을 사용. 컨테이너 이미지에 바이너리가 존재한다면 동일 역할을 하는 sleep infinity 등으로도 대체할 수 있다.*

<br>

---

🗎 참고. 사이트 링크
> <https://stackoverflow.com/questions/72856464/what-does-cat-tty-true-mean-in-yaml-configuration-of-kubernetes-agent-in-jenki>

---

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
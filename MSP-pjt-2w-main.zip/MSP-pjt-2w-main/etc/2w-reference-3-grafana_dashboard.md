# T3 과정 구축 4일차 - Self Study 01 참고

<br>

---
- [T3 과정 구축 4일차 - Self Study 01 참고](#t3-과정-구축-4일차---self-study-01-참고)
    - [Grafana Custom Dashboard 추가](#grafana-custom-dashboard-추가)
- [ \[목록\] ](#-목록-)
---

ⓘ 실습목표 : eshop app에 포함되어 배포된 Prometheus와 Grafana에 접속하여 등록된 모니터링 대시보드를 확인해보고, 추가 대시보드를 구성한다.

<br>


### Grafana Custom Dashboard 추가   

> Grafana Web UI에 접속하여 이미 등록되어 있는 Kubernetes Node Dashboard를 확인 할 수 있다.   

<br>

1. Grafana Web 에 접속한다.   
   
   → 접속 URL : https://<< DOMAIN >>/grafana    
   (e.g. eshop.mspt3.click/grafana)     
   
   ➕ Email or username : `admin`   

   ➕ Password :  `grafana Helm values.yaml에 정의한 값`   

    ![](../media2/2022-04-12_170944.png)
    
<br>

2. Grafana에 이미 등록되어 있는 Data Source, Dashboard 정보를 확인 가능하다.   
    <br>
    2-1. 좌측 `Configuration > Data Sources` 메뉴 클릭하면 Prometheus 서버가 이미 Data source로 등록되어 있음을 확인 할 수 있다.   
    ![](../media2/2022-04-12_164531.png)

    <br>

    2-2. 좌측 `Dashboards > Manage` 메뉴를 클릭 후 `Node Exporter for Prometheus Dashboard EN v20201010`을 선택한다.   

    - emarket eks cluster의 각 노드별 CPU/Memory/Disk/Network Metric을 모니터링 할 수 있다.   

    ![](../media2/2022-04-12_174531.png)

    <br>
    
    ![](../media2/image2022-2-18_17-34-13.png)
<br>

3. Grafana에 추가로 Kubernetes Cluster를 모니터링 하기 위한 Dashboard를 구성한다.   
    <br>
    3-1. Grafana Dashboard 사이트에서 `Kubernetes` 검색   
    
    > :point_right: Grafana는 Dashboard 사이트( https://grafana.com/grafana/dashboards/ )를 통해 다양한 Pre built된 공식/비공식 Dashboard를 공유하고 있다. Cloud Native Tool/System의 경우 대부분 이미 만들어져 공유된 Dashboard가 올라와 있으니, 직접 Dashboard를 구성하기 전에 검색을 통해 원하는 Dashboard가 있는지 확인 해본다!

    ![](../media2/2022-04-13_104711.png)
    <br>

    3-2. 스크롤을 내려 `Kubernetes cluster monitoring (via Prometheus)` 선택

    ![](../media2/2022-04-13_104811.png)
    <br>

    3-3. 우측 Dashboard 공유 ID(해당 Dashboard의 경우 315)를 확인

    ![](../media2/2022-04-13_104911.png)
    <br>

    3-4. Grafana `Dashborad > Manage` 화면에서 `Import` 버튼 클릭

    ![](../media2/image2022-2-21_12-59-4.png)
    <br>

    3-5. `Import via grafana.com` 에 3-3 에서 확인한 Kubernetes cluster dashboar의 ID인 *315* 를 입력 후 `Load` 버튼 클릭

    <img src="../media2/2022-04-13_105711.png" width="500">
    <br>

    3-6. 하단의 Prometheus에 기 등록되어 있는 `Prometheus` Data source를 선택 후 `Import` 버튼 클릭

    <img src="../media2/2022-04-13_143611.png" width="500">
    <br>

    3-7. Kubernetes cluster monitoring Dashboard가 추가되어 각종 그래프를 확인할 수 있다.

    ![](../media2/2022-04-13_143711.png)



<br>
<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
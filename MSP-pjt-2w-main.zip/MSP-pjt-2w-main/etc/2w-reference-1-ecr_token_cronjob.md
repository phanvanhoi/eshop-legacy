## K8s Cronjob을 이용한 ECR Token 갱신 적용

### 주제: K8s Cronjob, Secret, Configmap

<br>

## K8s Cronjob 구성(Service Account, RBAC)

<br>

필수과제에서 기본적으로 가이드되는 ECR Token의 갱신 방식은 Linux(admin server)시스템의 Crontab을 이용한 주기적인 갱신 방법이었다.

해당 방법은 admin server라는 EC2에 적용을 한 사항이며, 해당 admin server EC2의 상태에 따라 갱신의 성공, 실패가 좌우될 수 있다.

<br>

## 작업목적

이를 K8s Cluster 내에서 동일한 역할을 하는 Cronjob Object로 구성하여 ECR Token 갱신 시 EC2환경에 대한 의존성을 제거해보는 작업을 수행하는 목적이다.

K8s의 Cronjob에 대한 보다 자세한 내용은 아래 문서를 참고한다.

<https://kubernetes.io/ko/docs/concepts/workloads/controllers/cron-jobs/>

<br>

## 작업과정

1. Admin Server에서 ECR 갱신 역할을 하는 Service Account, Role, RoleBinding, Cronjob등이 구성된 레퍼런스 소스를 다운로드 받는다.

< EC2 환경 - admin server - mgmt context(mc) >
```bash
cd ~
```
> Admin Server의 Ubuntu Home으로 이동

< EC2 환경 - admin server - mgmt context(mc) >
```bash
aws s3 cp s3://t2hubintern/eshop-ecr-registry-helper.tar.gz .
```
> 토큰갱신용도의 역할을 수행하는 참고 구성소스 다운로드

< EC2 환경 - admin server - mgmt context(mc) >
```bash
tar xvfz eshop-ecr-registry-helper.tar.gz
```
> 토큰갱신용도의 역할을 수행하는 참고 구성소스 압축 해제

< EC2 환경 - admin server - mgmt context(mc) >
```bash
cd eshop-ecr-registry-helper
```
> 압축이 해제되면 eshop-ecr-registry-helper 디렉토리 명으로 파일 및 디렉토리가 압축 해제된다.

<br>

2. eshop-ecr-registry-helper 폴더 내 `ecr-registry-helper.yaml`파일 내부 변수값을 치환한다.

vi editor를 이용하여 아래 파일의 변수값을 치환하는 작업을 해준다.

**ecr-registry-helper.yaml**
```yaml
(...생략...)
stringData:
  AWS_ACCESS_KEY_ID: "<< Access key >>"               # Replace with your AWS access key ID
  AWS_SECRET_ACCESS_KEY: "<< Secret Access key >>"    # Replace with your AWS secret access key
  AWS_ACCOUNT: "<< AWS Account ID >>"                 # Replace with your AWS account ID
---
(...생략...)
```
> << Access key >>, << Secret Access key >>, << AWS Account ID >> 3가지 변수 값을 개인 값으로 치환 한다.

[치환대상 변수 값]
- << Access key >> : 개인 AWS IAM 계정인 mspuser에 발급한 AWS Access Key
- << Secret Access key >> : 개인 AWS IAM 계정인 mspuser에 발급한 AWS Secret Access Key
- << AWS Account ID >> : 개인 AWS 계정의 Account ID 총 12자리 숫자

<br>

3. `ecr-registry-helper.yaml`파일 내 변수 치환 후 3개의 yaml파일로 K8s Object들을 생성한다.

< EC2 환경 - admin server - mgmt context(mc) >
```bash
cd eshop-ecr-registry-helper
```
> yaml파일들이 있는 위치로 이동

< EC2 환경 - admin server - mgmt context(mc) >
```bash
cd eshop-ecr-registry-helper
```
> yaml파일들이 있는 위치로 이동

< EC2 환경 - admin server - mgmt context(mc) >
```bash
kubectl apply -f .
```
> 현재 디렉토리 내 yaml파일 내 생성된 리소스들을 K8s Cluster로 적용하는 명령어

✔ **(수행 코드/결과 예시)**
```bash
cronjob.batch/ecr-registry-helper created
role.rbac.authorization.k8s.io/role-full-access-to-secrets created
rolebinding.rbac.authorization.k8s.io/default-role-binding created
secret/ecr-registry-helper-secrets created
configmap/ecr-registry-helper-cm created
serviceaccount/sa-ecr created
```
> 위 출력 예시와 같이 총 6개의 사항들이 created 된다.

추가로, 실제로 kubectl 명령어를 통해 cronjob이 잘 생성되었는지 확인해본다.

< EC2 환경 - admin server - mgmt context(mc) >
```bash
kubectl get cronjobs.batch -n jenkins
```
> jenkins Namespace 내 존재하는 cronjob을 조회하는 명령어이다.

✔ **(수행 코드/결과 예시)**
```bash
NAME                  SCHEDULE      SUSPEND   ACTIVE   LAST SCHEDULE   AGE
ecr-registry-helper   * */6 * * *   False     0        <none>          2s
```
> 위와 같이 ecr-registry-helper라는 이름의 cronjob이 생성되어있으며, 6시간마다 cronjob이 수행되어 ECR Token 만료(12시간) 전 갱신을 수행할 것이다.

<br>

---

🗎 참고. K8s Cronjob

(Cronjob 수행여부 확인)

수행 된 후 Cronjob을 조회해보면 `LAST SCHEDULE`이란 항목이 변화되는데, 이는 해당 Cronjob이 실제로 수행된 후 지난 시간을 의미한다.

< EC2 환경 - admin server - mgmt context(mc) >
```bash
kubectl get cronjobs.batch -n jenkins
```

✔ **(수행 코드/결과 예시)**
```bash
NAME                  SCHEDULE    SUSPEND   ACTIVE   LAST SCHEDULE   AGE
ecr-registry-helper   * */6 * * *   False     0        7s              26h
```
> 이와 같은 출력은 ecr-registry-helper Cronjob이 수행된지 7초 후라고 볼 수 있다.


<br>


(Cronjob 수행 후 Cronjob Pod 조회)

추가로 Pod도 조회를 해보면 `STATUS가 Completed 상태`의 Pod를 볼 수 있는데, 이는 Cronjob이 수행 완료된 상태의 Pod라고 볼 수 있다. 실제로 Running 상태가 아닌 실제 구동중이지 않은 상태의 Pod가 된다.

< EC2 환경 - admin server - mgmt context(mc) >
```bash
kubectl get pod -n jenkins
```

✔ **(수행 코드/결과 예시)**
```bash
NAME                                 READY   STATUS      RESTARTS   AGE
ecr-registry-helper-28385440-wv4vg   0/1     Completed   0          24s
jenkins-0                            2/2     Running     0          26h
```


[예시] < EC2 환경 - admin server - mgmt context(mc) >
```bash
kubectl logs -f ecr-registry-helper-28385440-wv4vg -n jenkins
```
> Complete 상태의 cronjob pod 로그를 조회해보는 예시 명령어이다.


✔ **(수행 코드/결과 예시)**
```bash
configmap "jenkinscred" deleted
configmap/jenkinscred created
secret "jenkinscred" deleted
secret/jenkinscred created
Configmap & Secret was successfully updated at Thu Dec 21 03:06:02 UTC 2023
```
> 필수과제에서 Linux Crontab으로 구성한 바와 같이 configmap 기존것을 삭제하고 새로운 configmap을 생성한다. 추가로, secret도 동일한 동작을 하도록 구성되어있다. Cronjob의 Pod에 생성시각을 표출하도록 date 항목도 추가되어있음을 볼 수 있다.

참고로, 만일 K8s Secret을 활용할 경우에는 각 파이프라인의 Jenkinsfile 소스의 spec.containers.env.valueFrom 의 **configMapKeyRef**을 **secretKeyRef**으로 변경이 필요하다.

---

<br>

**😃 완료!!!**

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
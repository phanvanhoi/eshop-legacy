## Service EKS Cluster - MGMT EKS Cluster 간 VPC Peering

<br>

### 주제: AWS VPC Peering

<br>

![](../media2/image102.png)

<br>

## 실습 목표
- AWS VPC간 Peering을 맺는 작업을 수행한다.
- Peering이 맺어진 2개의 VPC(MGMT, SERVICE) 간 VPC Internal 통신을 수행한다.
- Peering이 맺어진 2개의 VPC(MGMT, SERVICE) 간 통신을 위해서 부가적인 설정(Route Table, Security Group)을 이해한다.

<br>

본 실습은 서로 다른 VPC간 통신할 수 있는 개념인, VPC Peering에 대한 이해와 실습을 수행해보도록 한다.

> **※ 기본적으로 다른 VPC간 통신을 위해서는 CIDR Block이 겹치지 않아야 한다.**
> 
> **VPC Peering 연결은 비용이 들지 않으나, 통신에 대한 비용은 있다.**
>
> [**https://docs.aws.amazon.com/ko_kr/vpc/latest/peering/what-is-vpc-peering.html**](https://docs.aws.amazon.com/ko_kr/vpc/latest/peering/what-is-vpc-peering.html)

현재 MGMT VPC의 경우 10.0.0.0/16 대역을 사용하며 Service VPC의 경우 192.168.0.0/16 대역을 사용하므로 VPC 레벨에서 부터 CIDR 블럭이 충돌하지 않는다.

따라서, VPC Peering을 맺을 수 있는 조건이 충족되어있다 볼 수 있다.

우선 VPC Peering Connection 생성을 진행한다.

본 실습의 배경은, Service VPC의 특정 매니지먼트성 EC2 자원에서 MGMT VPC의 Private Subnet 내에 있는 리소스들에 자유롭게 접근 해야한다는 Needs가 발생됐다고 가정한다.

<br>

---

🗎 참고. 아래 1 ~ 7번 과정인 VPC Peering Connection 생성 및 확정의 경우 Terraform을 통해 수행되기 어렵다. 

(Peering Connection 자체는 Terraform으로 생성 가능하지만, 두 종류(MGMT, SERVICE)의 IaC가 별도로 관리되고 있기 때문에 각 IaC에서 다른 VPC를 인식할 수 없기 때문이다.)

따라서, AWS Console UI로 작업하는 것으로 진행한다.

---

<br>

**<span style="color:red">반드시 아래 각각의 과정에 작업 Region을 확인한다.</span>**


<br>

1. Peering Connection 생성

Requester가 Service VPC이므로, Region을 `Oregon(us-west-2)`로 변경한 후 

작업 Region: `Oregon(us-west-2)`

AWS > VPC > Peering connections 메뉴에 접속한다.

![](../media2/image103.png)

<br>

2. Requester: Service VPC <-> Accepter: MGMT VPC 로 Peering Connection을 생성한다.

작업 Region: `Oregon(us-west-2)`

우측 상단에 `Create peering connection`버튼을 클릭한 후 각 항목에 아래사항들을 입력한다.

Name: my-pc-test

Select a local VPC to peer with `VPC ID (Requester)`: Service EKS Cluster가 설치된 VPC 선택
(CIDR: 192.168.0.0/16)

Select another VPC to peer with `Account`: `My account` 라디오버튼 선택

Select another VPC to peer with `Region`: `Another Region` 라디오버튼 선택

  - N.Virginia(us-east-1) 선택
  - Select another VPC to peer with `VPC ID (Accepter)`: `Mgmt EKS Cluster가 설치된 VPC (CIDR: 10.0.0.0/16)의 ID 값`을 입력
    - Accepter VPC ID 확인법 1) 1일차 MGMT IaC 수행결과 Output 중 `mgmt_vpc_id`값을 활용
    - Accepter VPC ID 확인법 2) AWS Console UI에서 N.Virginia(us-east-1) 리젼의 `eshop-mgmt-terraform-vpc` VPC의 상세정보에서 ID를 확인할 수 있다.

<br>

※ Service EKS Cluster와 Mgmt EKS Cluster가 서로 다른 region에 설치된 경우 해당 Region을 선택해 주고 VPC ID는 AWS Console을 통해 별도 확인하여 copy & paste 해준다.

![](../media2/image104.png)

<br>

3. Create VPC Peering Connection을 누른다.

작업 Region: `Oregon(us-west-2)`

![](../media2/image105.png)

<br>

4. Peering Connection 생성 확인한다.

작업 Region: `Oregon(us-west-2)`

![](../media2/image106.png)


<br>

5. Request를 Accept한다.

작업 Region: `N.Virginia(us-east-1)`

AWS > VPC > Peering connections 메뉴에 접속한다.

접속 후 `Pending acceptance` 상태의 Peering Connection이 존재하는지 확인 후 Actions > Accept 과정을 수행한다.

![](../media2/image107.png)

<br>

6. Status Active 상태를 확인한다.

![](../media2/image108.png)

<br>

7. Service VPC에 테스트용 EC2 생성.

<br>

Step1) EC2 Key Pair 생성 

<br>

※ Service EKS Cluster와 Mgmt EKS Cluster가 서로 다른 region에 생성되어있고 앞서 us-east-1에 생성한 Key Pair는 us-west-2 region에는 공유가 안되므로 Service VPC가 있는 region(us-west-2)에 EC2 Key Pair를 신규 생성해 준다.

<br>

AWS Console > EC2 > Key Pairs > Create key pair 클릭

아래 사진과 같이 Type 및 Format을 지정하여 생성하면, 기본 다운로드 디렉토리에 .pem 확장자를 가진 Private Key가 다운로드 된다.

![](../media2/create_key_pair.png)

<br>

아래와 같은 스펙의 VPC간 통신 테스트용 EC2를 테라폼을 통해 생성할 것이다.

- Name Tag: service-vpc-pc-test
- Instance Type: t3.nano
- AMI: Canonical, Ubuntu, 20.04 LTS
- Key Pair: MyKeyPair 선택
- Network settings 
  - VPC: eshop-service-terraform-vpc
  - Subnet: eshop-service-terraform-public-subnet1
  - Auto-assign public IP: `Enable`
- Security group name: eshop_pctest_sg
  - Inbound Entry
    - Source type: My IP
    - Port range: 22
    - Description: my public ip

<br>

2일차 과정에서 개인화한 eshop-service-IaC Github Repository에 새로운 도전과제용 브랜치를 생성한다. (브랜치명: `feature-peering`)

<br>

---

🗎 참고. 레퍼런스 IaC 소스

<s3://t2hubintern/chal_peering_eshop-service-IaC.tar.gz>

---

<br>

< WSL 환경 >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```
> service IaC의 워크스페이스 디렉토리로 이동


< WSL 환경 >
```bash
git branch
```
> service IaC의 브랜치 리스트 확인


✔ **(수행 코드/결과 예시)**
```bash
ubuntu@SEAN-OFFICE-LAPTOP:~/t3-msp-pjt/eshop-service-IaC$ git branch
* main
```
> 보통은 main브랜치로 지정이 되어있을 것이다.

< WSL 환경 >
```bash
git checkout -b feature-peering
```
> 도전과제용 feature-peering 브랜치를 생성 및 이동한다.


✔ **(수행 코드/결과 예시)**
```bash
ubuntu@SEAN-OFFICE-LAPTOP:~/t3-msp-pjt/eshop-service-IaC$ git checkout -b feature-peering
Switched to a new branch 'feature-peering'
```
> feature-peering라는 새로운 브랜치가 생성되며, 해당 브랜치로 이동된다.


< WSL 환경 >
```bash
git branch
```
> 다시 service IaC의 브랜치 리스트 확인해본다.


```bash
ubuntu@SEAN-OFFICE-LAPTOP:~/t3-msp-pjt/eshop-service-IaC$ git branch
* feature-peering
  main
```
> 현 시점에서는 feature-peering라는 브랜치로 지정이 되어있다.


`feature-peering` 브랜치 생성이 완료되었다면, 해당 브랜치에 본 도전과제에 필요한 eshop-service-IaC의 소스코드를 push한다.


< WSL 환경 >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```

< WSL 환경 >
```bash
rm -rf *
```
> feature-peering 브랜치에 새로운 IaC 소스를 반영하기 위해 기존 main브랜치 기준 소스들을 제거한다.

< WSL 환경 >
```bash
cd ~/t3-msp-pjt
```
> 다시 상위 디렉토리로 S3에서 레퍼런스 소스를 다운로드할 위치로 이동한다.

<br>

---

[🗎 참고. 유지되는 디렉토리 및 파일]
```
.git
.gitignore
.terraform
.terraform.lock.hcl
```

---

<br>

< WSL 환경 >
```bash
rm -rf .terraform
rm -rf .terraform.lock.hcl
```
> 추가로 테라폼 관련 워크스페이스 모듈들도 모두 삭제한다.


< WSL 환경 >
```bash
aws s3 cp s3://t2hubintern/chal_peering_eshop-service-IaC.tar.gz .
```
> chal_peering_eshop-service-IaC.tar.gz 이름의 본 도전과제에 필요한 service IaC 소스를 다운로드한다.

< WSL 환경 >
```bash
tar xvfz chal_peering_eshop-service-IaC.tar.gz
```
> chal_peering_eshop-service-IaC.tar.gz 이름의 본 도전과제에 필요한 service IaC 소스를 압축해제한다. 압축을 해제하면 eshop-service-IaC 디렉토리 하위에 자동적으로 소스들이 옮겨진다.

< WSL 환경 >
```bash
cd ~/t3-msp-pjt/eshop-service-IaC
```

< WSL 환경 >
```bash
git add .; git commit -m "add feature-peering"; git push origin feature-peering
```
> feature-peering 브랜치에 새로운 소스 내용을 반영(Push)한다.

---

🗎 참고. 본 도전과제의 IaC 수행은 WSL 로컬에서 수행하도록 한다. main 브랜치에 Pull Request 및 Merge하여 Jenkins IaC 파이프라인을 활용할 수도 있지만 향후 실습과정 상 혼란이 없게하기위해 main브랜치를 유지하고 별도 브랜치를 활용한 로컬 테라폼 수행을 권장한다.

---


< WSL 환경 >
```bash
terraform init
```
> Amazon MQ 모듈들이 로드되어야하므로 init을 수행해준다.

< WSL 환경 >
```bash
terraform plan
```

✔ **(수행 코드/결과 예시)**
```
Plan: 4 to add, 0 to change, 0 to destroy.
```
> 도전과제 수행여부에 따라 다르지만 보통 4일차 필수과제만 수행한 상태라면 위와 같이 4개 리소스 추가 Plan이 수행될 것이다. 
> 
> + resource "aws_mq_broker" "service" 관련 1개의 리소스 추가 Plan이 표출될 것이다.

< WSL 환경 >
```bash
terraform apply -auto-approve
```
> 테라폼을 수행시킨다.


✔ **(수행 코드/결과 예시)**
```bash
Apply complete! Resources: 4 added, 0 changed, 0 destroyed.

Outputs:

eip_allocation_id = <<EOT
eipalloc-0ce61725de01f6470,eipalloc-076f0e93374ec9634

EOT
my_ip = "221.167.219.186"
pctest_server_public_ip = "54.70.42.62"
```
> 테라폼이 수행이 완료되었다면 위와 같은 output이 표출될 것이다.

terraform apply까지 수행되었다면, 테스트에 필요한 EC2 및 관련 Security Group 세팅이 완료되었다. Mobaxterm을 통해 해당 EC2로 접근할 수 있으며, 접근 후 다음 과정을 진행하도록 한다.

---

[🗎 참고. output 중 메모할 사항]
- my_ip
  - 개인 WSL 환경의 Public IP 값
- pctest_server_public_ip
  - Peering 후 통신테스트 용도 EC2의 Public IP 값(Mobaxterm 세팅 시 사용)

---

<br>

8.  Target Server인 MGMT VPC내에 존재하는 admin server의 security group에 아래와 같은 Inbound Entry가 추가된 상태인지 확인한다.

1일차 mgmt IaC를 수행 시 admin server의 Security Group 내 eshop-service-terraform-public-subnet1 Subnet의 CIDR 대역인 `192.168.0.0/24` 블럭의 ssh 포트dml Inbound가 오픈처리 되었다.

**<span style="color:red">기 오픈여부를 확인만 한다.</span>**

Region: us-east-1

Security Group Name: eshop_mgmt_admin_sg
```
Type: Inbound
Source: 192.168.0.0/24
Port range: 22
Description: from service cluster subnet
```

<br>


---

🗎 참고. 아래 9 ~ 10번 과정의 경우 1 ~ 6번 과정과 마찬가지로, AWS Console UI작업으로만 가능한 상황이다.

따라서, AWS Console UI로 작업하는 것으로 진행한다.

---

<br>

9. 추가로, Service VPC의 Public Route Table (eshop-service-terraform-public-route)의 설정을 추가한다.

작업 Region: `Oregon(us-west-2)`

Routes 탭에 들어가서 아래 엔트리를 추가한다.
```
Destination: 10.0.0.0/16
Target: Peering Connection(my-pc-test) 선택 => pcx-******
```

추가 후 Status가 Active인지 확인

<br>

10. 추가로, MGMT VPC의 Private Route Table(eshop-mgmt-terraform-private-route)의 설정을 추가한다. 

작업 Region: `N.Virginia(us-east-1)`

Routes 탭에 들어가서 아래 엔트리를 추가한다.
```
Destination: 192.168.0.0/16
Target: Peering Connection(my-pc-test) 선택 => pcx-******
```

추가 후 Status가 Active인지 확인

<br>

---

🗎 참고. 아래 12번 과정부터는 VPC간 Peering 세팅이 완료된 후 실제 통신테스트를 수행하는 과정이다.

---

<br>

11.  상기 과정이 모두 완료됐다면 EC2(service-vpc-pc-test)에 접속하여 telnet 테스트를 해본다.(예시)

작업 Region: `Oregon(us-west-2)`
테스트 환경: EC2(service-vpc-pc-test)

명령어는 아래와 같이, MGMT VPC 내 존재하는 EC2 Private IP 

```
telnet << Admin Server의 Private IP >> 22
```

✔ **(수행 코드/결과 예시)**
```bash
ubuntu@ip-192-168-0-133:~$ telnet 10.0.10.201 22
Trying 10.0.10.201...
Connected to 10.0.10.201.
Escape character is '^]'.
SSH-2.0-OpenSSH_8.2p1 Ubuntu-4ubuntu0.9
```
> 위와 같이 Connected to 문구가 보이며 Telnet 연결이 되었으면 두 VPC간 내부통신이 잘 된다고 볼 수 있다. 범 VPC간 Private IP로 통신이 되는 상황이라 볼 수 있다.
> 
> 아래와 같은 흐름이다.
>
> Telnet Client(VPC 내부통신): EC2(service-vpc-pc-test) -> Telnet Server: EC2(eshop-admin)

<br>

12.  VPC간 Peering으로 통신 확인을 하였으면, 상기 과정에서 생성했던 Route Table의 엔트리들을 지운다. 

작업 Region: `N.Virginia(us-east-1)`

작업대상
- Route Table : eshop-mgmt-terraform-private-route
- 하기 엔트리 삭제
```
Destination: 192.168.0.0/16
Target: Peering Connection(my-pc-test) 선택 => pcx-******
```

작업 Region: `Oregon(us-west-2)`

작업대상
- Route Table : eshop-service-terraform-public-route
- 하기 엔트리 삭제
```
Destination: 10.0.0.0/16
Target: Peering Connection(my-pc-test) 선택 => pcx-******
```

<br>

13. 테스트 용도로 생성했던 EC2 및 EC2 Key Pair 등의 자원을 정리한다.
    
이어서, 7번 과정에서 테라폼을 통해 생성한 EC2 항목도 삭제를 하도록 한다. 
    
eshop-service-IaC의 `feature-peering` branch에서 다시 `main`브랜치로 변경 후 terraform apply를 수행하면 EC2가 삭제될 것이다. main브랜치 Jenkins IaC Pipeline으로 terraform을 수행하여도 되고, WSL상에서 terraform을 수행하여도 된다. 앞선 7번 과정에서 추가된 Peering 통신 테스트용도 4개의 EC2 및 Security Group 등의 자원들이 삭제될 것이다.

※ 앞서 생성한 us-west-2 Oregon region의 EC2 Key Pair인 `MyKeyPair` 도 삭제해 준다.

<br>

14.   최종적으로 VPC Peering Connection(`my-pc-test`)을 삭제한다.

작업 Region: `Oregon(us-west-2)`

<br>
<br>

## Evaluation
---
- VPC 간 Peering으로 통신을 위해서는 어떤 세팅들이 이루어지는지 실습한다.
- VPC 간 Peering시 범 VPC간의 통신이 Private하게 이루어짐을 확인한다.
---

<br>

😃 **참고자료 끝**

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
# Argocd app 강제 삭제

<br>

## Argocd

- Argocd 상 app 삭제를 시도했을 시 삭제가 정상적으로 되지 않는 경우가 있다.(ex. app이 설치되어있던 eks cluster가 destroy 됐을 시)

<br>

---

🗎 참고. `app`은 argocd 설치 후 생성된 CR(Custom Resource)이다.

---

<br>
<br>

Step 1) app 내 finalizers 메타정보를 주입한다.(Patch)

<br>

< EC2 환경 - admin server >
```bash
kubectl config use-context mgmt
```
> mgmt eks cluster(context)로 스위치

<br>

< EC2 환경 - admin server - mgmt context(mc) >
```bash
kubectl patch app << 행걸린 앱 이름 >> --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' -n argocd
```
> finalizers 메타정보를 주입한다.(Patch)
>
> << 행걸린 앱 이름 >> : 삭제되지 않는 앱의 이름으로 치환한다.

<br>
<br>

Step 2) 보통 finalizers를 주입하면 삭제작업이 걸려있던 경우 삭제가 되나, 삭제가 되지 않는다면 아래 delete 명령어를 호출한다.

<br>

< EC2 환경 - admin server - mgmt context(mc) >
```bash
kubectl delete app << 행걸린 앱 이름 >> -n argocd
```
> << 행걸린 앱 이름 >> : 삭제되지 않는 앱의 이름으로 치환한다.

<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
# Putty를 활용한 SSH Tunneling 방법

<br>

**ppk키변경**

<https://docs.aws.amazon.com/ko_kr/AWSEC2/latest/UserGuide/putty.html#putty-private-key>

<https://aws.amazon.com/ko/premiumsupport/knowledge-center/ec2-ppk-pem-conversion/>

**putty 다운로드(msi를 다운로드 및 설치하면 puttygen도 포함되어있다.)**

<https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html>

**putty 세팅**

Putty를 실행시켜 Session항목에 본인의 Bastion Server의 Public IP를 넣는다. 이후 Connection > SSH > Auth창을 열어 앞서 변환한 ppk키의 경로를 지정해준다.

![](../media2/image69.png)

그리고나서 Connection > Data 항목에 Auto-login-username을 "ubuntu"로 지정해준다.

![](../media2/image70.png)

다음은 Window 항목에서 Line 버퍼수를 50000정도까지 늘려준다.

반드시 할 필요는 없다.

![](../media2/image71.png)

다음은 Connection > SSH > Tunnels 항목으로 들어가 Local Port:13100 => remote:3100 터널링 규칙을 추가해준다.

이때 remote IP주소는 admin server의 private ip 주소가 된다.

![](../media2/image72.png)

최종적으로, 세팅이 완료된 후 Session항목에서 bastion이란 세션 이름을 Save해준다.

![](../media2/image73.png)

다음은 세션을 더블클릭하여 다음과 같은 화면으로 접속한다.

![](../media2/image74.png)

이로써 argo rollout dashboard에 접근하기 위한 사전준비를 마쳤다.


<br>

---

<br>
<br>
<br>

# <center> <a href="../README.md">[목록]</a> </center>
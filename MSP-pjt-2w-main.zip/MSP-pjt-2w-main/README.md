# T3 MSP Project 2nd Week Contents
- [T3 MSP Project 2nd Week Contents](#t3-msp-project-2nd-week-contents)
   - [Education Goals](#Education-Goals)
   - [Cautions](#Cautions)
     - [Overview](#overview)
     - [Troubleshooting case in practice environment] (#Practice environment-Troubleshooting-Case)
     - [Organize resources after completing practice] (#Organize resources after completing practice)
   - [Curriculum](#Curriculum)
   - [Challenge](#Challenge)
   - [Reference](#Reference)

----

<br>

## Educational Goals

- This is the process of solving given tasks by using the knowledge acquired during the development and construction of Cloud Native APP, performing application MSP and experiencing service operation based on the image.
- Understand the concept of IaC using Terraform and experience practical operation.
- Build a CI/CD environment and learn how to apply Github/Jenkins/Argocd.
- Build a Jenkins pipeline to perform CI.
- Service distribution method and method through Argocd GitOps operation to perform CD
   Gain indirect practical experience by utilizing various AWS services.

<br>

## caution

- The **screen capture** and **execution code/result example** sections in the textbook are samples.
   The screen may change during each person's practice, and different results may be displayed for each individual.
   **If you find it difficult to judge on your own, please actively search and ask your instructor**.

- During the practice process, **save the items you note down by date as one file**, and **parts variable for each content (<< variable >>) must be replaced with personal values** before performing the practice. ,
   Please be careful not to include other content.
  
----

<br>
<br>

### Overview
<li><a href="./docs/2w-0-Overview.md"> Week 2 GitOps & Outer Architecture Overview </a></li>

<br>
<br>

### Troubleshooting cases in practice environment
<li><a href="./etc/2w-reference-0-trouble_shootings.md"> 2nd week practice environment troubleshooting </a></li>

<br>
<br>

### Organizing resources after completing practice
<li><a href="./etc/2w-reference-5-cleanup.md">Resource Cleanup</a></li>

<br>
<br>

## curriculum
<table>
<thead>
   <tr>
     <th>Primary</th>
     <th>Separation</th>
     <th>Topic</th>
     <th style="min-width: 120px;">Textbook</th>
     <th>Learning objectives</th>
     <th>Related technologies</th>
   </tr>
</thead>
<tbody>

   <!-- Day 1 -->
   <tr>
     <td rowspan="1"><center>1</td>
     <td>Practice</td>
     <td>
       <li> Provisioning Management Environment by IaC </li>
       <li> Configure eshop CI/CD Pipeline </li>
     </td>
     <td>
       <li><a href="./docs/2w-1-Management_Configure.md"> Day 1 textbook </a></li>
     </td>
     <td>
       <ul>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Runs IaC to create a VPC for management purposes. (Terraform)</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Install CI/CD tools required for management (Jenkins, Argocd)</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Build a CI Pipeline using Jenkins.</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Build images of Micro Services in the Management VPC environment and push them to ECR.</li>
       </ul>
     </td>
     <td>
         <li> AWS ECR, Terraform, Jenkins, Argocd, Groovy Script, Jib, Kaniko, Slack, Ingress Nginx</li>
     </td>
   </tr>
    
   <!-- Day 2 -->
   <tr>
     <td rowspan="1"><center>2</td>
     <td>Practice</td>
     <td>
         <li> Provisioning Service Environment by IaC Pipeline </li>
         <li> Apply service mesh on eshop </li>
         <li> Configure eshop-PaC Repository(Helm Chart PaC) </li>
     </td>
     <td>
       <li><a href="./docs/2w-2-Production_Configure.md"> Day 2 textbook </a></li>
     </td>
     <td>
       <ul>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Build a VPC for service through IaC and use S3 as a backend for Terraform.</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Create an IaC Pipeline to manage infrastructure for services.</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Apply the Istio Service Mesh implementation to the eshop service and check how the Side Car Pattern is applied.</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Convert eshop service to Helm Chart format.</li>
       </ul>
     </td>
     <td>
         <li> IaC Pipeline, Service Mesh, Istio, Side Car Pattern, Istio Traffic Management, Helm Chart</li>
     </td>
   </tr><!-- Day 3 -->
   <tr>
     <td rowspan="1"><center>3</td>
     <td>Practice</td>
     <td>
       <li> Configure Observability OSS on Service Environment </li>
       <li> Configure AWS CloudWatch Container Insights </li>
     </td>
     <td>
       <li><a href="./docs/2w-3-Observability_Configure.md"> Day 3 textbook </a></li>
     </td>
     <td>
       <ul>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Install and configure monitoring OSS using Helm Chart.</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">When expanding OSS, insufficient infrastructure resources are checked and continuously maintained through Service IaC Pipeline.</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Install and examine Observability OSS that is mainly used when operating Cloud Native services.</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Try using commercial monitoring services AWS CloudWatch and Container Insights. In relation to this, we will utilize the AWS SNS service to set an operational alarm and conduct a reception test.</li>
       </ul>
     </td>
     <td>
       <li> metrics server, Observability, Prometheus, Grafana, Jaeger, Kiali, Istio Authz, AWS CloudWatch Container Insight, AWS SNS</li>
     </td>
   </tr>

   <!-- Day 4 -->
   <tr>
     <td rowspan="1"><center>4</td>
     <td>Practice</td>
     <td>
       <li> Configure Open Tracing on Service Applications </li>
       <li> Zero-downtime Application Deployment on Service Environment </li>
     </td>
     <td>
       <li><a href="./docs/2w-4-Zerodowntime_Deployment.md"> Day 4 textbook </a></li>
     </td>
     <td>
       <ul>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Experience application distributed tracing (open tracing) monitoring through Kiali and Jaeger.</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Understand and actually implement the canary and blue/green methods of service non-interruption among K8s deployment strategies.</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Experience deploying eshop on a Serverless container service using AWS Fargate EKS service.</li>
       </ul>
     </td>
     <td>
       <li> Istio Traffic Management, Argo Rollout, Open Tracing, SSH Tunneling, Canary, Blue/Green, AWS EKS Fargate, AWS ALB Ingress, AWS ACM, TLS</li>
     </td>
   </tr>

   <!-- Day 5 -->

   <!--

   '24 course 2nd week reorganized from 5 to 4 days

   <tr>
     <td rowspan="1"><center>5</td>
     <td>Practice</td>
     <td>
       <li> Handling failure on Service Environment </li>
       <li> Protect cascading failure on Service Environment </li>
       <li> Istio Circuit Breaking </li>
       <li> Introduce AWS Athena & VPC Peering </li>
     </td>
     <td>
       <li><a href="./docs/2w-5-Failurehandling_AWSservices.md"> Day 5 textbook </a></li>
     </td>
     <td>
       <ul>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">In terms of preventing the spread of failures, Istio's Circuit Breaking function is used to isolate service delays and abnormally operating microservices.< /li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Experience the extraction and analysis of abnormal logs from NLB Access Log using AWS Athena service.</li>
         <li style="margin:0cm;font-size:16px;font-family:Gulim;">Practice peering between AWS VPCs.</li>
       </ul>
     </td>
     <td>
       <li> Istio Circuit Breaking, AWS Athena, AWS VPC Network ACL, Abuse IP DB, AWS VPC Peering, Secure Copy (SCP)</li>
     </td>
   </tr>

   -->
</tbody>
</table>

<br>
<br>

## Challenges

<table>
<thead>
   <tr>
     <th style="min-width: 40px;">Primary</th>
     <th style="min-width: 190px;">Textbook</th>
     <th>Learning objectives</th>
   </tr>
</thead>

<tbody>

   <!-- Day 1 of the challenge -->
   <tr>
     <td rowspan="4"><center>1</td>
     <td>
       <a href="./docs/2w-challenge-1-1.md">2w-challenge-1-1.md</a>
     </td>
     <td>
       <li>Test deployment in MGMT environment</li>
     </td>
   </tr>
   <tr>
     <td>
       <a href="./docs/2w-challenge-1-2.md">2w-challenge-1-2.md</a>
     </td>
     <td>
       <li>Apply secret to ECR authentication token instead of configmap and pass data to Jenkins build container</li>
       <li>Try Base64 Decoding the value of the K8s Secret object</li>
     </td>
   </tr>
  <tr>
     <td>
       <a href="./docs/2w-challenge-1-3.md">2w-challenge-1-3.md</a>
     </td>
     <td>
       <li>Repo separation for each microservice and integration with Blue Ocean CI Pipeline (part that automates CI Pipeline Trigger)</li>
     </td>
   </tr>
   <tr>
     <td>
       <a href="./docs/2w-challenge-1-4.md">2w-challenge-1-4.md</a>
     </td>
     <td>
       <li>Link Jenkins CI Pipeline and Slack Notification</li>
     </td>
   </tr>

   <!-- Day 2 of the challenge -->
   <tr>
     <td rowspan="4"><center>2</td>
     <td>
       <a href="./docs/2w-challenge-2-1.md">2w-challenge-2-1.md</a>
     </td>
     <td>
       <li>Apply Slack Noti function to Jenkins IaC Pipeline</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-2-2.md">2w-challenge-2-2.md</a>
     </td>
     <td>
       <li>Deploy eshop application test via argocd on eshop-service-eks-cluster (eshop-MSA configuration)</li>
     </td>
   </tr>
  
   <tr>
     <td>
       <a href="./docs/2w-challenge-2-3.md">2w-challenge-2-3.md</a>
     </td>
     <td>
       <li>Configure eshop PaC Helm Chart directly through Helm command</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-2-4.md">2w-challenge-2-4.md</a>
     </td>
     <td>
       <li>Download (Helm Pull) Observability-related OSS in Helm Chart format</li>
     </td>
   </tr>
  
   <!-- Day 3 of the challenge -->

   <tr>
     <td rowspan="5"><center>3</td>
     <td>
       <a href="./docs/2w-challenge-3-1.md">2w-challenge-3-1.md</a>
     </td>
     <td>
       <li>Application of OSS monitoring tool authentication and authorization strengthening (Istio + Keycloak + Oauth2-proxy)</li>
       <li>Istio Service Mesh istio-discovery - override exntensionProviders</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-3-2.md">2w-challenge-3-2.md</a>
     </td>
     <td>
       <li>Increasing/decreasing the eshop app running in the Service EKS Cluster with replicaset HPA</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-3-3.md">2w-challenge-3-3.md</a>
     </td>
     <td>
       <li>Applying AWS CloudWatch Container Insights to Service EKS Cluster</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-3-4.md">2w-challenge-3-4.md</a>
     </td>
     <td>
       <li>Minor upgrade of RabbitMQ version and establishment of management UI monitoring environment</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-3-5.md">2w-challenge-3-5.md</a>
     </td>
     <td>
       <li>Asynchronous processing using rabbitMQ broker among AWS AmazonMQ services</li>
     </td>
   </tr>

   <!-- Day 4 of the challenge -->

   <tr>
     <td rowspan="6"><center>4</td>
     <td>
       <a href="./docs/2w-challenge-4-1.md">2w-challenge-4-1.md</a>
     </td>
     <td>
       <li>Applying distributed tracking to NodeJS-based Express App</li>
       <li> - currency service, product service </li>
       <li>Applying distributed tracking to Python-based Flask App</li>
       <li>-recommendservice </li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-4-2.md">2w-challenge-4-2.md</a>
     </td>
     <td>
       <li>Apply distributed tracking RabbitMQ asynchronous section tracking</li>
       <li>backend(Spring Boot), cartservice(Spring Boot), rabbitmq section </li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-4-3.md">2w-challenge-4-3.md</a>
     </td>
     <td>
       <li>Install Argo rollout</li>
       <li>Blue/Green Deployment</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-4-4.md">2w-challenge-4-4.md</a>
     </td>
     <td>
       <li>Install Argo rollout</li>
       <li>Canary deployment</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-4-5.md">2w-challenge-4-5.md</a>
     </td>
     <td>
       <li>AWS Fargate EKS Service</li>
       <li>Deploying eshop on a Serverless container service</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-4-6.md">2w-challenge-4-6.md</a>
     </td>
     <td>
       <li>Operation development stage</li>
       <li>Microservice development of new features</li>
       <li>Microservice deployment of new features</li>
     </td>
   </tr>

   <!-- Day 5 of the challenge -->
   <!--

   '24 course 2nd week reorganized from 5 to 4 days

   <tr>
     <td rowspan="2"><center>5</td>
     <td>
       <a href="./docs/2w-challenge-5-1.md">2w-challenge-5-1.md</a>
     </td>
     <td>
       <li>Analyzing ELB Access Log stored in AWS S3 using AWS Athena service</li>
       <li>Block specific IP boundaries within the VPC using AWS VPC Network ACL</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./docs/2w-challenge-5-2.md">2w-challenge-5-2.md</a>
     </td>
     <td>
       <li>Perform peering between AWS VPCs</li>
     </td>
   </tr>
   -->

</tbody>
</table>

<br>
<br>

## reference

<table>
<thead>
   <tr>
     <th style="min-width: 40px;">Related Dates</th>
     <th style="min-width: 190px;">Textbook</th>
     <th>Content</th>
   </tr>
</thead>
<tbody>
   <!-- All notes -->

   <!-- Troubleshooting -->
  <tr>
     <td rowspan="6"><center>-</td>
     <td>
       <a href="./etc/2w-reference-0-trouble_shootings.md">Reference. Major Troubleshooting Cases</a>
     </td>
     <td>
       <li>Collection of troubleshooting cases that occur during practice</li>
     </td>
   </tr>
  
   <tr>
     <td>
       <a href="./etc/2w-reference-0-pod_describe_logs.md">Reference. Check the description and log of eshop MicroService or Backing Service </a>
     </td>
     <td>
       <li>Process of examining Pods in Degraded and back off states when deploying eshop Helm Chart to argocd </li>
       <li>Process of checking and taking action on the cause of Pod problems through Describe or Log </li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./etc/2w-reference-0-argocd_force_delete.md">Reference. Forced delete when argocd app delete hangs </a>
     </td>
     <td>
       <li>How to delete argocd app when deletion does not work properly </li>
     </td>
   </tr>

   <!-- Previous day 5 -->
   <tr>
     <td>
       See <a href="./etc/2w-reference-0-failurehandling_awsservices.md">. Failure response using Istio </a>
     </td>
     <td>
       In terms of preventing the spread of failures, Istio's Circuit Breaking function is used to isolate service delays and abnormally operating microservices. <br><br>
       <li> Istio Circuit Breaking </li>
       <li> Handling failure on Service Environment </li>
       <li> Protect cascading failure on Service Environment </li>
     </td>
   </tr>


   <!-- Existing 5th day challenge -->

   <tr>
     <td>
       <a href="./etc/2w-reference-0-lb_accesslog_analysis.md">Reference. LB Access Log Analysis</a>
     </td>
     <td>
       <li>Analyzing ELB Access Log stored in AWS S3 using AWS Athena service</li>
       <li>Block specific IP boundaries within the VPC using AWS VPC Network ACL</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./etc/2w-reference-0-vpc_peering.md">Reference. AWS VPC Peering</a>
     </td>
     <td>
       <li>Perform peering between AWS VPCs</li>
     </td>
   </tr>


   <!-- Reference Day 1 -->

   <tr>
     <td rowspan="2"><center>1</td>
     <td>
       <a href="./etc/2w-reference-1-jenkinsfile_cat.md">Reference. Meaning of cat in Jenkinsfile</a>
     </td>
     <td>
       <li>Description of the role of cat in Jenkinsfile (gradle, kaniko, terraform)</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./etc/2w-reference-1-ecr_token_cronjob.md">Reference. ECR Token renewal using K8s Cronjob</a>
     </td>
     <td>
       <li>Introduction to ECR Token renewal method using K8s Cronjob</li>
     </td>
   </tr>

   <!-- Reference Day 2 -->
   <tr>
     <td rowspan="1"><center>2</td>
     <td>
       <a href="./etc/2w-reference-2-mongodb_sts_pvc_deploy.md">Reference. Declare and deploy PVC in MongoDB statefulset Workload</a>
     </td>
     <td>
       <li>Performing MongoDB PVC declaration deployment on Cloud using AWS EBS</li>
     </td>
   </tr>

   <!-- Reference Day 3 -->
   <tr>
     <td rowspan="3"><center>3</td>
     <td>
       <a href="./etc/2w-reference-3-helm_var_overriding.md">Reference. Helm Chart Variable Override </a>
     </td>
     <td>
       <li>Overriding variables for each environment to template Helm Chart</li>
       <li>Revisit the emarket Helm Chart</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./etc/2w-reference-3-grafana_dashboard.md">Reference. Add Grafana Dashboard</a>
     </td>
     <td>
       <li>Add Custom Dashboard in Grafana OSS tool</li>
     </td>
   </tr>

   <tr>
     <td>
       <a href="./etc/2w-reference-3-datadog.md">Reference. Datadog integration</a>
     </td>
     <td>
       <li>Try Datadog, a commercial monitoring solution</li>
     </td>
   </tr>
  
   <!-- Reference Day 4 -->
   <!-- putty -->
   <tr>
     <td rowspan="2"><center>4</td>
     <td>
       <a href="./etc/2w-reference-4-putty.md">Reference. SSH Tunneling Method Using Putty</a>
     </td>
     <td>
       <li>How to access Argo rollout Dashboard UI</li>
       <li>Introduction to SSH Tunneling method using Putty tool</li>
     </td>
   </tr>

   <!-- fargate -->
   <tr>
     <td>
       <a href="./etc/2w-reference-4-fargate.yaml">Reference. eshop fargate distribution NodePort</a>
       <br>
       <a href="./etc/2w-reference-4-fargate-clusterip.yaml">Reference. eshop fargate deployment ClusterIP</a>
     </td>
     <td>
       <li>Deploy eshop in a serverless environment</li>
       <li>Use AWS EKS Fargate services</li>
       <li>Use AWS ALB Ingress Controller</li>
     </td>
   </tr>
 
   <!-- Reference Day 5 -->
   <!-- Delete resource -->
   <!--

   '24 course 2nd week reorganized from 5 to 4 days
   <tr>
     <td rowspan="1"><center>5</td>
     <td>
       <a href="./etc/2w-reference-5-cleanup.md">Reference. Resource organizing</a>
     </td>
     <td>
       <li>Delete MGMT EKS cluster</li>
       <li>Delete SERVICE EKS cluster</li>
       <li>Delete other resources such as S3, ECR, EC2 Keypair, etc.</li>
     </td>
   </tr>

   -->
</tbody>
</table>